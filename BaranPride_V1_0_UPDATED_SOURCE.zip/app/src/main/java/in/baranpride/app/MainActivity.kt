package `in`.baranpride.app

import android.app.Activity
import android.speech.tts.TextToSpeech
import android.media.MediaPlayer
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import android.content.Intent
import android.content.ClipData
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import android.widget.Toast
import android.widget.FrameLayout
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader

/** Native Android shell: all end-user UI is bundled inside the APK, never hosted as a public website. */
class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    // Public business photos only. Never persist private or authenticated resources.
    private val businessImageCache by lazy { File(cacheDir, "bp_business_images_v1").apply { mkdirs() } }
    private val maxBusinessImageBytes = 5 * 1024 * 1024
    private val maxBusinessCacheBytes = 60L * 1024 * 1024
    private val businessImageTtlMs = 24L * 60 * 60 * 1000

    private fun cachedBusinessImage(uri: Uri): WebResourceResponse? {
        val host = uri.host?.lowercase(Locale.ROOT) ?: return null
        if (uri.scheme != "https" || host !in setOf("firebasestorage.googleapis.com", "storage.googleapis.com")) return null
        // Firebase download URLs contain URL-encoded object paths; only cache business images.
        val path = (uri.encodedPath ?: "").lowercase(Locale.ROOT)
        if (!(path.contains("businesses%2f") || path.contains("/businesses/"))) return null
        val rawUrl = uri.toString()
        val digest = MessageDigest.getInstance("SHA-256").digest(rawUrl.toByteArray())
            .joinToString("") { "%02x".format(it) }
        val file = File(businessImageCache, "$digest.img")
        val typeFile = File(businessImageCache, "$digest.type")
        fun fromDisk(): WebResourceResponse? = try {
            if (!file.isFile || !typeFile.isFile || file.length() !in 1..maxBusinessImageBytes.toLong()) null
            else {
                val mime = typeFile.readText().trim()
                if (mime !in setOf("image/jpeg", "image/png", "image/webp", "image/gif")) null
                else WebResourceResponse(mime, null, file.inputStream())
            }
        } catch (_: Exception) { null }
        if (file.exists() && System.currentTimeMillis() - file.lastModified() < businessImageTtlMs) {
            fromDisk()?.let { return it }
        }
        var connection: HttpURLConnection? = null
        try {
            connection = URL(rawUrl).openConnection() as HttpURLConnection
            connection.connectTimeout = 2500
            connection.readTimeout = 4000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Accept", "image/avif,image/webp,image/png,image/jpeg,image/gif,*/*")
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return fromDisk()
            val mime = connection.contentType?.substringBefore(';')?.trim()?.lowercase(Locale.ROOT) ?: ""
            if (mime !in setOf("image/jpeg", "image/png", "image/webp", "image/gif")) return fromDisk()
            if (connection.contentLengthLong > maxBusinessImageBytes) return fromDisk()
            val bytes = connection.inputStream.use { stream ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (true) {
                    val n = stream.read(buffer)
                    if (n < 0) break
                    if (output.size() + n > maxBusinessImageBytes) return fromDisk()
                    output.write(buffer, 0, n)
                }
                output.toByteArray()
            }
            if (bytes.isEmpty()) return fromDisk()
            // Atomic replacement prevents an interrupted download from corrupting last-good cache.
            try {
                val tmp = File(businessImageCache, "$digest.tmp")
                tmp.writeBytes(bytes)
                if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
                typeFile.writeText(mime)
                file.setLastModified(System.currentTimeMillis())
                pruneBusinessImageCache()
            } catch (_: Exception) { /* Image still displays even if storage is full. */ }
            return WebResourceResponse(mime, null, ByteArrayInputStream(bytes))
        } catch (_: Exception) {
            return fromDisk() // Offline: retain images even after TTL.
        } finally { connection?.disconnect() }
    }

    private fun pruneBusinessImageCache() {
        try {
            val images = businessImageCache.listFiles { f -> f.extension == "img" }
                ?.sortedBy { it.lastModified() } ?: return
            var total = images.sumOf { it.length() }
            for (img in images) {
                if (total <= maxBusinessCacheBytes) break
                total -= img.length()
                File(businessImageCache, img.nameWithoutExtension + ".type").delete()
                img.delete()
            }
        } catch (_: Exception) { }
    }
    private var welcomeTts: TextToSpeech? = null
    private var welcomePlayer: MediaPlayer? = null
    private var ttsReady = false
    private var pendingWelcome: Triple<String, String, String>? = null
    private var pendingWelcomeKey: String? = null
    private var pendingWelcomeDay: String? = null
    private var pendingWelcomeMessage: String? = null
    private var pendingWelcomeLanguage: String? = null
    private var pendingWelcomeFrequency: String? = null
    private var pendingWelcomeActive = false
    private var pendingFileChooser: ValueCallback<Array<Uri>>? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = pendingFileChooser ?: return@registerForActivityResult
        val uris: Array<Uri>? = if (result.resultCode == Activity.RESULT_OK) {
            val intent = result.data
            val chosen = mutableListOf<Uri>()
            intent?.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i).uri?.let { chosen.add(it) }
                }
            }
            intent?.data?.let { if (!chosen.contains(it)) chosen.add(it) }
            if (chosen.isEmpty()) {
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, intent)
            } else chosen.distinct().toTypedArray()
        } else null
        callback.onReceiveValue(uris)
        pendingFileChooser = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        welcomeTts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) runOnUiThread { pendingWelcome?.let { (message, language, frequency) ->
                pendingWelcome = null
                speakWelcome(message, language, frequency)
            } }
        }
        // Android 15+ lays edge-to-edge by default. Reserve real space for
        // status/navigation bars so the HTML header and fixed bottom tabs never overlap.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.rgb(244, 248, 254)
        window.navigationBarColor = android.graphics.Color.WHITE
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(244, 248, 254))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true // Required for content:// photo URIs returned by Android picker
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.mediaPlaybackRequiresUserGesture = true
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)
                        ?: cachedBusinessImage(request.url)

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (request.url.host == "appassets.androidplatform.net") return false
                    openAllowedUrl(request.url.toString())
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView,
                    filePathCallback: ValueCallback<Array<Uri>>,
                    fileChooserParams: FileChooserParams
                ): Boolean {
                    pendingFileChooser?.onReceiveValue(null)
                    pendingFileChooser = filePathCallback
                    try {
                        // ACTION_OPEN_DOCUMENT reliably returns readable content:// URIs,
                        // including multi-select from modern Android document providers.
                        val pickIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "image/*"
                            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        filePicker.launch(pickIntent)
                    } catch (_: Exception) {
                        pendingFileChooser?.onReceiveValue(null)
                        pendingFileChooser = null
                        Toast.makeText(this@MainActivity, "Cannot open photo picker", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
            }
            loadUrl("https://appassets.androidplatform.net/assets/index.html")
        }
        // Do not pad the WebView itself: WebView's CSS/fixed-position content may
        // still render under the system bars. Constrain its *viewport* with a parent.
        val root = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(244, 248, 254))
            addView(webView, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            // Keep bottom controls above Android's keyboard when form inputs are active.
            val keyboardBottom = if (insets.isVisible(WindowInsetsCompat.Type.ime())) {
                insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            } else 0
            view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, keyboardBottom))
            // We have handled these insets natively; don't apply them again in HTML.
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)
        ViewCompat.requestApplyInsets(root)
    }

    private fun openAllowedUrl(url: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" && uri.scheme != "tel" && uri.scheme != "geo") return
        try { startActivity(Intent(if (uri.scheme == "tel") Intent.ACTION_DIAL else Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { Toast.makeText(this, "No app available to open link", Toast.LENGTH_SHORT).show() }
    }

    private fun speakWelcome(message: String, language: String, frequency: String) {
        if (message.isBlank() || message.length > 300) return
        if (frequency !in setOf("every", "daily", "3days", "7days")) return
        val prefs = getSharedPreferences("baran_voice_welcome", MODE_PRIVATE)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val now = System.currentTimeMillis()
        val previous = prefs.getLong("lastPlayedAt", 0L)
        val elapsedDays = (now - previous) / 86400000L
        val alreadyToday = prefs.getString("lastPlayedDay", "") == today
        if (frequency == "daily" && alreadyToday) return
        if (frequency == "3days" && previous > 0 && elapsedDays < 3) return
        if (frequency == "7days" && previous > 0 && elapsedDays < 7) return
        if (!ttsReady) {
            pendingWelcome = Triple(message, language, frequency)
            return
        }
        val tts = welcomeTts ?: return
        val locale = if (language == "en") Locale.ENGLISH else Locale.forLanguageTag("hi-IN")
        val support = tts.setLanguage(locale)
        if (support == TextToSpeech.LANG_MISSING_DATA || support == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (tts.setLanguage(Locale.ENGLISH) < TextToSpeech.LANG_AVAILABLE) return
        }
        val result = tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "baran_welcome")
        if (result == TextToSpeech.SUCCESS) {
            prefs.edit().putLong("lastPlayedAt", now).putString("lastPlayedDay", today).apply()
        }
    }

    private fun playWelcomeAudio(url: String, frequency: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host != "firebasestorage.googleapis.com") return
        if (frequency !in setOf("every", "daily", "3days", "7days")) return
        val prefs = getSharedPreferences("baran_voice_welcome", MODE_PRIVATE)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val now = System.currentTimeMillis()
        val previous = prefs.getLong("lastPlayedAt", 0L)
        if (frequency == "daily" && prefs.getString("lastPlayedDay", "") == today) return
        if (frequency == "3days" && previous > 0 && now - previous < 3L * 86400000L) return
        if (frequency == "7days" && previous > 0 && now - previous < 7L * 86400000L) return
        try {
            welcomePlayer?.release()
            welcomePlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { player ->
                    player.start()
                    prefs.edit().putLong("lastPlayedAt", System.currentTimeMillis())
                        .putString("lastPlayedDay", today).apply()
                }
                setOnCompletionListener { it.release(); if (welcomePlayer === it) welcomePlayer = null }
                setOnErrorListener { player, _, _ -> player.release(); if (welcomePlayer === player) welcomePlayer = null; true }
                prepareAsync()
            }
        } catch (_: Exception) { welcomePlayer?.release(); welcomePlayer = null }
    }

    // A separate preference namespace preserves existing Welcome Voice playback history.
    private fun urgentAlreadyPlayed(id: String): Boolean =
        getSharedPreferences("baran_urgent_voice", MODE_PRIVATE).getBoolean(id, false)

    private fun markUrgentPlayed(id: String) {
        getSharedPreferences("baran_urgent_voice", MODE_PRIVATE).edit().putBoolean(id, true).apply()
    }

    private fun playUrgent(id: String, method: String, message: String, audioUrl: String) {
        pendingWelcome = null
        welcomeTts?.stop()
        welcomePlayer?.release()
        welcomePlayer = null
        if (method == "audio") {
            val uri = Uri.parse(audioUrl)
            if (uri.scheme != "https" || uri.host != "firebasestorage.googleapis.com") return
            try {
                welcomePlayer = MediaPlayer().apply {
                    setDataSource(this@MainActivity, uri)
                    setOnPreparedListener { player ->
                        player.start()
                        markUrgentPlayed(id)
                    }
                    setOnCompletionListener { player ->
                        player.release()
                        if (welcomePlayer === player) welcomePlayer = null
                    }
                    setOnErrorListener { player, _, _ ->
                        player.release()
                        if (welcomePlayer === player) welcomePlayer = null
                        true
                    }
                    prepareAsync()
                }
            } catch (_: Exception) { welcomePlayer?.release(); welcomePlayer = null }
        } else if (ttsReady && message.length in 3..500) {
            val tts = welcomeTts ?: return
            val support = tts.setLanguage(Locale.forLanguageTag("hi-IN"))
            if (support == TextToSpeech.LANG_MISSING_DATA || support == TextToSpeech.LANG_NOT_SUPPORTED) {
                if (tts.setLanguage(Locale.ENGLISH) < TextToSpeech.LANG_AVAILABLE) return
            }
            if (tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "baran_urgent_$id") == TextToSpeech.SUCCESS) {
                markUrgentPlayed(id)
            }
        }
    }

    private inner class AndroidBridge {
        @JavascriptInterface fun getVersionCode(): Int = packageManager.getPackageInfo(packageName, 0).versionCode

        @JavascriptInterface fun urgentAnnouncement(id: String, method: String, message: String, audioUrl: String): Boolean {
            if (!id.matches(Regex("urgent-[A-Za-z0-9-]{1,100}")) || method !in setOf("tts", "audio")) return false
            if (urgentAlreadyPlayed(id)) return false
            if (method == "tts" && (message.length !in 3..500 || !ttsReady)) return false
            if (method == "audio") {
                val uri = Uri.parse(audioUrl)
                if (uri.scheme != "https" || uri.host != "firebasestorage.googleapis.com") return false
            }
            runOnUiThread { if (!urgentAlreadyPlayed(id)) playUrgent(id, method, message, audioUrl) }
            return true
        }

        @JavascriptInterface fun welcomeVoice(message: String, language: String, frequency: String) = runOnUiThread {
            speakWelcome(message, language, frequency)
        }

        @JavascriptInterface fun welcomeAudio(url: String, frequency: String) = runOnUiThread {
            playWelcomeAudio(url, frequency)
        }

        @JavascriptInterface fun dial(phone: String) = runOnUiThread {
            val clean = phone.filter { it.isDigit() || it == '+' }
            if (clean.isNotBlank()) openAllowedUrl("tel:$clean")
        }
        @JavascriptInterface fun openUrl(url: String) = runOnUiThread { openAllowedUrl(url) }
        @JavascriptInterface fun shareText(text: String) = runOnUiThread {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text.take(2000))
            }
            startActivity(Intent.createChooser(intent, "Share business"))
        }
    }

    @Deprecated("Used for backwards compatibility on different Android versions")
    override fun onBackPressed() {
        webView.evaluateJavascript("window.BaranApp && window.BaranApp.goBack()") { result ->
            if (result == "false" || result == "null") finish()
        }
    }

    override fun onDestroy() {
        welcomePlayer?.release()
        welcomePlayer = null
        pendingFileChooser?.onReceiveValue(null)
        welcomeTts?.stop()
        welcomeTts?.shutdown()
        webView.removeJavascriptInterface("AndroidBridge")
        webView.destroy()
        super.onDestroy()
    }
}
