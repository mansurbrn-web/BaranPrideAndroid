(function(){
'use strict';
const C=window.BaranCloud;
const svgPaths={
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>', bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
 user:'<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',pin:'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
 sliders:'<path d="M4 7h8m4 0h4M4 17h3m4 0h9"/><circle cx="14" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
 cart:'<circle cx="9" cy="20" r="1"/><circle cx="19" cy="20" r="1"/><path d="M2 3h3l3 13h11l3-10H6"/>',
 health:'<path d="M5 4a4 4 0 0 0-4 4v5a6 6 0 0 0 12 0V8a4 4 0 0 0-4-4M5 4v3m4-3v3m4 6v2a5 5 0 0 0 10 0v-3"/><circle cx="19" cy="10" r="2"/>',
 food:'<path d="M4 2v8m4-8v8M2 6h8M6 10v12M17 2v20M17 2c7 3 7 11 0 11"/>',
 education:'<path d="m2 9 10-5 10 5-10 5zM6 11v6c4 3 8 3 12 0v-6M22 9v7"/>',
 property:'<path d="m2 11 10-9 10 9M5 10v12h14V10M9 22v-8h6v8"/>',
 tools:'<path d="M14 6a6 6 0 0 1-8 8L2 18l4 4 4-4a6 6 0 0 0 8-8l-4 4-4-4z"/>',
 car:'<path d="M5 16h14l-1-8H6zM3 16h18v4H3zM7 20v2m10-2v2M7 8l2-4h6l2 4"/>',
 job:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18m-11-1h4v3h-4z"/>',
 hotel:'<path d="M4 22V4h16v18M2 22h20M8 8h2m4 0h2M8 12h2m4 0h2M8 16h2m4 0h2M10 22v-4h4v4"/>',
 temple:'<path d="M4 22h16M5 22V9h14v13M3 9h18M12 2l8 7H4zM10 22v-7h4v7"/>',
 grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
 store:'<path d="M3 10h18l-2-6H5zM5 10v11h14V10M9 21v-7h6v7"/>',
 arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',back:'<path d="M15 18 9 12l6-6"/>',phone:'<path d="M22 16.5v3a2 2 0 0 1-2.2 2 19 19 0 0 1-17-17A2 2 0 0 1 4.8 2h3a2 2 0 0 1 2 1.7l.7 3a2 2 0 0 1-.7 2l-1.7 1.4a15 15 0 0 0 5.8 5.8l1.4-1.7a2 2 0 0 1 2-.7l3 .7a2 2 0 0 1 1.7 2.3z"/>',
 message:'<path d="M21 11.5a8.4 8.4 0 0 1-12 7.5L3 21l2-6A8.5 8.5 0 1 1 21 11.5z"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',share:'<circle cx="18" cy="5" r="2"/><circle cx="6" cy="12" r="2"/><circle cx="18" cy="19" r="2"/><path d="m8 11 8-5M8 13l8 5"/>',edit:'<path d="M12 20h9M16 3l5 5L9 20H4v-5z"/>',check:'<path d="m4 12 5 5L20 6"/>',logout:'<path d="M10 3H4v18h6M14 7l5 5-5 5m5-5H8"/>',camera:'<path d="M4 7h4l2-3h4l2 3h4v14H4z"/><circle cx="12" cy="14" r="4"/>',plus:'<path d="M12 3v18M3 12h18"/>',drop:'<path d="M12 3c2.6 4 7 8.4 7 12a7 7 0 0 1-14 0c0-3.6 4.4-8 7-12z"/>', menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',close:'<path d="M5 5l14 14M19 5 5 19"/>',book:'<path d="M12 7c-4-3-8-3-10-2v14c3-1 7-1 10 2m0-14c4-3 8-3 10-2v14c-3-1-7-1-10 2m0-14v14"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>',news:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h6v5H7zM16 8h2M16 11h2M7 16h11"/>',info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7h.01"/>',map:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3zM9 3v15m6-12v15"/>'
};
svgPaths['sync-check']='<circle cx="12" cy="12" r="9"/><path d="m7.5 12 3 3 6-6"/>';
svgPaths.briefcase='<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18M10 13v2h4v-2"/>';
const icon=(n,size=21)=>`<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${svgPaths[n]||svgPaths.grid}</svg>`;
const $=s=>document.querySelector(s), escapeHtml=(v)=>String(v??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
// V3.1: Mask every alternate visible character in EACH word of a donor name.
// Example: Mansur Ali -> M*n*u* A*i. This is a display-only mask.
function maskBloodDonorName(name){
  return String(name??'').trim().split(/(\s+)/u).map(word=>{
    if(/^\s+$/u.test(word))return word;
    const letters=typeof Intl.Segmenter==='function'
      ? Array.from(new Intl.Segmenter('hi',{granularity:'grapheme'}).segment(word),item=>item.segment)
      : Array.from(word);
    return letters.map((letter,index)=>index%2===0?letter:'*').join('');
  }).join('');
}
const categories=[['Shopping','cart'],['Doctors','health'],['Restaurants','food'],['Education','education'],['Property','property'],['Services','tools'],['Automobile','car'],['Jobs','job'],['Hotels','hotel'],['More','grid']];
// Full directory category screen: keep the ten existing homepage slots unchanged.
// New approved business categories and active admin-managed categories appear automatically.
const ALL_CATEGORY_SEED=[
 ['Shopping','cart'],['Doctors','health'],['Restaurants','food'],['Education','education'],
 ['Property','property'],['Services','tools'],['Automobile','car'],['Jobs','job'],
 ['Hotels','hotel'],['Temples','temple'],['Medical','health'],['Beauty Parlour','store'],
 ['Electronics','store'],['Clothing','cart'],['Hardware','tools'],['Gym','heart'],
 ['Photography','camera'],['Printing & Stationery','book'],['Grocery','cart'],
 ['Real Estate','property'],['Others','grid']
];
const categoryIcon=name=>{
 const n=String(name||'').toLowerCase().trim();
 return ALL_CATEGORY_SEED.find(item=>item[0].toLowerCase()===n)?.[1]||'store';
};
function allBusinessCategories(){
 const names=new Map();
 function add(value){const n=String(value||'').trim();if(!n||n.toLowerCase()==='more'||n.toLowerCase()==='all')return;
  const key=n.toLocaleLowerCase();if(!names.has(key))names.set(key,n)}
 ALL_CATEGORY_SEED.forEach(item=>add(item[0]));
 (S.customCategories||[]).forEach(add);
 S.businesses.filter(b=>b.status==='approved').forEach(b=>(Array.isArray(b.categories)&&b.categories.length?b.categories:[b.category]).forEach(add));
 return [...names.values()].sort((a,b)=>a.localeCompare(b,'en',{sensitivity:'base'}));
}
function categoryCount(name){return S.businesses.filter(b=>b.status==='approved'&&(Array.isArray(b.categories)&&b.categories.length?b.categories:[b.category]).some(c=>String(c||'').toLocaleLowerCase()===name.toLocaleLowerCase())).length}
function allCategoriesPage(){
 const items=allBusinessCategories().filter(n=>n.toLocaleLowerCase().includes(S.categorySearch.trim().toLocaleLowerCase()));
 return `<div class="screen categories-page">${head('All Business Categories')}<h1 class="page-title">Explore Categories</h1><p class="intro">श्रेणी चुनकर Baran के स्थानीय बिजनेस खोजें</p><div class="search-bar category-search">${icon('search')}<input id="all-categories-search" value="${escapeHtml(S.categorySearch)}" placeholder="Search categories..." autocomplete="off" aria-label="Search all categories"></div><p class="result-count" id="categories-result-count">${items.length} categories</p><div class="category-view-switch"><button type="button" data-category-view="list" class="${S.categoryView==='list'?'selected':''}">☰ List</button><button type="button" data-category-view="grid" class="${S.categoryView==='grid'?'selected':''}">▦ Grid</button></div><div class="all-category-grid ${S.categoryView==='list'?'category-list-view':''}" id="all-category-grid">${items.map(name=>`<button class="all-category-tile" data-all-category="${escapeHtml(name)}" data-category-search="${escapeHtml(name.toLocaleLowerCase())}"><span class="all-category-symbol">${icon(categoryIcon(name),25)}</span><strong>${escapeHtml(name)}</strong><small>${categoryCount(name)} businesses</small></button>`).join('')}</div><div class="city-message hidden" id="category-search-empty">No matching categories found.</div></div>`;
}
const DEMO=[
 {id:'demo-1',name:'The Royal Restaurant',category:'Restaurants',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/restaurant.jpg',rating:4.5,reviews:128,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-2',name:'MediCare Hospital',category:'Doctors',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/hospital.jpg',rating:4.8,reviews:210,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-3',name:'Fashion Hub',category:'Shopping',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/fashion.jpg',rating:4.3,reviews:96,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-4',name:'Sharma Electronics',category:'Shopping',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/electronics.jpg',rating:0,featured:false,status:'approved',demo:true,description:'Example business name only.'},
 {id:'demo-5',name:'Guru Kirpa Motors',category:'Automobile',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/automobile.jpg',rating:0,featured:false,status:'approved',demo:true,description:'Example business name only.'}
];
const CITY_TYPES=[['historical','Historical Places','ऐतिहासिक स्थल','temple'],['blogs','Blogs & Articles','ब्लॉग और लेख','book'],['tourist','Tourist Places','घूमने की जगहें','pin'],['events','Events & Festivals','कार्यक्रम और मेले','calendar'],['updates','City Updates','शहर की जानकारी','news'],['contacts','Important Contacts','जरूरी संपर्क','phone'],['about','About Baran','बारां के बारे में','info']];
const cityType=(id)=>CITY_TYPES.find(x=>x[0]===id)||CITY_TYPES[0];
const S={jobs:[],jobSearch:'',jobCategory:'All',jobId:null,jobLoading:false,jobMine:[],jobMineLoading:false,jobMineError:'',jobError:'',propertySlideIndex:0,propertyId:null,propertyFilter:"All",propertySort:"latest",propertyPhotoIndex:0,customCategories:[],categorySearch:'',categoryView:'list',notificationSettings:{enabled:true,theme:'purple'},heroImageUrl:'',shutterBanner:{enabled:false,imageUrl:'',linkUrl:''},returnToCategories:false,donors:[],donorError:'',donorFilter:'All',properties:[],propertyError:'',helpline:'7737325205',defaultBusinessCover:'img/baran-pride-default-business.jpg',propertySubmitting:false,marketplaceItems:[],marketplaceId:null,marketplaceSearch:"",marketplaceCategory:"All",marketplaceSort:"premium",marketplacePair:[],marketplaceError:"",marketplaceMine:[],marketplaceSending:false,drawer:false,cityType:'historical',cityItems:[],cityId:null,cityQuery:'',cityLoading:false,cityError:'',cityBackTarget:'cityList',homeCityItems:[],promotions:[],promotionSelected:null,promotionOrder:[],promotionIndex:0,offers:[],offerId:null,offerStart:0,notices:[],sliderMessages:[],noticeVisible:null,homeCityError:'',homeSlidePositions:{events:0,historical:0},page:'home',category:'All',query:'',businesses:[],owned:[],saved:new Set(JSON.parse(localStorage.getItem('baran_saved')||'[]')),detail:null,authTab:'signin',afterAuth:'add',editingId:null,loading:false};
const cacheGet=(k,def)=>{try{return JSON.parse(localStorage.getItem(k))??def}catch{return def}};
const toast=(msg)=>{let t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2600)};
function native(method,...args){try{if(window.AndroidBridge&&typeof window.AndroidBridge[method]==='function'){window.AndroidBridge[method](...args);return true}}catch(e){console.warn(e)}return false}
function openUrl(url){if(!url)return;if(!native('openUrl',url))window.open(url,'_blank','noopener')}
function demoWarning(){toast('यह सिर्फ Design Demo Listing है');}
function callBusiness(id){const b=findBiz(id);if(!b)return;if(!b.phone||b.demo)return demoWarning();if(!native('dial',b.phone))openUrl('tel:'+encodeURIComponent(b.phone));}
function whatsapp(id){const b=findBiz(id);if(!b)return;if(!b.whatsapp&&!b.phone||b.demo)return demoWarning();const num=(b.whatsapp||b.phone).replace(/[^\d]/g,'');openUrl('https://wa.me/'+(num.startsWith('91')?num:'91'+num));}
function businessMapLink(b){
 // Never generate a map search from the business name or address.
 const raw=String(b?.mapUrl||'').trim().replace(/&amp;/gi,'&');
 if(!raw)return '';
 try{
  const u=new URL(raw);
  if(u.protocol!=='https:')return '';
  const h=u.hostname.toLowerCase();
  if(h==='maps.app.goo.gl'||h==='goo.gl'&&u.pathname.startsWith('/maps'))return u.href;
  const googleHost=h==='google.com'||h==='maps.google.com'||h==='www.google.com'||/^((www|maps)\.)?google\.[a-z.]+$/.test(h);
  if(!googleHost)return '';
  // Accept Google Maps share links, places, directions and Google Maps query links.
  if(u.pathname.startsWith('/maps')||u.pathname.startsWith('/place')||u.pathname.startsWith('/search')||u.pathname.startsWith('/url')||u.pathname.startsWith('/dir')||u.searchParams.has('q')||u.searchParams.has('query')||u.searchParams.has('daddr'))return u.href;
 }catch(e){console.warn('Invalid business map URL',e)}
 return '';
}
function directions(id){const b=findBiz(id);if(!b)return;const url=businessMapLink(b);if(!url)return;if(b.demo)return demoWarning();openUrl(url);}
function share(id){const b=findBiz(id);if(!b)return;const txt=b.name+' — '+b.area+', Baran Rajasthan';if(native('shareText',txt))return;if(navigator.share){navigator.share({title:b.name,text:txt}).catch(()=>{})}else if(navigator.clipboard){navigator.clipboard.writeText(txt).then(()=>toast('Business details copied'))}}
function findBiz(id){return [...S.businesses,...S.owned].find(b=>b.id===id)}
function saveToggle(id){if(S.saved.has(id))S.saved.delete(id);else S.saved.add(id);localStorage.setItem('baran_saved',JSON.stringify([...S.saved]));toast(S.saved.has(id)?'Saved to favorites':'Removed from favorites');render()}
const bottom=()=>`<nav class="bottom-nav" aria-label="Main navigation">${[['home','home','Home'],['allCategories','grid','Categories'],['eventsTab','calendar','Events'],['owner','store','My Business'],['profile','user','Profile']].map(([key,ic,label])=>`<button class="nav-item ${S.page===key?'active':''}" data-go="${key}" aria-label="${label}">${icon(ic,24)}<span>${label}</span></button>`).join('')}</nav>`;
const brand=()=>`<div class="brand"><div class="logo"><img src="img/baran-pride-blue-logo.png" width="57" height="57" alt="BARAN PRIDE logo" loading="eager"></div><div><div class="brand-main">BARAN <span>PRIDE</span></div><div class="tagline">हमारा शहर, हमारी पहचान</div></div></div>`;
const head=(title)=>`<div class="back-header"><button data-back aria-label="Back">${icon('back')}</button><strong>${title}</strong></div>`;
const banner=()=>''; // Demo disclaimer removed; no changes to business data or Firebase.
function section(title,go){return `<div class="section-head"><h2>${title}</h2><button data-go="${go}">View All →</button></div>`}
function businessCover(b){const visible=Array.isArray(b?.photoUrls)?b.photoUrls.slice(0,isPremium(b)?5:2):[];const u=String(visible.length?(visible.includes(b?.cover)?b.cover:visible[0]):(b?.cover||'')).trim();return /^https:\/\//i.test(u)?u:S.defaultBusinessCover}
function businessImage(b,attrs=''){return `<img src="${escapeHtml(businessCover(b))}" onerror="this.onerror=null;this.src='img/baran-pride-default-business.jpg'" ${attrs}>`}
function isPremium(b){return b?.plan==='premium'&&b?.planStatus==='active'&&b?.paymentStatus==='paid'&&(typeof b.expiresAt?.toMillis==='function'&&b.expiresAt.toMillis()>Date.now())}
function businessCategories(b){return isPremium(b)&&Array.isArray(b.categories)&&b.categories.length?b.categories.slice(0,3):[b.category]}
function badgeTick(b){return isPremium(b)?'<span title="Priority business" aria-label="Priority business" style="color:#1266c2;font-weight:900;margin-left:4px">⭐✓</span>':''}
function businessName(b){return escapeHtml(b.name)+badgeTick(b)}
function prioritySort(a,b){const tier=Number(isPremium(b))-Number(isPremium(a));if(tier)return tier;const day=Math.floor(Date.now()/86400000),score=x=>{let h=(day*2654435761)>>>0;for(const c of String(x.id||x.name||''))h=(Math.imul(h,33)+c.charCodeAt(0))>>>0;return h};return score(a)-score(b)||String(a.name||'').localeCompare(String(b.name||''))}
function bizCard(b){return `<article class="business-card"><div class="imgwrap">${businessImage(b,` alt="${escapeHtml(b.name)}" loading="lazy"`)}${b.featured?'<span class="mark-featured">★ Featured</span>':''}</div><div class="card-body"><div class="card-name">${businessName(b)}</div><div class="card-sub">${escapeHtml(b.category)} · ${escapeHtml(b.area)}</div><div class="rating">${b.rating?`<span class="star">★</span> ${b.rating} <em>(${b.reviews||0})</em>`:'<em>New listing</em>'}</div><div class="card-actions"><button data-call="${b.id}">${icon('phone',17)}Call</button><button data-wa="${b.id}">${icon('message',17)}WhatsApp</button><button data-detail="${b.id}">${icon('pin',17)}Details</button></div></div></article>`}
function latestCard(b){return `<article class="latest-row">${businessImage(b,` alt=""`)}<div><strong>${businessName(b)}</strong><small>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</small></div><button class="smallaction" data-detail="${b.id}" aria-label="View business">${icon('arrow',18)}</button></article>`}
function filtered(){return S.businesses.filter(b=>(S.category==='All'||businessCategories(b).some(c=>String(c||'').toLocaleLowerCase()===S.category.toLocaleLowerCase()))&&[b.name,...businessCategories(b),b.area,b.address].join(' ').toLowerCase().includes(S.query.toLowerCase())).sort(prioritySort)}
// Homepage city panels are intentionally small additions to the existing V3.1 design.
// Only published AND explicitly chosen by Admin appear on the Homepage.
const HOME_SECTION_TYPES={events:['events'],historical:['historical'],news:['blogs','updates']};
function homeCitySorted(section){
 const types=HOME_SECTION_TYPES[section]||[];
 return S.homeCityItems.filter(x=>x.status==='published'&&x.showOnHomepage===true&&types.includes(x.type)).sort((a,b)=>{
  const order=x=>Number.isFinite(Number(x.homeOrder))?Number(x.homeOrder):100;
  const published=x=>x.publishedAt?.seconds||x.updatedAt?.seconds||0;
  return order(a)-order(b)||published(b)-published(a);
 });
}
function homeCityHeading(title,section,iconName){
 return `<div class="section-head home-city-section-head"><h2>${icon(iconName,20)} ${title}</h2><button data-home-viewall="${section}">View All →</button></div>`;
}
function homepageSlider(section,title,iconName){
 const items=homeCitySorted(section);if(!items.length)return '';
 const index=Math.min(Math.max(0,S.homeSlidePositions[section]||0),items.length-1);
 const slides=items.map((x,i)=>{
  const image=safeHttps(x.cover);
  const subtitle=section==='events'? [[x.startDate,x.endDate].filter(Boolean).join(' → ')||x.eventDate||cityDate(x.publishedAt),x.area].filter(Boolean).join(' · '): String(x.summary||'').trim();
  return `<article class="home-landscape-slide ${i===index?'is-current':''}" data-home-slide-index="${i}" role="group" aria-label="${i+1} of ${items.length}" aria-hidden="${i!==index}">
   ${image?`<img src="${escapeHtml(image)}" alt="${escapeHtml(x.title)}" loading="lazy">`:'<div class="home-landscape-no-image" aria-hidden="true"></div>'}
   <div class="home-landscape-shade"></div>
   <div class="home-landscape-caption"><div class="home-landscape-title">${escapeHtml(x.title)}</div>${subtitle?`<p>${escapeHtml(subtitle)}</p>`:''}</div>
   <button class="home-landscape-detail" data-home-detail="${escapeHtml(x.id)}" type="button">View Details →</button>
  </article>`;
 }).join('');
 return `<section class="home-city-block" aria-label="${title}">${homeCityHeading(title,section,iconName)}
  <div class="home-landscape-slider" data-home-carousel="${section}">${slides}
   ${items.length>1?`<button class="home-landscape-nav prev" data-home-slide="-1" aria-label="Previous ${title}">${icon('back',21)}</button><button class="home-landscape-nav next" data-home-slide="1" aria-label="Next ${title}">${icon('arrow',21)}</button>`:''}</div>
   ${items.length>1?`<div class="home-slider-dots" role="group" aria-label="${title} slides">${items.map((_,i)=>`<button data-home-dot="${i}" aria-label="Show item ${i+1}" class="${i===index?'active':''}"></button>`).join('')}</div>`:''}
 </section>`;
}
function homepageNews(){
 const items=homeCitySorted('news');if(!items.length)return '';
 return `<section class="home-city-block home-news-block" aria-label="News & Blog">${homeCityHeading('News & Blog','news','news')}
  <div class="featured-strip home-news-strip">${items.map(x=>{
   const image=safeHttps(x.cover);
   return `<article class="business-card home-news-card"><div class="imgwrap">${image?`<img src="${escapeHtml(image)}" loading="lazy" alt="${escapeHtml(x.title)}">`:`<div class="home-news-no-image">${icon('news',30)}</div>`}</div><div class="card-body"><div class="card-name">${escapeHtml(x.title)}</div><div class="card-sub">${escapeHtml(cityDate(x.publishedAt)||x.eventDate||'News & Blog')}</div><div class="card-actions"><button type="button" data-home-detail="${escapeHtml(x.id)}">Read More →</button></div></div></article>`;
  }).join('')}</div></section>`;
}
let homeSlidesTimer=null;
function displayHomeSlide(slider,index){
 const slides=[...slider.querySelectorAll('.home-landscape-slide')];if(!slides.length)return;
 const target=((index%slides.length)+slides.length)%slides.length;
 slides.forEach((el,i)=>{el.classList.toggle('is-current',i===target);el.setAttribute('aria-hidden',String(i!==target))});
 slider.parentElement.querySelectorAll('[data-home-dot]').forEach((el,i)=>el.classList.toggle('active',i===target));
 S.homeSlidePositions[slider.dataset.homeCarousel]=target;
}

/* Baran Pride: notification themes are bundled with app.js to avoid requiring a CSS replacement. */
function installNotificationStyles(){
 if(document.getElementById('bp-notification-v6-styles'))return;
 const style=document.createElement('style');style.id='bp-notification-v6-styles';
 style.textContent=`
 .bp-notification-strip{--bp-notice-bg:linear-gradient(110deg,#6539ba,#9854dd);--bp-notice-ink:#fff;--bp-notice-accent:#fff;display:flex;align-items:center;gap:9px;position:relative;overflow:hidden;min-height:43px;padding:7px 13px;background:var(--bp-notice-bg);color:var(--bp-notice-ink);border-radius:0;box-sizing:border-box}
 .bp-notification-icon{flex:0 0 auto;font-size:17px;line-height:1;filter:drop-shadow(0 1px 1px #0002)}
 .bp-notification-viewport{flex:1;min-width:0;overflow:hidden;position:relative;min-height:27px;display:flex;align-items:center}
 .bp-notification-track{width:100%;position:relative}
 .bp-notification-item{display:none;align-items:center;min-height:27px;font-size:13px;font-weight:650;line-height:1.4;letter-spacing:.1px;overflow-wrap:anywhere;color:inherit}
 .bp-notification-item:first-child{display:flex}
 .bp-notification-purple{--bp-notice-bg:linear-gradient(110deg,#5931aa,#9c5bda)}
 .bp-notification-blue{--bp-notice-bg:linear-gradient(110deg,#09469e,#2686df)}
 .bp-notification-orange{--bp-notice-bg:linear-gradient(110deg,#d95b12,#fa9b26)}
 .bp-notification-green{--bp-notice-bg:linear-gradient(110deg,#087b55,#2cbf85)}
 .bp-notification-pink{--bp-notice-bg:linear-gradient(110deg,#ad247e,#ed76b8)}
 .bp-notification-red{--bp-notice-bg:linear-gradient(110deg,#a91e31,#e9565d)}
 .bp-notification-yellow{--bp-notice-bg:linear-gradient(110deg,#ffe276,#ffc233);--bp-notice-ink:#4d3800}
 .bp-notification-sky{--bp-notice-bg:linear-gradient(110deg,#42b6db,#86e4f1);--bp-notice-ink:#073b57}
 .bp-notification-dark{--bp-notice-bg:linear-gradient(110deg,#13213e,#34496c)}
 .bp-notification-tiranga{--bp-notice-bg:linear-gradient(180deg,#ff9933 0 33.3%,#fff 33.3% 66.6%,#138808 66.6%);--bp-notice-ink:#122a65}
 .bp-notification-tiranga-wave{--bp-notice-bg:linear-gradient(135deg,#ff9933 0%,#ffbd73 28%,#fff 46%,#fff 57%,#4bb65b 78%,#138808 100%);--bp-notice-ink:#102e62}
 .bp-notification-tiranga-border{--bp-notice-bg:linear-gradient(180deg,#ff9933 0 5px,#fff 5px calc(100% - 5px),#138808 calc(100% - 5px));--bp-notice-ink:#153a75}
 .bp-notification-tiranga-gradient{--bp-notice-bg:linear-gradient(90deg,#ff9933 0%,#fff 49%,#138808 100%);--bp-notice-ink:#142d62}
 .bp-notification-tiranga-brush{--bp-notice-bg:repeating-linear-gradient(172deg,#ff9933 0 10px,#ffb762 10px 15px,#fff 15px 30px,#e5f4e7 30px 34px,#138808 34px 44px);--bp-notice-ink:#122a65}
 .bp-notification-tiranga-chakra{--bp-notice-bg:linear-gradient(180deg,#ff9933 0 28%,#fff 28% 72%,#138808 72%);--bp-notice-ink:#132c68}
 .bp-notification-fresh-green{--bp-notice-bg:linear-gradient(110deg,#0b7656,#28b88b);--bp-notice-ink:#ffffff}
 .bp-notification-modern-orange{--bp-notice-bg:linear-gradient(110deg,#ba4514,#f9a13e);--bp-notice-ink:#ffffff}
 .bp-notification-premium-purple{--bp-notice-bg:linear-gradient(110deg,#452189,#a268df);--bp-notice-ink:#ffffff}
 .bp-notification-soft-pink{--bp-notice-bg:linear-gradient(110deg,#f6d8ea,#ffebf5);--bp-notice-ink:#7b2354}
 .bp-notification-elegant-gold{--bp-notice-bg:linear-gradient(110deg,#6b4b10,#d2a744);--bp-notice-ink:#ffffff}
 .bp-notification-night-blue{--bp-notice-bg:linear-gradient(110deg,#071b39,#24569b);--bp-notice-ink:#ffffff}
 .bp-notification-dark-elegant{--bp-notice-bg:linear-gradient(110deg,#151821,#414654);--bp-notice-ink:#ffffff}
 .bp-notification-alert-red{--bp-notice-bg:linear-gradient(110deg,#981a29,#ec555b);--bp-notice-ink:#ffffff}
 .bp-notification-modern-teal{--bp-notice-bg:linear-gradient(110deg,#075e64,#1bb4b1);--bp-notice-ink:#ffffff}
 .bp-notification-gradient-pro{--bp-notice-bg:linear-gradient(110deg,#1644a5,#a353e2);--bp-notice-ink:#ffffff}
 .bp-notification-diwali{--bp-notice-bg:linear-gradient(110deg,#5b167d,#b947a1);--bp-notice-ink:#ffe599}
 .bp-notification-eid{--bp-notice-bg:linear-gradient(110deg,#00634d,#0c9b76);--bp-notice-ink:#fff3c1}
 .bp-notification-holi{--bp-notice-bg:linear-gradient(110deg,#ffb6dc,#ffe06c);--bp-notice-ink:#7a1559}
 .bp-notification-independence{--bp-notice-bg:linear-gradient(110deg,#ff9933,#138808);--bp-notice-ink:#122c64}
 .bp-notification-christmas{--bp-notice-bg:linear-gradient(110deg,#9b1735,#20754e);--bp-notice-ink:#ffffff}
 .bp-notification-makar-sankranti{--bp-notice-bg:linear-gradient(110deg,#fff0d4,#f5bd55);--bp-notice-ink:#8b3d0d}
 .bp-notification-ganesh-chaturthi{--bp-notice-bg:linear-gradient(110deg,#ad3e11,#ef9d21);--bp-notice-ink:#ffffff}
 .bp-notification-navratri{--bp-notice-bg:linear-gradient(110deg,#771b35,#dd8c31);--bp-notice-ink:#ffffff}
 .bp-notification-raksha-bandhan{--bp-notice-bg:linear-gradient(110deg,#ba387e,#8753bc);--bp-notice-ink:#ffffff}
 .bp-notification-janmashtami{--bp-notice-bg:linear-gradient(110deg,#074c80,#1e9b9e);--bp-notice-ink:#fff2bd}
 .bp-notification-guru-nanak{--bp-notice-bg:linear-gradient(110deg,#164b91,#f19a32);--bp-notice-ink:#ffffff}
 .bp-notification-rainbow-celebration{--bp-notice-bg:linear-gradient(110deg,#e24678,#4f6de0);--bp-notice-ink:#ffffff}
 .bp-notification-tiranga-chakra:after{content:"☸";position:absolute;right:12px;top:50%;transform:translateY(-50%);font-size:29px;color:#173b86;opacity:.17;pointer-events:none}
 .bp-notification-tiranga-border,.bp-notification-tiranga-chakra{box-shadow:inset 0 0 0 1px #0000000d}

/* V4.0 illustrated notification themes: same rules in app and admin preview */
.bp-notification-strip.bp-stylish,.bp-theme-preview.bp-stylish{position:relative;isolation:isolate;overflow:hidden;background:var(--bp-notice-bg);color:var(--bp-notice-ink);box-shadow:0 3px 12px #112e5820}
.bp-stylish:before{content:"";position:absolute;inset:0;background:var(--bp-decor);pointer-events:none;z-index:-1}
.bp-stylish:after{content:var(--bp-art);position:absolute;right:11px;top:50%;transform:translateY(-50%);font-size:23px;opacity:.44;pointer-events:none;z-index:-1}
.bp-stylish .bp-notification-icon,.bp-stylish .bp-preview-icon{display:grid;place-items:center;flex:0 0 31px;width:31px;height:31px;border:1.5px solid #ffffffa8;border-radius:50%;background:var(--bp-icon-bg,#1554b4);color:var(--bp-notice-accent,#fff);font-size:17px;box-shadow:0 2px 7px #0002;position:relative;z-index:1}
.bp-stylish .bp-notification-viewport,.bp-stylish .bp-preview-message{position:relative;z-index:1;padding-right:20px}
.bp-stylish .bp-theme-arrow{position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:23px;line-height:1;font-weight:800;color:var(--bp-notice-ink);opacity:.92;pointer-events:none;z-index:1}
.bp-theme-preview{display:flex;align-items:center;gap:10px;min-height:57px;padding:9px 12px;border-radius:14px;box-sizing:border-box}
.bp-theme-preview .bp-preview-message{font-weight:700;font-size:14px;line-height:1.4;overflow-wrap:anywhere;flex:1}
.bp-stylish.bp-notification-blue{--bp-notice-bg:linear-gradient(110deg,#0a3a96,#1558d0);--bp-notice-ink:#fff;--bp-icon-bg:#0a3a96;--bp-decor:radial-gradient(circle at 86% 115%,#50a7ff66 0 17%,transparent 18%),linear-gradient(120deg,transparent 60%,#4a9bff33 100%);--bp-art:"🏰"}
.bp-stylish.bp-notification-green{--bp-notice-bg:linear-gradient(110deg,#d6fbe8,#91edbb);--bp-notice-ink:#053d35;--bp-icon-bg:#d6fbe8;--bp-decor:radial-gradient(ellipse at 94% 100%,#19a56655 0 23%,transparent 24%),radial-gradient(ellipse at 4% 0%,#ffffff99 0 18%,transparent 19%);--bp-art:"🌿"}
.bp-stylish.bp-notification-orange{--bp-notice-bg:linear-gradient(110deg,#ffe7bd,#ff9e29);--bp-notice-ink:#9a2600;--bp-icon-bg:#ffe7bd;--bp-decor:radial-gradient(circle at 105% -40%,#fff8 0 43%,transparent 44%),repeating-radial-gradient(circle at 98% 115%,#ffffff55 0 2px,transparent 3px 11px);--bp-art:"📣"}
.bp-stylish.bp-notification-purple{--bp-notice-bg:linear-gradient(110deg,#5422c7,#a129ef);--bp-notice-ink:#fff;--bp-icon-bg:#5422c7;--bp-decor:repeating-radial-gradient(ellipse at 104% 140%,#ffffff24 0 2px,transparent 3px 15px);--bp-art:"🔔"}
.bp-stylish.bp-notification-pink{--bp-notice-bg:linear-gradient(110deg,#ffd4ea,#ff8cc5);--bp-notice-ink:#991451;--bp-icon-bg:#ffd4ea;--bp-decor:radial-gradient(circle at 93% 55%,#ffeffa 0 8%,transparent 9%),radial-gradient(circle at 86% 80%,#d9488b55 0 16%,transparent 17%);--bp-art:"🌸"}
.bp-stylish.bp-notification-elegant-gold{--bp-notice-bg:linear-gradient(110deg,#fff0bf,#f4bb4b);--bp-notice-ink:#76400c;--bp-icon-bg:#fff0bf;--bp-decor:repeating-radial-gradient(ellipse at 100% 155%,#bc8a2d55 0 2px,transparent 3px 12px);--bp-art:"★"}
.bp-stylish.bp-notification-night-blue{--bp-notice-bg:linear-gradient(110deg,#041532,#0a438a);--bp-notice-ink:#fff;--bp-icon-bg:#041532;--bp-decor:radial-gradient(circle at 92% 10%,#fff8 0 2px,transparent 3px),radial-gradient(ellipse at 100% 110%,#e6a74255 0 17%,transparent 18%);--bp-art:"🌙"}
.bp-stylish.bp-notification-sky{--bp-notice-bg:linear-gradient(110deg,#d5f4ff,#35aafa);--bp-notice-ink:#0c3479;--bp-icon-bg:#d5f4ff;--bp-decor:radial-gradient(ellipse at 90% 130%,#1377d3a8 0 27%,transparent 28%),radial-gradient(ellipse at 66% 150%,#ffffffa0 0 30%,transparent 31%);--bp-art:"ℹ"}
.bp-stylish.bp-notification-dark-elegant{--bp-notice-bg:linear-gradient(110deg,#121319,#252831);--bp-notice-ink:#fff1bd;--bp-icon-bg:#121319;--bp-decor:linear-gradient(130deg,transparent 73%,#f4c55a 74%,transparent 76%),linear-gradient(130deg,transparent 79%,#d49b30 80%,transparent 81%);--bp-art:"✦"}
.bp-stylish.bp-notification-red{--bp-notice-bg:linear-gradient(110deg,#ef122c,#ae0022);--bp-notice-ink:#fff;--bp-icon-bg:#ef122c;--bp-decor:repeating-radial-gradient(circle at 99% 80%,#ffffff24 0 1px,transparent 2px 9px);--bp-art:"❗"}
.bp-stylish.bp-notification-modern-teal{--bp-notice-bg:linear-gradient(110deg,#d4fbff,#3dd6df);--bp-notice-ink:#073a76;--bp-icon-bg:#d4fbff;--bp-decor:repeating-radial-gradient(circle at 101% 65%,#ffffff66 0 2px,transparent 3px 15px);--bp-art:"⬡"}
.bp-stylish.bp-notification-gradient-pro{--bp-notice-bg:linear-gradient(110deg,#008cf5,#bd25e6);--bp-notice-ink:#fff;--bp-icon-bg:#008cf5;--bp-decor:radial-gradient(ellipse at 98% 100%,#ff94aa 0 22%,transparent 23%),radial-gradient(ellipse at 0% 120%,#5239ff 0 24%,transparent 25%);--bp-art:"✨"}
.bp-stylish.bp-notification-diwali{--bp-notice-bg:linear-gradient(110deg,#ffdc73,#9d30a8);--bp-notice-ink:#fff8d4;--bp-icon-bg:#ffdc73;--bp-decor:radial-gradient(circle at 95% 15%,#ffe57d 0 3%,transparent 4%),radial-gradient(circle at 85% 80%,#ffe57d88 0 10%,transparent 11%);--bp-art:"🪔"}
.bp-stylish.bp-notification-eid{--bp-notice-bg:linear-gradient(110deg,#064c65,#07866c);--bp-notice-ink:#fff0bd;--bp-icon-bg:#064c65;--bp-decor:radial-gradient(circle at 90% 40%,#ffe9a4 0 10%,transparent 11%),radial-gradient(circle at 93% 34%,#07866c 0 9%,transparent 10%);--bp-art:"🌙"}
.bp-stylish.bp-notification-holi{--bp-notice-bg:linear-gradient(110deg,#ff8bc7,#ffdb64);--bp-notice-ink:#81216b;--bp-icon-bg:#ff8bc7;--bp-decor:radial-gradient(circle at 90% 80%,#45c5f1 0 17%,transparent 18%),radial-gradient(circle at 76% 5%,#ac56e2aa 0 13%,transparent 14%);--bp-art:"🎨"}
.bp-stylish.bp-notification-independence{--bp-notice-bg:linear-gradient(110deg,#ff9933,#138808);--bp-notice-ink:#102c6a;--bp-icon-bg:#ff9933;--bp-decor:linear-gradient(180deg,#ff9933 0 33%,#fff 33% 67%,#138808 67%);--bp-art:"🇮🇳"}
.bp-stylish.bp-notification-christmas{--bp-notice-bg:linear-gradient(110deg,#ad1735,#135c3b);--bp-notice-ink:#fff;--bp-icon-bg:#ad1735;--bp-decor:radial-gradient(circle at 90% 25%,#ffffff 0 2%,transparent 3%),radial-gradient(circle at 80% 85%,#ffd36688 0 10%,transparent 11%);--bp-art:"🎄"}
.bp-stylish.bp-notification-makar-sankranti{--bp-notice-bg:linear-gradient(110deg,#ffe2a2,#ffad35);--bp-notice-ink:#79350d;--bp-icon-bg:#ffe2a2;--bp-decor:linear-gradient(35deg,transparent 78%,#d65b18 79%,transparent 80%),radial-gradient(circle at 94% 35%,#fff5ca 0 14%,transparent 15%);--bp-art:"🪁"}
.bp-stylish.bp-notification-ganesh-chaturthi{--bp-notice-bg:linear-gradient(110deg,#ffca67,#ed7421);--bp-notice-ink:#7a2e0b;--bp-icon-bg:#ffca67;--bp-decor:radial-gradient(circle at 92% 70%,#f5d763 0 18%,transparent 19%);--bp-art:"🌺"}
.bp-stylish.bp-notification-navratri{--bp-notice-bg:linear-gradient(110deg,#8b214b,#e9982f);--bp-notice-ink:#fff;--bp-icon-bg:#8b214b;--bp-decor:repeating-conic-gradient(from 30deg at 95% 50%,#ffd46c44 0 14deg,transparent 15deg 30deg);--bp-art:"✨"}
.bp-stylish.bp-notification-raksha-bandhan{--bp-notice-bg:linear-gradient(110deg,#ffb4db,#b86adb);--bp-notice-ink:#6b1d67;--bp-icon-bg:#ffb4db;--bp-decor:radial-gradient(circle at 90% 50%,#fff0bf 0 12%,transparent 13%);--bp-art:"🎀"}
.bp-stylish.bp-notification-janmashtami{--bp-notice-bg:linear-gradient(110deg,#073b78,#199e9b);--bp-notice-ink:#fff4b8;--bp-icon-bg:#073b78;--bp-decor:radial-gradient(ellipse at 94% 65%,#33b3d7 0 18%,transparent 19%);--bp-art:"🦚"}
.bp-stylish.bp-notification-guru-nanak{--bp-notice-bg:linear-gradient(110deg,#13509b,#f7a344);--bp-notice-ink:#fff;--bp-icon-bg:#13509b;--bp-decor:radial-gradient(circle at 90% 50%,#ffdf77 0 14%,transparent 15%);--bp-art:"☀"}
.bp-stylish.bp-notification-rainbow-celebration{--bp-notice-bg:linear-gradient(110deg,#ff548f,#4a67e4);--bp-notice-ink:#fff;--bp-icon-bg:#ff548f;--bp-decor:linear-gradient(110deg,transparent 64%,#ffd85499 72%,#3bcda388 82%,#7b4be5aa 95%);--bp-art:"🎉"}
 @media(prefers-reduced-motion:reduce){.bp-notification-item{animation:none!important}}
 `;
 document.head.appendChild(style);
}
installNotificationStyles();

let bpNotificationTimer=null;
function startHomeSlides(){
 if(bpNotificationTimer){clearInterval(bpNotificationTimer);bpNotificationTimer=null}
 const noticeTrack=document.querySelector('.bp-notification-track');
 if(S.page==='home'&&noticeTrack){const messages=[...noticeTrack.querySelectorAll('.bp-notification-item')];if(messages.length>1){let index=0;bpNotificationTimer=setInterval(()=>{if(S.page!=='home'||document.hidden)return;messages[index].style.display='none';index=(index+1)%messages.length;messages[index].style.display='flex';messages[index].animate([{transform:'translateY(24px)',opacity:0},{transform:'translateY(0)',opacity:1}],{duration:450,easing:'ease-out'});},5000)}}

 if(homeSlidesTimer){clearInterval(homeSlidesTimer);homeSlidesTimer=null}
 if(S.page!=='home')return;
 const eligible=()=>[...document.querySelectorAll('[data-home-carousel]')].filter(el=>el.querySelectorAll('.home-landscape-slide').length>1);
 if(eligible().length && !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches))homeSlidesTimer=setInterval(()=>{
  if(S.page!=='home'||document.hidden)return;
  eligible().forEach(el=>displayHomeSlide(el,(S.homeSlidePositions[el.dataset.homeCarousel]||0)+1));
 },4800);
}
function cityNewsList(){
 const arr=S.cityItems.filter(x=>x.status==='published'&&['blogs','updates'].includes(x.type)).sort((a,b)=>(b.publishedAt?.seconds||b.createdAt?.seconds||0)-(a.publishedAt?.seconds||a.createdAt?.seconds||0));
 return `<div class="screen city-page">${head('News & Blog')}<div class="city-heading"><span>${icon('news',27)}</span><div><h1>News & Blog</h1><p>Published Baran city updates and articles</p></div></div>${S.cityLoading?'<div class="city-message">Loading published news and blogs...</div>':S.cityError?`<div class="city-message">${escapeHtml(S.cityError)}</div>`:arr.length?arr.map(x=>`<article class="city-list-card">${safeHttps(x.cover)?`<img src="${escapeHtml(safeHttps(x.cover))}" loading="lazy" alt="">`:`<div class="city-list-placeholder">${icon('news',32)}</div>`}<div class="city-list-text"><small>${x.type==='updates'?'City News':'Blog'} · ${escapeHtml(cityDate(x.publishedAt))}</small><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.summary||'')}</p><button data-city-detail="${escapeHtml(x.id)}">Read More →</button></div></article>`).join(''):'<div class="city-message">No published news or blogs yet.</div>'}</div>`;
}
async function openHomeCityList(section){
 if(section==='news'){
  S.cityError='';S.cityLoading=true;S.cityBackTarget='cityNews';go('cityNews');
  try{S.cityItems=C.enabled?await C.publicCity('updates').then(async updates=>[...updates,...await C.publicCity('blogs')]):[]}catch(e){S.cityError='Unable to load news and blogs.';console.warn(e)}
  finally{S.cityLoading=false;if(S.page==='cityNews')render()}
 }else{S.cityBackTarget='cityList';await openCity(section)}
}
function homeCityDetail(id){
 const x=S.homeCityItems.find(item=>item.id===id&&item.status==='published'&&item.showOnHomepage===true);
 if(!x)return toast('This information is no longer available');
 S.cityItems=S.homeCityItems;S.cityType=x.type;S.cityId=x.id;S.cityBackTarget='home';go('cityDetail');
}

function noticeAllowed(n){if(!n||n.active!==true)return false;const today=new Date().toISOString().slice(0,10);if(n.startDate&&n.startDate>today||n.endDate&&n.endDate<today)return false;const key='baran_notice_'+n.id;let rec={};try{rec=JSON.parse(localStorage.getItem(key)||'{}')}catch(e){}const mode=n.frequency||'once';if(mode==='always')return true;if(mode==='daily')return rec.day!==today;if(mode==='custom')return (rec.count||0)<Math.max(1,Number(n.maxShows)||1);return !rec.count}
function showNotice(){if(S.page!=='home'||S.noticeVisible)return;const n=S.notices.filter(noticeAllowed).sort((a,b)=>Number(b.priority||0)-Number(a.priority||0))[0];if(n){S.noticeVisible=n;render()}}
function dismissNotice(){const n=S.noticeVisible;if(!n)return;const key='baran_notice_'+n.id;let rec={};try{rec=JSON.parse(localStorage.getItem(key)||'{}')}catch(e){}rec.count=(rec.count||0)+1;rec.day=new Date().toISOString().slice(0,10);localStorage.setItem(key,JSON.stringify(rec));S.noticeVisible=null;render()}
function noticePopup(){const n=S.noticeVisible;if(!n)return '';return `<div class="notice-backdrop"><section class="notice-popup" role="dialog" aria-modal="true" aria-label="City Update"><div class="notice-popup-head"><strong>📣 CITY UPDATE</strong><button data-notice-close aria-label="Close notice">×</button></div>${/^https:\/\//.test(n.imageUrl||'')?`<img class="notice-image" src="${escapeHtml(n.imageUrl)}" alt="">`:''}<div class="notice-popup-copy"><h2>${escapeHtml(n.title||'City Update')}</h2><p>${escapeHtml(n.message||'')}</p></div>${n.phone&&/^\+?[0-9 -]{10,16}$/.test(n.phone)?`<button class="notice-confirm" data-notice-call="${escapeHtml(n.phone)}">☎ Call Now</button>`:''}<button class="notice-confirm" data-notice-close>✓ OK, Got It</button><small>BARAN PRIDE • Official Announcement</small></section></div>`}
function notificationStrip(){
 if(S.notificationSettings.enabled===false)return '';
 const items=S.sliderMessages.filter(n=>n.active===true);
 if(!items.length)return '';
 const theme=['purple','blue','orange','green','pink','red','yellow','sky','dark','tiranga','tiranga-wave','tiranga-border','tiranga-gradient','tiranga-brush','tiranga-chakra','fresh-green','modern-orange','premium-purple','soft-pink','elegant-gold','night-blue','dark-elegant','alert-red','modern-teal','gradient-pro','diwali','eid','holi','independence','christmas','makar-sankranti','ganesh-chaturthi','navratri','raksha-bandhan','janmashtami','guru-nanak','rainbow-celebration'].includes(S.notificationSettings.theme)?S.notificationSettings.theme:'purple';
 const safeColor=v=>/^#[0-9a-fA-F]{6}$/.test(String(v||''))?v:null; const bg=safeColor(S.notificationSettings.backgroundColor),ink=safeColor(S.notificationSettings.textColor),accent=safeColor(S.notificationSettings.iconColor); const vars=[bg?`--bp-notice-bg:${bg}`:'',ink?`--bp-notice-ink:${ink}`:'',accent?`--bp-notice-accent:${accent}`:''].filter(Boolean).join(';');
 return `<div class="bp-notification-strip bp-stylish bp-notification-${theme}" style="${vars}" aria-label="Baran Pride notifications"><span class="bp-notification-icon" style="${accent?`color:${accent}`:''}">${({"diwali":"🪔","eid":"🌙","holi":"🎨","independence":"🇮🇳","christmas":"🎄","makar-sankranti":"🪁","ganesh-chaturthi":"🌺","navratri":"✨","raksha-bandhan":"🎀","janmashtami":"🦚","guru-nanak":"☀","rainbow-celebration":"🎉","green":"🌿","orange":"📣","pink":"🌸","elegant-gold":"★","night-blue":"🌙","sky":"ℹ","dark-elegant":"✦","red":"❗","modern-teal":"⬡","gradient-pro":"✨"}[theme]||"🔔")}</span><div class="bp-notification-viewport"><div class="bp-notification-track">${items.map(n=>`<div class="bp-notification-item">${escapeHtml(n.text||'')}</div>`).join('')}</div></div><span class="bp-theme-arrow" aria-hidden="true">›</span></div>`;
}
function shutterBanner(){const b=S.shutterBanner||{},photo=safeHttps(b.imageUrl||'');if(!b.enabled||!photo)return '';const link=safeHttps(b.linkUrl||'');return `<section class="bp-shutter-banner" aria-label="Shutter reveal banner">${link?`<button type="button" class="bp-shutter-click" data-shutter-open aria-label="Open shutter banner link"><img src="${escapeHtml(photo)}" alt="Shutter banner"></button>`:`<img class="bp-shutter-image" src="${escapeHtml(photo)}" alt="Shutter banner">`}<span class="bp-shutter-panel left" aria-hidden="true"></span><span class="bp-shutter-panel right" aria-hidden="true"></span></section>`}
function bpEligiblePromotions(items){
 const now=Date.now();
 return (items||[]).filter(x=>{
  if(x.active!==true||!safeHttps(x.imageUrl||''))return false;
  const end=x.endDate||x.expiresAt||x.expiryDate||null;
  if(!end)return true;
  const ms=typeof end.toMillis==='function'?end.toMillis():Number.isFinite(end.__bpTimestampMs)?end.__bpTimestampMs:typeof end.seconds==='number'?end.seconds*1000:typeof end==='number'?end:Date.parse(end);
  return !Number.isFinite(ms)||ms>=now;
 });
}
function bpShufflePromotions(items){
 const arr=[...bpEligiblePromotions(items)];
 for(let i=arr.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[arr[i],arr[j]]=[arr[j],arr[i]]}
 const last=localStorage.getItem('baran_promo_previous')||'';
 if(arr.length>1&&arr[0].id===last){const first=arr.shift();arr.push(first)}
 if(arr[0])try{localStorage.setItem('baran_promo_previous',arr[0].id)}catch(e){}
 return arr;
}
function bpSetPromotionOrder(items){
 S.promotionOrder=bpShufflePromotions(items);
 S.promotionIndex=0;
 S.promotionSelected=S.promotionOrder[0]||null;
}
function bpCurrentPromotion(){return S.promotionOrder?.[S.promotionIndex]||null}
let bpPromotionTimer=null;
function bpShowPromotion(index){
 const track=document.querySelector('#bp-promo-track');
 if(!track||!S.promotionOrder?.length)return;
 const count=S.promotionOrder.length;
 S.promotionIndex=(index+count)%count;
 S.promotionSelected=bpCurrentPromotion();
 track.scrollTo({left:track.clientWidth*S.promotionIndex,behavior:'smooth'});
 document.querySelectorAll('[data-promo-dot]').forEach((dot,i)=>dot.classList.toggle('active',i===S.promotionIndex));
}
function bpStartPromotionSlider(){
 if(bpPromotionTimer){clearInterval(bpPromotionTimer);bpPromotionTimer=null}
 const track=document.querySelector('#bp-promo-track');
 if(S.page!=='home'||!track||S.promotionOrder.length<2)return;
 let paused=false,touchX=null;
 track.addEventListener('touchstart',e=>{paused=true;touchX=e.touches[0]?.clientX??null},{passive:true});
 track.addEventListener('touchend',e=>{
  const dx=touchX===null?0:(e.changedTouches[0]?.clientX??touchX)-touchX;
  if(Math.abs(dx)>30)bpShowPromotion(S.promotionIndex+(dx<0?1:-1));
  touchX=null;paused=false;
 },{passive:true});
 track.addEventListener('scroll',()=>{
  if(!track.clientWidth)return;
  const i=Math.round(track.scrollLeft/track.clientWidth);
  if(i>=0&&i<S.promotionOrder.length){
   S.promotionIndex=i;S.promotionSelected=bpCurrentPromotion();
   document.querySelectorAll('[data-promo-dot]').forEach((d,n)=>d.classList.toggle('active',n===i));
  }
 },{passive:true});
 if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;
 bpPromotionTimer=setInterval(()=>{
  if(S.page==='home'&&!document.hidden&&!paused)bpShowPromotion(S.promotionIndex+1);
 },3000);
}
function bpWarmPromotionImages(items){
 // Trigger the native public-image cache while online for every active promotion.
 for(const b of items){const url=safeHttps(b.imageUrl||'');if(url){const img=new Image();img.src=url}}
}
function bpSaveBannerSettings(){
 try{localStorage.setItem('bp_banner_settings_v1',JSON.stringify({heroImageUrl:S.heroImageUrl,shutterBanner:S.shutterBanner,savedAt:Date.now()}))}catch(e){}
}
function bpRestoreBannerSettings(){
 try{const v=JSON.parse(localStorage.getItem('bp_banner_settings_v1')||'null');if(v){S.heroImageUrl=safeHttps(v.heroImageUrl||'');S.shutterBanner=v.shutterBanner||{enabled:false,imageUrl:'',linkUrl:''}}}catch(e){}
}
function promotionBanner(){
 const items=S.promotionOrder||[];
 if(!items.length)return '';
 return `<section class="bp-promo bp-promo-slider" aria-label="Promotional banner slider"><div class="bp-promo-track" id="bp-promo-track">${items.map(b=>{
  const photo=safeHttps(b.imageUrl||'');
  return `<div class="bp-promo-slide"><button class="bp-promo-main" data-promo-detail="${escapeHtml(b.id)}" aria-label="Open banner details"><img src="${escapeHtml(photo)}" alt="${escapeHtml(b.title||'Promotional banner')}" onerror="this.onerror=null;this.style.visibility='hidden'"></button>${b.phone?`<button class="bp-promo-call" data-promo-call="${escapeHtml(b.id)}" aria-label="Call banner contact">${icon('phone',22)}</button>`:''}</div>`;
 }).join('')}</div>${items.length>1?`<div class="bp-promo-dots">${items.map((b,i)=>`<button type="button" data-promo-dot="${i}" class="${i===S.promotionIndex?'active':''}" aria-label="Show banner ${i+1}"></button>`).join('')}</div>`:''}</section>`;
}
function promotionDetail(){const b=S.promotionSelected;if(!b)return home();return `<div class="screen">${head('Featured Announcement')}<div class="bp-promo-detail">${safeHttps(b.imageUrl)?`<img src="${escapeHtml(safeHttps(b.imageUrl))}" alt="">`:''}<h1>${escapeHtml(b.title)}</h1><p>${escapeHtml(b.description||'')}</p>${b.phone?`<button class="primary-btn" data-promo-call="${escapeHtml(b.id)}">${icon('phone',19)} Call ${escapeHtml(b.phone)}</button>`:''}</div></div>`}
function aboutUs(){
 const features=[['store','Local Businesses','business'],['calendar','Events & Festivals','events'],['phone','Important Contacts','contacts'],['info','City Information','info']];
 const details=[['phone','Contact Number 1','+91 82333 66613','phone'],['phone','Contact Number 2','+91 77373 25205','phone'],['mail','Email Address','mansurbrn@gmail.com','email'],['globe','Official Website','www.itcampusbaran.in','web'],['pin','Office Address','Near Baba Phool Peer, Dol Mela Ground, Baran (Rajasthan) – 325205','address']];
 return `<div class="screen bp-about-v14">${head('About Us')}
 <section class="bp14-hero"><div class="bp14-monument">${icon('store',32)}</div><h1>BARAN PRIDE</h1><strong>हमारा शहर, हमारी पहचान</strong><p>Discover • Connect • Grow</p></section>
 <section class="bp14-card"><h2>About Baran Pride</h2><p>Baran Pride एक डिजिटल सिटी डायरेक्टरी प्लेटफॉर्म है, जिसका उद्देश्य बारां शहर के स्थानीय व्यवसायों, सेवाओं और महत्वपूर्ण जानकारियों को एक ही स्थान पर उपलब्ध कराना है।</p></section>
 <section class="bp14-card bp14-mission"><h2>Our Mission</h2><p>स्थानीय व्यापार को डिजिटल पहचान देना, लोगों को विश्वसनीय जानकारी से जोड़ना और बारां शहर के विकास में योगदान देना।</p></section>
 <section class="bp14-card"><h2>What We Provide</h2><div class="bp14-features">${features.map(([ic,title,cl])=>`<div class="bp14-feature bp14-${cl}">${icon(ic,25)}<strong>${title}</strong></div>`).join('')}</div></section>
 <section class="bp14-card"><h2>Our Organisation</h2><div class="bp14-org"><div class="bp14-orgitem"><span class="bp14-orgicon">${icon('store',24)}</span><div><strong>IT CAMPUS BARAN</strong><small>A Local Initiative for Our City</small></div></div><div class="bp14-orgitem"><span class="bp14-orgicon purple">${icon('user',24)}</span><div><small>Developed by</small><strong>IT CAMPUS</strong><small>Optimizing Website | Empowering Business</small></div></div></div></section>
 <section class="bp14-card"><h2>Contact Information</h2><div class="bp14-contacts">${details.map(([ic,label,value,cl])=>`<div class="bp14-contact"><span class="bp14-contacticon bp14-${cl}">${icon(ic,21)}</span><div><small>${label}</small><strong>${escapeHtml(value)}</strong></div></div>`).join('')}</div></section>
 <section class="bp14-card bp14-why"><h2>Why Choose Baran Pride?</h2>${['स्थानीय व्यवसायों की विश्वसनीय जानकारी','शहर की महत्वपूर्ण सेवाएँ एक ही स्थान पर','इवेंट्स, त्योहारों और शहर से जुड़ी जानकारियाँ','बारां के व्यापार और समुदाय के विकास में सहयोग'].map(t=>`<p><span class="bp14-check">✓</span>${t}</p>`).join('')}</section>
 <footer class="bp14-footer"><small>Designed & Developed by</small><strong>IT CAMPUS</strong><span>Optimizing Website | Empowering Business</span></footer></div>`;
}
function propertyIsVisible(x){if(!x||x.status!=='approved')return false;const t=x.expiresAt;const ms=typeof t?.seconds==='number'?t.seconds*1000:typeof t==='string'?Date.parse(t):0;return !ms||ms>Date.now()}
function propertyPhotoUrls(x){return [...new Set([...(Array.isArray(x.photoUrls)?x.photoUrls:[]),x.coverImage,x.coverUrl,x.imageUrl].map(safeHttps).filter(Boolean))]}
function propertyPrice(x){const n=Number(x.askingPrice||0);return n?'₹'+n.toLocaleString('en-IN'):'Price on request'}
function propertyTitle(x){return String(x.title||x.propertyName||x.propertyType||'Property')}
function propertyKind(x){return String(x.propertyType||'Property')}
function propertyDeal(x){return x.listingType==='Rent'?'For Rent':'For Sale'}
function propertyImage(x,cls='bp-property-hero-photo'){const url=propertyPhotoUrls(x)[0];return `<div class="${cls}">${url?`<img src="${escapeHtml(url)}" alt="${escapeHtml(propertyTitle(x))}" loading="lazy" onerror="this.style.display='none'">`:`<span class="bp-property-placeholder">${icon('property',52)}<small>Property photo coming soon</small></span>`}</div>`}
function propertyDarkInfo(x){return `<div class="bp-property-dark"><div class="bp-property-meta"><span class="bp-property-badge">${escapeHtml(propertyDeal(x))}</span><strong>${escapeHtml(propertyPrice(x))}</strong></div><h3>${escapeHtml(propertyTitle(x))}</h3><div class="bp-property-sub">${icon('pin',15)} ${escapeHtml(x.area||'Baran')} ${x.size?' · '+escapeHtml(x.size):''}</div></div>`}

// Marketplace Phase 1: public approved items only. No seller write actions until rules/admin are ready.
document.addEventListener('change',e=>{if(e.target?.id==='bp-market-sort'){S.marketplaceSort=e.target.value;render()}if(e.target?.id==='bp-market-search'){S.marketplaceSearch=e.target.value;render()}});
function bpMarketDate(v){if(v&&typeof v.toDate==='function')return v.toDate().getTime();if(v?.seconds)return v.seconds*1000;const n=Date.parse(v||'');return Number.isFinite(n)?n:0}
function bpMarketLive(x){return x?.status==='approved'&&x?.active!==false&&x?.isSold!==true}
function bpMarketPremium(x){return bpMarketLive(x)&&x.isPremium===true&&bpMarketDate(x.premiumExpiresAt)>Date.now()}
function bpMarketImages(x){return [...new Set([...(Array.isArray(x.images)?x.images:[]),...(Array.isArray(x.photoUrls)?x.photoUrls:[]),x.coverImage,x.imageUrl].map(safeHttps).filter(Boolean))]}
function bpMarketPrice(x){const n=Number(x.price);return Number.isFinite(n)&&n>=0?'₹'+n.toLocaleString('en-IN'):'Price on request'}
function bpMarketImage(x,cls){const u=bpMarketImages(x)[0];return `<div class="${cls}">${u?`<img src="${escapeHtml(u)}" alt="${escapeHtml(x.title||'Product')}" loading="lazy">`:`<span class="bp-property-placeholder">${icon('store',36)}<small>No photo</small></span>`}</div>`}
function bpMarketPair(){const a=S.marketplaceItems.filter(bpMarketPremium);if(!a.length){S.marketplacePair=[];return}const prev=S.marketplacePair.join('|');let choices=[];for(let i=0;i<a.length;i++)for(let j=i+1;j<a.length;j++)choices.push([a[i].id,a[j].id]);if(a.length===1)choices=[[a[0].id]];const other=choices.filter(x=>x.join('|')!==prev);const pool=other.length?other:choices;S.marketplacePair=pool[Math.floor(Math.random()*pool.length)]||[]}
function bpMarketHome(){
 return `<section class="bp-market-coming-home"><button class="bp-market-home-banner bp-market-coming-button" type="button" data-market-open aria-label="Buy and Sell Marketplace Coming Soon">
 <span class="bp-market-coming-icon">${icon('store',25)}</span>
 <span class="bp-market-coming-copy"><strong>BUY & SELL MARKETPLACE</strong><small>खरीदें और बेचें अपना सामान</small></span>
 <span class="bp-market-coming-arrow">${icon('arrow',20)}</span></button></section>`;
}
function bpMarketComingSoon(){
 return `<div class="screen city-page bp-market-coming-page">${head('Buy & Sell Marketplace')}
 <div class="bp-market-coming-panel"><div class="bp-market-coming-hero-icon">${icon('store',48)}</div>
 <h1>BUY & SELL MARKETPLACE</h1><span class="bp-market-coming-badge">COMING SOON</span>
 <h2>यह सेक्शन अगले अपडेट में उपलब्ध होगा!</h2>
 <p>जल्द ही आप Baran Pride पर मोबाइल, बाइक, फर्नीचर, इलेक्ट्रॉनिक्स और अन्य सामान खरीद व बेच सकेंगे।</p>
 <button class="primary-btn bp-market-coming-back" type="button" data-market-back-home>Back to Home</button>
 </div></div>`;
}
function bpMarketFiltered(){let a=S.marketplaceItems.filter(bpMarketLive);const q=S.marketplaceSearch.toLowerCase().trim();if(q)a=a.filter(x=>[x.title,x.description,x.location,x.category].some(v=>String(v||'').toLowerCase().includes(q)));if(S.marketplaceCategory!=='All')a=a.filter(x=>x.category===S.marketplaceCategory);return a.sort((x,y)=>S.marketplaceSort==='low'?Number(x.price||0)-Number(y.price||0):S.marketplaceSort==='high'?Number(y.price||0)-Number(x.price||0):S.marketplaceSort==='latest'?bpMarketDate(y.createdAt)-bpMarketDate(x.createdAt):Number(bpMarketPremium(y))-Number(bpMarketPremium(x))||bpMarketDate(y.createdAt)-bpMarketDate(x.createdAt))}
function bpMarketSellerForm(){
 if(!C.user){S.afterAuth='marketplaceSell';return auth()}
 return `<div class="screen city-page bp-market-seller">${head('Sell Your Item')}<h1 class="page-title">Sell Your Item</h1><p class="intro">Free listing · Unlimited validity · Admin approval required</p><form id="bp-market-sell-form" class="form-card">
 <div class="field"><label>Product Name *</label><input name="title" required minlength="3" maxlength="100"></div>
 <div class="field"><label>Category *</label><select name="category" required>${['Vehicles','Mobiles','Electronics','Furniture','Appliances','Books','Bicycles','Fashion','Others'].map(x=>`<option>${x}</option>`).join('')}</select></div>
 <div class="fieldrow"><div class="field"><label>Price (₹) *</label><input type="number" name="price" min="0" max="999999999" step="1" required></div><div class="field"><label>Condition *</label><select name="condition"><option>Used</option><option>New</option></select></div></div>
 <div class="field"><label>Location *</label><input name="location" maxlength="100" required placeholder="Area, Baran"></div>
 <div class="field"><label>Description *</label><textarea name="description" minlength="10" maxlength="2000" required></textarea></div>
 <div class="field"><label>Seller Name *</label><input name="sellerName" minlength="2" maxlength="100" required value="${escapeHtml(C.user.displayName||'')}"></div>
 <div class="field"><label>Mobile *</label><input name="sellerPhone" type="tel" inputmode="numeric" pattern="[6-9][0-9]{9}" maxlength="10" required></div>
 <div class="field"><label>Product Photos (up to 5)</label><input name="photos" type="file" accept="image/jpeg,image/png,image/webp" multiple><small>Each image must be under 5 MB.</small></div>
 <div class="field"><label><input type="checkbox" name="consent" required> I agree that my contact number will be public after approval.</label></div>
 <button class="primary-btn" type="submit" ${S.marketplaceSending?'disabled':''}>Submit for Approval</button><p id="bp-market-sell-message" class="fine-print"></p></form></div>`
}
function bpMarketMyPage(){
 if(!C.user){S.afterAuth='marketplaceMine';return auth()}
 return `<div class="screen city-page bp-market-my">${head('My Marketplace Listings')}<h1 class="page-title">My Listings</h1><button type="button" class="secondary-btn" data-market-my-refresh>Refresh My Listings</button><div class="bp-market-my-grid">${S.marketplaceMine.length?S.marketplaceMine.map(x=>`<article class="bp-market-my-card">${bpMarketImage(x,'bp-market-photo')}<h3>${escapeHtml(x.title||'Item')}</h3><strong>${escapeHtml(bpMarketPrice(x))}</strong><p>${x.isSold?'SOLD':escapeHtml(x.status||'pending')}</p>${x.status==='approved'&&!x.isSold?`<button class="secondary-btn" data-market-sold="${escapeHtml(x.id)}">Mark as Sold</button>`:''}</article>`).join(''):'<p class="city-message">No listings yet. Submit your first item!</p>'}</div></div>`
}
async function bpMarketMineLoad(){
 if(!C.user){S.marketplaceMine=[];return}
 try{S.marketplaceMine=await C.myMarketplace()}catch(e){console.warn('My Marketplace',e);toast('Could not load your listings')}
 if(S.page==='marketplaceMine')render()
}
async function bpMarketSubmit(form){
 if(S.marketplaceSending)return;
 const fd=new FormData(form),msg=form.querySelector('#bp-market-sell-message'),files=[...form.querySelector('[name=photos]').files];
 if(!fd.get('consent')){msg.textContent='Please confirm contact consent';return}
 if(!/^[6-9][0-9]{9}$/.test(String(fd.get('sellerPhone')||''))){msg.textContent='Enter valid mobile number';return}
 S.marketplaceSending=true;const btn=form.querySelector('[type=submit]');btn.disabled=true;msg.textContent='Submitting...';
 try{const d={};for(const k of ['title','category','condition','location','description','sellerName','sellerPhone'])d[k]=String(fd.get(k)||'').trim();d.price=Number(fd.get('price'));await C.submitMarketplace(d,files);toast('Listing sent for Admin approval');S.marketplaceMine=await C.myMarketplace();go('marketplaceMine')}
 catch(e){msg.textContent='Submission failed: '+String(e.message||e)}
 finally{S.marketplaceSending=false;btn.disabled=false}
}
async function bpMarketSold(id){
 const x=S.marketplaceMine.find(v=>v.id===id);
 if(!x||x.status!=='approved'||x.isSold)return;
 if(!confirm('Mark this item as SOLD? It will disappear from the public Marketplace.'))return;
 try{await C.markMarketplaceSold(id);S.marketplaceMine=await C.myMarketplace();S.marketplaceItems=S.marketplaceItems.filter(v=>v.id!==id);bpMarketPair();render();toast('Item marked as sold')}
 catch(e){toast('Could not mark sold: '+String(e.message||e))}
}
function bpMarketPage(){const a=bpMarketFiltered();const cats=['All',...new Set(S.marketplaceItems.filter(bpMarketLive).map(x=>String(x.category||'Others')))];return `<div class="screen city-page bp-market-page">${head('Buy & Sell Marketplace')}<div class="bp-market-title"><h1>Buy & Sell Marketplace</h1><p>Find items from sellers in Baran</p><div class="bp-market-seller-actions"><button type="button" class="primary-btn" data-market-sell-open>+ Sell Your Item</button><button type="button" class="secondary-btn" data-market-my-open>My Listings</button></div></div><div class="bp-market-search">${icon('search',18)}<input id="bp-market-search" value="${escapeHtml(S.marketplaceSearch)}" placeholder="Search products..."></div><div class="bp-market-cats">${cats.map(cat=>`<button type="button" class="${S.marketplaceCategory===cat?'active':''}" data-market-category="${escapeHtml(cat)}">${escapeHtml(cat)}</button>`).join('')}</div><div class="bp-market-toolbar"><span>${a.length} items</span><select id="bp-market-sort"><option value="premium" ${S.marketplaceSort==='premium'?'selected':''}>Premium First</option><option value="latest" ${S.marketplaceSort==='latest'?'selected':''}>Latest</option><option value="low" ${S.marketplaceSort==='low'?'selected':''}>Price: Low to High</option><option value="high" ${S.marketplaceSort==='high'?'selected':''}>Price: High to Low</option></select></div>${S.marketplaceError?`<p class="city-message">${escapeHtml(S.marketplaceError)}</p>`:''}${a.length?`<div class="bp-market-grid">${a.map(x=>`<button class="bp-market-card" data-market-detail="${escapeHtml(x.id)}">${bpMarketImage(x,'bp-market-photo')}<div class="bp-market-card-body">${bpMarketPremium(x)?'<span class="bp-market-premium">★ Premium</span>':''}<h3>${escapeHtml(x.title||'Item')}</h3><strong>${escapeHtml(bpMarketPrice(x))}</strong><small>${escapeHtml(x.location||'Baran')} · ${escapeHtml(x.condition||'')}</small></div></button>`).join('')}</div>`:'<p class="city-message">No available items yet. Approved listings will appear here.</p>'}<p class="bp-market-note">Sell Your Item will be available after seller submission and admin approval are enabled.</p></div>`}
function bpMarketDetail(){const x=S.marketplaceItems.find(x=>x.id===S.marketplaceId&&bpMarketLive(x));if(!x)return `<div class="screen city-page">${head('Item Details')}<p class="city-message">This listing is unavailable.</p></div>`;const photos=bpMarketImages(x);const phone=String(x.sellerPhone||'').replace(/\D/g,'');const valid=/^[6-9]\d{9}$/.test(phone);return `<div class="screen city-page bp-market-detail">${head('Item Details')}<div class="bp-market-gallery">${photos.length?photos.map(u=>`<img src="${escapeHtml(u)}" alt="${escapeHtml(x.title||'Item')}">`).join(''):`<div class="bp-market-no-photo">${icon('store',44)}</div>`}</div><div class="bp-market-detail-body">${bpMarketPremium(x)?'<span class="bp-market-premium">★ Premium</span>':''}<h1>${escapeHtml(x.title||'Item')}</h1><h2>${escapeHtml(bpMarketPrice(x))}</h2><p>${icon('pin',16)} ${escapeHtml(x.location||'Baran')}</p><div class="bp-market-facts"><span>Category: ${escapeHtml(x.category||'Others')}</span><span>Condition: ${escapeHtml(x.condition||'Not specified')}</span></div><h3>Description</h3><p>${escapeHtml(x.description||'No description provided.')}</p><h3>Seller</h3><p>${escapeHtml(x.sellerName||'Seller')}</p>${valid?`<div class="bp-market-contact"><button type="button" data-market-call="${phone}">${icon('phone',18)} Call Seller</button><button type="button" data-market-wa="${phone}">${icon('message',18)} WhatsApp</button></div>`:'<p>Seller contact not available.</p>'}</div></div>`}
async function bpMarketLoad(){try{S.marketplaceItems=await C.publicMarketplace();S.marketplaceError='';bpMarketPair()}catch(e){S.marketplaceError='Marketplace listings unavailable';console.warn(e)}}

function propertyHomeSection(){const items=S.properties.filter(x=>propertyIsVisible(x)).slice(0,4);if(!items.length)return '';return `<section class="bp-properties-home bp-properties-home-grid"><div class="bp-properties-head"><h2>${icon('property',22)} Properties in Baran</h2><button type="button" data-property-viewall>View All →</button></div><div class="bp-property-home-cards">${items.map(x=>`<button class="bp-property-home-card" type="button" data-property-open="${escapeHtml(x.id)}">${propertyImage(x,'bp-property-home-photo')}${propertyDarkInfo(x)}</button>`).join('')}</div></section>`}
function movePropertySlider(step=1,absolute=false){const track=document.querySelector('#bp-property-track');if(!track)return;const cards=[...track.children];if(!cards.length)return;S.propertySlideIndex=absolute?Math.max(0,Math.min(cards.length-1,step)):(S.propertySlideIndex+step+cards.length)%cards.length;track.scrollTo({left:cards[S.propertySlideIndex].offsetLeft-track.children[0].offsetLeft,behavior:'smooth'});document.querySelectorAll('.bp-property-dots button').forEach((b,i)=>b.classList.toggle('active',i===S.propertySlideIndex))}
let bpPropertyTimer=null;
function startPropertyCarousel(){if(bpPropertyTimer){clearInterval(bpPropertyTimer);bpPropertyTimer=null}if(S.page!=='home'||S.properties.filter(x=>propertyIsVisible(x)).length<=1)return;const track=document.querySelector('#bp-property-track');if(!track)return;let paused=false;track.addEventListener('touchstart',()=>{paused=true},{passive:true});track.addEventListener('touchend',()=>{paused=false},{passive:true});track.addEventListener('scroll',()=>{const cards=[...track.children];if(cards.length){S.propertySlideIndex=cards.reduce((best,card,i)=>Math.abs(card.offsetLeft-track.children[0].offsetLeft-track.scrollLeft)<Math.abs(cards[best].offsetLeft-track.children[0].offsetLeft-track.scrollLeft)?i:best,0);document.querySelectorAll('.bp-property-dots button').forEach((b,i)=>b.classList.toggle('active',i===S.propertySlideIndex))}},{passive:true});if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;bpPropertyTimer=setInterval(()=>{if(S.page==='home'&&!document.hidden&&!paused)movePropertySlider(1)},5500)}
function propertyFiltered(){let items=S.properties.filter(x=>propertyIsVisible(x));const f=S.propertyFilter;if(f==='Sale')items=items.filter(x=>x.listingType!=='Rent');else if(f==='Rent')items=items.filter(x=>x.listingType==='Rent');else if(f!=='All')items=items.filter(x=>propertyKind(x).toLowerCase().includes(f.toLowerCase()));if(S.propertySort==='low')items.sort((a,b)=>Number(a.askingPrice||0)-Number(b.askingPrice||0));else if(S.propertySort==='high')items.sort((a,b)=>Number(b.askingPrice||0)-Number(a.askingPrice||0));else items.sort((a,b)=>(b.publishedAt?.seconds||0)-(a.publishedAt?.seconds||0));return items}
function propertyListCard(x){return `<button type="button" class="bp-property-list-card" data-property-open="${escapeHtml(x.id)}">${propertyImage(x,'bp-property-list-photo')}${propertyDarkInfo(x)}</button>`}
function bpPropertyDisclaimer(){
 return `<section class="bp-property-disclaimer" aria-label="Property Safety and Disclaimer"><h3>⚠️ महत्वपूर्ण सूचना एवं अस्वीकरण (Property Safety &amp; Disclaimer)</h3><p>Baran Pride केवल प्रॉपर्टी की जानकारी एवं संपर्क उपलब्ध कराने वाला प्लेटफॉर्म है। यहाँ प्रकाशित प्रॉपर्टी की जानकारी संबंधित मालिक या अधिकृत व्यक्ति द्वारा दी जाती है।</p><p>Baran Pride प्रॉपर्टी के स्वामित्व, दस्तावेजों, कीमत, क्षेत्रफल, सुविधाओं, उपलब्धता या सौदे की सत्यता एवं वैधता की गारंटी नहीं देता। कोई भी निर्णय लेने से पहले प्रॉपर्टी, मालिक और संबंधित दस्तावेजों की स्वतंत्र जाँच करें।</p><p><strong>सुरक्षा संबंधी सावधानी:</strong> प्रॉपर्टी देखे और आवश्यक सत्यापन किए बिना अग्रिम राशि या टोकन न दें। OTP, Password, बैंक विवरण या संवेदनशील दस्तावेज अनजान व्यक्तियों के साथ साझा न करें।</p><p>प्रॉपर्टी से संबंधित विवाद, धोखाधड़ी या आर्थिक नुकसान की स्थिति में संबंधित पक्षों की जिम्मेदारी लागू कानूनों के अनुसार निर्धारित होगी। Baran Pride किसी सौदे के पूरा होने की गारंटी नहीं देता।</p><label class="bp-property-disclaimer-consent"><input type="checkbox" data-property-disclaimer-consent> <span>मैंने उपरोक्त शर्तें एवं सावधानियाँ पढ़ ली हैं और समझकर स्वीकार करता/करती हूँ।</span></label><p class="bp-property-consent-hint" data-property-consent-hint>Call या WhatsApp खोलने से पहले सहमति दें।</p></section>`;
}
function bpPropertyConsentAccepted(button){return !!button.closest('.bp-property-detail-body')?.querySelector('[data-property-disclaimer-consent]:checked')}
function propertyDetailPage(){const x=S.properties.find(p=>p.id===S.propertyId&&propertyIsVisible(p));if(!x)return `<div class="screen city-page">${head('Property Details')}<p class="city-message">This property is not available.</p></div>`;const photos=propertyPhotoUrls(x);const selected=photos.length?photos[S.propertyPhotoIndex%photos.length]:'';const features=Array.isArray(x.features)?x.features:[];const contact=x.contactMode==='owner'&&validPhone(x.publicContactPhone)?x.publicContactPhone:S.helpline;return `<div class="screen city-page">${head('Property Details')}<div class="bp-property-detail-gallery"><div class="bp-property-detail-image">${selected?`<img src="${escapeHtml(selected)}" alt="Property photo" onerror="this.style.display='none'">`:`<span class="bp-property-placeholder">${icon('property',56)}<small>No property photos yet</small></span>`}</div>${photos.length>1?`<div class="bp-property-gallery-nav"><button data-property-photo="-1">‹ Previous</button><span>${S.propertyPhotoIndex%photos.length+1} / ${photos.length}</span><button data-property-photo="1">Next ›</button></div>`:''}</div><article class="bp-property-detail-info">${propertyDarkInfo(x)}<div class="bp-property-detail-body"><h2>Property Information</h2><div class="bp-property-facts"><span>${icon('property',17)} ${escapeHtml(propertyKind(x))}</span>${x.size?`<span>${icon('sliders',17)} ${escapeHtml(x.size)}</span>`:''}<span>${icon('pin',17)} ${escapeHtml(x.area||'Baran')}</span></div>${x.description?`<h2>About This Property</h2><p>${escapeHtml(x.description)}</p>`:''}${features.length?`<h2>Property Features</h2><div class="bp-property-features">${features.map(f=>`<span>✓ ${escapeHtml(f)}</span>`).join('')}</div>`:''}${bpPropertyDisclaimer()}<h2>Contact ${x.contactMode==='owner'&&validPhone(x.publicContactPhone)?'Owner':'Customer Care'}</h2><div class="bp-property-contact-actions"><button class="primary-btn" disabled data-property-call="${escapeHtml(x.id)}">${icon('phone',18)} Call</button><button class="bp-property-whatsapp" disabled data-property-whatsapp="${escapeHtml(x.id)}">${icon('message',18)} WhatsApp</button></div><p class="bp-property-privacy">Contact is selected by Baran Pride Admin. Owner name is private.</p></div></article></div>`}
function bpDealDate(v){const s=String(v||'');return /^\d{4}-\d{2}-\d{2}$/.test(s)?s.slice(8,10)+'-'+s.slice(5,7)+'-'+s.slice(0,4):s;}
function offerActive(o){const today=new Date().toISOString().slice(0,10);return o.status==='published'&&(!o.startDate||o.startDate<=today)&&(!o.endDate||o.endDate>=today)}
function dealIcon(o){const c=String(o.category||'General').toLowerCase();return c.includes('fashion')?'shirt':c.includes('food')?'utensils':c.includes('electronic')?'phone':c.includes('education')?'book':c.includes('health')?'heart':c.includes('shopping')?'store':'gift'}
function dealMedia(o,cls='bp-deal-cover'){const url=safeHttps(o.imageUrl||'');return `<div class="${cls}">${url?`<img src="${escapeHtml(url)}" loading="lazy" alt="${escapeHtml(o.title||'Deal')}" onerror="this.hidden=true;this.nextElementSibling.hidden=false"><span class="bp-deal-icon" hidden>${icon(dealIcon(o),38)}</span>`:`<span class="bp-deal-icon">${icon(dealIcon(o),38)}</span>`}</div>`}
function offerCard(o){
 const count=Array.isArray(o.subOffers)?o.subOffers.length:0;
 const premium=bpDealPremium(o);
 const validity=o.endDate?`<span class="bp-ref-valid">${icon('calendar',15)} Valid till: ${escapeHtml(bpDealDate(o.endDate))}</span>`:'';
 return `<button class="bp-deal-card bp-ref-card" type="button" data-offer-open="${escapeHtml(o.id)}" aria-label="View ${escapeHtml(o.title||'Deal & Offer')}">
 <span class="bp-ref-media">${dealMedia(o)}<span class="bp-ref-tier ${premium?'is-premium':'is-free'}">${premium?'♛ Premium':'Free'}</span>${o.discount?`<span class="bp-ref-discount">${escapeHtml(o.discount)}</span>`:''}</span>
 <span class="bp-deal-card-body bp-ref-body">
 <span class="bp-ref-shop">${icon('store',20)} <span><b>${escapeHtml(o.businessName||'Local Business')}</b><small>${escapeHtml(o.category||'Local Deal')} • Baran</small></span></span>
 <strong>${escapeHtml(o.title||'Special Deal & Offer')}</strong>
 ${validity}${count?`<span class="bp-ref-count">${count} Offers</span>`:''}
 <span class="bp-ref-chevron" aria-hidden="true">›</span>
 </span></button>`;
}
function offersSection(){
 const list=S.offers.filter(o=>offerActive(o)&&o.featured===true).sort((a,b)=>(Number(a.displayOrder??100)-Number(b.displayOrder??100)));
 if(!list.length)return '';
 return `<section class="bp-featured-deals" aria-label="Featured Deals and Offers"><div class="bp-offers-head"><div><h2>Featured Deals & Offers</h2></div><button type="button" data-offers-all>View All →</button></div><div class="bp-featured-deals-track" id="bp-featured-deals-track">${list.map(o=>`<button type="button" class="bp-featured-deal-slide" data-offer-open="${escapeHtml(o.id)}" aria-label="View ${escapeHtml(o.title||'Featured Deal')}">${dealMedia(o,'bp-featured-deal-media')}<span class="bp-featured-deal-caption"><strong>${escapeHtml(o.title||'Special Deal')}</strong><small>${escapeHtml(o.businessName||'Local Business')}</small>${o.discount?`<em>${escapeHtml(o.discount)}</em>`:''}</span></button>`).join('')}</div>${list.length>1?`<div class="bp-featured-deals-dots">${list.map((_,i)=>`<button type="button" data-featured-deal-dot="${i}" class="${i===0?'active':''}" aria-label="Show featured deal ${i+1}"></button>`).join('')}</div>`:''}</section>`;
}
let bpFeaturedDealsTimer=null;
function bpStartFeaturedDealsSlider(){
 if(bpFeaturedDealsTimer){clearInterval(bpFeaturedDealsTimer);bpFeaturedDealsTimer=null}
 const track=document.querySelector('#bp-featured-deals-track');
 if(S.page!=='home'||!track||track.children.length<2)return;
 let paused=false;
 const update=()=>{const index=Math.round(track.scrollLeft/Math.max(1,track.clientWidth));document.querySelectorAll('[data-featured-deal-dot]').forEach((el,i)=>el.classList.toggle('active',i===index))};
 track.addEventListener('scroll',update,{passive:true});
 track.addEventListener('touchstart',()=>{paused=true},{passive:true});
 track.addEventListener('touchend',()=>{paused=false},{passive:true});
 if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;
 bpFeaturedDealsTimer=setInterval(()=>{if(S.page!=='home'||document.hidden||paused||!track.isConnected)return;const next=(Math.round(track.scrollLeft/Math.max(1,track.clientWidth))+1)%track.children.length;track.scrollTo({left:next*track.clientWidth,behavior:'smooth'})},4000);
}

// Warm only public, currently published Deals images when the user opens Deals.
// The Android WebView's native public-image interceptor persists eligible Firebase images.
function bpWarmDealImages(detailOnly=false){
 const items=detailOnly?S.offers.filter(o=>o.id===S.offerId&&offerActive(o)):S.offers.filter(offerActive);
 const urls=items.flatMap(o=>[o.imageUrl||'',...(Array.isArray(o.subOffers)?o.subOffers.map(x=>x.imageUrl||''):[])]);
 bpWarmImages(urls,Number.MAX_SAFE_INTEGER);
}
function bpDealPremium(o){return o.featured===true||o.premium===true||o.isPremium===true}
function bpDealSort(list){return [...list].sort((a,b)=>Number(bpDealPremium(b))-Number(bpDealPremium(a))||Number(a.displayOrder??100)-Number(b.displayOrder??100)||String(b.createdAt?.seconds||b.createdAt||'').localeCompare(String(a.createdAt?.seconds||a.createdAt||'')))}
function bpFilteredDeals(){return bpDealSort(S.offers.filter(offerActive).filter(o=>(!S.dealFilter||S.dealFilter==='All'||String(o.category||'Other').trim()===S.dealFilter)&&(!S.dealSearch||[o.title,o.businessName,o.discount,o.category,o.description].join(' ').toLowerCase().includes(S.dealSearch.toLowerCase()))))}
function bpDealCategoryColor(name){const c=String(name||'').toLowerCase();if(/food|restaurant|cafe|खाना/.test(c))return 'food';if(/shop|fashion|cloth|shopping|कपड़/.test(c))return 'shopping';if(/beauty|salon|parlour|spa/.test(c))return 'beauty';if(/educat|school|class|course|coaching/.test(c))return 'education';if(/electro|mobile|computer|phone/.test(c))return 'electronics';return 'general'}
let bpDealsView='premium';
function bpDealsStickyHeader(title,search=true){return `<div class="bp-deals-sticky"><div class="bp-deals-sticky-title">${head(title)}</div>${search?`<label class="bp-deals-search">${icon('search',18)}<input id="bp-deals-search" type="search" aria-label="Search Deals & Offers" placeholder="Search Deals & Offers and shops..." value="${escapeHtml(S.dealSearch||'')}"></label>`:''}</div>`}
function bpDealCategories(live){return [...new Set([...(Array.isArray(S.offerCategories)?S.offerCategories.filter(c=>c.active!==false).map(c=>String(c.name||'').trim()):[]),...live.map(o=>String(o.category||'General').trim())].filter(Boolean).filter(n=>!(Array.isArray(S.offerCategories)&&S.offerCategories.some(c=>c.name===n&&c.active===false))))].sort((a,b)=>a.localeCompare(b))}
function bpDealCategoryButtons(categories){return categories.map(c=>`<button type="button" class="bp-lav-category" data-deal-filter="${escapeHtml(c)}"><span class="bp-lav-category-icon bp-cat-${bpDealCategoryColor(c)}">${icon(dealIcon({category:c}),23)}</span><strong>${escapeHtml(c)}</strong></button>`).join('')}
function offersAll(){
 const live=S.offers.filter(offerActive),categories=bpDealCategories(live);
 if(S.dealFilter&&S.dealFilter!=='All'&&!categories.includes(S.dealFilter))S.dealFilter='All';
 const selected=S.dealFilter||'All',allView=bpDealsView==='all',matches=bpFilteredDeals().filter(o=>allView||bpDealPremium(o));
 const premium=matches.filter(bpDealPremium);
 const catButtons=bpDealCategoryButtons(categories);
 const filterButtons=`<div class="bp-market-cats bp-ref-filters"><button type="button" class="${selected==='All'?'active':''}" data-deal-filter="All">All</button>${categories.map(c=>`<button type="button" class="${selected===c?'active':''}" data-deal-filter="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('')}</div>`;
 return `<div class="screen city-page bp-deals-page bp-lav-page bp-ref-page">${bpDealsStickyHeader(allView?'All Deals & Offers':'Deals & Offers')}
 <div class="bp-deals-content">
 ${allView?`${filterButtons}<section class="bp-lav-results"><div class="bp-deals-toolbar"><div><strong>All Available Deals & Offers</strong><small>${matches.length} Deals & Offers available</small></div><span class="bp-ref-sort">Premium First</span></div><div class="bp-deal-grid">${S.offersLoadError?`<div class="city-message">${escapeHtml(S.offersLoadError)} <button type="button" data-offers-refresh>Retry</button></div>`:''}${matches.map(offerCard).join('')||'<div class="city-message bp-deals-empty">No matching Deals & Offers right now.</div>'}</div></section>`:
 `<section class="bp-ref-intro"><div><h1>🎁 Deals & Offers</h1><p>Baran के बेहतरीन Deals और Special Offers</p></div><span aria-hidden="true">🏷️</span></section>
 <section class="bp-lav-premium"><div class="bp-lav-section-title"><div><h2>👑 Premium Deals & Offers</h2></div></div><div class="bp-lav-grid bp-deals-premium-list">${premium.map(offerCard).join('')||'<p class="bp-lav-empty">No matching Premium Deals & Offers right now.</p>'}</div></section>
 <button type="button" class="primary-btn bp-ref-show-all" data-deals-show-all>Show All Deals & Offers ❯</button>
 <section class="bp-lav-categories"><div class="bp-lav-section-title"><div><h2>Browse by Category</h2></div></div><div class="bp-lav-category-grid">${catButtons||'<p class="bp-lav-empty">No categories yet.</p>'}</div></section>`}
 </div></div>`;
}
function bpRefreshDealsSearch(){
 const allView=bpDealsView==='all',list=bpFilteredDeals().filter(o=>allView||bpDealPremium(o));
 const target=document.querySelector(allView?'.bp-deal-grid':'.bp-deals-premium-list');
 if(target)target.innerHTML=list.map(offerCard).join('')||`<div class="city-message bp-deals-empty">No matching Deals & Offers right now.</div>`;
 const counter=document.querySelector('.bp-deals-toolbar small');if(counter)counter.textContent=list.length+' Deals & Offers available';
}
function offerDetail(){const o=S.offers.find(x=>x.id===S.offerId&&offerActive(x));if(!o)return `<div class="screen city-page">${bpDealsStickyHeader('Deal Details',false)}<div class="city-message">This deal is no longer available.</div></div>`;const linked=S.businesses.find(b=>b.id===o.businessId&&b.status==='approved'&&!b.hidden&&b.visible!==false);const map=safeHttps(o.mapUrl);const subs=Array.isArray(o.subOffers)?o.subOffers:[];return `<div class="screen city-page bp-deal-detail-page">${bpDealsStickyHeader('Deal Details',false)}<article class="bp-deal-detail">${dealMedia(o,'bp-deal-detail-cover')}<div class="bp-deal-detail-body"><span class="bp-detail-eyebrow">${bpDealPremium(o)?'✦ PREMIUM OFFER':'✦ LOCAL OFFER'}</span><div class="bp-detail-tags"><span class="bp-deal-category">${escapeHtml(o.category||'Local Deal')}</span><span class="bp-deal-discount">${escapeHtml(o.discount||'Special Deal')}</span></div><h1>${escapeHtml(o.title)}</h1><p class="bp-deal-shop">${icon('store',16)} ${escapeHtml(o.businessName||'Local Business')}</p><p>${escapeHtml(o.description||'')}</p><p class="bp-deal-valid">${icon('calendar',15)} ${escapeHtml(bpDealDate(o.startDate))} ${o.endDate?'– '+escapeHtml(bpDealDate(o.endDate)):''}</p>${subs.length?`<h2 class="bp-deal-section-heading">Available Offers <span>${subs.length}</span></h2><div class="bp-deal-sub-list">${subs.map(x=>`<div class="bp-deal-sub">${dealMedia({...x,category:o.category},'bp-deal-sub-media')}<div class="bp-deal-sub-copy"><strong>${escapeHtml(x.title||'Offer')}</strong><span class="bp-deal-discount">${escapeHtml(x.discount||'Special Offer')}</span><div class="bp-deal-prices">${x.originalPrice?`<del>₹${escapeHtml(x.originalPrice)}</del>`:''}${x.offerPrice?`<b>₹${escapeHtml(x.offerPrice)}</b>`:''}</div>${x.description?`<p>${escapeHtml(x.description)}</p>`:''}</div></div>`).join('')}</div>`:''}${o.terms?`<h3>Terms & Conditions</h3><p>${escapeHtml(o.terms)}</p>`:''}${o.address?`<p>${icon('pin',16)} ${escapeHtml(o.address)}</p>`:''}<div class="bp-offer-actions">${o.phone?`<button class="primary-btn" data-offer-call="${escapeHtml(o.id)}">${icon('phone',18)} Call</button><button class="secondary-btn" data-offer-whatsapp="${escapeHtml(o.id)}">WhatsApp</button>`:''}${map?`<button class="secondary-btn" data-offer-map="${escapeHtml(o.id)}">${icon('pin',18)} Map</button>`:''}${linked?`<button class="secondary-btn" data-offer-business="${escapeHtml(linked.id)}">View Business Profile</button>`:''}</div></div></article></div>`}
function homeQuickAccess(){
 const items=[
  ['updates','City Updates','news','updates'],
  ['properties','Buy/Sell Property','home','properties'],
  ['deals','Deals & Offers','gift','offersAll'],
  ['contacts','Important Contacts','phone','contacts'],
  ['jobs','Local Jobs','briefcase','jobs']
 ];
 return `<nav class="bp-quick-access" style="background:linear-gradient(120deg,#102A63,#2455A4)!important;border-color:#2455A4!important" aria-label="Explore Baran quick access"><div class="bp-quick-access-title">Explore Baran</div><div class="bp-quick-access-row">${items.map(([id,label,ico,target])=>`<button type="button" class="bp-quick-access-item bp-quick-${id}" ${id==='jobs'||id==='properties'||id==='deals'?`data-special="${id}"`:`data-city-type="${target}"`} aria-label="${label}"><span class="bp-quick-access-icon">${icon(ico,22)}</span><span class="bp-quick-access-label">${label}</span></button>`).join('')}</div></nav>`;
}
function home(){const featured=S.businesses.filter(b=>isPremium(b)).sort(prioritySort).slice(0,10);const latest=[...S.businesses].slice(-8).reverse();return `<div class="screen"><div class="topbar" id="bp-home-header">${brand()}<div class="top-actions"><button class="round-btn bp-support bp-support-profile-style" data-customer-care aria-label="Chat with Baran Pride on WhatsApp" title="WhatsApp Chat"><span aria-hidden="true">✆</span></button><button class="round-btn city-menu-toggle" data-menu-open aria-label="City information menu">${icon('menu')}</button></div></div><div id="bp-offline-progress" class="bp-offline-progress" hidden></div>${banner()}${notificationStrip()}${shutterBanner()}<section class="hero" ${S.heroImageUrl?`style="background-image:linear-gradient(90deg,rgba(12,50,106,.85),rgba(12,50,106,.32)),url('${escapeHtml(S.heroImageUrl)}')"`:''}><p class="location">${icon('pin',14)} Baran, Rajasthan</p><h1>Discover the<br>Best of Baran</h1><p class="subline">Find local businesses,<br>shops & services</p><form class="hero-search" id="hero-form">${icon('search',23)}<input id="hero-q" name="q" placeholder="Search businesses, services, places..." autocomplete="off" aria-label="Search"><button class="filter" type="submit" aria-label="Search">${icon('sliders')}</button></form></section>${homeQuickAccess()}${promotionBanner()}<section class="categories">${[...categories].sort((a,b)=>a[0]==='More'?1:b[0]==='More'?-1:a[0].localeCompare(b[0],'en')).map(([c,i])=>`<button class="cat" data-category="${c}"><span class="cat-icon">${icon(i,25)}</span><span>${c}</span></button>`).join('')}</section>${propertyHomeSection()}${homepageSlider('events','Events & Festivals','calendar')}<section class="grow"><span class="grow-icon">${icon('store',39)}</span><div class="grow-copy"><strong>Grow Your Business</strong><p>Get listed in Baran Pride and reach more customers</p></div><button class="pill-cta" data-go="add">Add Business →</button></section>${section('<span class="star">★</span> Featured Businesses','featuredBusinesses')}<div class="featured-strip">${featured.map(bizCard).join('')||'<p class="intro">Featured businesses will appear here when available.</p>'}</div>${homepageSlider('historical','Historical Places','temple')}${bpMarketHome()}${homepageNews()}<div class="bp-love-baran" aria-label="With Love, from Baran"><span>With Love,</span><span>from <span class="bp-love-heart">❤️</span>Baran</span></div></div>${noticePopup()}`}
function empty(title,desc,action,label){return `<div class="empty"><div style="color:#2f67ac">${icon('store',48)}</div><h3>${title}</h3><p>${desc}</p>${action?`<button class="primary-btn" data-go="${action}">${label||'Get Started'}</button>`:''}</div>`}
function featuredBusinesses(){const arr=S.businesses.filter(b=>isPremium(b)).sort(prioritySort);return `<div class="screen"><h1 class="page-title">★ Featured Businesses</h1><p class="intro">Explore featured businesses in Baran</p><p class="result-count">${arr.length} featured business${arr.length===1?'':'es'}</p>${arr.length?arr.map(b=>`<article class="listing-card">${businessImage(b,` alt=""`)}<main><h3>${businessName(b)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p><p>★ Featured</p><div class="row-actions"><button class="primary-small" data-detail="${b.id}">View Details</button><button class="outline-small" data-save="${b.id}">${S.saved.has(b.id)?'♥ Saved':'♡ Save'}</button></div></main></article>`).join(''):empty('No featured businesses','Featured businesses will appear here when available.')}</div>`}
function eventsTab(){return cityList()}
// Native network check is more reliable than navigator.onLine inside Android WebView.
function bpIsInternetAvailable(){
 try{if(window.AndroidBridge&&typeof AndroidBridge.isInternetAvailable==='function')return AndroidBridge.isInternetAvailable()===true}catch(e){}
 return navigator.onLine!==false;
}
function bpCategoryOfflineNotice(){
 if(S.category==='All'||bpIsInternetAvailable())return '';
 return `<section class="bp-category-offline" role="status" aria-live="polite"><div class="bp-category-offline-icon">${icon('wifi-off',30)}</div><h2>Connect to Internet</h2><p>इस Category की Listings अभी Offline उपलब्ध नहीं हैं। Internet ON करके दोबारा कोशिश करें।</p><button type="button" class="bp-category-retry" data-category-retry>${icon('refresh',17)} Retry</button></section>`;
}
function explore(){const arr=filtered();return `<div class="screen"><h1 class="page-title">Explore Baran</h1><p class="intro">Find the right shops, services and professionals</p>${banner()}<div class="search-bar">${icon('search')}<input id="explore-q" value="${escapeHtml(S.query)}" placeholder="Search business, category or area..."></div><div class="chipbar">${['All',...allBusinessCategories()].map(c=>`<button class="chip ${S.category===c?'selected':''}" data-category="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('')}</div><p class="result-count">${arr.length} business${arr.length===1?'':'es'} found</p>${arr.length?arr.map(b=>`<article class="listing-card">${businessImage(b,` alt=""`)}<main><h3>${businessName(b)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p><p>${b.rating?'★ '+b.rating+' · ':''}${b.featured?'Featured':'Local Business'}</p><div class="row-actions"><button class="primary-small" data-detail="${b.id}">View Details</button><button class="outline-small" data-save="${b.id}">${S.saved.has(b.id)?'♥ Saved':'♡ Save'}</button></div></main></article>`).join(''):(bpCategoryOfflineNotice()||empty('No businesses found','Try another search or select a different category.'))}</div>`}
function detail(){const b=findBiz(S.detail);if(!b)return explore();return `<div class="screen">${head('Business Details')}<img class="detail-photo" src="${escapeHtml(businessCover(b))}" alt="${escapeHtml(b.name)}"><div class="detail-head"><div><h1>${businessName(b)}</h1><p>${escapeHtml(businessCategories(b).join(', '))} · ${escapeHtml(b.area)}, Rajasthan</p></div><button class="round-btn" data-save="${b.id}" aria-label="Save business" style="color:${S.saved.has(b.id)?'#d64c69':''}">${icon('heart',23)}</button></div>${b.demo?banner():''}<div class="detail-actions"><button data-call="${b.id}">${icon('phone',23)}Call</button><button data-wa="${b.id}">${icon('message',23)}WhatsApp</button><button ${businessMapLink(b)?`data-map="${escapeHtml(b.id)}"`:'disabled aria-disabled="true"'}>${icon('pin',23)}Directions</button></div><h3 class="block-title">About Business</h3><div class="info-panel"><p style="font-size:13px;line-height:1.65;color:#425a7b;margin:0">${escapeHtml(b.description||'Explore this business in Baran.')}</p></div>${weeklyDisplay(b.weeklyHours)}<h3 class="block-title">Contact & Location</h3><div class="info-panel"><div class="info-row">${icon('pin')}<span>${escapeHtml(b.address||'Baran, Rajasthan')}</span></div><div class="info-row">${icon('clock')}<span>${escapeHtml(b.hours||'Contact business for opening hours')}</span></div><div class="info-row">${icon('phone')}<span>${escapeHtml(b.phone||'Not provided')}</span></div><button type="button" class="bp-business-map-preview" ${businessMapLink(b)?`data-map="${escapeHtml(b.id)}" aria-label="Open business location in Google Maps"`:`disabled aria-disabled="true" aria-label="Google Maps location unavailable"`}><img src="img/business-map-location.svg" alt="Google Maps Location" draggable="false"></button></div>${Array.isArray(b.photoUrls)&&b.photoUrls.length>1?`<div class="business-gallery">${b.photoUrls.slice(0,isPremium(b)?5:2).filter(u=>/^https:\/\//.test(u)).map(u=>`<img src="${escapeHtml(u)}" alt="${escapeHtml(b.name)}" loading="lazy">`).join('')}</div>`:''}<div class="detail-actions"><button data-share="${b.id}">${icon('share')}Share</button><button data-save="${b.id}">${icon('heart')}Save</button><button data-go="explore">${icon('search')}Explore</button></div></div>`}
function saved(){const arr=S.businesses.filter(b=>S.saved.has(b.id));return `<div class="screen"><h1 class="page-title">Saved Businesses</h1><p class="intro">Quickly find your favorite places</p>${arr.length?arr.map(b=>`<article class="listing-card">${businessImage(b,` alt=""`)}<main><h3>${businessName(b)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p><div class="row-actions"><button data-detail="${b.id}" class="primary-small">View Details</button><button data-save="${b.id}" class="outline-small">Remove</button></div></main></article>`).join(''):empty('No saved businesses','Save your favourite places to find them quickly.','explore','Explore Businesses')}</div>`}
function owner(){if(C.enabled&&!C.user)return `<div class="screen"><h1 class="page-title">My Business</h1><p class="intro">Manage your business listings</p>${empty('Sign in to manage listings','Sign in or register to add and view your businesses.','auth','Sign in / Register')}</div>`;
 return `<div class="screen"><h1 class="page-title">My Business</h1><p class="intro">Manage your listings and approval status</p>${!C.enabled?banner():''}<button class="primary-btn" data-go="add">${icon('plus',19)} Add New Business</button>${S.owned.length?S.owned.map(b=>`<article class="owner-card"><div style="display:flex;justify-content:space-between;align-items:flex-start;gap:9px"><div><h3>${businessName(b)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p></div><span class="status ${b.status||'pending'}">${escapeHtml(b.status||'pending').toUpperCase()}</span></div><div class="owner-statrow"><div class="stat"><small>Listing Plan</small><strong style="font-size:17px">${escapeHtml(b.plan||'Free')}</strong></div><div class="stat"><small>Payment</small><strong style="font-size:17px">${escapeHtml(b.paymentStatus||'Unpaid')}</strong></div></div><p><b>Validity:</b> ${b.expiresAt&&b.expiresAt.toDate?b.expiresAt.toDate().toLocaleDateString('en-IN'):'Not activated'}</p><p><b>Status:</b> ${b.status==='pending'?'Admin verification is pending.':b.status==='approved'?'Your business is live.':b.status==='rejected'?'Your listing needs corrections.':'Awaiting approval.'}</p><button class="secondary-btn" data-owner-photos="${b.id}">${icon('edit',15)} Manage Photos</button><button class="secondary-btn" data-edit="${b.id}">${icon('edit',15)} Request Profile Change</button></article>`).join(''):empty('No business added yet','Register your shop, institute or service to get listed on Baran Pride.','add','Add Your Business')}</div>`}
function ownerPhotos(){const b=S.owned.find(x=>x.id===S.photoBusinessId);if(!b)return owner();const urls=Array.isArray(b.photoUrls)?b.photoUrls:[],limit=isPremium(b)?5:2;
 return `<div class="screen">${head('Manage Business Photos')}<h2>${escapeHtml(b.name)}</h2><p>${urls.length} / ${limit} Photos · ${isPremium(b)?'Premium':'Free'}</p><form id="owner-photo-form" class="form-card"><div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">${urls.map((u,i)=>`<label style="min-width:0"><img src="${escapeHtml(u)}" style="width:100%;height:120px;object-fit:cover;border-radius:10px"><span><input type="checkbox" name="remove" value="${escapeHtml(u)}"> Remove</span><br><span><input type="radio" name="cover" value="${escapeHtml(u)}" ${u===(b.cover||urls[0])?'checked':''}> Cover</span></label>`).join('')}</div><label class="field">Add Photos <input type="file" name="photos" accept="image/jpeg,image/png,image/webp" multiple></label><p class="tiny">JPG/PNG/WebP under 5 MB each; automatically optimized to WebP when supported. Select a cover from existing photos or the first new photo becomes cover.</p><button class="primary-btn" type="submit">Save Photos</button></form></div>`;
}
async function onOwnerPhotos(f){const b=S.owned.find(x=>x.id===S.photoBusinessId);if(!b||!C.enabled)return;const urls=Array.isArray(b.photoUrls)?b.photoUrls:[],remove=[...f.querySelectorAll('input[name=remove]:checked')].map(x=>x.value),files=[...f.elements.photos.files],limit=isPremium(b)?5:2;
 if(urls.filter(u=>!remove.includes(u)).length+files.length>limit)return toast('Maximum '+limit+' photos allowed');const btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.textContent='Saving photos...';try{await C.managePhotos(b,files,remove,f.querySelector('input[name=cover]:checked')?.value||'');toast('Photos updated');await refresh();go('owner')}catch(e){toast(e.message);btn.disabled=false;btn.textContent='Save Photos'}}
const WEEK_DAYS=[['mon','Monday'],['tue','Tuesday'],['wed','Wednesday'],['thu','Thursday'],['fri','Friday'],['sat','Saturday'],['sun','Sunday']];
function weeklyEditor(existing){return `<div class="weekly-hours-editor"><strong>Monday–Sunday Opening / Closing</strong><p class="tiny">Closed चुनें या हर दिन अलग समय भरें</p>${WEEK_DAYS.map(([key,label])=>{const x=existing?.[key]||{};return `<div class="weekly-row"><strong>${label}</strong><input aria-label="${label} open" type="time" name="open_${key}" value="${escapeHtml(x.open||'09:00')}"><input aria-label="${label} close" type="time" name="close_${key}" value="${escapeHtml(x.close||'20:00')}"><label><input type="checkbox" name="closed_${key}" ${x.closed?'checked':''}> Closed</label></div>`}).join('')}</div>`}
function weeklyDisplay(hours){if(!hours||typeof hours!=='object')return '';return `<h3 class="block-title">Weekly Opening Hours</h3><div class="info-panel">${WEEK_DAYS.map(([key,label])=>{const x=hours[key];return `<div class="weekly-display-row"><strong>${label}</strong><span>${!x||x.closed?'Closed':escapeHtml((x.open||'--')+' – '+(x.close||'--'))}</span></div>`}).join('')}</div>`}
function addForm(){if(C.enabled&&!C.user){S.afterAuth='add';return auth()}let b=S.editingId?S.owned.find(x=>x.id===S.editingId):null;return `<div class="screen">${head(b?'Request Business Changes':'Add Your Business')}<h1 class="page-title">${b?'Edit Request':'Business Registration'}</h1><p class="intro">${b?'Admin must approve changes before they appear.':'Submit your listing for admin approval.'}</p>${!C.enabled?banner():''}<form id="business-form" class="form-card"><div class="field"><label for="b-name">Business Name *</label><input id="b-name" name="name" required minlength="3" maxlength="100" value="${escapeHtml(b?.name||'')}" placeholder="Enter business or shop name"></div><div class="fieldrow"><div class="field"><label>Category *</label><select name="category" required><option value="">Select</option>${allBusinessCategories().map((c)=>`<option ${b?.category===c?'selected':''}>${escapeHtml(c)}</option>`).join('')}</select>${b&&isPremium(b)?`<div class="field" style="margin-top:8px"><label>Additional Categories (up to 3 total)</label>${allBusinessCategories().map(c=>`<label style="display:block;font-size:12px;margin:4px 0"><input type="checkbox" name="extraCategory" value="${escapeHtml(c)}" ${(b.categories||[]).includes(c)&&c!==b.category?'checked':''}> ${escapeHtml(c)}</label>`).join('')}</div>`:''}</div><div class="field"><label>Area *</label><input name="area" required placeholder="e.g. Kota Road" value="${escapeHtml(b?.area||'')}"></div></div><div class="field"><label>Full Address *</label><textarea name="address" required placeholder="Street, landmark, Baran, Rajasthan">${escapeHtml(b?.address||'')}</textarea></div><div class="fieldrow"><div class="field"><label>Mobile Number *</label><input type="tel" name="phone" inputmode="numeric" pattern="[0-9+ -]{10,15}" required placeholder="10-digit mobile" value="${escapeHtml(b?.phone||'')}"></div><div class="field"><label>WhatsApp Number</label><input type="tel" name="whatsapp" inputmode="numeric" pattern="[0-9+ -]{10,15}" placeholder="Optional" value="${escapeHtml(b?.whatsapp||'')}"></div></div><div class="field"><label>About Business</label><textarea name="description" maxlength="700" placeholder="Tell customers about your business">${escapeHtml(b?.description||'')}</textarea></div><div class="field"><label>Opening Hours (optional summary)</label><input name="hours" placeholder="e.g. Mon-Sat 9 AM to 8 PM" value="${escapeHtml(b?.hours||'')}"></div><div class="field"><label>Google Maps Location Link (optional)</label><input type="url" name="mapUrl" placeholder="https://maps.app.goo.gl/..." value="${escapeHtml(b?.mapUrl||'')}"></div>${weeklyEditor(b?.weeklyHours)}${!b?`<div class="field"><label>Business Photos (up to 2, 5 MB each)</label><input type="file" name="photos" accept="image/jpeg,image/png,image/webp" multiple><div id="business-photo-preview" aria-live="polite" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:10px"></div><span class="tiny" id="business-photo-hint">Select up to 2 JPG, PNG or WebP photos (under 5 MB each).</span></div>`:''}<div class="form-note">Interested in a premium listing? Please call our team for details. Premium plans are managed manually by Admin; online paid activation is not available.</div><div class="form-note">After submission, the business remains <b>Pending</b> until approved by Admin. Premium payments are verified manually outside the Android app. No online payment link is shown here.</div><button class="primary-btn" id="submit-business" type="submit">${icon('check',18)} ${b?'Send Change Request':'Submit for Approval'}</button></form></div>`}
function auth(){return `<div class="screen">${head('Business Account')}<h1 class="page-title">${S.authTab==='signup'?'Create Account':'Welcome Back'}</h1><p class="intro">Sign in to manage your Baran Pride business</p><div class="chipbar"><button class="chip ${S.authTab==='signin'?'selected':''}" data-auth-tab="signin">Sign In</button><button class="chip ${S.authTab==='signup'?'selected':''}" data-auth-tab="signup">Register</button></div><form id="auth-form" class="form-card">${S.authTab==='signup'?`<div class="field"><label>Your Name *</label><input name="name" autocomplete="name" required></div><div class="field"><label>Mobile Number *</label><input name="mobile" type="tel" inputmode="numeric" pattern="[6-9][0-9]{9}" maxlength="10" placeholder="10-digit mobile number" required></div>`:''}<div class="field"><label>Email Address *</label><input name="email" type="email" autocomplete="email" required placeholder="you@example.com"></div><div class="field"><label>Password *</label><input name="password" type="password" minlength="6" autocomplete="${S.authTab==='signup'?'new-password':'current-password'}" required placeholder="Minimum 6 characters"></div><button class="primary-btn" type="submit">${S.authTab==='signup'?'Create Account':'Sign In'} ${icon('arrow',16)}</button>${S.authTab==='signup'?'':`<div style="display:flex;justify-content:space-between;gap:10px;margin-top:14px"><button type="button" class="secondary-btn" data-forgot-password>Forgot Password?</button><button type="button" class="secondary-btn" data-forgot-email>Forgot Email?</button></div>`}</form><div class="form-note">Only business owners need an account. Customers can browse listings without signing in.</div></div>`}
// Fixed public links shown only on the Profile screen (not the city drawer or admin).
const BP_PROFILE_SOCIAL_LINKS=Object.freeze({
 instagram:'https://www.instagram.com/baran_pride?rpxt=aHVzam4xMjhoMGU1',
 whatsapp:'https://whatsapp.com/channel/0029Va65V2o4IBhK8ACUvZ3l',
 facebook:'https://www.facebook.com/baranprideapp',
 website:'https://www.itcampusbaran.in',
 youtube:'https://www.youtube.com/channel/@baranpride'
});
function bpProfileSocial(){
 const items=[['instagram','Instagram','◎'],['whatsapp','WhatsApp','✆'],['facebook','Facebook','f'],['website','Website','🌐'],['youtube','YouTube','▶']];
 return `<section class="bp-profile-social" aria-label="Connect with Baran Pride"><h3>Connect With Us</h3><div class="bp-profile-social-row">${items.map(([key,label,mark])=>`<button type="button" class="bp-profile-social-link bp-profile-social-${key}" data-profile-social="${key}" aria-label="Open ${label}" title="${label}"><span aria-hidden="true">${mark}</span><small>${label}</small></button>`).join('')}</div></section>`;
}
function donatePage(){return `<div class="screen bp-donate-page">${head('Donate Us')}<section class="bp-donate" aria-label="Support Baran Pride"><h3>❤️ Donate Us — Support Baran Pride</h3><p>आपका सहयोग Baran Pride App को बेहतर बनाने, लगातार चलाने और नए Updates लाने में मदद करेगा। सहयोग पूरी तरह स्वैच्छिक है।</p><img src="img/it-campus-phonepe-qr.png" alt="IT Campus PhonePe donation QR code" loading="eager"><strong>Scan & Support via PhonePe</strong><small>Payment recipient: IT CAMPUS — कृपया भुगतान से पहले नाम की पुष्टि करें।</small><button type="button" class="secondary-btn" data-go="profile">← Back to Profile</button></section></div>`}
function bpDealSubmitPage(){
 const fields=(name,label,extra='')=>`<label class="field"><span>${label}</span><input name="${name}" ${extra}></label>`;
 return `<div class="screen city-page bp-deal-submit-page">${head('Submit Deals & Offers')}<div class="bp-deal-submit-hero"><h1>Submit Your Deal</h1><p>अपनी दुकान के Offers भेजें — Admin Approval के बाद दिखाई देंगे।</p></div><form id="bp-deal-request-form" class="form-card">
 ${fields('businessName','Business / Shop Name *','required maxlength="140"')}${fields('phone','Mobile Number *','required inputmode="numeric" pattern="[6-9][0-9]{9}" maxlength="10"')}
 ${fields('title','Main Deal Title *','required maxlength="120"')}
 <label class="field"><span>Category</span><select name="category">${['General','Fashion','Food','Electronics','Shopping','Services','Education','Health','Other'].map(c=>`<option>${c}</option>`).join('')}</select></label>
 <label class="field"><span>Description *</span><textarea name="description" maxlength="2500" required></textarea></label>
 <div class="bp-deal-request-dates">${fields('startDate','Start Date *','type="date" required')}${fields('endDate','End Date *','type="date" required')}</div>
 ${fields('discount','Main Discount / Headline','maxlength="100" placeholder="Up to 30% OFF"')}
 <label class="field"><span>Main Deal Image (optional, max 5 MB)</span><input type="file" name="coverImage" accept="image/jpeg,image/png,image/webp"></label>
 <h3>Offers in this Deal <small id="bp-request-offer-count">0/10</small></h3><div class="bp-request-offer-editor"><input id="bp-request-title" placeholder="Offer Title"><input id="bp-request-discount" placeholder="Discount"><input id="bp-request-original" placeholder="Original ₹" inputmode="decimal"><input id="bp-request-price" placeholder="Offer ₹" inputmode="decimal"><input id="bp-request-description" placeholder="Description"><input id="bp-request-image" type="file" accept="image/jpeg,image/png,image/webp" title="Optional image"><button type="button" class="secondary-btn" data-request-add-offer>+ Add Offer</button></div>
 <div class="bp-request-offers-table-wrap"><table class="bp-request-offers-table"><thead><tr><th>Title</th><th>Discount</th><th>Original</th><th>Offer</th><th>Image</th><th>Action</th></tr></thead><tbody id="bp-request-offers-list"></tbody></table></div>
 <label class="bp-job-check"><input name="consent" type="checkbox" required> I confirm these offers are accurate and agree that my business contact number can be displayed after approval.</label>
 <p id="bp-deal-request-message" role="status" aria-live="polite"></p><button type="submit" class="primary-btn">Submit for Admin Approval</button></form></div>`;
}
const bpRequestOffers=[];
function bpRequestRenderOffers(){const body=document.getElementById('bp-request-offers-list');if(!body)return;body.innerHTML=bpRequestOffers.map((x,i)=>`<tr><td>${escapeHtml(x.title)}</td><td>${escapeHtml(x.discount)}</td><td>${escapeHtml(x.originalPrice)}</td><td>${escapeHtml(x.offerPrice)}</td><td>${x.file?'Selected':'—'}</td><td><button type="button" data-request-remove-offer="${i}">Remove</button></td></tr>`).join('');document.getElementById('bp-request-offer-count').textContent=bpRequestOffers.length+'/10'}
async function bpSubmitDealRequest(form){const msg=document.getElementById('bp-deal-request-message'),btn=form.querySelector('[type=submit]');if(!C.enabled||!C.user){msg.textContent='Please sign in from Profile before submitting a deal.';return}const fd=new FormData(form);if(!bpRequestOffers.length){msg.textContent='Add at least one Offer first.';return}if(fd.get('endDate')<fd.get('startDate')){msg.textContent='End Date must be on or after Start Date.';return}btn.disabled=true;msg.textContent='Submitting for review...';try{await C.submitDealRequest(Object.fromEntries(fd.entries()),bpRequestOffers);bpRequestOffers.length=0;form.reset();bpRequestRenderOffers();msg.textContent='Deal submitted successfully. It will appear after Admin approval.'}catch(e){msg.textContent='Submission failed: '+(e?.code==='permission-denied'?'Secure Firebase rules for dealRequests must be deployed.':e.message)}finally{btn.disabled=false}}
document.addEventListener('click',e=>{const add=e.target.closest('[data-request-add-offer]');if(add){if(bpRequestOffers.length>=10)return toast('Maximum 10 offers');const val=id=>document.getElementById('bp-request-'+id).value.trim();if(!val('title'))return toast('Enter Offer Title');bpRequestOffers.push({title:val('title'),discount:val('discount'),originalPrice:val('original'),offerPrice:val('price'),description:val('description'),file:document.getElementById('bp-request-image').files[0]||null});['title','discount','original','price','description','image'].forEach(id=>document.getElementById('bp-request-'+id).value='');bpRequestRenderOffers();return}const rem=e.target.closest('[data-request-remove-offer]');if(rem){bpRequestOffers.splice(Number(rem.dataset.requestRemoveOffer),1);bpRequestRenderOffers()}});
document.addEventListener('submit',e=>{if(e.target.id==='bp-deal-request-form'){e.preventDefault();bpSubmitDealRequest(e.target)}});
function profile(){const user=C.user;return `<div class="screen"><h1 class="page-title">My Profile</h1><p class="intro">Account and app information</p><div class="account"><div class="avatar">${icon('user',36)}</div><h2>${escapeHtml(user?.displayName||'Welcome to Baran Pride')}</h2><p>${escapeHtml(user?.email||'Discover local businesses in Baran')}</p></div><div class="menu-group"><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="owner">${icon('store')} My Business ${icon('arrow',17)}</button><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="saved">${icon('heart')} Saved Businesses ${icon('arrow',17)}</button><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="add">${icon('plus')} Add Your Business ${icon('arrow',17)}</button></div>${C.enabled?(user?`<button class="secondary-btn" data-action="logout">${icon('logout',17)} Sign Out</button>`:`<button class="primary-btn" data-go="auth">Sign In / Register</button>`):'<div class="notice">Demo mode: Firebase project is not connected. Listings are samples or stored only on this device.</div>'}${bpProfileSocial()}<section class="bp-donate-entry"><button type="button" class="bp-donate-open" data-go="donate">${icon("heart",21)} Donate Us ${icon("arrow",18)}</button></section><p class="fine-print">BARAN PRIDE · हमारा शहर, हमारी पहचान<br>Royal Blue Premium • Version 1.0</p></div>`}

// V2: Additional city information lives only behind this drawer; original business homepage stays intact.
function socialFooter(){const cfg=S.socialLinks||{};const items=[['instagram','Instagram','📷'],['facebook','Facebook','f'],['youtube','YouTube','▶'],['whatsapp','WhatsApp','✆']].filter(([key])=>cfg[key]?.enabled&&/^https:\/\//i.test(cfg[key]?.url||''));return items.length?`<div class="bp-social-footer"><strong>Follow BARAN PRIDE</strong><div class="bp-social-icons">${items.map(([key,label,mark])=>`<button type="button" data-social="${key}" aria-label="${label}" title="${label}">${mark}</button>`).join('')}</div></div>`:''}
function cityDrawer(){return `<div class="city-drawer-layer"><button class="city-drawer-shade" data-menu-close aria-label="Close menu"></button><aside class="city-drawer" role="dialog" aria-modal="true" aria-label="Baran city information"><div class="city-drawer-header"><button class="city-drawer-x" data-menu-close aria-label="Close">${icon('close')}</button><strong>BARAN PRIDE</strong><small>हमारा शहर, हमारी पहचान</small><p>Explore More About Baran</p></div><div class="city-drawer-items"><button data-go="home">${icon('home')} Home ${icon('arrow',17)}</button><button data-go="explore">${icon('store')} Local Businesses ${icon('arrow',17)}</button><button data-go="aboutUs">${icon('info')} About Us ${icon('arrow',17)}</button><hr><button data-special="properties">${icon('property')}<span>Sell Property<small>प्रॉपर्टी बिक्री और ग्राहक सेवा</small></span>${icon('arrow',17)}</button><button data-special="donors">${icon('drop')}<span>Blood Donors<small>रक्तदाताओं की सूची</small></span>${icon('arrow',17)}</button>${CITY_TYPES.map(t=>`<button data-city-type="${t[0]}">${icon(t[3])}<span>${t[1]}<small>${t[2]}</small></span>${icon('arrow',17)}</button>`).join('')}</div>${socialFooter()}<p class="city-drawer-footer">City information is published only by the Admin.</p></aside></div>`}
function openDrawer(){if(document.querySelector('.city-drawer-layer'))return;S.drawer=true;$('#app').insertAdjacentHTML('beforeend',cityDrawer());document.body.classList.add('city-drawer-open')}
function closeDrawer(){S.drawer=false;document.querySelector('.city-drawer-layer')?.remove();document.body.classList.remove('city-drawer-open')}
// Phase 1D: public Important Contacts remain available offline after app restarts.
// Never cache credentials or private account data; do not overwrite last-good contacts
// with an empty/offline result. The Firestore layer uses a 24-hour refresh window.
const CONTACT_CACHE_KEY='bp_important_contacts_v1';
const CONTACT_REFRESH_MS=24*60*60*1000;
let contactSyncPromise=null, contactSynced=false, contactSessionItems=null;
function contactCacheRecord(){
 try{
  const v=JSON.parse(localStorage.getItem(CONTACT_CACHE_KEY)||'null');
  return v&&Array.isArray(v.items)?v:null;
 }catch{return null}
}
function cachedContacts(){return contactCacheRecord()?.items||[]}
function contactLastSynced(){const t=contactCacheRecord()?.savedAt;return Number.isFinite(t)?t:null}
function saveContactCache(items){
 const filtered=items.filter(x=>x.type==='contacts'&&x.status==='published'&&x.visible!==false);
 // Preserve last-known working directory if the SDK returns an empty offline snapshot.
 if(!filtered.length&&cachedContacts().length)return false;
 try{
  localStorage.setItem(CONTACT_CACHE_KEY,JSON.stringify({savedAt:Date.now(),items:filtered.map(x=>({
   id:x.id,type:x.type,status:x.status,visible:x.visible,title:x.title,
   summary:x.summary,phone:x.phone,contactCategory:x.contactCategory,
   area:x.area,featured:x.featured,homeOrder:x.homeOrder
  }))}));
  return true;
 }catch(e){console.warn('Contacts cache unavailable',e);return false}
}
async function syncContacts(force=false){
 if(force){contactSynced=false;}
 if(contactSyncPromise)return contactSyncPromise;
 if(!C.enabled)return;
 const savedAt=contactLastSynced();
 if(!force&&cachedContacts().length&&(contactSynced||(savedAt&&Date.now()-savedAt<CONTACT_REFRESH_MS)))return;
 contactSyncPromise=(async()=>{
  try{
   const items=await C.publicCity('contacts',force);
   const published=items.filter(x=>x.type==='contacts'&&x.status==='published'&&x.visible!==false);
   if(force||published.length){try{localStorage.setItem(CONTACT_CACHE_KEY,JSON.stringify({savedAt:Date.now(),items:published.map(x=>({id:x.id,type:x.type,status:x.status,visible:x.visible,title:x.title,summary:x.summary,phone:x.phone,contactCategory:x.contactCategory,area:x.area,featured:x.featured,homeOrder:x.homeOrder}))}))}catch(e){console.warn(e)}}
   contactSessionItems=force?published:(published.length?published:cachedContacts());
   contactSynced=contactSessionItems.length>0;
   if(S.cityType==='contacts'&&S.page==='cityList'){
    S.cityItems=contactSessionItems;S.cityError='';S.cityLoading=false;render();
   }
  }catch(e){if(force){S.cityError='Unable to refresh contacts. Showing saved contacts.';if(S.page==='cityList'&&S.cityType==='contacts')render()}console.warn('Contact background refresh unavailable',e);if(force)throw e}
  finally{contactSyncPromise=null}
 })();
 return contactSyncPromise;
}
function preloadContacts(){
 const run=()=>syncContacts();
 if(typeof requestIdleCallback==='function')requestIdleCallback(run,{timeout:2500});
 else setTimeout(run,1200);
}
// About Baran fallback is independent of Firebase SDK initialization (offline cold start).
const BP_ABOUT_CACHE='bp_about_baran_public_v2';
function bpAboutSaved(){try{const v=JSON.parse(localStorage.getItem(BP_ABOUT_CACHE)||'null');return Array.isArray(v?.items)?v.items.filter(x=>x.type==='about'&&x.status==='published').sort((a,b)=>Number(a.displayOrder??9999)-Number(b.displayOrder??9999)):[]}catch{return []}}
function bpAboutStore(items){const safe=items.filter(x=>x.type==='about'&&x.status==='published').map(x=>({id:x.id,type:x.type,status:x.status,title:x.title||'',summary:x.summary||'',body:x.body||'',area:x.area||'',cover:x.cover||'',photos:Array.isArray(x.photos)?x.photos:[],placeAddress:x.placeAddress||'',displayOrder:x.displayOrder??9999,publishedAt:x.publishedAt||null}));if(!safe.length)return;try{localStorage.setItem(BP_ABOUT_CACHE,JSON.stringify({savedAt:Date.now(),items:safe}))}catch(e){console.warn('About Baran cache storage unavailable',e)}}
async function openCity(type){closeDrawer();S.cityBackTarget='cityList';S.cityType=cityType(type)[0];S.cityId=null;S.cityQuery='';S.contactSelectedCategory='';S.cityError='';
 if(S.cityType==='contacts'){
  const cached=contactSessionItems||cachedContacts();S.cityItems=cached;S.cityLoading=!cached.length&&!contactSynced&&C.enabled;go('cityList');
  if(contactSynced&&cached.length){S.cityLoading=false;return}
  await syncContacts(!cached.length);if(S.page==='cityList'&&S.cityType==='contacts'){S.cityLoading=false;render()}return;
 }
 const about=S.cityType==='about';const events=S.cityType==='events';const saved=about?bpAboutSaved():events?(C.cachedPublicEvents?.()||[]):[];
 S.cityItems=saved;S.cityLoading=!saved.length;go('cityList');
 if((about||events)&&!C.enabled){S.cityLoading=false;render();return}
 try{const fresh=C.enabled?await C.publicCity(S.cityType):[];if(fresh.length){S.cityItems=fresh;if(about)bpAboutStore(fresh)}else if(!saved.length)S.cityItems=fresh;}
 catch(e){if(!saved.length)S.cityError='Unable to load city information. Please check the internet.';console.warn(e)}
 finally{S.cityLoading=false;if(S.page==='cityList')render()}
}
function safeHttps(u){try{const x=new URL(String(u||''));return x.protocol==='https:'?x.href:''}catch{return ''}}
function cityDate(v){const d=v&&typeof v.toDate==='function'?v.toDate():v?.seconds?new Date(v.seconds*1000):v?new Date(v):null;return d&&!Number.isNaN(d.getTime())?d.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}):''}
function contactCategory(x){return String(x.contactCategory||x.area||'Public').trim()||'Public'}
function contactPhone(x){return String(x.phone||'').replace(/[^0-9+]/g,'')}
function contactList(){
 const items=S.cityItems.filter(x=>x.type==='contacts'&&x.status==='published'&&x.visible!==false).sort((a,b)=>(Number(a.homeOrder)||100)-(Number(b.homeOrder)||100)||String(a.title).localeCompare(String(b.title)));
 const emergency=x=>x.featured||contactCategory(x).toLowerCase()==='emergency';
 const normal=items.filter(x=>!emergency(x)),emergencyItems=items.filter(emergency);
 const categories=[...new Set(normal.map(contactCategory))].sort((a,b)=>a.localeCompare(b));
 const selected=S.contactSelectedCategory||'';
 const q=(S.cityQuery||'').trim().toLowerCase();
 const matches=x=>[x.title,x.summary,x.phone,contactCategory(x)].join(' ').toLowerCase().includes(q);
 const row=x=>{const phone=contactPhone(x);return `<article class="bp-contact-card ${emergency(x)?'bp-emergency':''}" data-city-search="${escapeHtml([x.title,x.summary,x.phone,contactCategory(x)].join(' ').toLowerCase())}"><span class="bp-contact-symbol">${icon('phone',21)}</span><div class="bp-contact-info"><strong>${escapeHtml(x.title)}</strong><small>${escapeHtml(x.summary||contactCategory(x))}</small></div><div class="bp-contact-action">${phone?`<button data-city-call="${escapeHtml(x.id)}">${icon('phone',15)} Call Now</button><small>${escapeHtml(phone)}</small>`:'<small>Number unavailable</small>'}</div></article>`};
 const categoryIcon=c=>{const t=c.toLowerCase();return /hospital|medical|health|clinic|अस्पताल/.test(t)?'heart':/police|पुलिस/.test(t)?'shield':/school|college|शिक्षा/.test(t)?'book':/electric|बिजली/.test(t)?'zap':/water|पानी/.test(t)?'droplet':/transport|bus|यातायात/.test(t)?'car':/government|office|सरकारी/.test(t)?'home':'phone'};
 const synced=cachedContacts().length?contactLastSynced():null;
 const syncLabel=`<div class="bp-contact-sync-row"><span>${synced?'Last synced: '+escapeHtml(new Date(synced).toLocaleString('en-IN')):'Contacts may be saved offline'}</span><button type="button" data-contact-manual-sync>${icon('refresh',16)} Refresh Contacts</button></div>`;
 const shownEmergency=emergencyItems.filter(matches);
 const shownCategories=categories.filter(c=>normal.some(x=>contactCategory(x)===c&&matches(x)));
 const selectedItems=normal.filter(x=>contactCategory(x)===selected&&matches(x));
 const categoryGrid=`<h3 class="bp-contact-heading">Contact Categories</h3><div class="bp-contact-category-grid">${shownCategories.map(c=>`<button class="bp-contact-category-tile" data-contact-open="${escapeHtml(c)}"><span class="bp-contact-category-icon">${icon(categoryIcon(c),29)}</span><strong>${escapeHtml(c)}</strong><small>${normal.filter(x=>contactCategory(x)===c).length} Contacts</small></button>`).join('')}</div>`;
 return `<div class="screen city-page bp-contacts"><div class="bp-contact-hero">${head('Important Contacts')}<p>Baran City • Quick Help Directory</p><div class="search-bar">${icon('search')}<input id="city-search" value="${escapeHtml(S.cityQuery||'')}" placeholder="Search contact, department or number..."></div></div>${syncLabel}${S.cityLoading?'<div class="city-message">Loading contacts...</div>':S.cityError?`<div class="city-message">${escapeHtml(S.cityError)} <button data-city-retry>Retry</button></div>`:items.length?`<div id="city-results">${selected&&!q?`<div class="bp-contact-category-back"><button data-contact-back>← All Categories</button><h3>${escapeHtml(selected)}</h3></div>${selectedItems.map(row).join('')||'<p class="city-message">No contacts in this category.</p>'}`:`${shownEmergency.length?`<h3 class="bp-contact-heading">Emergency Helplines</h3>${shownEmergency.map(row).join('')}`:''}${categoryGrid}${q?`<h3 class="bp-contact-heading">Matching Contacts</h3>${normal.filter(matches).map(row).join('')}`:''}${!shownEmergency.length&&!shownCategories.length?'<p class="city-message">No matching contacts.</p>':''}`}</div>`:'<div class="city-message">अभी कोई Important Contact प्रकाशित नहीं है।</div>'}</div>`;
}
function cityList(){if(S.cityType==='contacts')return contactList();const t=cityType(S.cityType),arr=S.cityItems.filter(x=>x.type===S.cityType);return `<div class="screen city-page">${head(t[1])}<div class="city-heading"><span>${icon(t[3],27)}</span><div><h1>${t[1]}</h1><p>${t[2]} · BARAN PRIDE</p></div></div><div class="search-bar">${icon('search')}<input id="city-search" value="${escapeHtml(S.cityQuery)}" placeholder="Search ${escapeHtml(t[1].toLowerCase())}..." aria-label="Search city information"></div>${S.cityLoading?'<div class="city-message">Loading published information...</div>':S.cityError?`<div class="city-message">${escapeHtml(S.cityError)} <button data-city-retry>Retry</button></div>`:arr.length?`<div id="city-results">${arr.map(x=>`<article class="city-list-card" data-city-search="${escapeHtml([x.title,x.area,x.summary].join(' ').toLowerCase())}">${safeHttps(x.cover)?`<img src="${escapeHtml(safeHttps(x.cover))}" loading="lazy" alt="">`:`<div class="city-list-placeholder">${icon(t[3],32)}</div>`}<div class="city-list-text"><small>${escapeHtml(t[1])}${x.area?' · '+escapeHtml(x.area):''}</small><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.summary||'Tap to read more.')}</p><button data-city-detail="${escapeHtml(x.id)}">Read More →</button></div></article>`).join('')}</div><p class="city-no-match hidden" id="city-no-match">No matching information found.</p>`:'<div class="city-message">अभी इस सेक्शन में कोई जानकारी प्रकाशित नहीं हुई है।<br><small>Only Admin can publish new information.</small></div>'}</div>`}
function cityDetail(){const x=S.cityItems.find(o=>o.id===S.cityId&&o.status==='published'),t=cityType(S.cityType);if(!x)return cityList();let gallery=(Array.isArray(x.photos)?x.photos:[]).map(safeHttps).filter(Boolean);const cover=safeHttps(x.cover);if(!gallery.length&&cover)gallery=[cover];const mapUrl=safeHttps(x.mapUrl),phone=String(x.phone||'').replace(/[^0-9+]/g,'');return `<div class="screen city-page">${head(t[1])}<article class="city-article">${cover?`<img class="city-article-cover" src="${escapeHtml(cover)}" alt="${escapeHtml(x.title)}">`:`<div class="city-article-cover city-article-empty">${icon(t[3],55)}</div>`}<div class="city-article-meta">${escapeHtml(t[1])}${x.area?' · '+escapeHtml(x.area):''}</div><h1>${escapeHtml(x.title)}</h1>${x.summary?`<p class="city-summary">${escapeHtml(x.summary)}</p>`:''}<div class="city-article-actions"><button data-city-share="${escapeHtml(x.id)}">${icon('share',17)} Share</button>${mapUrl?`<button data-city-map="${escapeHtml(x.id)}">${icon('pin',17)} Directions</button>`:''}${(x.type==='contacts'||x.type==='events')&&phone?`<button data-city-call="${escapeHtml(x.id)}">${icon('phone',17)} ${x.type==='events'?'Call Organizer':'Call'}</button>`:''}</div>${x.area||x.placeAddress?`<div class="city-fact">${icon('pin',19)} ${escapeHtml([x.placeAddress,x.area].filter(Boolean).join(' · '))}</div>`:''}${x.type==='events'&&(x.startDate||x.endDate)?`<div class="city-fact">${icon('calendar',19)} ${escapeHtml([x.startDate,x.endDate].filter(Boolean).join(' → '))}</div>`:x.eventDate?`<div class="city-fact">${icon('calendar',19)} ${escapeHtml(x.eventDate)}</div>`:''}${x.type==='events'&&phone?`<div class="city-fact">${icon('phone',19)} <span><strong>Organizer Contact:</strong> ${escapeHtml(phone)}</span></div>`:''}<div class="city-prose">${escapeHtml(x.body||'').replace(/\r?\n/g,'<br>')}</div>${gallery.length>1?`<h3>Photo Gallery</h3><div class="city-gallery">${gallery.map(img=>`<img src="${escapeHtml(img)}" loading="lazy" alt="${escapeHtml(x.title)}">`).join('')}</div>`:''}<p class="city-published">Published by BARAN PRIDE Admin${cityDate(x.publishedAt)?' · '+cityDate(x.publishedAt):''}</p></article></div>`}
// V3: New sections in the side menu only; original business homepage is untouched.
const bloodGroups=['All','A+','A-','B+','B-','AB+','AB-','O+','O-'];
const validPhone=(v)=>/^[6-9]\d{9}$/.test(String(v||'').replace(/[^0-9]/g,''));
const dialDirect=(p)=>{const val=String(p||'').replace(/[^+\d]/g,'');if(!val)return toast('Contact number not available');if(!native('dial',val))openUrl('tel:'+val)};
function shuffleOffers(items){const result=Array.isArray(items)?[...items]:[];for(let i=result.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[result[i],result[j]]=[result[j],result[i]]}return result}
function shuffleDonors(items){const result=[...items];for(let i=result.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[result[i],result[j]]=[result[j],result[i]]}return result}
async function openDonors(){
 closeDrawer();S.donorError='';S.donors=[];S.donorFilter='All';go('donors');
 if(!C.enabled)return;
 // Show a still-valid offline snapshot immediately, while verifying against the server.
 const saved=C.cachedDonors();
 if(saved){S.donors=shuffleDonors(saved.items);if(S.page==='donors')render()}
 try{S.donors=shuffleDonors(await C.publicDonors());S.donorError=''}
 catch(e){if(!saved)S.donorError='Offline donor data unavailable or older than 24 hours. Connect to internet to refresh.'}
 if(S.page==='donors')render();
}
async function openProperties(){
 closeDrawer();S.propertyError='';S.helpline='7737325205';go('properties');
 try{
  const items=await C.publicProperties();
  S.properties=items;
  if(C.enabled){try{S.helpline=await C.customerCare()}catch(e){console.warn('Helpline refresh unavailable',e)}}
 }catch(e){S.propertyError='Unable to load properties. Check internet.'}
 if(S.page==='properties')render();
}
document.addEventListener('submit',e=>{if(e.target?.id==='bp-job-form'){e.preventDefault();bpSubmitJob(e.target)}});
const BP_JOB_CATEGORIES=['Education & Teaching', 'IT & Computer', 'Sales & Marketing', 'Office & Administration', 'Bank & Finance', 'Healthcare & Medical', 'Retail & Shop Staff', 'Hotel & Restaurant', 'Driver & Delivery', 'Technical & Skilled Work', 'Construction & Labour', 'Factory & Manufacturing', 'Security & Housekeeping', 'Other Jobs'];
function bpJobDate(x){return String(x?.lastApplyDate||'').trim()}
function bpJobLive(x){return x?.status==='approved'&&x?.active!==false&&(!bpJobDate(x)||(/^\d{4}-\d{2}-\d{2}$/.test(bpJobDate(x))&&bpJobDate(x)>=new Date().toISOString().slice(0,10)))}
function bpJobItems(){return (S.jobs||[]).filter(bpJobLive).filter(j=>{
 const q=S.jobSearch.trim().toLowerCase(),cat=S.jobCategory;
 return (cat==='All'||j.category===cat)&&(!q||[j.title,j.company,j.location,j.qualification].some(x=>String(x||'').toLowerCase().includes(q)));
}).sort((a,b)=>(b.createdAt?.seconds||b.createdAt?.__bpTimestampMs/1000||0)-(a.createdAt?.seconds||a.createdAt?.__bpTimestampMs/1000||0))}
async function openLocalJobs(){closeDrawer();S.jobCategory='All';S.jobSearch='';S.jobGroup='';S.jobError='';S.jobLoading=!C.cachedLocalJobs?.().length;S.jobs=C.cachedLocalJobs?.()||[];go('localJobs');try{S.jobs=await C.publicLocalJobs(bpIsInternetAvailable());S.jobError=''}catch(e){S.jobError='Jobs load failed: '+(e?.code||e?.message||'Unknown error')+' — showing saved jobs.';console.warn('Local Jobs open',e)}finally{S.jobLoading=false;if(S.page==='localJobs')render()}}
async function refreshLocalJobs(){
 if(S.jobLoading)return;
 if(!bpIsInternetAvailable()){S.jobError='Internet unavailable. Showing saved jobs.';if(S.page==='localJobs')render();return}
 S.jobLoading=true;S.jobError='';if(S.page==='localJobs')render();
 try{S.jobs=await C.publicLocalJobs(true);S.jobError='';toast('Local Jobs updated')}
 catch(e){S.jobError='Jobs refresh failed: '+(e?.code||e?.message||'Unknown error')+' — showing saved jobs.';console.warn('Local Jobs refresh',e)}
 finally{S.jobLoading=false;if(S.page==='localJobs')render()}
}
function bpJobCardUpper(value,fallback){return escapeHtml(String(value||fallback).toLocaleUpperCase())}
function bpJobThumb(j){const u=String(j.photoUrl||'');const src=/^https:\/\//i.test(u)?u:"img/baran-pride-local-jobs-default.webp";return `<img class="bp-job-small-photo" src="${escapeHtml(src)}" alt="Local Jobs" loading="lazy" onerror="this.onerror=null;this.src='img/baran-pride-local-jobs-default.webp'">`}
function bpJobCard(j){return `<article class="bp-job-card bp-emerald-card bp-job-banner-card"><div class="bp-job-banner-media">${bpJobThumb(j)}${j.featured?'<span class="bp-featured-tag">★ Featured</span>':''}</div><div class="bp-job-banner-body"><h3>${bpJobCardUpper(j.title,'Job Vacancy')}</h3><p class="bp-job-banner-company">${bpJobCardUpper(j.company,'Organisation')}</p><div class="bp-job-tags"><span>${icon('clock',13)} ${escapeHtml(j.jobType||'Job')}</span>${j.vacancies?`<span>${icon('user',13)} ${escapeHtml(String(j.vacancies))} Vacancies</span>`:''}<span>${icon('map-pin',13)} Baran</span></div><div class="bp-job-compact-bottom"><strong>${escapeHtml(j.salary||'Salary on enquiry')}</strong><button type="button" data-local-job="${escapeHtml(j.id)}">View Details ${icon('arrow',15)}</button></div></div></article>`}
function bpJobGroupCard(company,jobs){return `<article class="bp-job-card bp-emerald-card bp-job-group-card bp-job-banner-card"><div class="bp-job-banner-media">${bpJobThumb(jobs.find(j=>j.photoUrl)||jobs[0])}${jobs.some(j=>j.featured)?'<span class="bp-featured-tag">★ Featured</span>':''}</div><div class="bp-job-banner-body"><h3>${bpJobCardUpper(company,'Organisation')}</h3><p class="bp-job-banner-company">${icon('map-pin',13)} Baran, Rajasthan</p><div class="bp-job-compact-bottom bp-group-bottom"><strong>${jobs.length} JOBS AVAILABLE</strong><button type="button" data-job-group-detail="${escapeHtml(bpJobOwnerGroupKey(jobs[0]))}">View Details ${icon('arrow',15)}</button></div></div></article>`}
function bpJobOwnerGroupKey(j){return String(j.ownerUid||'legacy:'+j.id)+'|'+String(j.company||'Organisation').trim().toLocaleLowerCase()}
function localJobsPage(){
 const items=bpJobItems(),categories=['All',...BP_JOB_CATEGORIES];
 const groups=new Map();items.forEach(j=>{const key=bpJobOwnerGroupKey(j);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(j)});
 const allGroups=[...groups.values()];const featured=allGroups.filter(g=>g.some(j=>j.featured));const normal=allGroups.filter(g=>!g.some(j=>j.featured));
 const cards=g=>g.map(jobs=>jobs.length===1?bpJobCard(jobs[0]):bpJobGroupCard(jobs[0].company||'Organisation',jobs)).join('');
 const normalCards=cards(normal);
 return `<div class="screen city-page bp-jobs-page bp-jobs-compact bp-jobs-emerald bp-jobs-refined"><div class="bp-jobs-sticky-header">${head('Local Jobs')}<div class="bp-jobs-hero"><span class="bp-hero-eyebrow">BARAN PRIDE · CAREERS</span><h1>Local Jobs in Baran</h1><p>बारां और आसपास की रोजगार अवसर</p></div><div class="bp-jobs-compact-tools"><div class="bp-jobs-tools"><input id="bp-jobs-search" placeholder="Search jobs or organisation..." value="${escapeHtml(S.jobSearch)}" aria-label="Search jobs"><button type="button" class="bp-jobs-compact-refresh" data-jobs-refresh aria-label="Refresh Jobs" title="Refresh Jobs" ${S.jobLoading?'disabled':''}>${icon('refresh',16)}<span>${S.jobLoading?'Refreshing...':'Refresh Jobs'}</span></button></div><div class="bp-job-filter-wrap"><button type="button" class="bp-job-filter-toggle" data-job-filter-toggle aria-expanded="${S.jobFilterOpen?'true':'false'}" aria-label="Choose job category">${escapeHtml(S.jobCategory==='All'?'All Categories':S.jobCategory)} <span aria-hidden="true">▾</span></button>${S.jobFilterOpen?`<div class="bp-job-filter-menu" role="group" aria-label="Job categories">${categories.map(c=>`<button type="button" class="${c===S.jobCategory?'is-selected':''}" data-job-filter-select="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('')}</div>`:''}</div></div></div><div class="bp-job-post-entry bp-job-entry-actions"><button type="button" data-job-form-open>${icon('plus',16)} Post a Job</button><button type="button" data-job-my-open>${icon('briefcase',16)} My Jobs</button></div>${S.jobError?`<p class="city-message">${escapeHtml(S.jobError)}</p>`:''}${S.jobGroup?`<div class="bp-job-section-heading"><h2>${escapeHtml(S.jobGroup)}</h2><button type="button" data-job-group-back>All Jobs</button></div><div class="bp-job-results">${items.filter(j=>j.company===S.jobGroup).map(bpJobCard).join('')||'<p>No matching jobs.</p>'}</div>`:`${featured.length?`<div class="bp-job-section-heading"><h2>★ Featured Jobs</h2></div><div class="bp-job-results">${cards(featured)}</div>`:''}<div class="bp-job-section-heading"><h2>Jobs by Business / Organisation</h2></div><div class="bp-job-results">${S.jobLoading&&!items.length?'<p class="city-message">Loading approved jobs...</p>':normalCards.length?normalCards:featured.length?'':'<p class="city-message">No matching approved jobs yet.</p>'}</div><details class="bp-all-jobs-disclosure"><summary>Show All Local Jobs <span>${items.length} Jobs ▾</span></summary><div class="bp-job-results bp-job-all-results">${items.map(bpJobCard).join('')||'<p class="city-message">No matching jobs.</p>'}</div></details>`}<p class="fine-print">Verify the employer before sharing documents or making payments.</p></div>`;
}
function bpJobDisclaimer(){
 return `<section class="bp-job-disclaimer" aria-label="Job Safety and Disclaimer"><h3>⚠️ महत्वपूर्ण सूचना एवं अस्वीकरण (Job Safety &amp; Disclaimer)</h3><p>Baran Pride केवल एक स्थानीय जॉब सूचना एवं संपर्क प्लेटफॉर्म है। यहाँ प्रकाशित नौकरी संबंधी जानकारी संबंधित Employer/Organisation द्वारा प्रदान की जाती है।</p><p>Baran Pride किसी भी नौकरी, वेतन, चयन प्रक्रिया, नियुक्ति या Employer की विश्वसनीयता एवं जानकारी की सत्यता की गारंटी नहीं देता। आवेदन करने से पहले नौकरी, संस्था और रोजगार की शर्तों की स्वयं पुष्टि करें।</p><p><strong>सुरक्षा संबंधी सावधानी:</strong> नौकरी के नाम पर किसी को अग्रिम राशि न दें। किसी भी व्यक्ति या संस्था के साथ निजी दस्तावेज, बैंक विवरण, OTP, Password या अन्य संवेदनशील जानकारी साझा करने से पहले उसकी विश्वसनीयता की जाँच करें।</p><p>नौकरी से संबंधित किसी भी विवाद, धोखाधड़ी, आर्थिक नुकसान या अन्य समस्या की स्थिति में संबंधित पक्षों की जिम्मेदारी लागू कानूनों के अनुसार निर्धारित होगी। Baran Pride नौकरी उपलब्ध कराने, चयन होने या नियुक्ति की कोई गारंटी नहीं देता।</p><label class="bp-job-disclaimer-consent"><input type="checkbox" data-job-disclaimer-consent> <span>मैंने उपरोक्त सभी शर्तें एवं सावधानियाँ पढ़ ली हैं और समझकर स्वीकार करता/करती हूँ।</span></label><p class="bp-job-consent-hint" data-job-consent-hint>Call, WhatsApp या Apply Link खोलने से पहले सहमति दें।</p></section>`;
}
function bpJobConsentAccepted(button){const section=button.closest('.bp-job-detail-entry, .bp-job-group-contact');return !!section?.querySelector('[data-job-disclaimer-consent]:checked')}
function bpJobDetailContent(j,showContact=true,showPhoto=true){const fields=[['Salary',j.salary],['Job Type',j.jobType],['Qualification',j.qualification],['Experience',j.experience],['Vacancies',j.vacancies],['Required Skills',j.skills],['Working Hours',j.workingHours],['Weekly Off',j.weeklyOff],['Last Apply Date',j.lastApplyDate],['Category',j.category]];return `<div class="bp-job-detail-entry"><div class="bp-jobs-hero bp-detail-hero"><span class="bp-hero-eyebrow">LOCAL JOBS · BARAN</span><h1>${bpJobCardUpper(j.title,'Job Vacancy')}</h1><p>${bpJobCardUpper(j.company,'Organisation')} · Baran, Rajasthan</p></div>${showPhoto?`<img class="bp-job-detail-photo" src="${escapeHtml(/^https:\/\//i.test(String(j.photoUrl||''))?j.photoUrl:'img/baran-pride-local-jobs-default.webp')}" alt="Local Jobs" onerror="this.onerror=null;this.src='img/baran-pride-local-jobs-default.webp'">`:''}<article class="bp-job-detail-card"><div class="bp-detail-section-label">${icon('briefcase',18)} Job Information</div><div class="bp-job-facts">${fields.filter(([,v])=>v!==null&&v!==undefined&&String(v).trim()).map(([k,v])=>`<div><small>${escapeHtml(k)}</small><strong>${escapeHtml(String(v))}</strong></div>`).join('')}</div>${j.description?`<div class="bp-detail-section-label">${icon('list',18)} Job Description</div><p class="bp-job-description">${escapeHtml(j.description).replace(/\r?\n/g,'<br>')}</p>`:''}${showContact?`${bpJobDisclaimer()}<div class="bp-detail-section-label">${icon('phone',18)} Contact & Apply</div><div class="bp-job-actions">${/^[6-9]\d{9}$/.test(String(j.mobile||''))?`<button type="button" disabled data-job-call="${escapeHtml(j.id)}">${icon('phone',18)} Call</button>`:''}${/^[6-9]\d{9}$/.test(String(j.whatsapp||''))?`<button type="button" disabled data-job-whatsapp="${escapeHtml(j.id)}">${icon('message',18)} WhatsApp</button>`:''}${/^https:\/\//i.test(String(j.applyLink||''))?`<button type="button" disabled data-job-apply="${escapeHtml(j.id)}">${icon('arrow',18)} Apply Link</button>`:''}</div><p class="fine-print">Verify the vacancy and employer before sharing personal documents.</p>`:``}</article></div>`}

function localJobDetailPage(){const j=(S.jobs||[]).find(x=>x.id===S.jobId&&bpJobLive(x));if(!j)return localJobsPage();return `<div class="screen city-page bp-jobs-page bp-jobs-emerald bp-jobs-refined bp-jobs-detail-refined">${head('Job Details')}${bpJobDetailContent(j)}</div>`}
function bpJobCreatedTime(j){
 const t=j.createdAt;
 if(t&&typeof t.toMillis==='function')return t.toMillis();
 if(t&&typeof t.seconds==='number')return t.seconds*1000+Math.floor((t.nanoseconds||0)/1e6);
 if(t&&typeof t.__bpTimestampMs==='number')return t.__bpTimestampMs;
 if(typeof t==='number')return t;
 if(typeof t==='string'){const ms=Date.parse(t);return Number.isFinite(ms)?ms:0}
 return 0;
}
function bpJobGroupSharedValue(jobs,key){
 const values=jobs.map(j=>String(j[key]??'').trim());
 return values.every(v=>v&&v.toLowerCase()===values[0].toLowerCase())?values[0]:'Varies by position';
}
function bpJobGroupSummaryCard(jobs){
 // The submission form asks for TOTAL vacancies. A multi-title submission
 // copies that same total into each job document; never sum those copies.
 const values=jobs.map(j=>String(j.vacancies??'').trim()).filter(Boolean);
 const distinct=[...new Set(values)];
 const vacancies=distinct.length===1?distinct[0]:distinct.length?'Varies by submission':'Not specified';
 const fields=[['Job Type',bpJobGroupSharedValue(jobs,'jobType')],['Total Vacancies',vacancies],['Last Date to Apply',bpJobGroupSharedValue(jobs,'lastApplyDate')],['Category',bpJobGroupSharedValue(jobs,'category')]];
 return `<article class="bp-job-detail-card bp-job-group-summary"><div class="bp-detail-section-label">${icon('briefcase',18)} Job Overview</div><div class="bp-job-facts">${fields.map(([name,value])=>`<div><small>${escapeHtml(name)}</small><strong>${escapeHtml(value)}</strong></div>`).join('')}</div></article>`;
}
function bpJobGroupPositionCard(j,index){
 return `<div class="bp-job-group-row"><div class="bp-job-group-row-heading"><span class="bp-job-position-number">${index+1}</span><h3>${bpJobCardUpper(j.title,'Job Vacancy')}</h3></div></div>`;
}
function bpJobGroupDetailPage(){
 const jobs=(S.jobs||[]).filter(j=>bpJobLive(j)&&bpJobOwnerGroupKey(j)===S.jobDetailGroup);
 if(!jobs.length)return localJobsPage();
 // Only approved, currently visible jobs qualify. Use creation time, not edit time.
 const latest=[...jobs].sort((a,b)=>bpJobCreatedTime(b)-bpJobCreatedTime(a)||String(b.id||'').localeCompare(String(a.id||'')))[0];
 const mobile=String(latest.mobile||'').replace(/\D/g,'');
 const whatsapp=String(latest.whatsapp||'').replace(/\D/g,'')||mobile;
 const valid=n=>/^[6-9]\d{9}$/.test(n);
 const applyLink=/^https:\/\//i.test(String(latest.applyLink||''))?latest.applyLink:'';
 const actions=`${valid(mobile)?`<button type="button" disabled data-job-call="${escapeHtml(latest.id)}">${icon('phone',18)} Call</button>`:''}${valid(whatsapp)?`<button type="button" disabled data-job-whatsapp="${escapeHtml(latest.id)}">${icon('message',18)} WhatsApp</button>`:''}${applyLink?`<button type="button" disabled data-job-apply="${escapeHtml(latest.id)}">${icon('arrow',18)} Apply Link</button>`:''}`;
 return `<div class="screen city-page bp-jobs-page bp-jobs-emerald bp-jobs-refined bp-jobs-detail-refined">${head('Job Details')}<div class="bp-jobs-hero bp-detail-hero"><span class="bp-hero-eyebrow">LOCAL JOBS · BARAN</span><h1>${bpJobCardUpper(jobs[0].company,'Organisation')}</h1><p>${jobs.length} Jobs Available · Baran, Rajasthan</p></div>${bpJobGroupSummaryCard(jobs)}<article class="bp-job-detail-card bp-job-group-post-list"><div class="bp-detail-section-label">Available Job Posts (${jobs.length})</div>${jobs.map((j,i)=>bpJobGroupPositionCard(j,i,jobs)).join('')}</article><article class="bp-job-detail-card bp-job-group-contact"><div class="bp-detail-section-label">${icon('phone',18)} Contact Organisation</div>${bpJobDisclaimer()}${actions?`<div class="bp-job-actions">${actions}</div>`:'<p>Contact information unavailable.</p>'}<p class="fine-print">For enquiries about any of the above positions. Verify the employer before sharing personal documents.</p></article></div>`;
}

async function bpOpenMyJobs(){
 if(!C.user){S.afterAuth='localJobMine';S.authTab='signin';return go('auth')}
 S.jobMineLoading=true;S.jobMineError='';go('localJobMine');
 try{S.jobMine=await C.myLocalJobs()}catch(e){S.jobMineError=String(e.message||e)}
 finally{S.jobMineLoading=false;if(S.page==='localJobMine')render()}
}
function bpMyJobsPage(){
 if(!C.user){S.afterAuth='localJobMine';return auth()}
 return `<div class="screen city-page bp-jobs-page bp-jobs-emerald bp-jobs-refined">${head('My Jobs')}<div class="bp-jobs-hero bp-form-hero"><span class="bp-hero-eyebrow">BARAN PRIDE · LOCAL JOBS</span><h1>My Jobs</h1><p>अपनी Job Posts और Approval Status देखें</p></div><div class="bp-job-post-entry"><button type="button" data-job-form-open>${icon('plus',16)} Post a Job</button><button type="button" data-job-my-open>Refresh</button></div>${S.jobMineLoading?'<p class="city-message">Loading your jobs...</p>':''}${S.jobMineError?`<p class="city-message">${escapeHtml(S.jobMineError)}</p>`:''}<div class="bp-job-results">${(S.jobMine||[]).map(j=>`<article class="bp-job-card bp-emerald-card"><div class="bp-job-card-top"><span class="bp-job-compact-icon">${icon('briefcase',21)}</span><div><h3>${escapeHtml(j.title||'Job')}</h3><p>${escapeHtml(j.company||'Organisation')} · Baran</p></div><span class="bp-my-job-status bp-my-job-${escapeHtml(j.status||'pending')}">${escapeHtml(j.status||'pending')}</span></div><div class="bp-job-tags"><span>${escapeHtml(j.jobType||'Job')}</span><span>${escapeHtml(j.salary||'Salary on enquiry')}</span></div><div class="bp-job-compact-bottom"><button type="button" disabled aria-disabled="true" title="Editing is currently unavailable">Edit</button>${j.status!=='closed'?`<button type="button" data-job-mine-close="${escapeHtml(j.id)}">Close Job</button>`:''}</div></article>`).join('')||(!S.jobMineLoading?'<p class="city-message">You have not submitted any jobs yet.</p>':'')}</div></div>`
}
function bpEditMyJob(id){const j=S.jobMine.find(x=>x.id===id);if(!j)return;const company=prompt('Organisation Name',j.company||'');if(company===null)return;const title=prompt('Job Title',j.title||'');if(title===null)return;const salary=prompt('Salary (optional)',j.salary||'');if(salary===null)return;const description=prompt('Job Description (optional)',j.description||'');if(description===null)return;C.updateMyLocalJob(id,{company,title,salary,description}).then(()=>{toast('Changes submitted for Admin approval');bpOpenMyJobs()}).catch(e=>toast('Update failed: '+e.message))}

let bpJobFormStep=0;
function bpJobShowStep(step){const form=document.getElementById('bp-job-form');if(!form)return;const sections=[...form.querySelectorAll('[data-job-step]')];if(step>bpJobFormStep){const current=sections[bpJobFormStep];for(const field of current.querySelectorAll('input,select,textarea')){if(!field.checkValidity()){field.reportValidity();return}}}bpJobFormStep=Math.max(0,Math.min(3,step));sections.forEach((el,i)=>el.hidden=i!==bpJobFormStep);form.querySelectorAll('[data-job-step-indicator]').forEach((el,i)=>el.classList.toggle('active',i<=bpJobFormStep));form.querySelector('[data-job-back]').hidden=bpJobFormStep===0;form.querySelector('[data-job-next]').hidden=bpJobFormStep===3;form.querySelector('[data-job-final]').hidden=bpJobFormStep!==3;if(bpJobFormStep===3){const fd=new FormData(form);const preview=form.querySelector('#bp-job-review');preview.innerHTML=[['Organisation',fd.get('company')],['Job Posts',fd.get('titles')],['Vacancies',fd.get('vacancies')],['Category',fd.get('category')],['Job Type',fd.get('jobType')],['Salary',fd.get('salary')||'Not specified'],['Location','Baran, Rajasthan'],['Qualification',fd.get('qualification')||'Not specified'],['Experience',fd.get('experience')||'Not specified'],['Contact',fd.get('mobile')],['WhatsApp',fd.get('whatsapp')||'Not specified']].map(([k,v])=>`<p><strong>${escapeHtml(k)}:</strong> ${escapeHtml(String(v||''))}</p>`).join('')}window.scrollTo(0,0)}
function localJobFormPage(){if(!C.user){S.afterAuth='localJobForm';return auth()}bpJobFormStep=0;const field=(name,label,required=false,type='text',extra='')=>`<label class="bp-job-field">${label}${required?' *':''}<input name="${name}" type="${type}" ${required?'required':''} ${extra}></label>`;return `<div class="screen city-page bp-jobs-page bp-jobs-emerald">${head('Post a Job')}<div class="bp-jobs-hero bp-form-hero"><span class="bp-hero-eyebrow">BARAN PRIDE · LOCAL JOBS</span><h1>Post a Job</h1><p>आसान 4 Steps में अपनी Vacancy पोस्ट करें</p></div><form id="bp-job-form" class="bp-job-form bp-job-wizard"><div class="bp-job-steps">${['Basic Details','Requirements','Contact','Review'].map((n,i)=>`<span data-job-step-indicator class="${i===0?'active':''}">${i+1}<small>${n}</small></span>`).join('')}</div><section data-job-step><h2>1. Basic Job Details</h2>${field('company','Business / Organisation Name',true,'text','maxlength="120" placeholder="e.g. IT Campus"')}<label class="bp-job-field">Job Post Names *<textarea name="titles" required maxlength="1200" rows="3" placeholder="Computer Operator, Accountant, Teacher"></textarea><small>एक से ज्यादा पद Comma (,) लगाकर लिखें। अधिकतम 10 पद।</small></label>${field('vacancies','Total Vacancies',true,'number','min="1" max="1000" placeholder="e.g. 5"')}<label class="bp-job-field">Job Category *<select name="category" required><option value="">Select Category</option>${BP_JOB_CATEGORIES.map(x=>`<option>${escapeHtml(x)}</option>`).join('')}</select></label><label class="bp-job-field">Job Type *<select name="jobType" required><option value="">Select Job Type</option><option>Full Time</option><option>Part Time</option><option>Contract</option><option>Internship</option></select></label>${field('salary','Salary (Optional)',false,'text','maxlength="100" placeholder="₹10,000–15,000 / Negotiable"')}<div class="bp-job-fixed-location">${icon('pin',18)} Location: <strong>Baran, Rajasthan</strong></div><input type="hidden" name="location" value="Baran, Rajasthan"></section><section data-job-step hidden><h2>2. Job Requirements <small>(Optional)</small></h2>${field('qualification','Qualification',false,'text','maxlength="120" placeholder="12th / Graduate"')}<label class="bp-job-field">Experience<select name="experience"><option value="">Not specified</option><option>Fresher</option><option>Experienced</option><option>Both</option></select></label>${field('skills','Required Skills',false,'text','maxlength="200" placeholder="Computer, Typing, Tally"')}${field('workingHours','Working Hours',false,'text','maxlength="80" placeholder="9 AM – 6 PM"')}${field('weeklyOff','Weekly Off',false,'text','maxlength="80" placeholder="Sunday"')}<label class="bp-job-field">Job Description<textarea name="description" maxlength="2000" rows="4" placeholder="काम की जानकारी लिखें..."></textarea></label>${field('lastApplyDate','Last Date to Apply',false,'date')}<label class="bp-job-field">Job / Business Photo (Optional)<input type="file" name="jobPhoto" accept="image/jpeg,image/png,image/webp"><small>One photo, JPG/PNG/WebP, maximum 5 MB</small></label></section><section data-job-step hidden><h2>3. Contact & Apply</h2>${field('mobile','Contact Mobile Number',true,'tel','inputmode="numeric" pattern="[6-9][0-9]{9}" maxlength="10" placeholder="10-digit mobile"')}<label class="bp-job-check"><input type="checkbox" data-job-same-whatsapp> WhatsApp Number भी यही है</label>${field('whatsapp','WhatsApp Number (Optional)',false,'tel','inputmode="numeric" pattern="[6-9][0-9]{9}" maxlength="10"')}${field('applyLink','External Apply Link (Optional)',false,'url','maxlength="500" placeholder="https://example.com/apply"')}</section><section data-job-step hidden><h2>4. Review & Submit</h2><div id="bp-job-review" class="bp-job-review"></div><label class="bp-job-check"><input name="consent" type="checkbox" required> I confirm the job details are accurate and agree to display the contact number after approval.</label><p class="fine-print">Your job will appear after Admin approval.</p></section><p class="bp-job-message" id="bp-job-message" role="status" aria-live="polite"></p><div class="bp-job-wizard-actions"><button type="button" data-job-back hidden>← Back</button><button type="button" data-job-next>Next →</button><button type="submit" class="bp-job-submit-button" data-job-final hidden>Submit for Admin Approval</button></div></form></div>`}
let bpJobSending=false;
async function bpSubmitJob(form){
 const msg=form.querySelector('#bp-job-message'),btn=form.querySelector('[type=submit]');
 if(bpJobSending||form.dataset.jobSubmitted==='true')return;
 const fd=new FormData(form),data=Object.fromEntries(fd.entries());const photo=data.jobPhoto;delete data.jobPhoto;if(photo?.size){if(!['image/jpeg','image/png','image/webp'].includes(photo.type)||photo.size>5*1024*1024){msg.textContent='Select JPG, PNG or WebP photo under 5 MB.';return}data.jobPhoto=photo}
 if(!/^[6-9][0-9]{9}$/.test(data.mobile||'')||(data.whatsapp&&!/^[6-9][0-9]{9}$/.test(data.whatsapp))){msg.textContent='Enter valid 10-digit contact numbers.';return}
 if(!data.consent){msg.textContent='Please confirm the contact-publication consent.';return}
 if(!C.enabled||!C.user){msg.textContent='Please sign in before submitting a job.';return}
 if(typeof navigator!=='undefined'&&navigator.onLine===false){msg.textContent='Internet connection is off. Connect and try again.';return}
 bpJobSending=true;btn.disabled=true;btn.textContent='Submitting...';msg.textContent='Submitting for review...';
 try{
  const count=await C.submitLocalJobs(data);
  form.dataset.jobSubmitted='true';btn.type='button';btn.setAttribute('data-job-back-latest','');btn.disabled=false;btn.textContent='← Back to Latest Jobs';msg.textContent=count+' job(s) submitted successfully for Admin approval. Your jobs will appear publicly after approval.';
 }catch(e){
  msg.textContent='Submission not completed: '+(e?.code==='permission-denied'?'Firebase permission denied. Admin must deploy the secure job rules.':String(e?.message||'Please retry.'));
  btn.disabled=false;btn.textContent='Submit for Admin Approval';
 }finally{bpJobSending=false}
}
function donorPage(){const group=S.donorFilter;const entries=S.donors.filter(d=>group==='All'||d.bloodGroup===group);return `<div class="screen city-page">${head('Blood Donors')}<div class="city-heading">${icon('drop',32)}<div><h1>Blood Donors</h1><p>स्वैच्छिक रक्तदाताओं की सूची</p></div></div><div class="special-note">केवल सहमति देने वाले रक्तदाताओं के फोन नंबर दिखते हैं। रक्त की उपलब्धता की गारंटी नहीं है। आपात स्थिति में अस्पताल या ब्लड बैंक से संपर्क करें।</div><p class="fine-print">Offline donor information is saved for up to 24 hours and may be outdated. Please confirm availability directly.</p><div class="special-filter">${bloodGroups.map(g=>`<button class="${group===g?'selected':''}" data-blood-filter="${escapeHtml(g)}">${escapeHtml(g)}</button>`).join('')}</div>${S.donorError?`<div class="city-message">${escapeHtml(S.donorError)}</div>`:entries.length?entries.map(d=>`<article class="blood-card"><span class="blood-pill">${escapeHtml(d.bloodGroup)}</span><div class="blood-card-text"><strong>${escapeHtml(maskBloodDonorName(d.name))}</strong><small>${escapeHtml(d.area||'Baran')} · Voluntary Donor</small><p>${escapeHtml(d.phone)}</p></div><button data-blood-call="${escapeHtml(d.id)}" aria-label="Call ${escapeHtml(maskBloodDonorName(d.name))}">${icon('phone',18)} Call</button></article>`).join(''):`<div class="city-message">इस ग्रुप में फिलहाल कोई सत्यापित रक्तदाता उपलब्ध नहीं है।<br><small>Admin से सूची अपडेट की जाएगी।</small></div>`}<p class="fine-print">प्रकाशित नंबर स्वैच्छिक सार्वजनिक सहमति पर आधारित हैं। गलत नंबर या सूची हटाने के लिए BARAN PRIDE Admin से संपर्क करें।</p></div>`}
function propertiesPage(){return `<div class="screen city-page">${head('All Properties')}<div class="bp-property-list-heading"><h1>All Properties</h1><p>Find your perfect property in Baran</p></div><div class="bp-property-filters">${['All','Sale','Rent','House','Plot','Shop'].map(f=>`<button type="button" data-property-filter="${f}" class="${S.propertyFilter===f?'active':''}">${f}</button>`).join('')}</div><div class="bp-property-sort"><span>${propertyFiltered().length} Properties Found</span><select id="bp-property-sort"><option value="latest" ${S.propertySort==='latest'?'selected':''}>Latest First</option><option value="low" ${S.propertySort==='low'?'selected':''}>Price: Low to High</option><option value="high" ${S.propertySort==='high'?'selected':''}>Price: High to Low</option></select></div>${S.propertyError?`<p class="city-message">${escapeHtml(S.propertyError)}</p>`:propertyFiltered().length?`<div class="bp-property-list">${propertyFiltered().map(propertyListCard).join('')}</div>`:'<p class="city-message">No matching approved properties yet.</p>'}<button class="primary-btn bp-property-submit-link" data-go="propertySubmit">${icon('plus',18)} List Your Property</button></div>`}
function propertySubmitPage(){if(C.enabled&&!C.user){S.afterAuth='propertySubmit';return auth()}return `<div class="screen city-page">${head('Sell Your Property')}<h1 class="page-title">Property Sale Request</h1><p class="intro">प्रॉपर्टी की जानकारी भरें। Owner Name और Mobile केवल Admin को दिखाई देंगे।</p>${!C.enabled?banner():''}<form id="property-request-form" class="form-card"><div class="field"><label>Owner Name * (PRIVATE)</label><input name="ownerName" required minlength="3" maxlength="100" placeholder="Property owner name"></div><div class="field"><label>Owner Mobile Number * (PRIVATE)</label><input name="ownerPhone" type="tel" inputmode="numeric" required maxlength="10" pattern="[6-9][0-9]{9}" placeholder="10-digit number"></div><div class="fieldrow"><div class="field"><label>Property Type *</label><select name="propertyType" required><option value="">Select Type</option>${['Plot','House','Flat','Shop','Land','Commercial Property','Other'].map(x=>`<option>${x}</option>`).join('')}</select></div><div class="field"><label>Area / Locality *</label><input name="area" required maxlength="100" placeholder="e.g. Kota Road"></div></div><div class="fieldrow"><div class="field"><label>Property Size</label><input name="size" maxlength="60" placeholder="e.g. 1200 sq ft"></div><div class="field"><label>Expected Price ₹</label><input type="number" min="1" max="1000000000" step="1" name="askingPrice" placeholder="Optional"></div></div><div class="field"><label>Listing Type</label><select name="listingType"><option value="Sale">For Sale</option><option value="Rent">For Rent</option></select></div><div class="field"><label>Property Photos (up to 5, optional)</label><input type="file" name="propertyPhotos" accept="image/jpeg,image/png,image/webp" multiple><small>Each photo must be under 5 MB. Upload only photos you own or are authorized to share.</small></div><div class="field"><label>Property Features (optional)</label><div class="bp-property-feature-choices">${['Parking','Water Supply','Furnished','Corner Property','Lift','Balcony','Road Access','Electricity','Near Market'].map(f=>`<label><input type="checkbox" name="propertyFeature" value="${f}"> ${f}</label>`).join('')}</div><input name="customFeatures" maxlength="200" placeholder="Other features, comma separated (optional)"></div><div class="field"><label>Property Details</label><textarea name="description" maxlength="900" placeholder="Rooms, facilities, property features (do not include names or phone numbers)"></textarea></div><label class="special-consent"><input type="checkbox" name="confirmed" required> मैं मालिक हूँ या अधिकृत प्रतिनिधि हूँ। मेरा नाम और मोबाइल Admin सत्यापन के लिए दिया गया है।</label><label class="special-consent"><input type="checkbox" name="publicPhoneConsent"> मैं स्पष्ट सहमति देता/देती हूँ कि BARAN PRIDE Admin चाहे तो मेरा मोबाइल नंबर ऐप पर सार्वजनिक कर सकता है। यह विकल्प वैकल्पिक है; नंबर दिखाने का अंतिम निर्णय सिर्फ Admin करेगा।</label><div class="form-note">आपका नाम हमेशा छिपा रहेगा। डिफॉल्ट नंबर Customer Care 7737325205 होगा। अगर आपने ऊपर सार्वजनिक नंबर की अनुमति दी है, तब भी केवल Admin ही नंबर दिखाने का फैसला करेगा। अनुमति वापस लेने के लिए Customer Care से संपर्क करें।</div><button type="submit" class="primary-btn">${icon('check',18)} Submit to Admin</button></form></div>`}
async function submitProperty(f){const fd=new FormData(f);const data={ownerName:String(fd.get('ownerName')||'').trim(),ownerPhone:String(fd.get('ownerPhone')||'').trim(),propertyType:String(fd.get('propertyType')||'').trim(),area:String(fd.get('area')||'').trim(),size:String(fd.get('size')||'').trim(),askingPrice:Number(fd.get('askingPrice')||0),description:String(fd.get('description')||'').trim(),listingType:String(fd.get('listingType')||'Sale'),features:[...new Set([...fd.getAll('propertyFeature').map(String),...String(fd.get('customFeatures')||'').split(',').map(x=>x.trim()).filter(Boolean)])].slice(0,15).map(x=>x.slice(0,60)),publicPhoneConsent:fd.get('publicPhoneConsent')==='on'};if(!validPhone(data.ownerPhone)||data.ownerName.length<3||!data.area||!data.propertyType||fd.get('confirmed')!=='on')return toast('Please complete all required fields');const btn=f.querySelector('button[type=submit]');btn.disabled=true;try{if(C.enabled){if(!C.user)throw Error('Please sign in first');await C.submitProperty(data,[...f.querySelector('[name=propertyPhotos]').files]);toast('Property request sent for Admin approval')}else toast('Demo only: connect Firebase to submit a real request');openProperties()}catch(err){toast('Unable to submit: '+err.message);btn.disabled=false}}
function cityGoBack(){if(S.page==='cityDetail'){return bpReturnToPrevious(S.cityBackTarget||'cityList')}if(S.page==='cityNews'){return bpReturnToPrevious('home')}if(S.page==='cityList'){if(S.cityType==='contacts'&&S.contactSelectedCategory){S.contactSelectedCategory='';S.cityQuery='';render();requestAnimationFrame(()=>window.scrollTo(0,S.bpContactScroll||0));return true}return bpReturnToPrevious('home')}return false}
function cityShare(id){const x=S.cityItems.find(o=>o.id===id&&o.status==='published');if(!x)return;const msg=x.title+' — BARAN PRIDE\n'+(x.summary||'');if(native('shareText',msg))return;if(navigator.share)navigator.share({title:x.title,text:msg}).catch(()=>{});else if(navigator.clipboard)navigator.clipboard.writeText(msg).then(()=>toast('Information copied'))}


// App update notices: versionCode comes from native Android, not editable WebView storage.
let bpUpdateSettings=null;
let bpUpdateLater=false;
function bpPlayStoreLink(url){try{const u=new URL(url);return u.protocol==='https:'&&u.hostname==='play.google.com'&&u.pathname==='/store/apps/details'&&/^[a-zA-Z][a-zA-Z0-9_]*(?:\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(u.searchParams.get('id')||'')}catch(e){return false}}
function bpDirectApkLink(url){try{const u=new URL(url);return u.protocol==='https:'&&/\.apk$/i.test(u.pathname)&&!u.username&&!u.password}catch(e){return false}}
function bpUpdateTarget(u){const source=u.source==='apk'?'apk':'play';const link=source==='apk'?u.apkUrl:u.playStoreUrl;return (source==='apk'?bpDirectApkLink(link):bpPlayStoreLink(link))?{source,url:link}:null}
function bpShowUpdate(){
 const old=document.getElementById('bp-update-overlay');if(old)old.remove();
 const u=bpUpdateSettings;
 const target=u&&bpUpdateTarget(u);
 if(!u||u.enabled!==true||!target)return;
 let installed=0;try{installed=Number(window.AndroidBridge?.getVersionCode?.()||0)}catch(e){return}
 const latest=Number(u.latestVersionCode);
 if(!Number.isSafeInteger(installed)||installed<1||!Number.isSafeInteger(latest)||latest<=installed)return;
 const force=u.mode==='force';if(!force&&bpUpdateLater)return;
 const overlay=document.createElement('div');overlay.id='bp-update-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Baran Pride App Update');
 overlay.style.cssText='position:fixed;inset:0;z-index:2147483647;background:rgba(3,17,43,.82);display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box';
 const card=document.createElement('section');card.style.cssText='width:100%;max-width:410px;max-height:90vh;overflow:auto;border-radius:20px;background:#fff;color:#102d61;padding:25px 21px;box-shadow:0 15px 60px #0006;text-align:center;font-family:inherit';
 const title=document.createElement('h2');title.textContent=force?'App Update Required':'New Update Available';title.style.cssText='margin:0 0 12px;font-size:23px;color:#103d9c';
 const version=document.createElement('p');version.textContent='Baran Pride v'+String(u.latestVersionName||latest);version.style.cssText='font-weight:700;margin:0 0 12px';
 const msg=document.createElement('p');msg.textContent=String(u.message||'A new version of Baran Pride is available.').slice(0,500);msg.style.cssText='line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere';
 const update=document.createElement('button');update.type='button';update.textContent=target.source==='apk'?'Download New APK':'Update on Google Play';update.style.cssText='display:block;width:100%;border:0;border-radius:12px;padding:14px;background:#154bb4;color:white;font-size:16px;font-weight:700;margin-top:16px';
 update.addEventListener('click',()=>{if(!native('openUrl',target.url))window.open(target.url,'_blank','noopener')});
 card.append(title,version,msg,update);
 if(!force){const later=document.createElement('button');later.type='button';later.textContent='Later';later.style.cssText='border:0;background:transparent;padding:15px;color:#315586;font-weight:700';later.addEventListener('click',()=>{bpUpdateLater=true;overlay.remove()});card.appendChild(later)}
 overlay.appendChild(card);document.body.appendChild(overlay);
}


// Phase 2G-B: foreground background-sync coordinator. Existing cache keys and TTLs are unchanged.
let bpSyncBusy=false,bpSyncQueued=false,bpSyncLast=0,bpSyncStatus='ready',bpSyncError=false,bpSyncFailedModules=[];
const bpSyncImageQueue=new Set();
let bpSyncImageRunning=false;
let bpImageDone=0,bpImageFailed=0,bpImageTotal=0,bpImagePreparing=false;
// Keep popup state separate from the background caching lifecycle.
let bpProgressDismissed=false;
let bpProgressFinishedAt=0;
let bpProgressStartedAt=0;
let bpSyncTasksTotal=0,bpSyncTasksDone=0,bpSyncTasksFinished=false;
let bpSyncPaused=false;
const bpStartupWasPrepared=(()=>{try{return localStorage.getItem('bp-offline-prepared-v1')==='yes'}catch{return false}})();
let bpStartupSpinnerVisible=bpStartupWasPrepared;
let bpStartupSpinnerUntil=Date.now()+3000;
function bpStartupSpinner(){
 let el=document.getElementById('bp-startup-loader');
 if(!el){el=document.createElement('div');el.id='bp-startup-loader';el.setAttribute('role','status');el.setAttribute('aria-live','polite');document.body.appendChild(el)}
 el.hidden=!bpStartupSpinnerVisible;
 if(bpStartupSpinnerVisible)el.innerHTML='<div class="bp-startup-mark"><span class="bp-startup-spinner"></span></div><strong>BARAN PRIDE</strong><small>Checking latest updates...</small>';
}
function bpFinishStartupSpinner(){
 const delay=Math.max(0,bpStartupSpinnerUntil-Date.now());
 setTimeout(()=>{bpStartupSpinnerVisible=false;bpStartupSpinner()},delay);
}
if(bpStartupWasPrepared){bpStartupSpinner();bpFinishStartupSpinner()}


const bpImageSeen=new Set();
function bpNetworkOnline(){return bpIsInternetAvailable()}
function bpIsDiskCached(url){
 try{return window.AndroidBridge?.isPublicImageCached?.(url)===true}catch(e){return false}
}
let bpSyncPanelOpen=false,bpSyncMessageTimer=null,bpSyncPanelTimer=null;
function bpScheduleSyncPanelClose(){clearTimeout(bpSyncPanelTimer);if(bpSyncPanelOpen)bpSyncPanelTimer=setTimeout(()=>{bpSyncPanelOpen=false;bpUpdateSyncIndicator()},3000)}
function bpSyncMode(){return !bpNetworkOnline()?'offline':bpSyncError?'failed':(bpSyncBusy||bpSyncImageRunning||bpSyncStatus==='syncing'||!bpSyncTasksFinished)?'syncing':'complete'}
function bpStatusMarkup(){
 const mode=bpSyncMode();
 const title={offline:'Offline — saved data',failed:'Sync failed — view details',syncing:'Sync in progress',complete:'Sync complete'}[mode];
 const symbol={offline:'wifi-off',failed:'info',syncing:'refresh',complete:'sync-check'}[mode];
 return `<button type="button" class="bp-mini-sync ${mode}" data-bp-sync-status aria-label="${escapeHtml(title)}" title="${escapeHtml(title)}" aria-expanded="${bpSyncPanelOpen?'true':'false'}">${icon(symbol,21)}</button>`;
}
function bpSyncPanel(){
 let el=document.getElementById('bp-sync-panel');
 if(!bpSyncPanelOpen){el?.remove();return}
 if(!el){el=document.createElement('section');el.id='bp-sync-panel';el.className='bp-sync-panel';document.body.appendChild(el)}
 const mode=bpSyncMode();const title={offline:'Offline Mode',failed:'Sync Failed',syncing:'Sync in Progress',complete:'Sync Complete'}[mode];
 const when=bpSyncLast?new Date(bpSyncLast).toLocaleString('en-IN'):'Not completed yet';
 el.innerHTML=`<div class="bp-sync-panel-top"><strong>${escapeHtml(title)}</strong><button type="button" data-bp-sync-close aria-label="Close sync details">${icon('close',17)}</button></div><p>${mode==='offline'?'Saved data may be available. Connect to the internet to sync.':mode==='failed'?'Some public sections could not update.':mode==='syncing'?'Updating public sections and offline content.':'Public section sync is up to date.'}</p><small>Last sync: ${escapeHtml(when)}</small>${bpSyncFailedModules.length&&mode==='failed'?`<small>${escapeHtml(bpSyncFailedModules.slice(0,2).join(' | '))}</small>`:''}`;
}
function bpUpdateSyncIndicator(){
 const bar=document.querySelector('.topbar .top-actions');if(!bar)return;
 bar.querySelector('.bp-mini-sync')?.remove();
 bar.insertAdjacentHTML('afterbegin',bpStatusMarkup());bpSyncPanel();
}
function bpSyncCompletedMessage(){
 if(bpSyncMode()!=='complete')return;
 let el=document.getElementById('bp-sync-complete-message');
 if(!el){el=document.createElement('div');el.id='bp-sync-complete-message';el.className='bp-sync-complete-message';document.body.appendChild(el)}
 el.textContent='✓ Sync Complete';el.classList.add('visible');
 clearTimeout(bpSyncMessageTimer);bpSyncMessageTimer=setTimeout(()=>el.classList.remove('visible'),3000);
}
function bpOfflineProgress(){
 let host=document.querySelector('#bp-offline-progress');
 if(!host){host=document.createElement('div');host.id='bp-offline-progress';host.className='bp-offline-progress';host.hidden=true;document.body.appendChild(host)}
 else if(host.parentElement!==document.body)document.body.appendChild(host);
 host.onclick=e=>{if(e.target.closest('[data-bp-progress-hide]')){e.preventDefault();e.stopPropagation();bpProgressDismissed=true;host.hidden=true}};
 if(!bpImagePreparing||bpProgressDismissed||bpStartupWasPrepared){host.hidden=true;return}
 host.hidden=false;
 const complete=bpSyncTasksFinished&&!bpSyncBusy&&!bpSyncImageRunning&&bpSyncImageQueue.size===0&&(bpImageDone+bpImageFailed>=bpImageTotal);
 if(complete&&!bpStartupWasPrepared){try{localStorage.setItem('bp-offline-prepared-v1','yes')}catch{}}

 const tasksProgress=bpSyncTasksTotal?bpSyncTasksDone/bpSyncTasksTotal:0;
 const imageProgress=bpImageTotal?(bpImageDone+bpImageFailed)/bpImageTotal:(bpSyncTasksFinished?1:0);
 const progress=complete?100:Math.min(99,Math.max(0,Math.round(100*(.65*tasksProgress+.35*imageProgress))));
 if(complete&&bpProgressFinishedAt===0){
 bpProgressFinishedAt=Date.now();
 setTimeout(()=>{if(bpProgressFinishedAt){bpProgressDismissed=true;bpOfflineProgress()}},Math.max(1400,2200-(Date.now()-bpProgressStartedAt)));
}else if(!complete){bpProgressFinishedAt=0}
 // Keep the meter element mounted so CSS width transitions are not reset on every sync event.
 if(!host.querySelector('[data-bp-meter-fill]')){
  host.innerHTML=`<div class="bp-offline-head"><span data-bp-progress-title></span><button type="button" data-bp-progress-hide aria-label="Hide download status">×</button></div><div class="bp-offline-sub" data-bp-progress-sub></div><div class="bp-offline-meter" role="progressbar" aria-label="Offline download progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span data-bp-meter-fill style="width:0%"></span></div><small data-bp-progress-count></small>`;
 }
 const title=host.querySelector('[data-bp-progress-title]');
 const subtitle=host.querySelector('[data-bp-progress-sub]');
 const meter=host.querySelector('.bp-offline-meter');
 const fill=host.querySelector('[data-bp-meter-fill]');
 const count=host.querySelector('[data-bp-progress-count]');
 title.textContent=complete?(bpImageFailed?'Offline download partially complete':'Offline content ready'):'Preparing offline content';
 subtitle.textContent=complete?(bpImageFailed?`${bpImageFailed} image(s) could not be saved. Open sections online to retry.`:'Selected images saved for offline use.'):bpSyncPaused?'Waiting for app to resume syncing...':bpSyncBusy?'Checking sections and downloading images...':`Saving images ${bpImageDone+bpImageFailed}/${bpImageTotal}`;
 meter.setAttribute('aria-valuenow',String(progress));
 fill.style.width=progress+'%';
 count.textContent=`${progress}% complete · ${bpSyncTasksDone}/${bpSyncTasksTotal||11} sections · ${bpImageDone} cached${bpImageFailed?' · '+bpImageFailed+' unavailable':''}${!complete?' · You can continue using the app':''}`;
}
function bpWarmImages(urls,limit=32){
 for(const raw of (urls||[]).slice(0,limit)){
  const url=safeHttps(raw||'');
  if(!url||!/^https:\/\//.test(url)||bpImageSeen.has(url))continue;
  bpImageSeen.add(url);
  bpImageTotal++;
  if(bpIsDiskCached(url)){bpImageDone++;continue}
  bpSyncImageQueue.add(url);
 }
 bpOfflineProgress();
 bpDrainImages();
}
async function bpDrainImages(){
 if(bpSyncImageRunning||!bpNetworkOnline()||!bpSyncImageQueue.size)return;
 bpSyncImageRunning=true;bpUpdateSyncIndicator();
 try{
  while(bpNetworkOnline()&&bpSyncImageQueue.size){
   const url=bpSyncImageQueue.values().next().value;bpSyncImageQueue.delete(url);
   if(bpIsDiskCached(url)){bpImageDone++;bpOfflineProgress();continue}
   const ok=await new Promise(resolve=>{
    const img=new Image();let finished=false;
    const done=success=>{if(finished)return;finished=true;clearTimeout(timeout);img.onload=null;img.onerror=null;resolve(success)};
    const timeout=setTimeout(()=>done(false),9000);
    img.onload=()=>done(true);img.onerror=()=>done(false);
    img.src=url;
   });
   // Image onload is not proof of persistent disk cache: ask native bridge.
   if(ok&&bpIsDiskCached(url))bpImageDone++;else bpImageFailed++;
   bpOfflineProgress();
  }
 }finally{bpSyncImageRunning=false;bpUpdateSyncIndicator();bpOfflineProgress()}
}
function bpBusinessPhotos(list){
 return (list||[]).flatMap(b=>[b.cover||b.photoUrls?.[0]||'',...(b.photoUrls||[]).slice(0,1)]);
}
function bpCategoryWarm(category){
 if(!bpNetworkOnline())return;
 const match=(S.businesses||[]).filter(b=>businessCategories(b).some(c=>String(c).toLowerCase()===String(category).toLowerCase()));
 bpWarmImages(bpBusinessPhotos(match),36);
}
function bpHomeWarm(){
 // Limit automatic preloading to the images actually needed on the homepage.
 const featured=S.businesses.filter(b=>isPremium(b)).sort(prioritySort).slice(0,4);
 const latest=S.businesses.slice(-2);
 bpWarmImages(bpBusinessPhotos([...featured,...latest]),6);
}
async function bpBackgroundSync(force=false){
 if(!C.enabled||!bpNetworkOnline())return;
 if(bpSyncBusy){bpSyncQueued=bpSyncQueued||force;return}
 if(!force&&!bpSyncPaused&&Date.now()-bpSyncLast<5*60*1000)return;
 bpSyncPaused=false;bpSyncBusy=true;bpSyncError=false;bpSyncFailedModules=[];bpSyncTasksFinished=false;bpSyncTasksDone=0;bpSyncTasksTotal=11;bpImagePreparing=true;if(!bpProgressStartedAt)bpProgressStartedAt=Date.now();bpOfflineProgress();bpSyncStatus='syncing';bpUpdateSyncIndicator();
 try{
  // Reuse existing TTLs. No authentication or private records are prefetched.
  const cityImages=items=>(items||[]).map(x=>x.cover||x.imageUrl||x.coverImage||'');
  const eventImages=items=>(items||[]).flatMap(x=>[x.cover||x.imageUrl||x.coverImage||'',...(Array.isArray(x.photos)?x.photos:[])]);
  const tasks=[
   ()=>C.publicPromotions().then(items=>bpWarmImages(items.filter(x=>x.active===true).map(x=>x.imageUrl||''),200)),
   // Cache all photos from approved public properties, including detail-gallery images.
   ()=>C.publicProperties().then(items=>{
    S.properties=items.filter(x=>propertyIsVisible(x));
    bpWarmImages(S.properties.flatMap(propertyPhotoUrls),Number.MAX_SAFE_INTEGER);
   }),
   // Blood donor directory is text-only: fetch only opt-in published adult donors.
   // No donor photos, private fields or expired consent data are retained.
   ()=>C.publicDonors().then(items=>{S.donors=items}),
   ()=>C.publicLocalJobs(true).then(items=>{S.jobs=items;if(S.page==='localJobs')render()}),
   // Historical places include all published cover and gallery images.
   ()=>C.publicCity('historical').then(items=>bpWarmImages(eventImages(items),Number.MAX_SAFE_INTEGER)),
   ()=>C.publicCity('events').then(items=>bpWarmImages(eventImages(items),200)),
   ()=>C.publicCity('updates').then(items=>bpWarmImages(cityImages(items),10)),
   ()=>C.publicCity('tourist').then(items=>bpWarmImages(cityImages(items),10)),
   ()=>C.publicCity('blogs').then(items=>bpWarmImages(cityImages(items),10)),
   ()=>syncContacts(true),
   ()=>C.publicCity('about').then(items=>{bpAboutStore(items);bpWarmImages(cityImages(items),1)})
  ]; const taskNames=['Promotions','Properties','Blood Donors','Local Jobs','Historical','Events','Updates','Tourist','Blogs','Contacts','About']; for(const [taskIndex,task] of tasks.entries()){
   if(!bpNetworkOnline()||document.hidden){bpSyncPaused=true;bpOfflineProgress();break;}
   try{await task()}catch(e){console.warn('Background public sync failed',taskNames[taskIndex],e);bpSyncError=true;bpSyncFailedModules.push(taskNames[taskIndex]+': '+(e?.code||e?.message||'Unknown error'))}finally{bpSyncTasksDone++;bpOfflineProgress()}
  }
  if(!bpSyncPaused&&!bpSyncError&&bpSyncTasksDone===bpSyncTasksTotal)bpSyncLast=Date.now();
 }finally{
  bpSyncBusy=false;bpSyncTasksFinished=!bpSyncError&&!bpSyncPaused&&bpSyncTasksDone===bpSyncTasksTotal;bpSyncStatus='ready';bpUpdateSyncIndicator();bpOfflineProgress();if(!bpSyncQueued)bpSyncCompletedMessage();
  if(bpSyncQueued){const q=bpSyncQueued;bpSyncQueued=false;if(q)bpBackgroundSync(true)}
 }
}
function bpScheduleSync(){
 if(!C.enabled||!bpNetworkOnline())return;
 bpImagePreparing=true;if(!bpProgressStartedAt)bpProgressStartedAt=Date.now();bpOfflineProgress();bpHomeWarm();
 setTimeout(()=>{if(!document.hidden)bpBackgroundSync(bpSyncPaused)},1100);
}

// Universal image placeholder: applies only to public content images.
// The image itself displays the local placeholder while its remote URL loads.
// Existing Business, Property and Homepage Banner image defaults remain untouched.
const bpUniversalPlaceholder='img/no-image-download.png';
function bpEligiblePlaceholderImage(img){
 if(!img||img.tagName!=='IMG'||!/^https:\/\//i.test(img.getAttribute('src')||''))return false;
 if(img.closest('.business-card:not(.home-news-card),.featured-business-card,.business-detail,.bp-property-hero-photo,.bp-property-list-photo,.bp-property-detail-image,.bp-property-home-photo,.bp-property-photo,.bp-promo-slide,.bp-promo-detail,.bp-shutter-banner,.brand,.bp-hero,.hero-banner,.bp-banner,.bp-property-gallery'))return false;
 // Keep existing business covers and property defaults, even outside their normal containers.
 const fallback=img.getAttribute('onerror')||'';
 if(fallback.includes('baran-pride-default-business')||fallback.includes('bp-property'))return false;
 return true;
}
function bpPreparePlaceholderImage(img){
 if(!bpEligiblePlaceholderImage(img))return;
 const src=img.getAttribute('src');
 if(img.dataset.bpPlaceholderSource===src)return;
 img.dataset.bpPlaceholderSource=src;
 img.classList.add('bp-universal-image');
 // Handle images that failed before the observer saw them (e.g. cached errors).
 if(img.complete&&img.naturalWidth===0)bpFailPlaceholderImage(img);
}
function bpFailPlaceholderImage(img){
 if(!img||!img.classList.contains('bp-universal-image'))return;
 img.classList.remove('bp-universal-image');
 img.dataset.bpPlaceholderSource='';
 img.removeAttribute('onerror');
 img.src=bpUniversalPlaceholder;
}
document.addEventListener('error',event=>{
 const img=event.target;
 if(img?.tagName!=='IMG')return;
 if(!img.classList.contains('bp-universal-image'))bpPreparePlaceholderImage(img);
 if(img.classList.contains('bp-universal-image')){
  event.stopImmediatePropagation();
  bpFailPlaceholderImage(img);
 }
},true);
function bpScanPlaceholderImages(root){
 if(!root)return;
 if(root.tagName==='IMG')bpPreparePlaceholderImage(root);
 root.querySelectorAll?.('img').forEach(bpPreparePlaceholderImage);
}
const bpPlaceholderObserver=new MutationObserver(changes=>{
 for(const change of changes){
  if(change.type==='attributes')bpPreparePlaceholderImage(change.target);
  else for(const node of change.addedNodes)if(node.nodeType===1)bpScanPlaceholderImages(node);
 }
});
bpPlaceholderObserver.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['src']});
function render(){const pages={home,featuredBusinesses,eventsTab,aboutUs,promotionDetail,offersAll,offerDetail,dealSubmit:bpDealSubmitPage,explore,allCategories:allCategoriesPage,detail,saved,owner,ownerPhotos,add:addForm,auth,profile,donate:donatePage,cityList,cityNews:cityNewsList,cityDetail,donors:donorPage,localJobs:localJobsPage,localJobDetail:localJobDetailPage,localJobGroupDetail:bpJobGroupDetailPage,localJobForm:localJobFormPage,localJobMine:bpMyJobsPage,properties:propertiesPage,propertySubmit:propertySubmitPage,propertyDetail:propertyDetailPage,marketplace:bpMarketPage,marketplaceComingSoon:bpMarketComingSoon,marketplaceDetail:bpMarketDetail,marketplaceSell:bpMarketSellerForm,marketplaceMine:bpMarketMyPage};const fn=pages[S.page]||home;$('#app').innerHTML=fn()+bottom();bpScanPlaceholderImages($('#app'));bpUpdateSyncIndicator();bpOfflineProgress();startHomeSlides();bpStartPromotionSlider();bpStartFeaturedDealsSlider();if(bpPropertyTimer){clearInterval(bpPropertyTimer);bpPropertyTimer=null}window.scrollTo(0,0);bpShowUpdate()}
const bpRouteStack=[];
let bpRestoringRoute=false;
function bpReturnToPrevious(fallback='home'){
 const prev=bpRouteStack.pop();
 if(prev){bpRestoringRoute=true;S.page=prev.page;S.cityType=prev.cityType;S.contactSelectedCategory=prev.contactSelectedCategory;S.cityQuery=prev.cityQuery;S.category=prev.category;S.query=prev.query;S.returnToCategories=prev.returnToCategories;render();requestAnimationFrame(()=>{window.scrollTo(0,prev.scrollY);bpRestoringRoute=false});return true}
 if(S.page!==fallback){bpRestoringRoute=true;S.page=fallback;render();bpRestoringRoute=false;return true}
 return false;
}
function go(page){closeDrawer();if(page==='add')S.editingId=null;if(page==='offersAll'&&S.page!=='offerDetail'&&S.page!=='offersAll'){bpDealsView='premium';S.dealFilter='All';S.dealSearch=''}if(page!==S.page&&!bpRestoringRoute){bpRouteStack.push({page:S.page,scrollY:window.scrollY||document.documentElement.scrollTop||0,cityType:S.cityType,contactSelectedCategory:S.contactSelectedCategory,cityQuery:S.cityQuery,category:S.category,query:S.query,returnToCategories:S.returnToCategories});if(bpRouteStack.length>30)bpRouteStack.shift()}S.page=page;render();if(page==='offersAll'||page==='offerDetail')bpWarmDealImages(page==='offerDetail')}
async function refresh(){if(C.enabled){try{
 const [pub,own,adminCategories,homeContent]=await Promise.all([
  C.approved(),C.user?C.owned().catch(e=>{console.warn('Owned listings unavailable offline',e);return S.owned||[]}):Promise.resolve([]),C.publicCategories().catch(()=>S.customCategories||[]),C.publicHomepageCity().catch(e=>{console.warn('Homepage content could not load',e);return S.homeCityItems||[]})
 ]);
 S.businesses=pub.map(x=>({...x,cover:x.cover||x.photoUrls?.[0]||''}));
 try{const publicSettings=await C.m.F.getDoc(C.m.F.doc(C.db,'appSettings','public'));const url=publicSettings.exists()?String(publicSettings.data().defaultBusinessCoverUrl||''):'';S.defaultBusinessCover=/^https:\/\//i.test(url)?url:'img/baran-pride-default-business.jpg';const settings=publicSettings.exists()?publicSettings.data():{};S.offerCategories=Array.isArray(settings.offerCategories)?settings.offerCategories:[];bpUpdateSettings=settings.appUpdate||null;S.notificationSettings={enabled:settings.notificationSliderEnabled!==false,theme:settings.notificationSliderTheme||'purple',backgroundColor:settings.notificationSliderBackgroundColor||'',textColor:settings.notificationSliderTextColor||'',iconColor:settings.notificationSliderIconColor||''};S.heroImageUrl=safeHttps(settings.homeHeroImageUrl||'');S.shutterBanner=settings.shutterBanner||{enabled:false,imageUrl:'',linkUrl:''};bpSaveBannerSettings();S.socialLinks=settings.socialLinks||{};
 // Urgent announcement takes priority over welcome voice. Android tracks each ID once per installation.
 let urgentStarted=false;
 const urgent=settings.urgentAnnouncement;
 if(urgent && urgent.enabled===true && typeof window.AndroidBridge?.urgentAnnouncement==='function'){
  const id=String(urgent.id||'');
  const expiry=String(urgent.expiresOn||'');
  const localToday=new Date();
  const today=[localToday.getFullYear(),String(localToday.getMonth()+1).padStart(2,'0'),String(localToday.getDate()).padStart(2,'0')].join('-');
  if(/^urgent-[a-zA-Z0-9-]+$/.test(id) && (!expiry || (/^\d{4}-\d{2}-\d{2}$/.test(expiry) && expiry>=today))){
   const method=urgent.method==='audio'?'audio':'tts';
   const audio=String(urgent.audioUrl||'');
   const msg=String(urgent.message||'').trim();
   if((method==='audio' && /^https:\/\/firebasestorage\.googleapis\.com\//i.test(audio)) || (method==='tts' && msg.length>=3 && msg.length<=500)){
    urgentStarted=window.AndroidBridge.urgentAnnouncement(id,method,msg,audio)===true;
   }
  }
 }
 // Native Android TTS only. Never play a fallback welcome when settings cannot be read.
 if(!urgentStarted && settings.voiceWelcomeEnabled!==false && typeof window.AndroidBridge?.welcomeVoice==='function'){
  const msg=String(settings.voiceWelcomeMessage||'Welcome to Baran Pride! आपका अपना शहर, आपकी अपनी डायरेक्टरी।').trim();
  const lang=['hi','en','mix'].includes(settings.voiceWelcomeLanguage)?settings.voiceWelcomeLanguage:'mix';
  const freq=['every','daily','3days','7days'].includes(settings.voiceWelcomeFrequency)?settings.voiceWelcomeFrequency:'daily';
  const audio=String(settings.voiceWelcomeAudioUrl||'');
  if(/^https:\/\/firebasestorage\.googleapis\.com\//i.test(audio) && typeof window.AndroidBridge.welcomeAudio==='function')window.AndroidBridge.welcomeAudio(audio,freq);
  else if(!audio && msg.length>=3&&msg.length<=300)window.AndroidBridge.welcomeVoice(msg,lang,freq);
 }
 }catch(e){S.defaultBusinessCover='img/baran-pride-default-business.jpg';bpRestoreBannerSettings();S.socialLinks={};bpUpdateSettings=null}
 S.owned=own;S.customCategories=adminCategories;S.homeCityItems=homeContent;
 try{S.properties=await C.publicProperties()}catch(e){console.warn('Homepage properties unavailable',e);S.properties=[]}
 await bpMarketLoad();
 try{
  S.promotions=await C.publicPromotions();
  bpSetPromotionOrder(S.promotions);
  bpWarmPromotionImages(S.promotions);
 }catch(e){
  console.warn('Promotions unavailable',e);
  S.promotions=C.cachedPromotions();
  bpSetPromotionOrder(S.promotions);
 }
 try{S.offers=shuffleOffers(await C.publicOffers());S.offerStart=0;S.offersLoadError=''}catch(e){console.warn('Offers unavailable',e);S.offers=C.cachedOffers?C.cachedOffers().filter(offerActive):[];S.offersLoadError=e?.code==='permission-denied'?'Deals access denied by Firestore rules. Check published offers read permissions.':'Could not refresh deals. Check connection and retry.'}try{S.notices=await C.publicNotices()}catch(e){console.warn('Notices not available',e);S.notices=[]}try{S.sliderMessages=await C.publicSliderMessages()}catch(e){console.warn('Slider messages unavailable',e);S.sliderMessages=[]}
 }catch(e){console.warn(e);toast('Could not load listings. Check internet.')}}else{
 S.businesses=[];S.properties=[];try{S.properties=await C.publicProperties()}catch(e){}bpUpdateSettings=null;
 S.notificationSettings={enabled:true,theme:'purple'};S.heroImageUrl='';bpRestoreBannerSettings();S.owned=cacheGet('baran_demo_owned',[]);S.customCategories=[];S.homeCityItems=[];S.promotions=C.cachedPromotions();bpSetPromotionOrder(S.promotions);S.offers=[];S.sliderMessages=[];
 }render();showNotice();bpScheduleSync()}
async function onAuthSubmit(f){if(!C.enabled)return toast('Firebase settings not configured');let fd=new FormData(f),btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.innerHTML='<span class="loader"></span> Please wait';try{if(S.authTab==='signup')await C.signUp(fd.get('email').trim(),fd.get('password'),fd.get('name').trim(),String(fd.get('mobile')||'').trim());else await C.signIn(fd.get('email').trim(),fd.get('password'));toast('Signed in successfully');await refresh();go(S.afterAuth||'owner')}catch(e){toast(e.message.replace('Firebase: ','').slice(0,105));btn.disabled=false;render()}}
async function onBusinessSubmit(f){const fd=new FormData(f),data={};for(const k of ['name','category','area','address','phone','whatsapp','description','hours','mapUrl'])data[k]=String(fd.get(k)||'').trim();if(!/^[0-9+ -]{10,15}$/.test(data.phone))return toast('Please enter a valid phone number');const files=[...f.querySelector('[name=photos]')?.files||[]];if(files.length>2)return toast('Free listing allows maximum 2 photos');if(files.some(x=>x.size>5*1024*1024))return toast('Each photo must be 5 MB or less');const weekly={};for(const day of ['mon','tue','wed','thu','fri','sat','sun']){weekly[day]={closed:fd.get('closed_'+day)==='on',open:String(fd.get('open_'+day)||''),close:String(fd.get('close_'+day)||'')}}data.weeklyHours=weekly;if(data.mapUrl&&!/^https:\/\/(maps\.app\.goo\.gl|www\.google\.[^/]+\/maps|google\.[^/]+\/maps|maps\.google\.[^/]+\/)/i.test(data.mapUrl))return toast('Enter a valid Google Maps HTTPS link');const btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.innerHTML='<span class="loader"></span> Saving...';try{
 if(S.editingId){const old=S.owned.find(x=>x.id===S.editingId);const selected=[...new Set([data.category,...fd.getAll('extraCategory').map(x=>String(x))])];if(selected.length>(isPremium(old)?3:1))throw Error('Select maximum '+(isPremium(old)?3:1)+' categories');data.categories=selected;if(C.enabled)await C.requestEdit(S.editingId,data);else {let own=cacheGet('baran_demo_owned',[]);const idx=own.findIndex(b=>b.id===S.editingId);if(idx>=0){own[idx].pendingChange=data;localStorage.setItem('baran_demo_owned',JSON.stringify(own))}}toast('Change request sent for approval');}
 else if(C.enabled){await C.register(data,files,message=>{btn.innerHTML='<span class="loader"></span> '+escapeHtml(message)});toast('Submitted! Awaiting admin approval');}
 else{let own=cacheGet('baran_demo_owned',[]);own.unshift({...data,id:'local-'+Date.now(),status:'pending',plan:'free',planStatus:'inactive',paymentStatus:'unpaid',cover:'',demo:true});localStorage.setItem('baran_demo_owned',JSON.stringify(own));toast('Demo saved on this device (not sent to admin)');}
 S.editingId=null;await refresh();go('owner');
 }catch(e){const msg='Business registration failed: '+(e?.message||'Unknown error');console.error(msg,e);toast(msg.slice(0,180));alert(msg);btn.disabled=false;btn.textContent='Try Again'}}
// Branded password-reset dialog (avoids the WebView JavaScript prompt URL heading).
function openPasswordResetDialog(){
  document.getElementById('bp-reset-overlay')?.remove();
  if(!document.getElementById('bp-reset-style')){
    const style=document.createElement('style');style.id='bp-reset-style';
    style.textContent=`.bp-reset-overlay{position:fixed;inset:0;z-index:99999;background:#071b39a8;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box}.bp-reset-panel{width:100%;max-width:420px;background:#fff;border-radius:20px;padding:24px;box-shadow:0 20px 60px #061c4050;box-sizing:border-box;color:#102b50;font-family:inherit}.bp-reset-heading{display:flex;align-items:center;justify-content:space-between;gap:12px}.bp-reset-heading h2{margin:0;font-size:21px;color:#133e7b}.bp-reset-x{background:#edf3fc;border:0;border-radius:50%;width:34px;height:34px;font-size:23px;color:#315b92;cursor:pointer}.bp-reset-desc{font-size:13px;line-height:1.7;color:#53657c;margin:13px 0 19px}.bp-reset-label{font-size:13px;font-weight:700;display:block;margin-bottom:8px}.bp-reset-input{display:block;width:100%;box-sizing:border-box;border:1px solid #b8cce5;border-radius:11px;padding:13px 12px;font-size:15px;color:#183b66;background:#fff;outline:none}.bp-reset-input:focus{border-color:#1456b8;box-shadow:0 0 0 3px #1456b81c}.bp-reset-help{font-size:12px;line-height:1.5;color:#4c6582;background:#eff5ff;border-radius:10px;padding:11px;margin:14px 0}.bp-reset-error{font-size:12px;color:#b3261e;min-height:18px;margin:8px 0}.bp-reset-send{width:100%;background:#1456b8;color:#fff;border:0;border-radius:11px;padding:13px;font-size:15px;font-weight:700;cursor:pointer}.bp-reset-send:disabled{opacity:.65;cursor:wait}.bp-reset-cancel{display:block;margin:13px auto 0;background:transparent;border:0;color:#53657c;font-size:14px;cursor:pointer}`;
    document.head.appendChild(style);
  }
  const overlay=document.createElement('div');overlay.id='bp-reset-overlay';overlay.className='bp-reset-overlay';
  overlay.innerHTML=`<section class="bp-reset-panel" role="dialog" aria-modal="true" aria-labelledby="bp-reset-title"><div class="bp-reset-heading"><h2 id="bp-reset-title">🔒 Reset Your Password</h2><button type="button" class="bp-reset-x" data-reset-close aria-label="Close">×</button></div><p class="bp-reset-desc">अपना Registered Email Address दर्ज करें। हम आपको Password Reset Link भेजेंगे।</p><form id="bp-reset-form"><label class="bp-reset-label" for="bp-reset-email">Registered Email Address</label><input class="bp-reset-input" id="bp-reset-email" name="email" type="email" placeholder="you@example.com" autocomplete="email" required><p class="bp-reset-help">ℹ Reset Link आपके Email पर आएगा। Inbox और Spam Folder दोनों चेक करें।</p><div class="bp-reset-error" id="bp-reset-error" role="alert"></div><button class="bp-reset-send" type="submit">✉ Send Reset Link</button><button class="bp-reset-cancel" type="button" data-reset-close>Cancel</button></form></section>`;
  document.body.appendChild(overlay);
  const close=()=>overlay.remove();
  overlay.addEventListener('click',e=>{if(e.target===overlay||e.target.closest('[data-reset-close]'))close()});
  overlay.querySelector('#bp-reset-form').addEventListener('submit',async e=>{
    e.preventDefault();const email=overlay.querySelector('#bp-reset-email').value.trim();
    const error=overlay.querySelector('#bp-reset-error');const btn=overlay.querySelector('.bp-reset-send');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){error.textContent='Please enter a valid email address.';return}
    error.textContent='';btn.disabled=true;btn.textContent='Sending Reset Link...';
    try{await C.resetPassword(email);close();toast('If the email is registered, a reset link will arrive. Check Spam too.')}
    catch(err){error.textContent='Unable to send reset email. Please try again.';btn.disabled=false;btn.textContent='✉ Send Reset Link'}
  });
  overlay.querySelector('#bp-reset-email').focus();
}
$('#app').addEventListener('click',async e=>{
 const button=e.target.closest('button');if(!button)return;
 if(button.hasAttribute('data-shutter-open')){const url=safeHttps(S.shutterBanner?.linkUrl||'');if(url)window.open(url,'_blank','noopener,noreferrer');return}
 if(button.hasAttribute('data-promo-dot'))return bpShowPromotion(Number(button.dataset.promoDot));
 if(button.hasAttribute('data-promo-detail')){
  const b=S.promotionOrder.find(x=>x.id===button.dataset.promoDetail)||bpCurrentPromotion();
  if(!b)return;
  const section=String(b.linkSection||'').trim().toLowerCase();
  const type=String(b.linkType||'').trim().toLowerCase();
  const id=String(b.linkId||'').trim();
  const openSection=()=>{
   if(['jobs','localjobs','local-jobs'].includes(section)){openLocalJobs();return true}
   if(['properties','property','buysellproperty'].includes(section)){go('properties');return true}
   if(['offersall','offers','deals','dealsandoffers'].includes(section)){go('offersAll');return true}
   if(['business','businesses','directory','featuredbusiness','featuredbusinesses'].includes(section)){go('explore');return true}
   if(['donate','donateus'].includes(section)){go('donate');return true}
   if(['aboutus','about'].includes(section)){go('aboutUs');return true}
   if(['donors','blooddonors'].includes(section)){go('donors');return true}
   const cityMap={events:'events',festivals:'events',tourist:'tourist',touristplaces:'tourist',historical:'historical',historicalplaces:'historical',contacts:'contacts',importantcontacts:'contacts',updates:'updates',cityupdates:'updates',news:'updates',blogs:'blogs',articles:'blogs',blogarticles:'blogs',aboutbaran:'about'};
   if(cityMap[section]){openCity(cityMap[section]);return true}
   return false;
  };
  if(type==='external'&&safeHttps(b.linkUrl)){openUrl(safeHttps(b.linkUrl));return}
  if(type==='section'&&openSection())return;
  if(type==='detail'&&id){
   if(['offersall','offers','deals','dealsandoffers'].includes(section)&&S.offers.some(o=>o.id===id&&offerActive(o))){S.offerId=id;go('offerDetail');return}
   if(['business','businesses','directory','featuredbusiness','featuredbusinesses'].includes(section)&&S.businesses.some(o=>o.id===id&&o.status==='approved')){S.detail=id;go('detail');return}
   if(['properties','property','buysellproperty'].includes(section)&&S.properties.some(o=>o.id===id&&o.status==='approved')){S.propertyId=id;S.propertyPhotoIndex=0;go('propertyDetail');return}
   if(['jobs','localjobs','local-jobs'].includes(section)&&S.jobs.some(o=>o.id===id&&bpJobLive(o))){S.jobId=id;go('localJobDetail');return}
   const content=(S.cityItems||[]).find(o=>o.id===id);
   if(content){S.cityId=id;S.cityType=content.type||section;S.cityBackTarget='cityList';go('cityDetail');return}
   toast('Linked listing is unavailable');return;
  }
  if(type==='none')return;
  S.promotionSelected=b;go('promotionDetail');return;
 }
 if(button.hasAttribute('data-offers-refresh')){try{S.offers=shuffleOffers(await C.publicOffers(true));S.offersLoadError='';bpWarmDealImages();toast('Deals refreshed')}catch(e){S.offersLoadError=e?.code==='permission-denied'?'Deals access denied by Firestore rules.':'Deals refresh failed: '+(e?.code||e?.message||'unknown error')}return render()}
 if(button.hasAttribute('data-featured-deal-dot')){const track=document.querySelector('#bp-featured-deals-track');if(track)track.scrollTo({left:Number(button.dataset.featuredDealDot)*track.clientWidth,behavior:'smooth'});return;}
 if(button.hasAttribute('data-offers-all')){bpDealsView='premium';S.dealFilter='All';S.dealSearch='';return go('offersAll')}
 if(button.hasAttribute('data-deals-show-all')){bpDealsView='all';S.dealFilter='All';return render()}
 if(button.dataset.dealFilter){S.dealFilter=button.dataset.dealFilter;bpDealsView='all';return render()}
 if(button.dataset.offerOpen){S.offerId=button.dataset.offerOpen;return go('offerDetail')}
 if(button.dataset.offerCall){const o=S.offers.find(x=>x.id===button.dataset.offerCall&&offerActive(x));if(o&&o.phone)return dialDirect(o.phone);return}
 if(button.dataset.offerWhatsapp){const o=S.offers.find(x=>x.id===button.dataset.offerWhatsapp&&offerActive(x));if(o&&o.phone){const digits=String(o.phone).replace(/\D/g,'');openUrl('https://wa.me/'+(digits.length===10?'91'+digits:digits));}return}
 if(button.dataset.offerMap){const o=S.offers.find(x=>x.id===button.dataset.offerMap&&offerActive(x));if(o&&safeHttps(o.mapUrl))openUrl(safeHttps(o.mapUrl));return}
 if(button.dataset.offerBusiness){const b=S.businesses.find(x=>x.id===button.dataset.offerBusiness&&x.status==='approved');if(b){S.detail=b.id;return go('detail')}return}
 if(button.hasAttribute('data-promo-call')){const b=S.promotionOrder?.find(x=>x.id===button.dataset.promoCall);if(b&&b.id===button.dataset.promoCall&&/^\+?[0-9 -]{10,16}$/.test(b.phone||''))return dialDirect(b.phone);return}
 if(button.hasAttribute('data-menu-open'))return openDrawer();
 if(button.hasAttribute('data-menu-close'))return closeDrawer();
 if(button.hasAttribute('data-city-type'))return openCity(button.dataset.cityType);
 if(button.hasAttribute('data-notice-call')){const n=S.noticeVisible;if(n&&button.dataset.noticeCall===n.phone)return dialDirect(n.phone);return}
 if(button.hasAttribute('data-notice-close'))return dismissNotice();
 if(button.dataset.special==='donors')return openDonors();
 if(button.dataset.special==='jobs'){S.jobGroup='';return openLocalJobs()}
 if(button.dataset.special==='deals')return go('offersAll');
 if(button.hasAttribute('data-job-filter-toggle')){S.jobFilterOpen=!S.jobFilterOpen;return render()}
 if(button.hasAttribute('data-job-filter-select')){S.jobCategory=button.dataset.jobFilterSelect;S.jobFilterOpen=false;S.jobGroup='';return render()}
 if(button.hasAttribute('data-jobs-refresh'))return refreshLocalJobs();
 if(button.hasAttribute('data-job-back-latest'))return openLocalJobs();
 if(button.hasAttribute('data-job-next'))return bpJobShowStep(bpJobFormStep+1);
 if(button.hasAttribute('data-job-back'))return bpJobShowStep(bpJobFormStep-1);
 if(button.hasAttribute('data-job-group')){S.jobGroup=button.dataset.jobGroup;return render()}
 if(button.hasAttribute('data-job-group-back')){S.jobGroup='';return render()}
 if(button.hasAttribute('data-job-category-pick')){S.jobCategory=button.dataset.jobCategoryPick;S.jobFilterOpen=false;S.jobGroup='';return render()}
 if((button.hasAttribute('data-job-apply')||button.hasAttribute('data-job-call')||button.hasAttribute('data-job-whatsapp'))&&!bpJobConsentAccepted(button))return toast('पहले Job Disclaimer स्वीकार करें।');
 if(button.hasAttribute('data-job-apply')){const j=S.jobs.find(x=>x.id===button.dataset.jobApply&&bpJobLive(x));if(j&&/^https:\/\//i.test(String(j.applyLink||''))){if(!native('openUrl',j.applyLink))window.open(j.applyLink,'_blank','noopener')}return}
 if(button.hasAttribute('data-job-group-detail')){S.jobDetailGroup=button.dataset.jobGroupDetail;return go('localJobGroupDetail')}
 if(button.hasAttribute('data-local-job')){S.jobId=button.dataset.localJob;return go('localJobDetail')}
 if(button.hasAttribute('data-job-call')||button.hasAttribute('data-job-whatsapp')){const id=button.dataset.jobCall||button.dataset.jobWhatsapp;const j=S.jobs.find(x=>x.id===id&&bpJobLive(x));if(!j)return;const wa=button.hasAttribute('data-job-whatsapp');const number=String(wa?(j.whatsapp||j.mobile):j.mobile||'').replace(/\D/g,'');if(!/^[6-9][0-9]{9}$/.test(number))return toast('Contact number unavailable');const url=wa?'https://wa.me/91'+number+'?text='+encodeURIComponent('Hello, I am interested in the '+j.title+' vacancy listed on Baran Pride.'): 'tel:'+number;if(!native('openUrl',url))window.open(url,'_blank','noopener');return}
 if(button.hasAttribute('data-job-my-open'))return bpOpenMyJobs();
 if(button.hasAttribute('data-job-mine-edit'))return;
 if(button.hasAttribute('data-job-mine-close')){if(confirm('Close this job?'))C.closeMyLocalJob(button.dataset.jobMineClose).then(()=>bpOpenMyJobs()).catch(e=>toast(e.message));return}
 if(button.hasAttribute('data-job-form-open')){if(!C.user){S.afterAuth='localJobForm';S.authTab='signin';toast('Please sign in or register to submit a job');return go('auth')}return go('localJobForm')}
 if(button.dataset.special==='properties')return openProperties();
 if(button.hasAttribute('data-market-sell-open')){if(!C.user){S.afterAuth='marketplaceSell';S.authTab='signin';return go('auth')}return go('marketplaceSell')}
 if(button.hasAttribute('data-market-my-open')){if(!C.user){S.afterAuth='marketplaceMine';S.authTab='signin';return go('auth')}go('marketplaceMine');bpMarketMineLoad();return}
 if(button.hasAttribute('data-market-my-refresh')){bpMarketMineLoad();return}
 if(button.hasAttribute('data-market-sold')){bpMarketSold(button.dataset.marketSold);return}
 if(button.hasAttribute('data-market-open')){go('marketplaceComingSoon');return}
 if(button.hasAttribute('data-market-back-home')){go('home');return}
  if(button.hasAttribute('data-market-detail')){S.marketplaceId=button.dataset.marketDetail;go('marketplaceDetail');return}
  if(button.hasAttribute('data-market-call')){const p=button.dataset.marketCall;if(/^[6-9]\d{9}$/.test(p))openUrl('tel:+91'+p);return}
  if(button.hasAttribute('data-market-wa')){const p=button.dataset.marketWa;if(/^[6-9]\d{9}$/.test(p))openUrl('https://wa.me/91'+p);return}
  if(button.hasAttribute('data-market-category')){S.marketplaceCategory=button.dataset.marketCategory;render();return}
  if(button.hasAttribute('data-property-viewall'))return openProperties();
 if(button.hasAttribute('data-property-open')){S.propertyId=button.dataset.propertyOpen;S.propertyPhotoIndex=0;return go('propertyDetail')}
 if(button.hasAttribute('data-property-slide'))return movePropertySlider(Number(button.dataset.propertySlide));
 if(button.hasAttribute('data-property-dot'))return movePropertySlider(Number(button.dataset.propertyDot),true);
 if(button.hasAttribute('data-property-filter')){S.propertyFilter=button.dataset.propertyFilter;return render()}
 if(button.hasAttribute('data-property-photo')){const x=S.properties.find(p=>p.id===S.propertyId);const count=propertyPhotoUrls(x||{}).length;if(count){S.propertyPhotoIndex=(S.propertyPhotoIndex+Number(button.dataset.propertyPhoto)+count)%count;return render()}return}
 if(button.hasAttribute('data-blood-filter')){S.donorFilter=button.dataset.bloodFilter;S.donors=shuffleDonors(S.donors);return render()}
 if(button.hasAttribute('data-blood-call')){const d=S.donors.find(x=>x.id===button.dataset.bloodCall&&x.publicConsent===true&&x.status==='published');if(d)return dialDirect(d.phone);return}
 if((button.hasAttribute('data-property-whatsapp')||button.hasAttribute('data-property-call'))&&!bpPropertyConsentAccepted(button))return toast('पहले Property Disclaimer स्वीकार करें।');
 if(button.dataset.propertyWhatsapp){const item=S.properties.find(p=>p.id===button.dataset.propertyWhatsapp&&propertyIsVisible(p)&&p.status==='approved');if(!item)return toast('Property unavailable');const number=item.contactMode==='owner'&&validPhone(item.publicContactPhone)?item.publicContactPhone:S.helpline;if(!validPhone(number))return toast('Contact not available');const msg='Namaste, I saw your '+propertyTitle(item)+' in '+(item.area||'Baran')+' on Baran Pride. Please share more details.';return openUrl('https://wa.me/91'+number+'?text='+encodeURIComponent(msg))}
 if(button.dataset.propertyCall){const item=S.properties.find(p=>p.id===button.dataset.propertyCall&&propertyIsVisible(p));if(!item)return toast('Property is not available');const number=item.contactMode==='owner'&&validPhone(item.publicContactPhone)?item.publicContactPhone:S.helpline;return dialDirect(number)}
 if(button.hasAttribute('data-customer-care'))return openUrl('https://wa.me/917737325205');
 if(button.hasAttribute('data-city-retry'))return openCity(S.cityType);
 if(button.hasAttribute('data-home-viewall'))return openHomeCityList(button.dataset.homeViewall);
 if(button.hasAttribute('data-home-detail'))return homeCityDetail(button.dataset.homeDetail);
 if(button.hasAttribute('data-home-slide')){const slider=button.closest('[data-home-carousel]');if(slider)return displayHomeSlide(slider,(S.homeSlidePositions[slider.dataset.homeCarousel]||0)+Number(button.dataset.homeSlide));return}
 if(button.hasAttribute('data-home-dot')){const slider=button.closest('.home-city-block')?.querySelector('[data-home-carousel]');if(slider)return displayHomeSlide(slider,Number(button.dataset.homeDot));return}
 if(button.hasAttribute('data-contact-manual-sync')){if(!bpNetworkOnline())return toast('Internet required to refresh contacts');toast('Refreshing published contacts...');return syncContacts(true).then(()=>toast('Contacts refreshed')).catch(e=>toast('Contacts refresh failed: '+(e?.code||e?.message||'Unknown error')))}
 if(button.hasAttribute('data-contact-open')){S.bpContactScroll=window.scrollY||0;S.contactSelectedCategory=button.dataset.contactOpen;S.cityQuery='';render();return}if(button.hasAttribute('data-contact-back')){S.contactSelectedCategory='';S.cityQuery='';render();requestAnimationFrame(()=>window.scrollTo(0,S.bpContactScroll||0));return}
 if(button.hasAttribute('data-city-detail')){const x=S.cityItems.find(o=>o.id===button.dataset.cityDetail);if(x)S.cityType=x.type;S.cityId=button.dataset.cityDetail;S.cityBackTarget=S.page==='cityNews'?'cityNews':'cityList';return go('cityDetail')}
 if(button.hasAttribute('data-city-share'))return cityShare(button.dataset.cityShare);
 if(button.hasAttribute('data-city-map')){const x=S.cityItems.find(i=>i.id===button.dataset.cityMap);return x&&openUrl(safeHttps(x.mapUrl))}
 if(button.hasAttribute('data-city-call')){const x=S.cityItems.find(i=>i.id===button.dataset.cityCall);if(x&&x.phone){const ph=String(x.phone).replace(/[^0-9+]/g,'');if(!native('dial',ph))openUrl('tel:'+ph)}return}
 if(button.hasAttribute('data-go'))return button.dataset.go==='properties'?openProperties():button.dataset.go==='eventsTab'?openCity('events'):go(button.dataset.go);
 if(button.hasAttribute('data-back')&&S.page==='offersAll'&&bpDealsView==='all'){bpDealsView='premium';S.dealFilter='All';return render()}
 if(button.hasAttribute('data-back')&&['localJobDetail','localJobGroupDetail'].includes(S.page))return go('localJobs');
 if(button.hasAttribute('data-back'))return cityGoBack()||bpReturnToPrevious(['propertySubmit','propertyDetail'].includes(S.page)?'properties':'home');
 if(button.hasAttribute('data-bp-progress-hide')){bpProgressDismissed=true;bpOfflineProgress();return}
 if(button.hasAttribute('data-bp-sync-status')){bpSyncPanelOpen=!bpSyncPanelOpen;bpUpdateSyncIndicator();bpScheduleSyncPanelClose();return}
 if(button.hasAttribute('data-bp-sync-close')){bpSyncPanelOpen=false;bpUpdateSyncIndicator();return}
 if(button.hasAttribute('data-category-retry')){
  if(!bpIsInternetAvailable())return toast('Please connect to the internet and try again');
  toast('Refreshing business listings...');
  return refresh();
 }
 if(button.hasAttribute('data-category-view')){S.categoryView=button.dataset.categoryView==='grid'?'grid':'list';return render()}
 if(button.hasAttribute('data-all-category')){bpCategoryWarm(button.dataset.allCategory);S.category=button.dataset.allCategory;S.query='';S.returnToCategories=true;return go('explore')}
 if(button.hasAttribute('data-category')){if(button.dataset.category!=='All')bpCategoryWarm(button.dataset.category);
  const category=button.dataset.category;
  if(category==='More'){S.categorySearch='';S.returnToCategories=false;return go('allCategories')}
  S.category=category;S.query='';S.returnToCategories=false;return go('explore');
 }
 if(button.hasAttribute('data-detail')){S.detail=button.dataset.detail;return go('detail')}
 if(button.hasAttribute('data-save'))return saveToggle(button.dataset.save);
 if(button.hasAttribute('data-call'))return callBusiness(button.dataset.call);
 if(button.hasAttribute('data-wa'))return whatsapp(button.dataset.wa);
 if(button.hasAttribute('data-map'))return directions(button.dataset.map);
 if(button.hasAttribute('data-share'))return share(button.dataset.share);
 if(button.hasAttribute('data-owner-photos')){S.photoBusinessId=button.dataset.ownerPhotos;return go('ownerPhotos')}
 if(button.hasAttribute('data-edit')){S.editingId=button.dataset.edit;S.page='add';return render()}
 if(button.hasAttribute('data-profile-social')){const url=BP_PROFILE_SOCIAL_LINKS[button.dataset.profileSocial];if(url)openUrl(url);return}
 if(button.hasAttribute('data-social')){const url=S.socialLinks?.[button.dataset.social]?.url;if(/^https:\/\//i.test(url||''))openUrl(url);return}
 if(button.hasAttribute('data-forgot-password'))return openPasswordResetDialog();
 if(button.hasAttribute('data-forgot-email')){if(!native('dial','7737325205'))openUrl('tel:7737325205');return}
 if(button.hasAttribute('data-auth-tab')){S.authTab=button.dataset.authTab;return render()}
 if(button.dataset.action==='notifications'){const n=S.notices.filter(noticeAllowed)[0];if(n){S.noticeVisible=n;return render()}return toast('No new announcements')}
 if(button.dataset.action==='logout'){await C.signOut();S.owned=[];toast('Signed out');go('profile')}
});
// Photo picker feedback: selection is visible before registration is submitted.
$('#app').addEventListener('change',e=>{
 if(!e.target.matches('input[name="photos"]'))return;
 const input=e.target, preview=$('#business-photo-preview'), hint=$('#business-photo-hint');
 if(!preview)return;
 const files=Array.from(input.files||[]);
 preview.replaceChildren();
 if(!files.length){if(hint)hint.textContent='No photo selected';return}
 if(files.length>2 || files.some(f=>!/^image\/(jpeg|png|webp)$/i.test(f.type)||f.size>=5*1024*1024)){
  input.value='';if(hint)hint.textContent='Please choose up to 2 JPG, PNG or WebP photos, each under 5 MB';toast('Invalid photo selection');return;
 }
 if(hint)hint.textContent=files.length+' photo(s) selected';
 files.forEach((file,i)=>{
  const box=document.createElement('div');
  box.style.cssText='min-width:0;border:1px solid #d7e4f4;border-radius:12px;padding:8px;background:#f7faff';
  const img=document.createElement('img');img.alt='Selected photo '+(i+1);img.style.cssText='width:100%;height:100px;object-fit:cover;border-radius:8px;display:block';
  const label=document.createElement('div');label.textContent=file.name;label.title=file.name;label.style.cssText='font-size:11px;overflow-wrap:anywhere;margin-top:5px;color:#27466c';
  const tag=document.createElement('strong');tag.textContent=i===0?'Cover Photo':'Gallery Photo';tag.style.cssText='display:block;font-size:11px;margin-top:4px;color:#185aa0';
  box.append(img,label,tag);preview.append(box);
  const reader=new FileReader();reader.onload=()=>{if(box.isConnected)img.src=reader.result};reader.onerror=()=>{label.textContent=file.name+' (preview unavailable)'};reader.readAsDataURL(file);
 });
});
$('#app').addEventListener('submit',e=>{
 if(e.target.id==='hero-form'){e.preventDefault();S.category='All';S.query=($('#hero-q')?.value||'').trim();go('explore')}
 else if(e.target.id==='business-form'){e.preventDefault();onBusinessSubmit(e.target)}
 else if(e.target.id==='owner-photo-form'){e.preventDefault();onOwnerPhotos(e.target)}
 else if(e.target.id==='auth-form'){e.preventDefault();onAuthSubmit(e.target)}
 else if(e.target.id==='property-request-form'){e.preventDefault();submitProperty(e.target)}
 else if(e.target.id==='bp-market-sell-form'){e.preventDefault();bpMarketSubmit(e.target)}
});
$('#app').addEventListener('change',e=>{if(e.target.id==='bp-property-sort'){S.propertySort=e.target.value;render()}});
let debounce;$('#app').addEventListener('input',e=>{
 if(e.target.id==='all-categories-search'){
  S.categorySearch=e.target.value;
  let visible=0;
  document.querySelectorAll('.all-category-tile').forEach(tile=>{
   const show=(tile.dataset.categorySearch||'').includes(S.categorySearch.trim().toLocaleLowerCase());
   tile.classList.toggle('hidden',!show);if(show)visible++;
  });
  const count=$('#categories-result-count');if(count)count.textContent=visible+' categories';
  const empty=$('#category-search-empty');if(empty)empty.classList.toggle('hidden',visible!==0);
  return;
 }
 if(e.target.id==='bp-jobs-search'){S.jobSearch=e.target.value;const pos=e.target.selectionStart;render();const input=$('#bp-jobs-search');if(input){input.focus();input.setSelectionRange(pos,pos)}return}
 if(e.target.id==='city-search'){S.cityQuery=e.target.value;if(S.cityType==='contacts'){S.contactSelectedCategory='';const pos=e.target.selectionStart;render();const inp=document.querySelector('#city-search');if(inp){inp.focus();inp.setSelectionRange(pos,pos)}return}let n=0;document.querySelectorAll('.city-list-card').forEach(el=>{const show=(el.dataset.citySearch||'').includes(S.cityQuery.trim().toLowerCase());el.classList.toggle('hidden',!show);if(show)n++});const msg=$('#city-no-match');if(msg)msg.classList.toggle('hidden',n!==0);return}if(e.target.id==='explore-q'){const {selectionStart}=e.target;S.query=e.target.value;clearTimeout(debounce);debounce=setTimeout(()=>{let inp=$('#explore-q');const v=inp?.value;render();inp=$('#explore-q');if(inp){inp.focus();inp.value=v;inp.setSelectionRange(selectionStart,selectionStart)}},200)}});
document.addEventListener('change',e=>{if(!e.target.matches('[data-property-disclaimer-consent]'))return;const section=e.target.closest('.bp-property-detail-body');if(!section)return;const agreed=e.target.checked;section.querySelectorAll('[data-property-call],[data-property-whatsapp]').forEach(button=>{button.disabled=!agreed});const hint=section.querySelector('[data-property-consent-hint]');if(hint)hint.textContent=agreed?'सहमति स्वीकार की गई। Contact Buttons अब उपलब्ध हैं।':'Call या WhatsApp खोलने से पहले सहमति दें।'});
document.addEventListener('change',e=>{if(!e.target.matches('[data-job-disclaimer-consent]'))return;const section=e.target.closest('.bp-job-detail-entry, .bp-job-group-contact');if(!section)return;const agreed=e.target.checked;section.querySelectorAll('[data-job-call],[data-job-whatsapp],[data-job-apply]').forEach(button=>{button.disabled=!agreed});const hint=section.querySelector('[data-job-consent-hint]');if(hint)hint.textContent=agreed?'सहमति स्वीकार की गई। Contact Buttons अब उपलब्ध हैं।':'Call, WhatsApp या Apply Link खोलने से पहले सहमति दें।'});
document.addEventListener('change',e=>{if(e.target.hasAttribute('data-job-same-whatsapp')){const form=e.target.closest('form');const wa=form?.querySelector('[name=whatsapp]');if(wa){wa.value=e.target.checked?form.querySelector('[name=mobile]').value:'';wa.readOnly=e.target.checked}return}if(e.target.id==='bp-jobs-category'){S.jobCategory=e.target.value;render()}});
window.addEventListener('online',()=>{if(S.page==='explore'&&S.category!=='All')refresh().catch(e=>console.warn('Reconnect refresh failed',e))});
window.addEventListener('offline',()=>{bpUpdateSyncIndicator();if(S.page==='explore')render()});
window.addEventListener('focus',()=>{bpUpdateSyncIndicator();if(bpImagePreparing&&!bpSyncTasksFinished&&!bpSyncBusy&&bpNetworkOnline())bpScheduleSync()});
window.addEventListener('online',()=>{bpImageSeen.clear();bpImageDone=0;bpImageFailed=0;bpImageTotal=0;bpSyncError=false;bpSyncTasksFinished=false;bpSyncTasksDone=0;bpProgressDismissed=false;bpProgressFinishedAt=0;bpProgressStartedAt=Date.now();bpUpdateSyncIndicator();bpBackgroundSync(true)});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&bpNetworkOnline())bpScheduleSync();else if(document.hidden&&bpImagePreparing&&!bpSyncTasksFinished){bpSyncPaused=true;bpOfflineProgress()}});
// First-install progress watchdog: the initial refresh may have completed its own
// cache writes before the separate progress-accounted background sync starts.
// This only starts the existing coordinator; it does not change Firebase queries,
// cached values, or image download behavior.
let bpFirstPrepRetryAt=0;
const bpFirstPrepWatchdog=setInterval(()=>{
 if(bpStartupWasPrepared||bpProgressDismissed||!C.enabled){
  if(bpStartupWasPrepared||bpProgressDismissed)clearInterval(bpFirstPrepWatchdog);
  return;
 }
 if(bpSyncBusy||bpSyncImageRunning){bpOfflineProgress();return;}
 if(!bpNetworkOnline()){
  const sub=document.querySelector('#bp-offline-progress [data-bp-progress-sub]');
  if(sub)sub.textContent='Waiting for internet to continue offline preparation...';
  return;
 }
 if(bpSyncTasksFinished){bpOfflineProgress();return;}
 if(Date.now()-bpFirstPrepRetryAt<5000)return;
 bpFirstPrepRetryAt=Date.now();
 // No separate sync pipeline: count progress through bpBackgroundSync's existing tasks.
 bpBackgroundSync(true).catch(e=>console.warn('First install progress sync failed',e));
},2500);
let bpPreviousNetworkStatus=bpIsInternetAvailable();
setInterval(()=>{
 const current=bpIsInternetAvailable();
 if(current===bpPreviousNetworkStatus)return;
 bpPreviousNetworkStatus=current;
 if(S.page==='explore'){
  if(current&&S.category!=='All')refresh().catch(e=>console.warn('Category refresh failed',e));
  else render();
 }
},2500);

window.BaranApp={go,render,refresh,goBack(){if(S.drawer){closeDrawer();return true}if(cityGoBack())return true;if(S.page==='offersAll'&&bpDealsView==='all'){bpDealsView='premium';S.dealFilter='All';render();return true}if(['localJobDetail','localJobGroupDetail'].includes(S.page)||S.page==='localJobMine'){return bpReturnToPrevious('localJobs')}if(S.page==='donate'){return bpReturnToPrevious('profile')}if(['propertySubmit','propertyDetail'].includes(S.page)){return bpReturnToPrevious('properties')}if(S.page==='explore'&&S.returnToCategories){S.returnToCategories=false;return bpReturnToPrevious('allCategories')}if(S.page==='home')return false;return bpReturnToPrevious(S.page==='detail'?'explore':'home')}};
C.onUserChange=async user=>{if(C.enabled){C.user=user;await refresh()}};
render();C.init().then(()=>{preloadContacts();return refresh()});
// Deals & Offers search listener is inside the app closure so state is accessible.
document.addEventListener('input',e=>{if(e.target.id!=='bp-deals-search')return;S.dealSearch=e.target.value;bpRefreshDealsSearch()});
})();

// Close the sync popover on outside tap, without affecting other actions.
// The sync panel lives under document.body, outside #app: handle its controls here.
document.addEventListener('click',e=>{
 const close=e.target.closest('[data-bp-sync-close]');
 if(close){e.preventDefault();e.stopPropagation();clearTimeout(bpSyncPanelTimer);bpSyncPanelOpen=false;bpUpdateSyncIndicator();return}
 if(bpSyncPanelOpen&&!e.target.closest('#bp-sync-panel')&&!e.target.closest('[data-bp-sync-status]')){clearTimeout(bpSyncPanelTimer);bpSyncPanelOpen=false;bpUpdateSyncIndicator()}
},true);
