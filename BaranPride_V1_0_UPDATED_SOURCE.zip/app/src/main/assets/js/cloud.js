/* Optional Firebase data layer. App works as an explicitly labelled demo until configured. */
(function(){
 const cfg=window.BARAN_FIREBASE_CONFIG||{};
 const C={enabled:false,ready:false,user:null,auth:null,db:null,storage:null,m:null,onUserChange:null};
 const base='https://www.gstatic.com/firebasejs/10.14.1/';
 C.init=async function(){
  if(!cfg.apiKey||!cfg.projectId||!cfg.appId){C.ready=true;return false}
  try{
   const [A,U,F,S]=await Promise.all([import(base+'firebase-app.js'),import(base+'firebase-auth.js'),import(base+'firebase-firestore.js'),import(base+'firebase-storage.js')]);
   const app=A.initializeApp(cfg); C.auth=U.getAuth(app);C.db=F.getFirestore(app);C.storage=S.getStorage(app);C.m={U,F,S};C.enabled=true;
   U.onAuthStateChanged(C.auth,user=>{C.user=user;if(typeof C.onUserChange==='function') C.onUserChange(user)});
   C.ready=true;return true;
  }catch(e){console.error('Firebase unavailable',e);C.ready=true;C.error=e.message;return false}
 };
 C.signUp=async function(email,password,name,mobile){
  if(!/^[6-9][0-9]{9}$/.test(String(mobile||'')))throw Error('Enter a valid 10-digit mobile number');
  const x=await C.m.U.createUserWithEmailAndPassword(C.auth,email,password);
  if(name)await C.m.U.updateProfile(x.user,{displayName:name});C.user=x.user;
  // Profile writes are owner-only; do not store passwords in Firestore.
  try{await C.m.F.setDoc(C.m.F.doc(C.db,'userProfiles',x.user.uid),{uid:x.user.uid,name,email,mobile,createdAt:C.m.F.serverTimestamp()})}
  catch(e){console.error('Profile save failed',e);throw Error('Account created, but mobile profile could not be saved. Contact support before registering again.')}
  return x.user;
 };
 C.submitLocalJob=async function(input){
  if(!C.enabled||!C.user)throw Error('Sign in to submit a job');
  const trim=(key,max)=>String(input[key]||'').trim().slice(0,max);
  const fields=['title','company','category','location','qualification','jobType','description','contactPerson','mobile'];
  if(fields.some(k=>!String(input[k]||'').trim()))throw Error('Please complete all required fields');
  if(!/^[6-9][0-9]{9}$/.test(trim('mobile',10)))throw Error('Invalid mobile number');
  const whatsapp=trim('whatsapp',10);
  if(whatsapp&&!/^[6-9][0-9]{9}$/.test(whatsapp))throw Error('Invalid WhatsApp number');
  const description=trim('description',2000);
  if(description.length<20)throw Error('Description must be at least 20 characters');
  if(!input.consent)throw Error('Contact publication consent is required');
  const payload={
   title:trim('title',100),company:trim('company',120),category:trim('category',50),
   location:trim('location',180),qualification:trim('qualification',120),
   experience:trim('experience',100),salary:trim('salary',100),
   jobType:trim('jobType',30),vacancies:input.vacancies?Math.max(1,Math.min(1000,Number(input.vacancies)||1)):null,
   description,contactPerson:trim('contactPerson',100),mobile:trim('mobile',10),whatsapp,
   lastApplyDate:trim('lastApplyDate',10),contactConsent:true,
   status:'pending',active:false,ownerUid:C.user.uid,createdAt:C.m.F.serverTimestamp()
  };
  const result=await C.m.F.addDoc(C.m.F.collection(C.db,'localJobs'),payload);
  return result.id;
 };
 // Multiple titles entered using comma or newline create individual pending jobs.
 C.submitLocalJobs=async function(input){
  if(!C.enabled||!C.user)throw Error('Sign in to submit a job');
  const titles=[...new Set(String(input.titles||'').split(/[,\\r\\n]+/).map(x=>x.trim()).filter(Boolean))];
  if(!titles.length)throw Error('Enter at least one job title');
  if(titles.length>10)throw Error('Maximum 10 jobs per submission');
  if(titles.some(x=>x.length>100))throw Error('Each job title must be 100 characters or less');
  let count=0;
  for(const title of titles){
   try{await C.submitLocalJob({...input,title});count++}
   catch(e){throw Error(count+' of '+titles.length+' jobs submitted. '+(e?.message||'Please retry the remaining jobs'))}
  }
  return count;
 };
 // Public jobs cache: 30-minute TTL, only approved and active jobs.
 const bpJobPublic=j=>j.status==='approved'&&j.active===true&&(!j.lastApplyDate||(/^\d{4}-\d{2}-\d{2}$/.test(j.lastApplyDate)&&j.lastApplyDate>=new Date().toISOString().slice(0,10)));
 C.cachedLocalJobs=function(){const saved=bpCacheRead('local_jobs_v1',30*60*1000);return saved?bpRestoreTime(saved).filter(bpJobPublic):[]};
 C.publicLocalJobs=async function(forceFresh=false){
  const saved=bpCacheRead('local_jobs_v1',30*60*1000);
  if(!C.enabled)return saved?bpRestoreTime(saved).filter(bpJobPublic):[];
  if(!forceFresh&&saved)return bpRestoreTime(saved).filter(bpJobPublic);
  const F=C.m.F;
  try{
   const q=F.query(F.collection(C.db,'localJobs'),F.where('status','==','approved'));
   const snap=await F.getDocs(q);
   const items=snap.docs.map(d=>({id:d.id,...d.data()})).filter(bpJobPublic);
   if(snap.metadata.fromCache&&items.length===0&&saved?.length)return bpRestoreTime(saved).filter(bpJobPublic);
   if(!snap.metadata.fromCache)bpCacheWrite('local_jobs_v1',bpCacheTime(items));
   return items;
  }catch(e){if(saved)return bpRestoreTime(saved).filter(bpJobPublic);throw e}
 };
 C.resetPassword=async function(email){return C.m.U.sendPasswordResetEmail(C.auth,email)};
 C.signIn=async function(email,password){let x=await C.m.U.signInWithEmailAndPassword(C.auth,email,password);C.user=x.user;return x.user};
 C.signOut=async function(){await C.m.U.signOut(C.auth);C.user=null};
 // Public-only local cache. Authentication and owner/admin queries are never cached here.
 // Cache is scoped by Firebase project ID and versioned for safe future migrations.
 const bpCachePrefix='bp_public_v1_'+String(cfg.projectId||'demo')+'_';
 const bpCacheRead=(key,maxAge=Infinity)=>{
  try{
   const raw=localStorage.getItem(bpCachePrefix+key);
   if(!raw)return null;
   const record=JSON.parse(raw);
   if(!record||record.version!==1||!Array.isArray(record.data)||!Number.isFinite(record.savedAt))return null;
   if(Date.now()-record.savedAt>maxAge||record.savedAt>Date.now()+60000)return null;
   return record.data;
  }catch(e){return null}
 };
 const bpCacheWrite=(key,data)=>{
  try{
   const value=JSON.stringify({version:1,savedAt:Date.now(),data});
   // Avoid filling WebView localStorage; fall back to normal Firebase reads for large lists.
   if(value.length>750000)return;
   localStorage.setItem(bpCachePrefix+key,value);
  }catch(e){console.warn('Public cache unavailable',e?.message||e)}
 };
 const bpCacheTime=(x)=>{
  // Firestore Timestamp objects are not JSON-safe for .toMillis() callers.
  if(!x||typeof x!=='object')return x;
  if(Array.isArray(x))return x.map(bpCacheTime);
  if(typeof x.toMillis==='function')return {__bpTimestampMs:x.toMillis()};
  const result={};for(const [key,value] of Object.entries(x))result[key]=bpCacheTime(value);
  return result;
 };
 const bpRestoreTime=(x)=>{
  if(!x||typeof x!=='object')return x;
  if(Array.isArray(x))return x.map(bpRestoreTime);
  if(Number.isFinite(x.__bpTimestampMs)&&Object.keys(x).length===1)return C.m.F.Timestamp.fromMillis(x.__bpTimestampMs);
  const result={};for(const [key,value] of Object.entries(x))result[key]=bpRestoreTime(value);
  return result;
 };
 C.clearPublicCache=function(){try{for(const key of ['businesses','categories'])localStorage.removeItem(bpCachePrefix+key)}catch(e){}};
 C.approved=async function(forceFresh=false){const F=C.m.F;
  const cached=!forceFresh&&bpCacheRead('businesses',30*60*1000);
  if(cached)return bpRestoreTime(cached);
  try{
   const snap=await F.getDocs(F.query(F.collection(C.db,'businesses'),F.where('status','==','approved')));
   const data=snap.docs.map(d=>({id:d.id,...d.data()}));
   // Never replace a populated last-good cache with an empty offline snapshot.
   if(snap.metadata.fromCache && data.length===0){
    const saved=bpCacheRead('businesses');if(saved&&saved.length)return bpRestoreTime(saved);
   }
   if(!snap.metadata.fromCache)bpCacheWrite('businesses',bpCacheTime(data));
   return data;
  }catch(e){
   // Offline fallback is time-limited to avoid showing removed listings indefinitely.
   const stale=bpCacheRead('businesses');
   if(stale){console.warn('Using offline business cache',e);return bpRestoreTime(stale)}
   throw e;
  }
 };
 // Optional admin-managed categories; approved listings are also discovered dynamically.
 C.publicCategories=async function(forceFresh=false){if(!C.enabled)return[];const F=C.m.F;
  const cached=!forceFresh&&bpCacheRead('categories',24*60*60*1000);
  if(cached)return cached;
  try{
   const q=F.query(F.collection(C.db,'businessCategories'),F.where('active','==',true));
   const snap=await F.getDocs(q);
   const data=snap.docs.map(d=>String(d.data().name||'').trim()).filter(Boolean);
   if(!snap.metadata.fromCache)bpCacheWrite('categories',data);return data;
  }catch(e){const stale=bpCacheRead('categories');if(stale)return stale;throw e}
 };
 C.owned=async function(){if(!C.user)return[];const F=C.m.F;
  const snap=await F.getDocs(F.query(F.collection(C.db,'businesses'),F.where('ownerUid','==',C.user.uid)));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
 };

// Client-side optimization. Never uploads the uncompressed original on successful conversion.
async function bpOptimizeBusinessPhoto(file){
 if(!file || !/^image\/(jpeg|png|webp)$/i.test(file.type))throw Error('Please choose JPG, PNG or WebP');
 if(file.size>5*1024*1024)throw Error('Business photo must be under 5 MB');
 if(typeof createImageBitmap!=='function')return file; // Older WebView: preserve working upload
 let bitmap;try{bitmap=await createImageBitmap(file)}catch(e){return file}
 try{
  const ratio=Math.min(1,1200/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*ratio));canvas.height=Math.max(1,Math.round(bitmap.height*ratio));
  canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);
  let blob=null;
  for(const quality of [.82,.78,.73,.67,.60]){
   const next=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',quality));
   if(!next||next.type!=='image/webp')break;
   if(!blob||next.size<blob.size)blob=next;
   if(next.size<=250*1024)break;
  }
  if(!blob||blob.size>=file.size)return file;
  return new File([blob],String(file.name||'photo').replace(/\.[^.]+$/,'')+'.webp',{type:'image/webp',lastModified:Date.now()});
 }finally{bitmap.close?.()}
}

 C.register=async function(data,files,onProgress){
  if(!C.user)throw Error('Please sign in first');
  const F=C.m.F;
  const doc=F.doc(F.collection(C.db,'businesses'));
  const selected=Array.from(files||[]);
  if(selected.length>2)throw Error('Free listing allows maximum 2 photos');
  for(let i=0;i<selected.length;i++){
   const file=selected[i];
   if(!/^image\/(jpeg|png|webp)$/i.test(file.type))throw Error('Photo '+(i+1)+': choose JPG, PNG or WebP');
   if(file.size>=5*1024*1024)throw Error('Photo '+(i+1)+': must be under 5 MB');
  }
  // Firestore create rules require empty cover and photoUrls. Create the pending
  // record first, then upload images and update only permitted photo fields.
  onProgress?.('Saving business details...');
  try{
   await F.setDoc(doc,{
    name:data.name,category:data.category,categories:[data.category],area:data.area,address:data.address,phone:data.phone,whatsapp:data.whatsapp||data.phone,
    description:data.description||'',hours:data.hours||'Contact business',weeklyHours:data.weeklyHours||{},mapUrl:data.mapUrl||'',ownerUid:C.user.uid,
    status:'pending',plan:'free',planStatus:'inactive',paymentStatus:'unpaid',featured:false,
    cover:'',photoUrls:[],views:0,callClicks:0,createdAt:F.serverTimestamp(),updatedAt:F.serverTimestamp()
   });
  }catch(e){console.error('Business create failed',e);throw Error('Business save failed: '+(e?.code||e?.message||'unknown error'))}
  const urls=[];
  for(let i=0;i<selected.length;i++){
   const file=await bpOptimizeBusinessPhoto(selected[i]);
   const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
   const path='businesses/'+C.user.uid+'/'+doc.id+'/'+Date.now()+'-'+i+'-'+safeName;
   onProgress?.('Uploading photo '+(i+1)+' of '+selected.length+'...');
   try{
    const ref=C.m.S.ref(C.storage,path);
    await C.m.S.uploadBytes(ref,file,{contentType:file.type});
    urls.push(await C.m.S.getDownloadURL(ref));
    // Save after EACH successful upload to avoid losing completed photos.
    await F.updateDoc(doc,{cover:urls[0]||'',photoUrls:[...urls],updatedAt:F.serverTimestamp()});
   }catch(e){
    console.error('Business photo upload/update failed', {path,code:e?.code},e);
    throw Error('Business saved as Pending, but photo '+(i+1)+' failed: '+(e?.code||e?.message||'unknown error')+'. Contact Admin before retrying to avoid duplicate listings.');
   }
  }
  return doc.id;
 };
  C.managePhotos=async function(b,files=[],removeUrls=[],coverUrl=''){
   if(!C.user || b.ownerUid!==C.user.uid)throw Error('Not your business');
   const F=C.m.F,S=C.m.S,doc=F.doc(C.db,'businesses',b.id);
   const latest=(await F.getDoc(doc)).data();if(!latest||latest.ownerUid!==C.user.uid)throw Error('Business unavailable');
   const premium=latest.plan==='premium'&&latest.planStatus==='active'&&latest.paymentStatus==='paid'&&latest.expiresAt?.toMillis?.()>Date.now();
   const limit=premium?5:2;
   const old=Array.isArray(latest.photoUrls)?latest.photoUrls:[];
   const kept=old.filter(u=>!removeUrls.includes(u));
   if(kept.length+files.length>limit)throw Error('Maximum '+limit+' photos allowed');
   const added=[];
   try{
    for(const originalFile of files){
     const file=await bpOptimizeBusinessPhoto(originalFile);
     if(!/^image\/(jpeg|png|webp)$/i.test(file.type)||file.size>=5*1024*1024)throw Error('Use JPG, PNG or WebP under 5 MB');
     const path='businesses/'+C.user.uid+'/'+b.id+'/'+Date.now()+'-'+Math.random().toString(36).slice(2)+'-'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
     const ref=S.ref(C.storage,path);await S.uploadBytes(ref,file,{contentType:file.type});added.push(await S.getDownloadURL(ref));
    }
    const urls=[...kept,...added];const cover=urls.includes(coverUrl)?coverUrl:urls[0]||'';
    await F.updateDoc(doc,{photoUrls:urls,cover,updatedAt:F.serverTimestamp()});
    for(const url of removeUrls.filter(u=>old.includes(u))){try{await S.deleteObject(S.ref(C.storage,url))}catch(e){console.warn('Old image cleanup failed',e)}}
   }catch(e){for(const url of added){try{await S.deleteObject(S.ref(C.storage,url))}catch(_){}}throw e}
  };
 C.requestEdit=async function(id,patch){if(!C.user)throw Error('Please sign in');
  const F=C.m.F;
  await F.addDoc(F.collection(C.db,'changeRequests'),{businessId:id,ownerUid:C.user.uid,patch,createdAt:F.serverTimestamp(),status:'pending'});
 };
 // Public query only loads published content; Firestore denies access to drafts.
 // Phase 1B: cache only public city sections; contacts retain their existing session cache.
 // Each section has an independent refresh window. Stale entries are used only on fetch errors
 // or empty Firestore offline snapshots, not as a replacement for successful online updates.
 // Phase 2C: shared public Events cache, seeded by homepage and Events tab.
 // Keep only published records and ignore expired ISO-date events on offline reads.
 const bpEventValid=x=>{
  if(!x||x.type!=='events'||x.status!=='published')return false;
  const end=String(x.endDate||'').trim();
  return !/^\d{4}-\d{2}-\d{2}$/.test(end)||end>=new Date().toISOString().slice(0,10);
 };
 const bpEventRead=()=>{
  const direct=bpCacheRead('city_v2_events');
  const homepage=bpCacheRead('homepage_city_v2');
  const all=[...(direct||[]),...(homepage||[])];
  return [...new Map(all.filter(bpEventValid).map(x=>[x.id,x])).values()];
 };
 C.cachedPublicEvents=()=>bpEventRead().map(x=>C.enabled?bpRestoreTime(x):x);
 const bpEventSave=(items)=>{
  const published=items.filter(bpEventValid);
  if(published.length)bpCacheWrite('city_v2_events',bpCacheTime(published));
 };
 const bpCityTtl={historical:24*60*60*1000,tourist:24*60*60*1000,blogs:6*60*60*1000,updates:10*60*1000,contacts:24*60*60*1000,about:24*60*60*1000,events:30*60*1000};
 const bpCitySort=(items)=>items.sort((a,b)=>{
  const v=x=>x.publishedAt?.seconds||x.updatedAt?.seconds||0;
  return Number(!!b.featured)-Number(!!a.featured)||v(b)-v(a);
 });
 // City cache v2: do not reuse an old empty cache as evidence that no content exists.
 // Always attempt the server when a section has no saved published items.
 C.publicCity=async function(type=null){if(!C.enabled)return type==='events'?C.cachedPublicEvents():[];const F=C.m.F;
  const key=type&&Object.prototype.hasOwnProperty.call(bpCityTtl,type)?'city_v2_'+type:null;
  const cached=key?bpCacheRead(key,bpCityTtl[type]):null;
  if(cached?.length)return bpCitySort(bpRestoreTime(type==='events'?cached.filter(bpEventValid):cached));
  const query=F.query(F.collection(C.db,'cityContent'),F.where('status','==','published'));
  try{
   // Server-first on a cache miss avoids silently accepting an empty SDK offline snapshot.
   // Offline requests fail quickly into the last-good local cache below.
   let snap;
   try{snap=await F.getDocsFromServer(query)}catch(serverError){
    if(key){const stale=type==='events'?bpEventRead():bpCacheRead(key);if(stale?.length)return bpCitySort(bpRestoreTime(stale));}
    // SDK may still have valid Firestore offline documents, even without our own cache.
    snap=await F.getDocsFromCache(query);
   }
   const all=snap.docs.map(d=>({id:d.id,...d.data()}));
   if(key){
    const filtered=all.filter(x=>x.type===type&&x.status==='published');
    if(!snap.metadata.fromCache&&filtered.length){if(type==='events')bpEventSave(filtered);else bpCacheWrite(key,bpCacheTime(filtered));}
    if(!filtered.length){const stale=type==='events'?bpEventRead():bpCacheRead(key);if(stale?.length&&snap.metadata.fromCache)return bpCitySort(bpRestoreTime(stale));}
    return bpCitySort(type==='events'?filtered.filter(bpEventValid):filtered);
   }
   return bpCitySort(all);
  }catch(e){
   if(key){const stale=type==='events'?bpEventRead():bpCacheRead(key);if(stale?.length){console.warn('Using last-good city cache',type,e);return bpCitySort(bpRestoreTime(stale));}}
   throw e;
  }
 };

 // Homepage city entries share the short news freshness interval; do not cache drafts.
 C.publicHomepageCity=async function(){if(!C.enabled)return[];const F=C.m.F;
  const key='homepage_city_v2';const cached=bpCacheRead(key,10*60*1000);if(cached?.length)return bpRestoreTime(cached);
  const q=F.query(F.collection(C.db,'cityContent'),F.where('status','==','published'));
  try{
   let snap;
   try{snap=await F.getDocsFromServer(q)}catch(serverError){
    const stale=bpCacheRead(key);if(stale?.length)return bpRestoreTime(stale);
    snap=await F.getDocsFromCache(q);
   }
   const data=snap.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.status==='published'&&x.showOnHomepage===true).slice(0,60);
   if(!snap.metadata.fromCache&&data.length){bpCacheWrite(key,bpCacheTime(data));bpEventSave(data);}
   if(snap.metadata.fromCache&&!data.length){const stale=bpCacheRead(key);if(stale?.length)return bpRestoreTime(stale);}
   return data;
  }catch(e){const stale=bpCacheRead(key);if(stale?.length){console.warn('Using offline homepage city cache',e);return bpRestoreTime(stale)}throw e;}
 };

 // Public blood donor directory. Only adults who explicitly consented and were published by Admin are visible.
 // Sensitive public directory: minimal opt-in fields only, never keep donor data beyond 24 hours.
 // Read from server on each opening when possible so consent withdrawals take effect promptly.
 const donorCacheKey='bp_donors_optin_v1_'+String(cfg.projectId||'demo');
 const donorMaxAge=24*60*60*1000;
 const donorGroups=new Set(['A+','A-','B+','B-','AB+','AB-','O+','O-']);
 const donorPublic=(x)=>x&&x.publicConsent===true&&x.status==='published'&&donorGroups.has(x.bloodGroup)&&/^[6-9]\d{9}$/.test(String(x.phone||'').replace(/\D/g,''));
 const donorMinimal=(x)=>({id:String(x.id),name:String(x.name||'').slice(0,100),area:String(x.area||'').slice(0,100),phone:String(x.phone||'').replace(/[^+\d]/g,''),bloodGroup:x.bloodGroup,publicConsent:true,status:'published'});
 function donorReadCache(){
  try{
   const raw=localStorage.getItem(donorCacheKey);if(!raw)return null;
   const rec=JSON.parse(raw),now=Date.now();
   if(!rec||rec.v!==1||!Number.isFinite(rec.at)||rec.at>now+60000||now-rec.at>donorMaxAge||!Array.isArray(rec.items)){
    localStorage.removeItem(donorCacheKey);return null;
   }
   return {items:rec.items.filter(donorPublic).map(donorMinimal),savedAt:rec.at};
  }catch(e){try{localStorage.removeItem(donorCacheKey)}catch(_){}return null}
 }
 function donorWriteCache(items){
  try{localStorage.setItem(donorCacheKey,JSON.stringify({v:1,at:Date.now(),items:items.filter(donorPublic).map(donorMinimal)}))}
  catch(e){console.warn('Donor offline cache unavailable',e)}
 }
 C.cachedDonors=function(){return donorReadCache()};
 C.publicDonors=async function(){
  if(!C.enabled)return[];
  const F=C.m.F;
  const q=F.query(F.collection(C.db,'bloodDonors'),F.where('status','==','published'),F.where('publicConsent','==',true));
  try{
   const snap=await F.getDocsFromServer(q);
   const items=snap.docs.map(x=>({id:x.id,...x.data()})).filter(donorPublic).map(donorMinimal).sort((a,b)=>a.bloodGroup.localeCompare(b.bloodGroup));
   // An authoritative empty response clears withdrawn or removed donors too.
   donorWriteCache(items);return items;
  }catch(e){
   const cached=donorReadCache();if(cached)return cached.items;
   throw e;
  }
 };
 C.publicOffers=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'offers'),F.where('status','==','published')));const today=new Date().toISOString().slice(0,10);return snap.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.status==='published'&&(!x.startDate||x.startDate<=today)&&(!x.endDate||x.endDate>=today));};
 C.cachedPromotions=function(){return bpCacheRead('home_promotions')||[]};
 C.publicPromotions=async function(forceFresh=false){
  const key='home_promotions',saved=C.cachedPromotions();
  if(!C.enabled)return saved;
  if(!forceFresh){const fresh=bpCacheRead(key,30*60*1000);if(fresh)return fresh}
  const F=C.m.F;
  try{
   const snap=await F.getDocs(F.query(F.collection(C.db,'homePromotions'),F.where('active','==',true)));
   const items=snap.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.active===true);
   if(snap.metadata.fromCache&&items.length===0&&saved.length)return saved;
   if(!snap.metadata.fromCache)bpCacheWrite(key,bpCacheTime(items));
   return items.length||!snap.metadata.fromCache?items:saved;
  }catch(e){if(saved.length)return saved;throw e}
 };
 C.publicSliderMessages=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'notificationSliderMessages'),F.where('active','==',true)));return snap.docs.map(d=>({id:d.id,...d.data()}))};
 C.publicNotices=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'appNotices'),F.where('active','==',true)));return snap.docs.map(d=>({id:d.id,...d.data()}))};
 // Approved public listings only. A stale fallback is used on network errors;
// an online empty result replaces the cache so removed listings disappear.
 C.publicProperties=async function(forceFresh=false){
  const key='approved_properties_v1',ttl=30*60*1000;
  const cached=bpCacheRead(key);
  if(!C.enabled)return cached||[];
  if(!forceFresh){const fresh=bpCacheRead(key,ttl);if(fresh)return bpRestoreTime(fresh)}
  const F=C.m.F;
  try{
   const snap=await F.getDocs(F.query(F.collection(C.db,'propertyListings'),F.where('status','==','approved')));
   const data=snap.docs.map(x=>({id:x.id,...x.data()}));
   if(snap.metadata.fromCache&&data.length===0&&cached?.length)return bpRestoreTime(cached);
   if(!snap.metadata.fromCache)bpCacheWrite(key,bpCacheTime(data));
   return data.length||!snap.metadata.fromCache?data:(cached?bpRestoreTime(cached):data);
  }catch(e){
   if(cached){console.warn('Using saved property listings',e);return bpRestoreTime(cached)}
   throw e;
  }
 };
 C.customerCare=async function(){const fallback='7737325205';if(!C.enabled)return fallback;const F=C.m.F;const snap=await F.getDoc(F.doc(C.db,'appSettings','public'));return snap.exists()?String(snap.data().customerCarePhone||fallback):fallback};
 C.submitProperty=async function(data,photos=[]){if(!C.user)throw Error('Sign in before submitting a property');const F=C.m.F;const files=photos.slice(0,5);if(photos.length>5)throw Error('Maximum 5 property photos');for(const file of files){if(!/^image\/(jpeg|png|webp)$/.test(file.type)||file.size>5*1024*1024)throw Error('Use JPG, PNG or WebP images under 5 MB')}const snap=await F.addDoc(F.collection(C.db,'propertyRequests'),{...data,ownerUid:C.user.uid,status:'pending',createdAt:F.serverTimestamp()});if(files.length){try{const S=C.m.S;const urls=[];for(let i=0;i<files.length;i++){const f=files[i];const ref=S.ref(C.storage,'propertyRequests/'+C.user.uid+'/'+snap.id+'/'+i+'-'+Date.now()+'.'+(f.type==='image/png'?'png':f.type==='image/webp'?'webp':'jpg'));await S.uploadBytes(ref,f,{contentType:f.type});urls.push(await S.getDownloadURL(ref))}await F.updateDoc(F.doc(C.db,'propertyRequests',snap.id),{photoUrls:urls})}catch(e){throw Error('Request saved, but photo upload failed. Contact Admin before submitting again: '+e.message)}}return snap.id};
 window.BaranCloud=C;
})();
