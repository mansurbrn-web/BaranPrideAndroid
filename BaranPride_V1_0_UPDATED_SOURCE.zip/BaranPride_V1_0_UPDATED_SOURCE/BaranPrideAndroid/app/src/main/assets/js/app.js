(function(){
'use strict';
const C=window.BaranCloud;
const svgPaths={
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>', bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
 user:'<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',pin:'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
 sliders:'<path d="M4 7h8m4 0h4M4 17h3m4 0h9"/><circle cx="14" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
 cart:'<circle cx="9" cy="20" r="1"/><circle cx="19" cy="20" r="1"/><path d="M2 3h3l3 13h11l3-10H6"/>',
 health:'<path d="M5 4a4 4 0 0 0-4 4v5a6 6 0 0 0 12 0V8a4 4 0 0 0-4-4M5 4v3m4-3v3m4 6v2a5 5 0 0 0 10 0v-3"/><circle cx="19" cy="10" r="2"/>',
 food:'<path d="M4 2v8m4-8v8M2 6h8M6 10v12M17 2v20M17 2c7 3 7 11 0 11"/>',
 education:'<path d="m2 9 10-5 10 5-10 5zM6 11v6c4 3 8 3 12 0v-6M22 9v7"/>',
 property:'<path d="m2 11 10-9 10 9M5 10v12h14V10M9 22v-8h6v8"/>',
 tools:'<path d="M14 6a6 6 0 0 1-8 8L2 18l4 4 4-4a6 6 0 0 0 8-8l-4 4-4-4z"/>',
 car:'<path d="M5 16h14l-1-8H6zM3 16h18v4H3zM7 20v2m10-2v2M7 8l2-4h6l2 4"/>',
 job:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18m-11-1h4v3h-4z"/>',
 hotel:'<path d="M4 22V4h16v18M2 22h20M8 8h2m4 0h2M8 12h2m4 0h2M8 16h2m4 0h2M10 22v-4h4v4"/>',
 temple:'<path d="M4 22h16M5 22V9h14v13M3 9h18M12 2l8 7H4zM10 22v-7h4v7"/>',
 grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
 store:'<path d="M3 10h18l-2-6H5zM5 10v11h14V10M9 21v-7h6v7"/>',
 arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',back:'<path d="M15 18 9 12l6-6"/>',phone:'<path d="M22 16.5v3a2 2 0 0 1-2.2 2 19 19 0 0 1-17-17A2 2 0 0 1 4.8 2h3a2 2 0 0 1 2 1.7l.7 3a2 2 0 0 1-.7 2l-1.7 1.4a15 15 0 0 0 5.8 5.8l1.4-1.7a2 2 0 0 1 2-.7l3 .7a2 2 0 0 1 1.7 2.3z"/>',
 message:'<path d="M21 11.5a8.4 8.4 0 0 1-12 7.5L3 21l2-6A8.5 8.5 0 1 1 21 11.5z"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',share:'<circle cx="18" cy="5" r="2"/><circle cx="6" cy="12" r="2"/><circle cx="18" cy="19" r="2"/><path d="m8 11 8-5M8 13l8 5"/>',edit:'<path d="M12 20h9M16 3l5 5L9 20H4v-5z"/>',check:'<path d="m4 12 5 5L20 6"/>',logout:'<path d="M10 3H4v18h6M14 7l5 5-5 5m5-5H8"/>',camera:'<path d="M4 7h4l2-3h4l2 3h4v14H4z"/><circle cx="12" cy="14" r="4"/>',plus:'<path d="M12 3v18M3 12h18"/>',drop:'<path d="M12 3c2.6 4 7 8.4 7 12a7 7 0 0 1-14 0c0-3.6 4.4-8 7-12z"/>', menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',close:'<path d="M5 5l14 14M19 5 5 19"/>',book:'<path d="M12 7c-4-3-8-3-10-2v14c3-1 7-1 10 2m0-14c4-3 8-3 10-2v14c-3-1-7-1-10 2m0-14v14"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>',news:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h6v5H7zM16 8h2M16 11h2M7 16h11"/>',info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7h.01"/>',map:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3zM9 3v15m6-12v15"/>'
};
const icon=(n,size=21)=>`<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${svgPaths[n]||svgPaths.grid}</svg>`;
const $=s=>document.querySelector(s), escapeHtml=(v)=>String(v??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
// V3.1: Mask every alternate visible character in EACH word of a donor name.
// Example: Mansur Ali -> M*n*u* A*i. This is a display-only mask.
function maskBloodDonorName(name){
  return String(name??'').trim().split(/(\s+)/u).map(word=>{
    if(/^\s+$/u.test(word))return word;
    const letters=typeof Intl.Segmenter==='function'
      ? Array.from(new Intl.Segmenter('hi',{granularity:'grapheme'}).segment(word),item=>item.segment)
      : Array.from(word);
    return letters.map((letter,index)=>index%2===0?letter:'*').join('');
  }).join('');
}
const categories=[['Shopping','cart'],['Doctors','health'],['Restaurants','food'],['Education','education'],['Property','property'],['Services','tools'],['Automobile','car'],['Jobs','job'],['Hotels','hotel'],['More','grid']];
// Full directory category screen: keep the ten existing homepage slots unchanged.
// New approved business categories and active admin-managed categories appear automatically.
const ALL_CATEGORY_SEED=[
 ['Shopping','cart'],['Doctors','health'],['Restaurants','food'],['Education','education'],
 ['Property','property'],['Services','tools'],['Automobile','car'],['Jobs','job'],
 ['Hotels','hotel'],['Temples','temple'],['Medical','health'],['Beauty Parlour','store'],
 ['Electronics','store'],['Clothing','cart'],['Hardware','tools'],['Gym','heart'],
 ['Photography','camera'],['Printing & Stationery','book'],['Grocery','cart'],
 ['Real Estate','property'],['Others','grid']
];
const categoryIcon=name=>{
 const n=String(name||'').toLowerCase().trim();
 return ALL_CATEGORY_SEED.find(item=>item[0].toLowerCase()===n)?.[1]||'store';
};
function allBusinessCategories(){
 const names=new Map();
 function add(value){const n=String(value||'').trim();if(!n||n.toLowerCase()==='more'||n.toLowerCase()==='all')return;
  const key=n.toLocaleLowerCase();if(!names.has(key))names.set(key,n)}
 ALL_CATEGORY_SEED.forEach(item=>add(item[0]));
 (S.customCategories||[]).forEach(add);
 S.businesses.filter(b=>b.status==='approved').forEach(b=>(Array.isArray(b.categories)&&b.categories.length?b.categories:[b.category]).forEach(add));
 return [...names.values()].sort((a,b)=>a.localeCompare(b,'en',{sensitivity:'base'}));
}
function categoryCount(name){return S.businesses.filter(b=>b.status==='approved'&&(Array.isArray(b.categories)&&b.categories.length?b.categories:[b.category]).some(c=>String(c||'').toLocaleLowerCase()===name.toLocaleLowerCase())).length}
function allCategoriesPage(){
 const items=allBusinessCategories().filter(n=>n.toLocaleLowerCase().includes(S.categorySearch.trim().toLocaleLowerCase()));
 return `<div class="screen categories-page">${head('All Business Categories')}<h1 class="page-title">Explore Categories</h1><p class="intro">श्रेणी चुनकर Baran के स्थानीय बिजनेस खोजें</p><div class="search-bar category-search">${icon('search')}<input id="all-categories-search" value="${escapeHtml(S.categorySearch)}" placeholder="Search categories..." autocomplete="off" aria-label="Search all categories"></div><p class="result-count" id="categories-result-count">${items.length} categories</p><div class="category-view-switch"><button type="button" data-category-view="list" class="${S.categoryView==='list'?'selected':''}">☰ List</button><button type="button" data-category-view="grid" class="${S.categoryView==='grid'?'selected':''}">▦ Grid</button></div><div class="all-category-grid ${S.categoryView==='list'?'category-list-view':''}" id="all-category-grid">${items.map(name=>`<button class="all-category-tile" data-all-category="${escapeHtml(name)}" data-category-search="${escapeHtml(name.toLocaleLowerCase())}"><span class="all-category-symbol">${icon(categoryIcon(name),25)}</span><strong>${escapeHtml(name)}</strong><small>${categoryCount(name)} businesses</small></button>`).join('')}</div><div class="city-message hidden" id="category-search-empty">No matching categories found.</div></div>`;
}
const DEMO=[
 {id:'demo-1',name:'The Royal Restaurant',category:'Restaurants',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/restaurant.jpg',rating:4.5,reviews:128,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-2',name:'MediCare Hospital',category:'Doctors',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/hospital.jpg',rating:4.8,reviews:210,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-3',name:'Fashion Hub',category:'Shopping',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/fashion.jpg',rating:4.3,reviews:96,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-4',name:'Sharma Electronics',category:'Shopping',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/electronics.jpg',rating:0,featured:false,status:'approved',demo:true,description:'Example business name only.'},
 {id:'demo-5',name:'Guru Kirpa Motors',category:'Automobile',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/automobile.jpg',rating:0,featured:false,status:'approved',demo:true,description:'Example business name only.'}
];
const CITY_TYPES=[['historical','Historical Places','ऐतिहासिक स्थल','temple'],['blogs','Blogs & Articles','ब्लॉग और लेख','book'],['tourist','Tourist Places','घूमने की जगहें','pin'],['events','Events & Festivals','कार्यक्रम और मेले','calendar'],['updates','City Updates','शहर की जानकारी','news'],['contacts','Important Contacts','जरूरी संपर्क','phone'],['about','About Baran','बारां के बारे में','info']];
const cityType=(id)=>CITY_TYPES.find(x=>x[0]===id)||CITY_TYPES[0];
const S={propertySlideIndex:0,customCategories:[],categorySearch:'',categoryView:'list',notificationSettings:{enabled:true,theme:'purple'},heroImageUrl:'',returnToCategories:false,donors:[],donorError:'',donorFilter:'All',properties:[],propertyError:'',helpline:'7737325205',defaultBusinessCover:'img/baran-pride-default-business.jpg',propertySubmitting:false,drawer:false,cityType:'historical',cityItems:[],cityId:null,cityQuery:'',cityLoading:false,cityError:'',cityBackTarget:'cityList',homeCityItems:[],promotions:[],promotionSelected:null,notices:[],sliderMessages:[],noticeVisible:null,homeCityError:'',homeSlidePositions:{events:0,historical:0},page:'home',category:'All',query:'',businesses:[],owned:[],saved:new Set(JSON.parse(localStorage.getItem('baran_saved')||'[]')),detail:null,authTab:'signin',afterAuth:'add',editingId:null,loading:false};
const cacheGet=(k,def)=>{try{return JSON.parse(localStorage.getItem(k))??def}catch{return def}};
const toast=(msg)=>{let t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2600)};
function native(method,...args){try{if(window.AndroidBridge&&typeof window.AndroidBridge[method]==='function'){window.AndroidBridge[method](...args);return true}}catch(e){console.warn(e)}return false}
function openUrl(url){if(!url)return;if(!native('openUrl',url))window.open(url,'_blank','noopener')}
function demoWarning(){toast('यह सिर्फ Design Demo Listing है');}
function callBusiness(id){const b=findBiz(id);if(!b)return;if(!b.phone||b.demo)return demoWarning();if(!native('dial',b.phone))openUrl('tel:'+encodeURIComponent(b.phone));}
function whatsapp(id){const b=findBiz(id);if(!b)return;if(!b.whatsapp&&!b.phone||b.demo)return demoWarning();const num=(b.whatsapp||b.phone).replace(/[^\d]/g,'');openUrl('https://wa.me/'+(num.startsWith('91')?num:'91'+num));}
function directions(id){const b=findBiz(id);if(!b)return;if(b.demo)return demoWarning();openUrl(/^https:\/\//.test(b.mapUrl||'')?b.mapUrl:'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(b.address+', '+b.area+', Rajasthan'));}
function share(id){const b=findBiz(id);if(!b)return;const txt=b.name+' — '+b.area+', Baran Rajasthan';if(native('shareText',txt))return;if(navigator.share){navigator.share({title:b.name,text:txt}).catch(()=>{})}else if(navigator.clipboard){navigator.clipboard.writeText(txt).then(()=>toast('Business details copied'))}}
function findBiz(id){return [...S.businesses,...S.owned].find(b=>b.id===id)}
function saveToggle(id){if(S.saved.has(id))S.saved.delete(id);else S.saved.add(id);localStorage.setItem('baran_saved',JSON.stringify([...S.saved]));toast(S.saved.has(id)?'Saved to favorites':'Removed from favorites');render()}
const bottom=()=>`<nav class="bottom-nav" aria-label="Main navigation">${[['home','home','Home'],['allCategories','grid','Categories'],['eventsTab','calendar','Events'],['owner','store','My Business'],['profile','user','Profile']].map(([key,ic,label])=>`<button class="nav-item ${S.page===key?'active':''}" data-go="${key}" aria-label="${label}">${icon(ic,24)}<span>${label}</span></button>`).join('')}</nav>`;
const brand=()=>`<div class="brand"><div class="logo"><img src="img/baran-pride-blue-logo.png" width="57" height="57" alt="BARAN PRIDE logo" loading="eager"></div><div><div class="brand-main">BARAN <span>PRIDE</span></div><div class="tagline">हमारा शहर, हमारी पहचान</div></div></div>`;
const head=(title)=>`<div class="back-header"><button data-back aria-label="Back">${icon('back')}</button><strong>${title}</strong></div>`;
const banner=()=>''; // Demo disclaimer removed; no changes to business data or Firebase.
function section(title,go){return `<div class="section-head"><h2>${title}</h2><button data-go="${go}">View All →</button></div>`}
function businessCover(b){const visible=Array.isArray(b?.photoUrls)?b.photoUrls.slice(0,isPremium(b)?5:2):[];const u=String(visible.length?(visible.includes(b?.cover)?b.cover:visible[0]):(b?.cover||'')).trim();return /^https:\/\//i.test(u)?u:S.defaultBusinessCover}
function businessImage(b,attrs=''){return `<img src="${escapeHtml(businessCover(b))}" onerror="this.onerror=null;this.src='img/baran-pride-default-business.jpg'" ${attrs}>`}
function isPremium(b){return b?.plan==='premium'&&b?.planStatus==='active'&&b?.paymentStatus==='paid'&&(typeof b.expiresAt?.toMillis==='function'&&b.expiresAt.toMillis()>Date.now())}
function businessCategories(b){return isPremium(b)&&Array.isArray(b.categories)&&b.categories.length?b.categories.slice(0,3):[b.category]}
function badgeTick(b){return isPremium(b)?'<span title="Priority business" aria-label="Priority business" style="color:#1266c2;font-weight:900;margin-left:4px">⭐✓</span>':''}
function businessName(b){return escapeHtml(b.name)+badgeTick(b)}
function prioritySort(a,b){const tier=Number(isPremium(b))-Number(isPremium(a));if(tier)return tier;const day=Math.floor(Date.now()/86400000),score=x=>{let h=(day*2654435761)>>>0;for(const c of String(x.id||x.name||''))h=(Math.imul(h,33)+c.charCodeAt(0))>>>0;return h};return score(a)-score(b)||String(a.name||'').localeCompare(String(b.name||''))}
function bizCard(b){return `<article class="business-card"><div class="imgwrap">${businessImage(b,` alt="${escapeHtml(b.name)}" loading="lazy"`)}${b.featured?'<span class="mark-featured">★ Featured</span>':''}</div><div class="card-body"><div class="card-name">${businessName(b)}</div><div class="card-sub">${escapeHtml(b.category)} · ${escapeHtml(b.area)}</div><div class="rating">${b.rating?`<span class="star">★</span> ${b.rating} <em>(${b.reviews||0})</em>`:'<em>New listing</em>'}</div><div class="card-actions"><button data-call="${b.id}">${icon('phone',17)}Call</button><button data-wa="${b.id}">${icon('message',17)}WhatsApp</button><button data-detail="${b.id}">${icon('pin',17)}Details</button></div></div></article>`}
function latestCard(b){return `<article class="latest-row">${businessImage(b,` alt=""`)}<div><strong>${businessName(b)}</strong><small>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</small></div><button class="smallaction" data-detail="${b.id}" aria-label="View business">${icon('arrow',18)}</button></article>`}
function filtered(){return S.businesses.filter(b=>(S.category==='All'||businessCategories(b).some(c=>String(c||'').toLocaleLowerCase()===S.category.toLocaleLowerCase()))&&[b.name,...businessCategories(b),b.area,b.address].join(' ').toLowerCase().includes(S.query.toLowerCase())).sort(prioritySort)}
// Homepage city panels are intentionally small additions to the existing V3.1 design.
// Only published AND explicitly chosen by Admin appear on the Homepage.
const HOME_SECTION_TYPES={events:['events'],historical:['historical'],news:['blogs','updates']};
function homeCitySorted(section){
 const types=HOME_SECTION_TYPES[section]||[];
 return S.homeCityItems.filter(x=>x.status==='published'&&x.showOnHomepage===true&&types.includes(x.type)).sort((a,b)=>{
  const order=x=>Number.isFinite(Number(x.homeOrder))?Number(x.homeOrder):100;
  const published=x=>x.publishedAt?.seconds||x.updatedAt?.seconds||0;
  return order(a)-order(b)||published(b)-published(a);
 });
}
function homeCityHeading(title,section,iconName){
 return `<div class="section-head home-city-section-head"><h2>${icon(iconName,20)} ${title}</h2><button data-home-viewall="${section}">View All →</button></div>`;
}
function homepageSlider(section,title,iconName){
 const items=homeCitySorted(section);if(!items.length)return '';
 const index=Math.min(Math.max(0,S.homeSlidePositions[section]||0),items.length-1);
 const slides=items.map((x,i)=>{
  const image=safeHttps(x.cover);
  const subtitle=section==='events'? [[x.startDate,x.endDate].filter(Boolean).join(' → ')||x.eventDate||cityDate(x.publishedAt),x.area].filter(Boolean).join(' · '): String(x.summary||'').trim();
  return `<article class="home-landscape-slide ${i===index?'is-current':''}" data-home-slide-index="${i}" role="group" aria-label="${i+1} of ${items.length}" aria-hidden="${i!==index}">
   ${image?`<img src="${escapeHtml(image)}" alt="${escapeHtml(x.title)}" loading="lazy">`:'<div class="home-landscape-no-image" aria-hidden="true"></div>'}
   <div class="home-landscape-shade"></div>
   <div class="home-landscape-caption"><div class="home-landscape-title">${escapeHtml(x.title)}</div>${subtitle?`<p>${escapeHtml(subtitle)}</p>`:''}</div>
   <button class="home-landscape-detail" data-home-detail="${escapeHtml(x.id)}" type="button">View Details →</button>
  </article>`;
 }).join('');
 return `<section class="home-city-block" aria-label="${title}">${homeCityHeading(title,section,iconName)}
  <div class="home-landscape-slider" data-home-carousel="${section}">${slides}
   ${items.length>1?`<button class="home-landscape-nav prev" data-home-slide="-1" aria-label="Previous ${title}">${icon('back',21)}</button><button class="home-landscape-nav next" data-home-slide="1" aria-label="Next ${title}">${icon('arrow',21)}</button>`:''}</div>
   ${items.length>1?`<div class="home-slider-dots" role="group" aria-label="${title} slides">${items.map((_,i)=>`<button data-home-dot="${i}" aria-label="Show item ${i+1}" class="${i===index?'active':''}"></button>`).join('')}</div>`:''}
 </section>`;
}
function homepageNews(){
 const items=homeCitySorted('news');if(!items.length)return '';
 return `<section class="home-city-block home-news-block" aria-label="News & Blog">${homeCityHeading('News & Blog','news','news')}
  <div class="featured-strip home-news-strip">${items.map(x=>{
   const image=safeHttps(x.cover);
   return `<article class="business-card home-news-card"><div class="imgwrap">${image?`<img src="${escapeHtml(image)}" loading="lazy" alt="${escapeHtml(x.title)}">`:`<div class="home-news-no-image">${icon('news',30)}</div>`}</div><div class="card-body"><div class="card-name">${escapeHtml(x.title)}</div><div class="card-sub">${escapeHtml(cityDate(x.publishedAt)||x.eventDate||'News & Blog')}</div><div class="card-actions"><button type="button" data-home-detail="${escapeHtml(x.id)}">Read More →</button></div></div></article>`;
  }).join('')}</div></section>`;
}
let homeSlidesTimer=null;
function displayHomeSlide(slider,index){
 const slides=[...slider.querySelectorAll('.home-landscape-slide')];if(!slides.length)return;
 const target=((index%slides.length)+slides.length)%slides.length;
 slides.forEach((el,i)=>{el.classList.toggle('is-current',i===target);el.setAttribute('aria-hidden',String(i!==target))});
 slider.parentElement.querySelectorAll('[data-home-dot]').forEach((el,i)=>el.classList.toggle('active',i===target));
 S.homeSlidePositions[slider.dataset.homeCarousel]=target;
}

/* Baran Pride: notification themes are bundled with app.js to avoid requiring a CSS replacement. */
function installNotificationStyles(){
 if(document.getElementById('bp-notification-v6-styles'))return;
 const style=document.createElement('style');style.id='bp-notification-v6-styles';
 style.textContent=`
 .bp-notification-strip{--bp-notice-bg:linear-gradient(110deg,#6539ba,#9854dd);--bp-notice-ink:#fff;--bp-notice-accent:#fff;display:flex;align-items:center;gap:9px;position:relative;overflow:hidden;min-height:43px;padding:7px 13px;background:var(--bp-notice-bg);color:var(--bp-notice-ink);border-radius:0;box-sizing:border-box}
 .bp-notification-icon{flex:0 0 auto;font-size:17px;line-height:1;filter:drop-shadow(0 1px 1px #0002)}
 .bp-notification-viewport{flex:1;min-width:0;overflow:hidden;position:relative;min-height:27px;display:flex;align-items:center}
 .bp-notification-track{width:100%;position:relative}
 .bp-notification-item{display:none;align-items:center;min-height:27px;font-size:13px;font-weight:650;line-height:1.4;letter-spacing:.1px;overflow-wrap:anywhere;color:inherit}
 .bp-notification-item:first-child{display:flex}
 .bp-notification-purple{--bp-notice-bg:linear-gradient(110deg,#5931aa,#9c5bda)}
 .bp-notification-blue{--bp-notice-bg:linear-gradient(110deg,#09469e,#2686df)}
 .bp-notification-orange{--bp-notice-bg:linear-gradient(110deg,#d95b12,#fa9b26)}
 .bp-notification-green{--bp-notice-bg:linear-gradient(110deg,#087b55,#2cbf85)}
 .bp-notification-pink{--bp-notice-bg:linear-gradient(110deg,#ad247e,#ed76b8)}
 .bp-notification-red{--bp-notice-bg:linear-gradient(110deg,#a91e31,#e9565d)}
 .bp-notification-yellow{--bp-notice-bg:linear-gradient(110deg,#ffe276,#ffc233);--bp-notice-ink:#4d3800}
 .bp-notification-sky{--bp-notice-bg:linear-gradient(110deg,#42b6db,#86e4f1);--bp-notice-ink:#073b57}
 .bp-notification-dark{--bp-notice-bg:linear-gradient(110deg,#13213e,#34496c)}
 .bp-notification-tiranga{--bp-notice-bg:linear-gradient(180deg,#ff9933 0 33.3%,#fff 33.3% 66.6%,#138808 66.6%);--bp-notice-ink:#122a65}
 .bp-notification-tiranga-wave{--bp-notice-bg:linear-gradient(135deg,#ff9933 0%,#ffbd73 28%,#fff 46%,#fff 57%,#4bb65b 78%,#138808 100%);--bp-notice-ink:#102e62}
 .bp-notification-tiranga-border{--bp-notice-bg:linear-gradient(180deg,#ff9933 0 5px,#fff 5px calc(100% - 5px),#138808 calc(100% - 5px));--bp-notice-ink:#153a75}
 .bp-notification-tiranga-gradient{--bp-notice-bg:linear-gradient(90deg,#ff9933 0%,#fff 49%,#138808 100%);--bp-notice-ink:#142d62}
 .bp-notification-tiranga-brush{--bp-notice-bg:repeating-linear-gradient(172deg,#ff9933 0 10px,#ffb762 10px 15px,#fff 15px 30px,#e5f4e7 30px 34px,#138808 34px 44px);--bp-notice-ink:#122a65}
 .bp-notification-tiranga-chakra{--bp-notice-bg:linear-gradient(180deg,#ff9933 0 28%,#fff 28% 72%,#138808 72%);--bp-notice-ink:#132c68}
 .bp-notification-fresh-green{--bp-notice-bg:linear-gradient(110deg,#0b7656,#28b88b);--bp-notice-ink:#ffffff}
 .bp-notification-modern-orange{--bp-notice-bg:linear-gradient(110deg,#ba4514,#f9a13e);--bp-notice-ink:#ffffff}
 .bp-notification-premium-purple{--bp-notice-bg:linear-gradient(110deg,#452189,#a268df);--bp-notice-ink:#ffffff}
 .bp-notification-soft-pink{--bp-notice-bg:linear-gradient(110deg,#f6d8ea,#ffebf5);--bp-notice-ink:#7b2354}
 .bp-notification-elegant-gold{--bp-notice-bg:linear-gradient(110deg,#6b4b10,#d2a744);--bp-notice-ink:#ffffff}
 .bp-notification-night-blue{--bp-notice-bg:linear-gradient(110deg,#071b39,#24569b);--bp-notice-ink:#ffffff}
 .bp-notification-dark-elegant{--bp-notice-bg:linear-gradient(110deg,#151821,#414654);--bp-notice-ink:#ffffff}
 .bp-notification-alert-red{--bp-notice-bg:linear-gradient(110deg,#981a29,#ec555b);--bp-notice-ink:#ffffff}
 .bp-notification-modern-teal{--bp-notice-bg:linear-gradient(110deg,#075e64,#1bb4b1);--bp-notice-ink:#ffffff}
 .bp-notification-gradient-pro{--bp-notice-bg:linear-gradient(110deg,#1644a5,#a353e2);--bp-notice-ink:#ffffff}
 .bp-notification-diwali{--bp-notice-bg:linear-gradient(110deg,#5b167d,#b947a1);--bp-notice-ink:#ffe599}
 .bp-notification-eid{--bp-notice-bg:linear-gradient(110deg,#00634d,#0c9b76);--bp-notice-ink:#fff3c1}
 .bp-notification-holi{--bp-notice-bg:linear-gradient(110deg,#ffb6dc,#ffe06c);--bp-notice-ink:#7a1559}
 .bp-notification-independence{--bp-notice-bg:linear-gradient(110deg,#ff9933,#138808);--bp-notice-ink:#122c64}
 .bp-notification-christmas{--bp-notice-bg:linear-gradient(110deg,#9b1735,#20754e);--bp-notice-ink:#ffffff}
 .bp-notification-makar-sankranti{--bp-notice-bg:linear-gradient(110deg,#fff0d4,#f5bd55);--bp-notice-ink:#8b3d0d}
 .bp-notification-ganesh-chaturthi{--bp-notice-bg:linear-gradient(110deg,#ad3e11,#ef9d21);--bp-notice-ink:#ffffff}
 .bp-notification-navratri{--bp-notice-bg:linear-gradient(110deg,#771b35,#dd8c31);--bp-notice-ink:#ffffff}
 .bp-notification-raksha-bandhan{--bp-notice-bg:linear-gradient(110deg,#ba387e,#8753bc);--bp-notice-ink:#ffffff}
 .bp-notification-janmashtami{--bp-notice-bg:linear-gradient(110deg,#074c80,#1e9b9e);--bp-notice-ink:#fff2bd}
 .bp-notification-guru-nanak{--bp-notice-bg:linear-gradient(110deg,#164b91,#f19a32);--bp-notice-ink:#ffffff}
 .bp-notification-rainbow-celebration{--bp-notice-bg:linear-gradient(110deg,#e24678,#4f6de0);--bp-notice-ink:#ffffff}
 .bp-notification-tiranga-chakra:after{content:"☸";position:absolute;right:12px;top:50%;transform:translateY(-50%);font-size:29px;color:#173b86;opacity:.17;pointer-events:none}
 .bp-notification-tiranga-border,.bp-notification-tiranga-chakra{box-shadow:inset 0 0 0 1px #0000000d}

/* V4.0 illustrated notification themes: same rules in app and admin preview */
.bp-notification-strip.bp-stylish,.bp-theme-preview.bp-stylish{position:relative;isolation:isolate;overflow:hidden;background:var(--bp-notice-bg);color:var(--bp-notice-ink);box-shadow:0 3px 12px #112e5820}
.bp-stylish:before{content:"";position:absolute;inset:0;background:var(--bp-decor);pointer-events:none;z-index:-1}
.bp-stylish:after{content:var(--bp-art);position:absolute;right:11px;top:50%;transform:translateY(-50%);font-size:23px;opacity:.44;pointer-events:none;z-index:-1}
.bp-stylish .bp-notification-icon,.bp-stylish .bp-preview-icon{display:grid;place-items:center;flex:0 0 31px;width:31px;height:31px;border:1.5px solid #ffffffa8;border-radius:50%;background:var(--bp-icon-bg,#1554b4);color:var(--bp-notice-accent,#fff);font-size:17px;box-shadow:0 2px 7px #0002;position:relative;z-index:1}
.bp-stylish .bp-notification-viewport,.bp-stylish .bp-preview-message{position:relative;z-index:1;padding-right:20px}
.bp-stylish .bp-theme-arrow{position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:23px;line-height:1;font-weight:800;color:var(--bp-notice-ink);opacity:.92;pointer-events:none;z-index:1}
.bp-theme-preview{display:flex;align-items:center;gap:10px;min-height:57px;padding:9px 12px;border-radius:14px;box-sizing:border-box}
.bp-theme-preview .bp-preview-message{font-weight:700;font-size:14px;line-height:1.4;overflow-wrap:anywhere;flex:1}
.bp-stylish.bp-notification-blue{--bp-notice-bg:linear-gradient(110deg,#0a3a96,#1558d0);--bp-notice-ink:#fff;--bp-icon-bg:#0a3a96;--bp-decor:radial-gradient(circle at 86% 115%,#50a7ff66 0 17%,transparent 18%),linear-gradient(120deg,transparent 60%,#4a9bff33 100%);--bp-art:"🏰"}
.bp-stylish.bp-notification-green{--bp-notice-bg:linear-gradient(110deg,#d6fbe8,#91edbb);--bp-notice-ink:#053d35;--bp-icon-bg:#d6fbe8;--bp-decor:radial-gradient(ellipse at 94% 100%,#19a56655 0 23%,transparent 24%),radial-gradient(ellipse at 4% 0%,#ffffff99 0 18%,transparent 19%);--bp-art:"🌿"}
.bp-stylish.bp-notification-orange{--bp-notice-bg:linear-gradient(110deg,#ffe7bd,#ff9e29);--bp-notice-ink:#9a2600;--bp-icon-bg:#ffe7bd;--bp-decor:radial-gradient(circle at 105% -40%,#fff8 0 43%,transparent 44%),repeating-radial-gradient(circle at 98% 115%,#ffffff55 0 2px,transparent 3px 11px);--bp-art:"📣"}
.bp-stylish.bp-notification-purple{--bp-notice-bg:linear-gradient(110deg,#5422c7,#a129ef);--bp-notice-ink:#fff;--bp-icon-bg:#5422c7;--bp-decor:repeating-radial-gradient(ellipse at 104% 140%,#ffffff24 0 2px,transparent 3px 15px);--bp-art:"🔔"}
.bp-stylish.bp-notification-pink{--bp-notice-bg:linear-gradient(110deg,#ffd4ea,#ff8cc5);--bp-notice-ink:#991451;--bp-icon-bg:#ffd4ea;--bp-decor:radial-gradient(circle at 93% 55%,#ffeffa 0 8%,transparent 9%),radial-gradient(circle at 86% 80%,#d9488b55 0 16%,transparent 17%);--bp-art:"🌸"}
.bp-stylish.bp-notification-elegant-gold{--bp-notice-bg:linear-gradient(110deg,#fff0bf,#f4bb4b);--bp-notice-ink:#76400c;--bp-icon-bg:#fff0bf;--bp-decor:repeating-radial-gradient(ellipse at 100% 155%,#bc8a2d55 0 2px,transparent 3px 12px);--bp-art:"★"}
.bp-stylish.bp-notification-night-blue{--bp-notice-bg:linear-gradient(110deg,#041532,#0a438a);--bp-notice-ink:#fff;--bp-icon-bg:#041532;--bp-decor:radial-gradient(circle at 92% 10%,#fff8 0 2px,transparent 3px),radial-gradient(ellipse at 100% 110%,#e6a74255 0 17%,transparent 18%);--bp-art:"🌙"}
.bp-stylish.bp-notification-sky{--bp-notice-bg:linear-gradient(110deg,#d5f4ff,#35aafa);--bp-notice-ink:#0c3479;--bp-icon-bg:#d5f4ff;--bp-decor:radial-gradient(ellipse at 90% 130%,#1377d3a8 0 27%,transparent 28%),radial-gradient(ellipse at 66% 150%,#ffffffa0 0 30%,transparent 31%);--bp-art:"ℹ"}
.bp-stylish.bp-notification-dark-elegant{--bp-notice-bg:linear-gradient(110deg,#121319,#252831);--bp-notice-ink:#fff1bd;--bp-icon-bg:#121319;--bp-decor:linear-gradient(130deg,transparent 73%,#f4c55a 74%,transparent 76%),linear-gradient(130deg,transparent 79%,#d49b30 80%,transparent 81%);--bp-art:"✦"}
.bp-stylish.bp-notification-red{--bp-notice-bg:linear-gradient(110deg,#ef122c,#ae0022);--bp-notice-ink:#fff;--bp-icon-bg:#ef122c;--bp-decor:repeating-radial-gradient(circle at 99% 80%,#ffffff24 0 1px,transparent 2px 9px);--bp-art:"❗"}
.bp-stylish.bp-notification-modern-teal{--bp-notice-bg:linear-gradient(110deg,#d4fbff,#3dd6df);--bp-notice-ink:#073a76;--bp-icon-bg:#d4fbff;--bp-decor:repeating-radial-gradient(circle at 101% 65%,#ffffff66 0 2px,transparent 3px 15px);--bp-art:"⬡"}
.bp-stylish.bp-notification-gradient-pro{--bp-notice-bg:linear-gradient(110deg,#008cf5,#bd25e6);--bp-notice-ink:#fff;--bp-icon-bg:#008cf5;--bp-decor:radial-gradient(ellipse at 98% 100%,#ff94aa 0 22%,transparent 23%),radial-gradient(ellipse at 0% 120%,#5239ff 0 24%,transparent 25%);--bp-art:"✨"}
.bp-stylish.bp-notification-diwali{--bp-notice-bg:linear-gradient(110deg,#ffdc73,#9d30a8);--bp-notice-ink:#fff8d4;--bp-icon-bg:#ffdc73;--bp-decor:radial-gradient(circle at 95% 15%,#ffe57d 0 3%,transparent 4%),radial-gradient(circle at 85% 80%,#ffe57d88 0 10%,transparent 11%);--bp-art:"🪔"}
.bp-stylish.bp-notification-eid{--bp-notice-bg:linear-gradient(110deg,#064c65,#07866c);--bp-notice-ink:#fff0bd;--bp-icon-bg:#064c65;--bp-decor:radial-gradient(circle at 90% 40%,#ffe9a4 0 10%,transparent 11%),radial-gradient(circle at 93% 34%,#07866c 0 9%,transparent 10%);--bp-art:"🌙"}
.bp-stylish.bp-notification-holi{--bp-notice-bg:linear-gradient(110deg,#ff8bc7,#ffdb64);--bp-notice-ink:#81216b;--bp-icon-bg:#ff8bc7;--bp-decor:radial-gradient(circle at 90% 80%,#45c5f1 0 17%,transparent 18%),radial-gradient(circle at 76% 5%,#ac56e2aa 0 13%,transparent 14%);--bp-art:"🎨"}
.bp-stylish.bp-notification-independence{--bp-notice-bg:linear-gradient(110deg,#ff9933,#138808);--bp-notice-ink:#102c6a;--bp-icon-bg:#ff9933;--bp-decor:linear-gradient(180deg,#ff9933 0 33%,#fff 33% 67%,#138808 67%);--bp-art:"🇮🇳"}
.bp-stylish.bp-notification-christmas{--bp-notice-bg:linear-gradient(110deg,#ad1735,#135c3b);--bp-notice-ink:#fff;--bp-icon-bg:#ad1735;--bp-decor:radial-gradient(circle at 90% 25%,#ffffff 0 2%,transparent 3%),radial-gradient(circle at 80% 85%,#ffd36688 0 10%,transparent 11%);--bp-art:"🎄"}
.bp-stylish.bp-notification-makar-sankranti{--bp-notice-bg:linear-gradient(110deg,#ffe2a2,#ffad35);--bp-notice-ink:#79350d;--bp-icon-bg:#ffe2a2;--bp-decor:linear-gradient(35deg,transparent 78%,#d65b18 79%,transparent 80%),radial-gradient(circle at 94% 35%,#fff5ca 0 14%,transparent 15%);--bp-art:"🪁"}
.bp-stylish.bp-notification-ganesh-chaturthi{--bp-notice-bg:linear-gradient(110deg,#ffca67,#ed7421);--bp-notice-ink:#7a2e0b;--bp-icon-bg:#ffca67;--bp-decor:radial-gradient(circle at 92% 70%,#f5d763 0 18%,transparent 19%);--bp-art:"🌺"}
.bp-stylish.bp-notification-navratri{--bp-notice-bg:linear-gradient(110deg,#8b214b,#e9982f);--bp-notice-ink:#fff;--bp-icon-bg:#8b214b;--bp-decor:repeating-conic-gradient(from 30deg at 95% 50%,#ffd46c44 0 14deg,transparent 15deg 30deg);--bp-art:"✨"}
.bp-stylish.bp-notification-raksha-bandhan{--bp-notice-bg:linear-gradient(110deg,#ffb4db,#b86adb);--bp-notice-ink:#6b1d67;--bp-icon-bg:#ffb4db;--bp-decor:radial-gradient(circle at 90% 50%,#fff0bf 0 12%,transparent 13%);--bp-art:"🎀"}
.bp-stylish.bp-notification-janmashtami{--bp-notice-bg:linear-gradient(110deg,#073b78,#199e9b);--bp-notice-ink:#fff4b8;--bp-icon-bg:#073b78;--bp-decor:radial-gradient(ellipse at 94% 65%,#33b3d7 0 18%,transparent 19%);--bp-art:"🦚"}
.bp-stylish.bp-notification-guru-nanak{--bp-notice-bg:linear-gradient(110deg,#13509b,#f7a344);--bp-notice-ink:#fff;--bp-icon-bg:#13509b;--bp-decor:radial-gradient(circle at 90% 50%,#ffdf77 0 14%,transparent 15%);--bp-art:"☀"}
.bp-stylish.bp-notification-rainbow-celebration{--bp-notice-bg:linear-gradient(110deg,#ff548f,#4a67e4);--bp-notice-ink:#fff;--bp-icon-bg:#ff548f;--bp-decor:linear-gradient(110deg,transparent 64%,#ffd85499 72%,#3bcda388 82%,#7b4be5aa 95%);--bp-art:"🎉"}
 @media(prefers-reduced-motion:reduce){.bp-notification-item{animation:none!important}}
 `;
 document.head.appendChild(style);
}
installNotificationStyles();

let bpNotificationTimer=null;
function startHomeSlides(){
 if(bpNotificationTimer){clearInterval(bpNotificationTimer);bpNotificationTimer=null}
 const noticeTrack=document.querySelector('.bp-notification-track');
 if(S.page==='home'&&noticeTrack){const messages=[...noticeTrack.querySelectorAll('.bp-notification-item')];if(messages.length>1){let index=0;bpNotificationTimer=setInterval(()=>{if(S.page!=='home'||document.hidden)return;messages[index].style.display='none';index=(index+1)%messages.length;messages[index].style.display='flex';messages[index].animate([{transform:'translateY(24px)',opacity:0},{transform:'translateY(0)',opacity:1}],{duration:450,easing:'ease-out'});},5000)}}

 if(homeSlidesTimer){clearInterval(homeSlidesTimer);homeSlidesTimer=null}
 if(S.page!=='home')return;
 const eligible=()=>[...document.querySelectorAll('[data-home-carousel]')].filter(el=>el.querySelectorAll('.home-landscape-slide').length>1);
 if(eligible().length && !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches))homeSlidesTimer=setInterval(()=>{
  if(S.page!=='home'||document.hidden)return;
  eligible().forEach(el=>displayHomeSlide(el,(S.homeSlidePositions[el.dataset.homeCarousel]||0)+1));
 },4800);
}
function cityNewsList(){
 const arr=S.cityItems.filter(x=>x.status==='published'&&['blogs','updates'].includes(x.type));
 return `<div class="screen city-page">${head('News & Blog')}<div class="city-heading"><span>${icon('news',27)}</span><div><h1>News & Blog</h1><p>Published Baran city updates and articles</p></div></div>${S.cityLoading?'<div class="city-message">Loading published news and blogs...</div>':S.cityError?`<div class="city-message">${escapeHtml(S.cityError)}</div>`:arr.length?arr.map(x=>`<article class="city-list-card">${safeHttps(x.cover)?`<img src="${escapeHtml(safeHttps(x.cover))}" loading="lazy" alt="">`:`<div class="city-list-placeholder">${icon('news',32)}</div>`}<div class="city-list-text"><small>${x.type==='updates'?'City News':'Blog'} · ${escapeHtml(cityDate(x.publishedAt))}</small><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.summary||'')}</p><button data-city-detail="${escapeHtml(x.id)}">Read More →</button></div></article>`).join(''):'<div class="city-message">No published news or blogs yet.</div>'}</div>`;
}
async function openHomeCityList(section){
 if(section==='news'){
  S.cityError='';S.cityLoading=true;S.cityBackTarget='cityNews';go('cityNews');
  try{S.cityItems=C.enabled?await C.publicCity():[]}catch(e){S.cityError='Unable to load news and blogs.';console.warn(e)}
  finally{S.cityLoading=false;if(S.page==='cityNews')render()}
 }else{S.cityBackTarget='cityList';await openCity(section)}
}
function homeCityDetail(id){
 const x=S.homeCityItems.find(item=>item.id===id&&item.status==='published'&&item.showOnHomepage===true);
 if(!x)return toast('This information is no longer available');
 S.cityItems=S.homeCityItems;S.cityType=x.type;S.cityId=x.id;S.cityBackTarget='home';go('cityDetail');
}

function noticeAllowed(n){if(!n||n.active!==true)return false;const today=new Date().toISOString().slice(0,10);if(n.startDate&&n.startDate>today||n.endDate&&n.endDate<today)return false;const key='baran_notice_'+n.id;let rec={};try{rec=JSON.parse(localStorage.getItem(key)||'{}')}catch(e){}const mode=n.frequency||'once';if(mode==='always')return true;if(mode==='daily')return rec.day!==today;if(mode==='custom')return (rec.count||0)<Math.max(1,Number(n.maxShows)||1);return !rec.count}
function showNotice(){if(S.page!=='home'||S.noticeVisible)return;const n=S.notices.filter(noticeAllowed).sort((a,b)=>Number(b.priority||0)-Number(a.priority||0))[0];if(n){S.noticeVisible=n;render()}}
function dismissNotice(){const n=S.noticeVisible;if(!n)return;const key='baran_notice_'+n.id;let rec={};try{rec=JSON.parse(localStorage.getItem(key)||'{}')}catch(e){}rec.count=(rec.count||0)+1;rec.day=new Date().toISOString().slice(0,10);localStorage.setItem(key,JSON.stringify(rec));S.noticeVisible=null;render()}
function noticePopup(){const n=S.noticeVisible;if(!n)return '';return `<div class="notice-backdrop"><section class="notice-popup" role="dialog" aria-modal="true" aria-label="City Update"><div class="notice-popup-head"><strong>📣 CITY UPDATE</strong><button data-notice-close aria-label="Close notice">×</button></div>${/^https:\/\//.test(n.imageUrl||'')?`<img class="notice-image" src="${escapeHtml(n.imageUrl)}" alt="">`:''}<div class="notice-popup-copy"><h2>${escapeHtml(n.title||'City Update')}</h2><p>${escapeHtml(n.message||'')}</p></div>${n.phone&&/^\+?[0-9 -]{10,16}$/.test(n.phone)?`<button class="notice-confirm" data-notice-call="${escapeHtml(n.phone)}">☎ Call Now</button>`:''}<button class="notice-confirm" data-notice-close>✓ OK, Got It</button><small>BARAN PRIDE • Official Announcement</small></section></div>`}
function notificationStrip(){
 if(S.notificationSettings.enabled===false)return '';
 const items=S.sliderMessages.filter(n=>n.active===true);
 if(!items.length)return '';
 const theme=['purple','blue','orange','green','pink','red','yellow','sky','dark','tiranga','tiranga-wave','tiranga-border','tiranga-gradient','tiranga-brush','tiranga-chakra','fresh-green','modern-orange','premium-purple','soft-pink','elegant-gold','night-blue','dark-elegant','alert-red','modern-teal','gradient-pro','diwali','eid','holi','independence','christmas','makar-sankranti','ganesh-chaturthi','navratri','raksha-bandhan','janmashtami','guru-nanak','rainbow-celebration'].includes(S.notificationSettings.theme)?S.notificationSettings.theme:'purple';
 const safeColor=v=>/^#[0-9a-fA-F]{6}$/.test(String(v||''))?v:null; const bg=safeColor(S.notificationSettings.backgroundColor),ink=safeColor(S.notificationSettings.textColor),accent=safeColor(S.notificationSettings.iconColor); const vars=[bg?`--bp-notice-bg:${bg}`:'',ink?`--bp-notice-ink:${ink}`:'',accent?`--bp-notice-accent:${accent}`:''].filter(Boolean).join(';');
 return `<div class="bp-notification-strip bp-stylish bp-notification-${theme}" style="${vars}" aria-label="Baran Pride notifications"><span class="bp-notification-icon" style="${accent?`color:${accent}`:''}">${({"diwali":"🪔","eid":"🌙","holi":"🎨","independence":"🇮🇳","christmas":"🎄","makar-sankranti":"🪁","ganesh-chaturthi":"🌺","navratri":"✨","raksha-bandhan":"🎀","janmashtami":"🦚","guru-nanak":"☀","rainbow-celebration":"🎉","green":"🌿","orange":"📣","pink":"🌸","elegant-gold":"★","night-blue":"🌙","sky":"ℹ","dark-elegant":"✦","red":"❗","modern-teal":"⬡","gradient-pro":"✨"}[theme]||"🔔")}</span><div class="bp-notification-viewport"><div class="bp-notification-track">${items.map(n=>`<div class="bp-notification-item">${escapeHtml(n.text||'')}</div>`).join('')}</div></div><span class="bp-theme-arrow" aria-hidden="true">›</span></div>`;
}
function promotionBanner(){const b=S.promotionSelected;if(!b)return '';const photo=safeHttps(b.imageUrl);return `<section class="bp-promo" aria-label="Promotional banner"><button class="bp-promo-main" data-promo-detail="${escapeHtml(b.id)}" aria-label="Open banner details">${photo?`<img src="${escapeHtml(photo)}" alt="" onerror="this.onerror=null;this.style.display='none'">`:''}</button>${b.phone?`<button class="bp-promo-call" data-promo-call="${escapeHtml(b.id)}" aria-label="Call banner contact">${icon('phone',22)}</button>`:''}</section>`}

function promotionDetail(){const b=S.promotionSelected;if(!b)return home();return `<div class="screen">${head('Featured Announcement')}<div class="bp-promo-detail">${safeHttps(b.imageUrl)?`<img src="${escapeHtml(safeHttps(b.imageUrl))}" alt="">`:''}<h1>${escapeHtml(b.title)}</h1><p>${escapeHtml(b.description||'')}</p>${b.phone?`<button class="primary-btn" data-promo-call="${escapeHtml(b.id)}">${icon('phone',19)} Call ${escapeHtml(b.phone)}</button>`:''}</div></div>`}
function aboutUs(){
 const features=[['store','Local Businesses','business'],['calendar','Events & Festivals','events'],['phone','Important Contacts','contacts'],['info','City Information','info']];
 const details=[['phone','Contact Number 1','+91 82333 66613','phone'],['phone','Contact Number 2','+91 77373 25205','phone'],['mail','Email Address','mansurbrn@gmail.com','email'],['globe','Official Website','www.itcampusbaran.in','web'],['pin','Office Address','Near Baba Phool Peer, Dol Mela Ground, Baran (Rajasthan) – 325205','address']];
 return `<div class="screen bp-about-v14">${head('About Us')}
 <section class="bp14-hero"><div class="bp14-monument">${icon('store',32)}</div><h1>BARAN PRIDE</h1><strong>हमारा शहर, हमारी पहचान</strong><p>Discover • Connect • Grow</p></section>
 <section class="bp14-card"><h2>About Baran Pride</h2><p>Baran Pride एक डिजिटल सिटी डायरेक्टरी प्लेटफॉर्म है, जिसका उद्देश्य बारां शहर के स्थानीय व्यवसायों, सेवाओं और महत्वपूर्ण जानकारियों को एक ही स्थान पर उपलब्ध कराना है।</p></section>
 <section class="bp14-card bp14-mission"><h2>Our Mission</h2><p>स्थानीय व्यापार को डिजिटल पहचान देना, लोगों को विश्वसनीय जानकारी से जोड़ना और बारां शहर के विकास में योगदान देना।</p></section>
 <section class="bp14-card"><h2>What We Provide</h2><div class="bp14-features">${features.map(([ic,title,cl])=>`<div class="bp14-feature bp14-${cl}">${icon(ic,25)}<strong>${title}</strong></div>`).join('')}</div></section>
 <section class="bp14-card"><h2>Our Organisation</h2><div class="bp14-org"><div class="bp14-orgitem"><span class="bp14-orgicon">${icon('store',24)}</span><div><strong>IT CAMPUS BARAN</strong><small>A Local Initiative for Our City</small></div></div><div class="bp14-orgitem"><span class="bp14-orgicon purple">${icon('user',24)}</span><div><small>Developed by</small><strong>IT CAMPUS</strong><small>Optimizing Website | Empowering Business</small></div></div></div></section>
 <section class="bp14-card"><h2>Contact Information</h2><div class="bp14-contacts">${details.map(([ic,label,value,cl])=>`<div class="bp14-contact"><span class="bp14-contacticon bp14-${cl}">${icon(ic,21)}</span><div><small>${label}</small><strong>${escapeHtml(value)}</strong></div></div>`).join('')}</div></section>
 <section class="bp14-card bp14-why"><h2>Why Choose Baran Pride?</h2>${['स्थानीय व्यवसायों की विश्वसनीय जानकारी','शहर की महत्वपूर्ण सेवाएँ एक ही स्थान पर','इवेंट्स, त्योहारों और शहर से जुड़ी जानकारियाँ','बारां के व्यापार और समुदाय के विकास में सहयोग'].map(t=>`<p><span class="bp14-check">✓</span>${t}</p>`).join('')}</section>
 <footer class="bp14-footer"><small>Designed & Developed by</small><strong>IT CAMPUS</strong><span>Optimizing Website | Empowering Business</span></footer></div>`;
}
function propertyHomeSection(){
 const items=S.properties.filter(x=>x.status==='approved');
 if(!items.length)return '';
 const cards=items.map(x=>{
  const title=String(x.title||x.propertyName||x.propertyType||'Property for Sale');
  const price=Number(x.askingPrice||0);
  const photo=safeHttps(x.coverImage||x.coverUrl||x.imageUrl||(Array.isArray(x.photoUrls)?x.photoUrls[0]:''));
  return `<button type="button" class="bp-property-mini" data-property-open="${escapeHtml(x.id)}" aria-label="View ${escapeHtml(title)}"><span class="bp-property-photo">${photo?`<img src="${escapeHtml(photo)}" alt="" loading="lazy" onerror="this.style.display='none'">`:icon('property',30)}</span><strong>${escapeHtml(title)}</strong><b>${price?'₹'+price.toLocaleString('en-IN'):'Price on request'}</b><small>${icon('pin',12)} ${escapeHtml(x.area||'Baran')}</small></button>`;
 });
 return `<section class="bp-properties-home"><div class="bp-properties-head"><h2>${icon('property',22)} Properties for Sale</h2><button type="button" data-property-viewall>View All →</button></div><div class="bp-property-window"><div class="bp-property-track" id="bp-property-track">${cards.join('')}</div></div></section>`;
}
function movePropertySlider(step=1){
 const track=document.querySelector('#bp-property-track');if(!track)return;
 const cards=[...track.children];if(cards.length<=1)return;
 S.propertySlideIndex=(S.propertySlideIndex+step+cards.length)%cards.length;
 const card=cards[S.propertySlideIndex];track.scrollTo({left:card.offsetLeft-track.offsetLeft,behavior:'smooth'});
}
let bpPropertyTimer=null;
function startPropertyCarousel(){
 if(bpPropertyTimer){clearInterval(bpPropertyTimer);bpPropertyTimer=null}
 if(S.page!=='home'||S.properties.length<=1)return;
 const track=document.querySelector('#bp-property-track');if(!track)return;
 if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;
 bpPropertyTimer=setInterval(()=>{if(S.page==='home'&&!document.hidden)movePropertySlider(1)},5000);
}
function home(){const featured=S.businesses.filter(b=>isPremium(b)).sort(prioritySort).slice(0,10);const latest=[...S.businesses].slice(-8).reverse();return `<div class="screen"><div class="topbar">${brand()}<div class="top-actions"><button class="round-btn bp-support" data-customer-care aria-label="Call Baran Pride Support">${icon('phone')}</button><button class="round-btn city-menu-toggle" data-menu-open aria-label="City information menu">${icon('menu')}</button></div></div>${banner()}${notificationStrip()}<section class="hero" ${S.heroImageUrl?`style="background-image:linear-gradient(90deg,rgba(12,50,106,.85),rgba(12,50,106,.32)),url('${escapeHtml(S.heroImageUrl)}')"`:''}><p class="location">${icon('pin',14)} Baran, Rajasthan</p><h1>Discover the<br>Best of Baran</h1><p class="subline">Find local businesses,<br>shops & services</p><form class="hero-search" id="hero-form">${icon('search',23)}<input id="hero-q" name="q" placeholder="Search businesses, services, places..." autocomplete="off" aria-label="Search"><button class="filter" type="submit" aria-label="Search">${icon('sliders')}</button></form></section>${promotionBanner()}<section class="categories">${[...categories].sort((a,b)=>a[0]==='More'?1:b[0]==='More'?-1:a[0].localeCompare(b[0],'en')).map(([c,i])=>`<button class="cat" data-category="${c}"><span class="cat-icon">${icon(i,25)}</span><span>${c}</span></button>`).join('')}</section>${propertyHomeSection()}${homepageSlider('events','Events & Festivals','calendar')}<section class="grow"><span class="grow-icon">${icon('store',39)}</span><div class="grow-copy"><strong>Grow Your Business</strong><p>Get listed in Baran Pride and reach more customers</p></div><button class="pill-cta" data-go="add">Add Business →</button></section>${section('<span class="star">★</span> Featured Businesses','featuredBusinesses')}<div class="featured-strip">${featured.map(bizCard).join('')||'<p class="intro">Featured businesses will appear here when available.</p>'}</div>${homepageSlider('historical','Historical Places','temple')}${homepageNews()}${section('◷ Recently Added','explore')}${latest.map(latestCard).join('')||empty('No listings yet','Approved businesses will appear here.')}</div>${noticePopup()}`}
function empty(title,desc,action,label){return `<div class="empty"><div style="color:#2f67ac">${icon('store',48)}</div><h3>${title}</h3><p>${desc}</p>${action?`<button class="primary-btn" data-go="${action}">${label||'Get Started'}</button>`:''}</div>`}
function featuredBusinesses(){const arr=S.businesses.filter(b=>isPremium(b)).sort(prioritySort);return `<div class="screen"><h1 class="page-title">★ Featured Businesses</h1><p class="intro">Explore featured businesses in Baran</p><p class="result-count">${arr.length} featured business${arr.length===1?'':'es'}</p>${arr.length?arr.map(b=>`<article class="listing-card">${businessImage(b,` alt=""`)}<main><h3>${businessName(b)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p><p>★ Featured</p><div class="row-actions"><button class="primary-small" data-detail="${b.id}">View Details</button><button class="outline-small" data-save="${b.id}">${S.saved.has(b.id)?'♥ Saved':'♡ Save'}</button></div></main></article>`).join(''):empty('No featured businesses','Featured businesses will appear here when available.')}</div>`}
function eventsTab(){return cityList()}
function explore(){const arr=filtered();return `<div class="screen"><h1 class="page-title">Explore Baran</h1><p class="intro">Find the right shops, services and professionals</p>${banner()}<div class="search-bar">${icon('search')}<input id="explore-q" value="${escapeHtml(S.query)}" placeholder="Search business, category or area..."></div><div class="chipbar">${['All',...allBusinessCategories()].map(c=>`<button class="chip ${S.category===c?'selected':''}" data-category="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('')}</div><p class="result-count">${arr.length} business${arr.length===1?'':'es'} found</p>${arr.length?arr.map(b=>`<article class="listing-card">${businessImage(b,` alt=""`)}<main><h3>${businessName(b)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p><p>${b.rating?'★ '+b.rating+' · ':''}${b.featured?'Featured':'Local Business'}</p><div class="row-actions"><button class="primary-small" data-detail="${b.id}">View Details</button><button class="outline-small" data-save="${b.id}">${S.saved.has(b.id)?'♥ Saved':'♡ Save'}</button></div></main></article>`).join(''):empty('No businesses found','Try another search or select a different category.')}</div>`}
function detail(){const b=findBiz(S.detail);if(!b)return explore();return `<div class="screen">${head('Business Details')}<img class="detail-photo" src="${escapeHtml(businessCover(b))}" alt="${escapeHtml(b.name)}"><div class="detail-head"><div><h1>${businessName(b)}</h1><p>${escapeHtml(businessCategories(b).join(', '))} · ${escapeHtml(b.area)}, Rajasthan</p></div><button class="round-btn" data-save="${b.id}" aria-label="Save business" style="color:${S.saved.has(b.id)?'#d64c69':''}">${icon('heart',23)}</button></div>${b.demo?banner():''}<div class="detail-actions"><button data-call="${b.id}">${icon('phone',23)}Call</button><button data-wa="${b.id}">${icon('message',23)}WhatsApp</button><button data-map="${b.id}">${icon('pin',23)}Directions</button></div><h3 class="block-title">About Business</h3><div class="info-panel"><p style="font-size:13px;line-height:1.65;color:#425a7b;margin:0">${escapeHtml(b.description||'Explore this business in Baran.')}</p></div>${weeklyDisplay(b.weeklyHours)}<h3 class="block-title">Contact & Location</h3><div class="info-panel"><div class="info-row">${icon('pin')}<span>${escapeHtml(b.address||'Baran, Rajasthan')}</span></div><div class="info-row">${icon('clock')}<span>${escapeHtml(b.hours||'Contact business for opening hours')}</span></div><div class="info-row">${icon('phone')}<span>${escapeHtml(b.phone||'Not provided')}</span></div><button class="bp-map-link" data-map="${escapeHtml(b.id)}">${icon('pin',20)} Open Location in Google Maps ${icon('arrow',17)}</button></div>${Array.isArray(b.photoUrls)&&b.photoUrls.length>1?`<div class="business-gallery">${b.photoUrls.slice(0,isPremium(b)?5:2).filter(u=>/^https:\/\//.test(u)).map(u=>`<img src="${escapeHtml(u)}" alt="${escapeHtml(b.name)}" loading="lazy">`).join('')}</div>`:''}<div class="detail-actions"><button data-share="${b.id}">${icon('share')}Share</button><button data-save="${b.id}">${icon('heart')}Save</button><button data-go="explore">${icon('search')}Explore</button></div></div>`}
function saved(){const arr=S.businesses.filter(b=>S.saved.has(b.id));return `<div class="screen"><h1 class="page-title">Saved Businesses</h1><p class="intro">Quickly find your favorite places</p>${arr.length?arr.map(b=>`<article class="listing-card">${businessImage(b,` alt=""`)}<main><h3>${businessName(b)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p><div class="row-actions"><button data-detail="${b.id}" class="primary-small">View Details</button><button data-save="${b.id}" class="outline-small">Remove</button></div></main></article>`).join(''):empty('No saved businesses','Save your favourite places to find them quickly.','explore','Explore Businesses')}</div>`}
function owner(){if(C.enabled&&!C.user)return `<div class="screen"><h1 class="page-title">My Business</h1><p class="intro">Manage your business listings</p>${empty('Sign in to manage listings','Sign in or register to add and view your businesses.','auth','Sign in / Register')}</div>`;
 return `<div class="screen"><h1 class="page-title">My Business</h1><p class="intro">Manage your listings and approval status</p>${!C.enabled?banner():''}<button class="primary-btn" data-go="add">${icon('plus',19)} Add New Business</button>${S.owned.length?S.owned.map(b=>`<article class="owner-card"><div style="display:flex;justify-content:space-between;align-items:flex-start;gap:9px"><div><h3>${businessName(b)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p></div><span class="status ${b.status||'pending'}">${escapeHtml(b.status||'pending').toUpperCase()}</span></div><div class="owner-statrow"><div class="stat"><small>Listing Plan</small><strong style="font-size:17px">${escapeHtml(b.plan||'Free')}</strong></div><div class="stat"><small>Payment</small><strong style="font-size:17px">${escapeHtml(b.paymentStatus||'Unpaid')}</strong></div></div><p><b>Validity:</b> ${b.expiresAt&&b.expiresAt.toDate?b.expiresAt.toDate().toLocaleDateString('en-IN'):'Not activated'}</p><p><b>Status:</b> ${b.status==='pending'?'Admin verification is pending.':b.status==='approved'?'Your business is live.':b.status==='rejected'?'Your listing needs corrections.':'Awaiting approval.'}</p><button class="secondary-btn" data-owner-photos="${b.id}">${icon('edit',15)} Manage Photos</button><button class="secondary-btn" data-edit="${b.id}">${icon('edit',15)} Request Profile Change</button></article>`).join(''):empty('No business added yet','Register your shop, institute or service to get listed on Baran Pride.','add','Add Your Business')}</div>`}
function ownerPhotos(){const b=S.owned.find(x=>x.id===S.photoBusinessId);if(!b)return owner();const urls=Array.isArray(b.photoUrls)?b.photoUrls:[],limit=isPremium(b)?5:2;
 return `<div class="screen">${head('Manage Business Photos')}<h2>${escapeHtml(b.name)}</h2><p>${urls.length} / ${limit} Photos · ${isPremium(b)?'Premium':'Free'}</p><form id="owner-photo-form" class="form-card"><div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">${urls.map((u,i)=>`<label style="min-width:0"><img src="${escapeHtml(u)}" style="width:100%;height:120px;object-fit:cover;border-radius:10px"><span><input type="checkbox" name="remove" value="${escapeHtml(u)}"> Remove</span><br><span><input type="radio" name="cover" value="${escapeHtml(u)}" ${u===(b.cover||urls[0])?'checked':''}> Cover</span></label>`).join('')}</div><label class="field">Add Photos <input type="file" name="photos" accept="image/jpeg,image/png,image/webp" multiple></label><p class="tiny">JPG/PNG/WebP under 5 MB each; automatically optimized to WebP when supported. Select a cover from existing photos or the first new photo becomes cover.</p><button class="primary-btn" type="submit">Save Photos</button></form></div>`;
}
async function onOwnerPhotos(f){const b=S.owned.find(x=>x.id===S.photoBusinessId);if(!b||!C.enabled)return;const urls=Array.isArray(b.photoUrls)?b.photoUrls:[],remove=[...f.querySelectorAll('input[name=remove]:checked')].map(x=>x.value),files=[...f.elements.photos.files],limit=isPremium(b)?5:2;
 if(urls.filter(u=>!remove.includes(u)).length+files.length>limit)return toast('Maximum '+limit+' photos allowed');const btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.textContent='Saving photos...';try{await C.managePhotos(b,files,remove,f.querySelector('input[name=cover]:checked')?.value||'');toast('Photos updated');await refresh();go('owner')}catch(e){toast(e.message);btn.disabled=false;btn.textContent='Save Photos'}}
const WEEK_DAYS=[['mon','Monday'],['tue','Tuesday'],['wed','Wednesday'],['thu','Thursday'],['fri','Friday'],['sat','Saturday'],['sun','Sunday']];
function weeklyEditor(existing){return `<div class="weekly-hours-editor"><strong>Monday–Sunday Opening / Closing</strong><p class="tiny">Closed चुनें या हर दिन अलग समय भरें</p>${WEEK_DAYS.map(([key,label])=>{const x=existing?.[key]||{};return `<div class="weekly-row"><strong>${label}</strong><input aria-label="${label} open" type="time" name="open_${key}" value="${escapeHtml(x.open||'09:00')}"><input aria-label="${label} close" type="time" name="close_${key}" value="${escapeHtml(x.close||'20:00')}"><label><input type="checkbox" name="closed_${key}" ${x.closed?'checked':''}> Closed</label></div>`}).join('')}</div>`}
function weeklyDisplay(hours){if(!hours||typeof hours!=='object')return '';return `<h3 class="block-title">Weekly Opening Hours</h3><div class="info-panel">${WEEK_DAYS.map(([key,label])=>{const x=hours[key];return `<div class="weekly-display-row"><strong>${label}</strong><span>${!x||x.closed?'Closed':escapeHtml((x.open||'--')+' – '+(x.close||'--'))}</span></div>`}).join('')}</div>`}
function addForm(){if(C.enabled&&!C.user){S.afterAuth='add';return auth()}let b=S.editingId?S.owned.find(x=>x.id===S.editingId):null;return `<div class="screen">${head(b?'Request Business Changes':'Add Your Business')}<h1 class="page-title">${b?'Edit Request':'Business Registration'}</h1><p class="intro">${b?'Admin must approve changes before they appear.':'Submit your listing for admin approval.'}</p>${!C.enabled?banner():''}<form id="business-form" class="form-card"><div class="field"><label for="b-name">Business Name *</label><input id="b-name" name="name" required minlength="3" maxlength="100" value="${escapeHtml(b?.name||'')}" placeholder="Enter business or shop name"></div><div class="fieldrow"><div class="field"><label>Category *</label><select name="category" required><option value="">Select</option>${allBusinessCategories().map((c)=>`<option ${b?.category===c?'selected':''}>${escapeHtml(c)}</option>`).join('')}</select>${b&&isPremium(b)?`<div class="field" style="margin-top:8px"><label>Additional Categories (up to 3 total)</label>${allBusinessCategories().map(c=>`<label style="display:block;font-size:12px;margin:4px 0"><input type="checkbox" name="extraCategory" value="${escapeHtml(c)}" ${(b.categories||[]).includes(c)&&c!==b.category?'checked':''}> ${escapeHtml(c)}</label>`).join('')}</div>`:''}</div><div class="field"><label>Area *</label><input name="area" required placeholder="e.g. Kota Road" value="${escapeHtml(b?.area||'')}"></div></div><div class="field"><label>Full Address *</label><textarea name="address" required placeholder="Street, landmark, Baran, Rajasthan">${escapeHtml(b?.address||'')}</textarea></div><div class="fieldrow"><div class="field"><label>Mobile Number *</label><input type="tel" name="phone" inputmode="numeric" pattern="[0-9+ -]{10,15}" required placeholder="10-digit mobile" value="${escapeHtml(b?.phone||'')}"></div><div class="field"><label>WhatsApp Number</label><input type="tel" name="whatsapp" inputmode="numeric" pattern="[0-9+ -]{10,15}" placeholder="Optional" value="${escapeHtml(b?.whatsapp||'')}"></div></div><div class="field"><label>About Business</label><textarea name="description" maxlength="700" placeholder="Tell customers about your business">${escapeHtml(b?.description||'')}</textarea></div><div class="field"><label>Opening Hours (optional summary)</label><input name="hours" placeholder="e.g. Mon-Sat 9 AM to 8 PM" value="${escapeHtml(b?.hours||'')}"></div><div class="field"><label>Google Maps Location Link (optional)</label><input type="url" name="mapUrl" placeholder="https://maps.app.goo.gl/..." value="${escapeHtml(b?.mapUrl||'')}"></div>${weeklyEditor(b?.weeklyHours)}${!b?`<div class="field"><label>Business Photos (up to 2, 5 MB each)</label><input type="file" name="photos" accept="image/jpeg,image/png,image/webp" multiple><div id="business-photo-preview" aria-live="polite" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:10px"></div><span class="tiny" id="business-photo-hint">Select up to 2 JPG, PNG or WebP photos (under 5 MB each).</span></div>`:''}<div class="form-note">Interested in a premium listing? Please call our team for details. Premium plans are managed manually by Admin; online paid activation is not available.</div><div class="form-note">After submission, the business remains <b>Pending</b> until approved by Admin. Premium payments are verified manually outside the Android app. No online payment link is shown here.</div><button class="primary-btn" id="submit-business" type="submit">${icon('check',18)} ${b?'Send Change Request':'Submit for Approval'}</button></form></div>`}
function auth(){return `<div class="screen">${head('Business Account')}<h1 class="page-title">${S.authTab==='signup'?'Create Account':'Welcome Back'}</h1><p class="intro">Sign in to manage your Baran Pride business</p><div class="chipbar"><button class="chip ${S.authTab==='signin'?'selected':''}" data-auth-tab="signin">Sign In</button><button class="chip ${S.authTab==='signup'?'selected':''}" data-auth-tab="signup">Register</button></div><form id="auth-form" class="form-card">${S.authTab==='signup'?`<div class="field"><label>Your Name *</label><input name="name" autocomplete="name" required></div><div class="field"><label>Mobile Number *</label><input name="mobile" type="tel" inputmode="numeric" pattern="[6-9][0-9]{9}" maxlength="10" placeholder="10-digit mobile number" required></div>`:''}<div class="field"><label>Email Address *</label><input name="email" type="email" autocomplete="email" required placeholder="you@example.com"></div><div class="field"><label>Password *</label><input name="password" type="password" minlength="6" autocomplete="${S.authTab==='signup'?'new-password':'current-password'}" required placeholder="Minimum 6 characters"></div><button class="primary-btn" type="submit">${S.authTab==='signup'?'Create Account':'Sign In'} ${icon('arrow',16)}</button>${S.authTab==='signup'?'':`<div style="display:flex;justify-content:space-between;gap:10px;margin-top:14px"><button type="button" class="secondary-btn" data-forgot-password>Forgot Password?</button><button type="button" class="secondary-btn" data-forgot-email>Forgot Email?</button></div>`}</form><div class="form-note">Only business owners need an account. Customers can browse listings without signing in.</div></div>`}
function profile(){const user=C.user;return `<div class="screen"><h1 class="page-title">My Profile</h1><p class="intro">Account and app information</p><div class="account"><div class="avatar">${icon('user',36)}</div><h2>${escapeHtml(user?.displayName||'Welcome to Baran Pride')}</h2><p>${escapeHtml(user?.email||'Discover local businesses in Baran')}</p></div><div class="menu-group"><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="owner">${icon('store')} My Business ${icon('arrow',17)}</button><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="saved">${icon('heart')} Saved Businesses ${icon('arrow',17)}</button><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="add">${icon('plus')} Add Your Business ${icon('arrow',17)}</button></div>${C.enabled?(user?`<button class="secondary-btn" data-action="logout">${icon('logout',17)} Sign Out</button>`:`<button class="primary-btn" data-go="auth">Sign In / Register</button>`):'<div class="notice">Demo mode: Firebase project is not connected. Listings are samples or stored only on this device.</div>'}<p class="fine-print">BARAN PRIDE · हमारा शहर, हमारी पहचान<br>Royal Blue Premium • Version 1.0</p></div>`}

// V2: Additional city information lives only behind this drawer; original business homepage stays intact.
function socialFooter(){const cfg=S.socialLinks||{};const items=[['instagram','Instagram','📷'],['facebook','Facebook','f'],['youtube','YouTube','▶'],['whatsapp','WhatsApp','✆']].filter(([key])=>cfg[key]?.enabled&&/^https:\/\//i.test(cfg[key]?.url||''));return items.length?`<div class="bp-social-footer"><strong>Follow BARAN PRIDE</strong><div class="bp-social-icons">${items.map(([key,label,mark])=>`<button type="button" data-social="${key}" aria-label="${label}" title="${label}">${mark}</button>`).join('')}</div></div>`:''}
function cityDrawer(){return `<div class="city-drawer-layer"><button class="city-drawer-shade" data-menu-close aria-label="Close menu"></button><aside class="city-drawer" role="dialog" aria-modal="true" aria-label="Baran city information"><div class="city-drawer-header"><button class="city-drawer-x" data-menu-close aria-label="Close">${icon('close')}</button><strong>BARAN PRIDE</strong><small>हमारा शहर, हमारी पहचान</small><p>Explore More About Baran</p></div><div class="city-drawer-items"><button data-go="home">${icon('home')} Home ${icon('arrow',17)}</button><button data-go="explore">${icon('store')} Local Businesses ${icon('arrow',17)}</button><button data-go="aboutUs">${icon('info')} About Us ${icon('arrow',17)}</button><hr><button data-special="properties">${icon('property')}<span>Sell Property<small>प्रॉपर्टी बिक्री और ग्राहक सेवा</small></span>${icon('arrow',17)}</button><button data-special="donors">${icon('drop')}<span>Blood Donors<small>रक्तदाताओं की सूची</small></span>${icon('arrow',17)}</button>${CITY_TYPES.map(t=>`<button data-city-type="${t[0]}">${icon(t[3])}<span>${t[1]}<small>${t[2]}</small></span>${icon('arrow',17)}</button>`).join('')}</div>${socialFooter()}<p class="city-drawer-footer">City information is published only by the Admin.</p></aside></div>`}
function openDrawer(){if(document.querySelector('.city-drawer-layer'))return;S.drawer=true;$('#app').insertAdjacentHTML('beforeend',cityDrawer());document.body.classList.add('city-drawer-open')}
function closeDrawer(){S.drawer=false;document.querySelector('.city-drawer-layer')?.remove();document.body.classList.remove('city-drawer-open')}
// Smart cache: render last published contacts immediately, refresh once per app session.
const CONTACT_CACHE_KEY='bp_important_contacts_v1';
let contactSyncPromise=null, contactSynced=false, contactSessionItems=null;
function cachedContacts(){try{const v=JSON.parse(localStorage.getItem(CONTACT_CACHE_KEY)||'null');return Array.isArray(v?.items)?v.items:[]}catch{return []}}
function saveContactCache(items){try{localStorage.setItem(CONTACT_CACHE_KEY,JSON.stringify({savedAt:Date.now(),items:items.filter(x=>x.type==='contacts'&&x.status==='published'&&x.visible!==false).map(x=>({id:x.id,type:x.type,status:x.status,visible:x.visible,title:x.title,summary:x.summary,phone:x.phone,contactCategory:x.contactCategory,area:x.area,featured:x.featured,homeOrder:x.homeOrder}))}))}catch(e){console.warn('Contacts cache unavailable',e)}}
async function syncContacts(){if(contactSyncPromise)return contactSyncPromise;if(contactSynced||!C.enabled)return;contactSyncPromise=(async()=>{try{const items=await C.publicCity();saveContactCache(items);contactSessionItems=items.filter(x=>x.type==='contacts'&&x.status==='published'&&x.visible!==false);contactSynced=true;if(S.cityType==='contacts'&&S.page==='cityList'){S.cityItems=contactSessionItems;S.cityError='';S.cityLoading=false;render()}}catch(e){console.warn('Contact background refresh unavailable',e)}finally{contactSyncPromise=null}})();return contactSyncPromise}
function preloadContacts(){const run=()=>syncContacts();if(typeof requestIdleCallback==='function')requestIdleCallback(run,{timeout:2500});else setTimeout(run,1200)}
async function openCity(type){closeDrawer();S.cityBackTarget='cityList';S.cityType=cityType(type)[0];S.cityId=null;S.cityQuery='';S.cityError='';
 if(S.cityType==='contacts'){
  const cached=contactSessionItems||cachedContacts();S.cityItems=cached;S.cityLoading=!cached.length&&!contactSynced&&C.enabled;go('cityList');
  if(contactSynced){S.cityLoading=false;return}
  await syncContacts();if(S.page==='cityList'&&S.cityType==='contacts'){S.cityLoading=false;render()}return;
 }
 S.cityLoading=true;go('cityList');
 try{S.cityItems=C.enabled?await C.publicCity():[]}
 catch(e){S.cityError='Unable to load city information. Please check the internet.';console.warn(e)}
 finally{S.cityLoading=false;if(S.page==='cityList')render()}
}
function safeHttps(u){try{const x=new URL(String(u||''));return x.protocol==='https:'?x.href:''}catch{return ''}}
function cityDate(v){const d=v&&typeof v.toDate==='function'?v.toDate():v?.seconds?new Date(v.seconds*1000):v?new Date(v):null;return d&&!Number.isNaN(d.getTime())?d.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}):''}
function contactCategory(x){return String(x.contactCategory||x.area||'Public').trim()||'Public'}
function contactPhone(x){return String(x.phone||'').replace(/[^0-9+]/g,'')}
function contactList(){
 const items=S.cityItems.filter(x=>x.type==='contacts'&&x.status==='published'&&x.visible!==false).sort((a,b)=>(Number(a.homeOrder)||100)-(Number(b.homeOrder)||100)||String(a.title).localeCompare(String(b.title)));
 const cats=['All',...new Set(items.map(contactCategory))];
 const row=x=>{const phone=contactPhone(x),em=x.featured||contactCategory(x).toLowerCase()==='emergency';return `<article class="bp-contact-card ${em?'bp-emergency':''}" data-city-search="${escapeHtml([x.title,x.summary,x.phone,contactCategory(x)].join(' ').toLowerCase())}" data-contact-category="${escapeHtml(contactCategory(x))}"><span class="bp-contact-symbol">${icon(em?'phone':'phone',21)}</span><div class="bp-contact-info"><strong>${escapeHtml(x.title)}</strong><small>${escapeHtml(x.summary||contactCategory(x))}</small></div><div class="bp-contact-action">${phone?`<button data-city-call="${escapeHtml(x.id)}">${icon('phone',15)} Call Now</button><small>${escapeHtml(phone)}</small>`:'<small>Number unavailable</small>'}</div></article>`};
 return `<div class="screen city-page bp-contacts"><div class="bp-contact-hero">${head('Important Contacts')}<p>Baran City • Quick Help Directory</p><div class="search-bar">${icon('search')}<input id="city-search" value="${escapeHtml(S.cityQuery)}" placeholder="Search contact, department or number..."></div></div><div class="bp-contact-categories">${cats.map((c,i)=>`<button class="bp-cat ${i===0?'active':''}" data-contact-filter="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('')}</div>${S.cityLoading?'<div class="city-message">Loading contacts...</div>':S.cityError?`<div class="city-message">${escapeHtml(S.cityError)} <button data-city-retry>Retry</button></div>`:items.length?`<div id="city-results"><h3 class="bp-contact-heading">Emergency Helplines</h3>${items.filter(x=>x.featured||contactCategory(x).toLowerCase()==='emergency').map(row).join('')}<h3 class="bp-contact-heading">City Services & Departments</h3>${items.filter(x=>!(x.featured||contactCategory(x).toLowerCase()==='emergency')).map(row).join('')}</div><p class="city-no-match hidden" id="city-no-match">No matching contacts.</p>`:'<div class="city-message">अभी कोई Important Contact प्रकाशित नहीं है।</div>'}</div>`;
}
function cityList(){if(S.cityType==='contacts')return contactList();const t=cityType(S.cityType),arr=S.cityItems.filter(x=>x.type===S.cityType);return `<div class="screen city-page">${head(t[1])}<div class="city-heading"><span>${icon(t[3],27)}</span><div><h1>${t[1]}</h1><p>${t[2]} · BARAN PRIDE</p></div></div><div class="search-bar">${icon('search')}<input id="city-search" value="${escapeHtml(S.cityQuery)}" placeholder="Search ${escapeHtml(t[1].toLowerCase())}..." aria-label="Search city information"></div>${S.cityLoading?'<div class="city-message">Loading published information...</div>':S.cityError?`<div class="city-message">${escapeHtml(S.cityError)} <button data-city-retry>Retry</button></div>`:arr.length?`<div id="city-results">${arr.map(x=>`<article class="city-list-card" data-city-search="${escapeHtml([x.title,x.area,x.summary].join(' ').toLowerCase())}">${safeHttps(x.cover)?`<img src="${escapeHtml(safeHttps(x.cover))}" loading="lazy" alt="">`:`<div class="city-list-placeholder">${icon(t[3],32)}</div>`}<div class="city-list-text"><small>${escapeHtml(t[1])}${x.area?' · '+escapeHtml(x.area):''}</small><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.summary||'Tap to read more.')}</p><button data-city-detail="${escapeHtml(x.id)}">Read More →</button></div></article>`).join('')}</div><p class="city-no-match hidden" id="city-no-match">No matching information found.</p>`:'<div class="city-message">अभी इस सेक्शन में कोई जानकारी प्रकाशित नहीं हुई है।<br><small>Only Admin can publish new information.</small></div>'}</div>`}
function cityDetail(){const x=S.cityItems.find(o=>o.id===S.cityId&&o.status==='published'),t=cityType(S.cityType);if(!x)return cityList();let gallery=(Array.isArray(x.photos)?x.photos:[]).map(safeHttps).filter(Boolean);const cover=safeHttps(x.cover);if(!gallery.length&&cover)gallery=[cover];const mapUrl=safeHttps(x.mapUrl),phone=String(x.phone||'').replace(/[^0-9+]/g,'');return `<div class="screen city-page">${head(t[1])}<article class="city-article">${cover?`<img class="city-article-cover" src="${escapeHtml(cover)}" alt="${escapeHtml(x.title)}">`:`<div class="city-article-cover city-article-empty">${icon(t[3],55)}</div>`}<div class="city-article-meta">${escapeHtml(t[1])}${x.area?' · '+escapeHtml(x.area):''}</div><h1>${escapeHtml(x.title)}</h1>${x.summary?`<p class="city-summary">${escapeHtml(x.summary)}</p>`:''}<div class="city-article-actions"><button data-city-share="${escapeHtml(x.id)}">${icon('share',17)} Share</button>${mapUrl?`<button data-city-map="${escapeHtml(x.id)}">${icon('pin',17)} Directions</button>`:''}${(x.type==='contacts'||x.type==='events')&&phone?`<button data-city-call="${escapeHtml(x.id)}">${icon('phone',17)} ${x.type==='events'?'Call Organizer':'Call'}</button>`:''}</div>${x.area||x.placeAddress?`<div class="city-fact">${icon('pin',19)} ${escapeHtml([x.placeAddress,x.area].filter(Boolean).join(' · '))}</div>`:''}${x.type==='events'&&(x.startDate||x.endDate)?`<div class="city-fact">${icon('calendar',19)} ${escapeHtml([x.startDate,x.endDate].filter(Boolean).join(' → '))}</div>`:x.eventDate?`<div class="city-fact">${icon('calendar',19)} ${escapeHtml(x.eventDate)}</div>`:''}${x.type==='events'&&phone?`<div class="city-fact">${icon('phone',19)} <span><strong>Organizer Contact:</strong> ${escapeHtml(phone)}</span></div>`:''}<div class="city-prose">${escapeHtml(x.body||'').replace(/\r?\n/g,'<br>')}</div>${gallery.length>1?`<h3>Photo Gallery</h3><div class="city-gallery">${gallery.map(img=>`<img src="${escapeHtml(img)}" loading="lazy" alt="${escapeHtml(x.title)}">`).join('')}</div>`:''}<p class="city-published">Published by BARAN PRIDE Admin${cityDate(x.publishedAt)?' · '+cityDate(x.publishedAt):''}</p></article></div>`}
// V3: New sections in the side menu only; original business homepage is untouched.
const bloodGroups=['All','A+','A-','B+','B-','AB+','AB-','O+','O-'];
const validPhone=(v)=>/^[6-9]\d{9}$/.test(String(v||'').replace(/[^0-9]/g,''));
const dialDirect=(p)=>{const val=String(p||'').replace(/[^+\d]/g,'');if(!val)return toast('Contact number not available');if(!native('dial',val))openUrl('tel:'+val)};
function shuffleDonors(items){const result=[...items];for(let i=result.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[result[i],result[j]]=[result[j],result[i]]}return result}
async function openDonors(){closeDrawer();S.donorError='';S.donors=[];S.donorFilter='All';go('donors');if(!C.enabled)return;try{S.donors=shuffleDonors(await C.publicDonors())}catch(e){S.donorError='Unable to load donors. Check internet.'}if(S.page==='donors')render()}
async function openProperties(){closeDrawer();S.properties=[];S.propertyError='';S.helpline='7737325205';go('properties');if(!C.enabled)return;try{const [items,number]=await Promise.all([C.publicProperties(),C.customerCare()]);S.properties=items;S.helpline=number}catch(e){S.propertyError='Unable to load properties. Check internet.'}if(S.page==='properties')render()}
function donorPage(){const group=S.donorFilter;const entries=S.donors.filter(d=>group==='All'||d.bloodGroup===group);return `<div class="screen city-page">${head('Blood Donors')}<div class="city-heading">${icon('drop',32)}<div><h1>Blood Donors</h1><p>स्वैच्छिक रक्तदाताओं की सूची</p></div></div><div class="special-note">केवल सहमति देने वाले रक्तदाताओं के फोन नंबर दिखते हैं। रक्त की उपलब्धता की गारंटी नहीं है। आपात स्थिति में अस्पताल या ब्लड बैंक से संपर्क करें।</div><div class="special-filter">${bloodGroups.map(g=>`<button class="${group===g?'selected':''}" data-blood-filter="${escapeHtml(g)}">${escapeHtml(g)}</button>`).join('')}</div>${S.donorError?`<div class="city-message">${escapeHtml(S.donorError)}</div>`:entries.length?entries.map(d=>`<article class="blood-card"><span class="blood-pill">${escapeHtml(d.bloodGroup)}</span><div class="blood-card-text"><strong>${escapeHtml(maskBloodDonorName(d.name))}</strong><small>${escapeHtml(d.area||'Baran')} · Voluntary Donor</small><p>${escapeHtml(d.phone)}</p></div><button data-blood-call="${escapeHtml(d.id)}" aria-label="Call ${escapeHtml(maskBloodDonorName(d.name))}">${icon('phone',18)} Call</button></article>`).join(''):`<div class="city-message">इस ग्रुप में फिलहाल कोई सत्यापित रक्तदाता उपलब्ध नहीं है।<br><small>Admin से सूची अपडेट की जाएगी।</small></div>`}<p class="fine-print">प्रकाशित नंबर स्वैच्छिक सार्वजनिक सहमति पर आधारित हैं। गलत नंबर या सूची हटाने के लिए BARAN PRIDE Admin से संपर्क करें।</p></div>`}
function propertiesPage(){return `<div class="screen city-page">${head('Sell Property')}<div class="city-heading">${icon('property',31)}<div><h1>Property in Baran</h1><p>प्रॉपर्टी देखें या बेचने के लिए भेजें</p></div></div><div class="special-note">प्रॉपर्टी मालिक का <b>नाम हमेशा निजी</b> रहेगा। फोन नंबर दिखाने का फैसला सिर्फ BARAN PRIDE Admin करेगा। डिफॉल्ट संपर्क Customer Care <b>7737325205</b> है; मालिक की अनुमति मिलने पर Admin उसका नंबर दिखा सकता है।</div><button class="primary-btn" data-go="propertySubmit">${icon('plus',18)} List Your Property for Sale</button><h2 class="block-title">Available Properties</h2>${S.propertyError?`<div class="city-message">${escapeHtml(S.propertyError)}</div>`:S.properties.length?S.properties.map(x=>`<article class="property-card"><div class="property-banner">${icon('property',29)}<span>${escapeHtml(x.propertyType||'Property')}</span></div><div class="property-body"><h3>${escapeHtml(x.propertyType||'Property for Sale')} · ${escapeHtml(x.area||'Baran')}</h3><p>Area: ${escapeHtml(x.area||'Baran')}${x.size?' · Size: '+escapeHtml(x.size):''}</p>${x.askingPrice?`<strong class="property-price">₹${Number(x.askingPrice).toLocaleString('en-IN')}</strong>`:''}${x.description?`<p>${escapeHtml(x.description)}</p>`:''}<div class="property-contact-line"><b>${x.contactMode==='owner'&&validPhone(x.publicContactPhone)?'Owner Contact':'Customer Care'}:</b> ${escapeHtml(x.contactMode==='owner'&&validPhone(x.publicContactPhone)?x.publicContactPhone:S.helpline)}</div><button class="primary-btn" data-property-call="${escapeHtml(x.id)}">${icon('phone',18)} ${x.contactMode==='owner'&&validPhone(x.publicContactPhone)?'Call Property Owner':'Call Customer Care'}</button></div></article>`).join(''):'<div class="city-message">अभी कोई Approved Property नहीं है।<br><small>नए विज्ञापन Admin Approval के बाद दिखेंगे।</small></div>'}${S.helpline?`<button class="secondary-btn" data-customer-care>${icon('phone',18)} Customer Care: ${escapeHtml(S.helpline)}</button>`:'<div class="form-note">Customer Care नंबर अभी Admin द्वारा सेट नहीं किया गया है।</div>'}</div>`}
function propertySubmitPage(){if(C.enabled&&!C.user){S.afterAuth='propertySubmit';return auth()}return `<div class="screen city-page">${head('Sell Your Property')}<h1 class="page-title">Property Sale Request</h1><p class="intro">प्रॉपर्टी की जानकारी भरें। Owner Name और Mobile केवल Admin को दिखाई देंगे।</p>${!C.enabled?banner():''}<form id="property-request-form" class="form-card"><div class="field"><label>Owner Name * (PRIVATE)</label><input name="ownerName" required minlength="3" maxlength="100" placeholder="Property owner name"></div><div class="field"><label>Owner Mobile Number * (PRIVATE)</label><input name="ownerPhone" type="tel" inputmode="numeric" required maxlength="10" pattern="[6-9][0-9]{9}" placeholder="10-digit number"></div><div class="fieldrow"><div class="field"><label>Property Type *</label><select name="propertyType" required><option value="">Select Type</option>${['Plot','House','Flat','Shop','Land','Commercial Property','Other'].map(x=>`<option>${x}</option>`).join('')}</select></div><div class="field"><label>Area / Locality *</label><input name="area" required maxlength="100" placeholder="e.g. Kota Road"></div></div><div class="fieldrow"><div class="field"><label>Property Size</label><input name="size" maxlength="60" placeholder="e.g. 1200 sq ft"></div><div class="field"><label>Expected Price ₹</label><input type="number" min="1" max="1000000000" step="1" name="askingPrice" placeholder="Optional"></div></div><div class="field"><label>Property Details</label><textarea name="description" maxlength="900" placeholder="Rooms, facilities, property features (do not include names or phone numbers)"></textarea></div><label class="special-consent"><input type="checkbox" name="confirmed" required> मैं मालिक हूँ या अधिकृत प्रतिनिधि हूँ। मेरा नाम और मोबाइल Admin सत्यापन के लिए दिया गया है।</label><label class="special-consent"><input type="checkbox" name="publicPhoneConsent"> मैं स्पष्ट सहमति देता/देती हूँ कि BARAN PRIDE Admin चाहे तो मेरा मोबाइल नंबर ऐप पर सार्वजनिक कर सकता है। यह विकल्प वैकल्पिक है; नंबर दिखाने का अंतिम निर्णय सिर्फ Admin करेगा।</label><div class="form-note">आपका नाम हमेशा छिपा रहेगा। डिफॉल्ट नंबर Customer Care 7737325205 होगा। अगर आपने ऊपर सार्वजनिक नंबर की अनुमति दी है, तब भी केवल Admin ही नंबर दिखाने का फैसला करेगा। अनुमति वापस लेने के लिए Customer Care से संपर्क करें।</div><button type="submit" class="primary-btn">${icon('check',18)} Submit to Admin</button></form></div>`}
async function submitProperty(f){const fd=new FormData(f);const data={ownerName:String(fd.get('ownerName')||'').trim(),ownerPhone:String(fd.get('ownerPhone')||'').trim(),propertyType:String(fd.get('propertyType')||'').trim(),area:String(fd.get('area')||'').trim(),size:String(fd.get('size')||'').trim(),askingPrice:Number(fd.get('askingPrice')||0),description:String(fd.get('description')||'').trim(),publicPhoneConsent:fd.get('publicPhoneConsent')==='on'};if(!validPhone(data.ownerPhone)||data.ownerName.length<3||!data.area||!data.propertyType||fd.get('confirmed')!=='on')return toast('Please complete all required fields');const btn=f.querySelector('button[type=submit]');btn.disabled=true;try{if(C.enabled){if(!C.user)throw Error('Please sign in first');await C.submitProperty(data);toast('Property request sent for Admin approval')}else toast('Demo only: connect Firebase to submit a real request');openProperties()}catch(err){toast('Unable to submit: '+err.message);btn.disabled=false}}
function cityGoBack(){if(S.page==='cityDetail'){go(S.cityBackTarget||'cityList');return true}if(S.page==='cityNews'){go('home');return true}if(S.page==='cityList'){go('home');return true}return false}
function cityShare(id){const x=S.cityItems.find(o=>o.id===id&&o.status==='published');if(!x)return;const msg=x.title+' — BARAN PRIDE\n'+(x.summary||'');if(native('shareText',msg))return;if(navigator.share)navigator.share({title:x.title,text:msg}).catch(()=>{});else if(navigator.clipboard)navigator.clipboard.writeText(msg).then(()=>toast('Information copied'))}

function render(){const pages={home,featuredBusinesses,eventsTab,aboutUs,promotionDetail,explore,allCategories:allCategoriesPage,detail,saved,owner,ownerPhotos,add:addForm,auth,profile,cityList,cityNews:cityNewsList,cityDetail,donors:donorPage,properties:propertiesPage,propertySubmit:propertySubmitPage};const fn=pages[S.page]||home;$('#app').innerHTML=fn()+bottom();startHomeSlides();startPropertyCarousel();window.scrollTo(0,0)}
function go(page){closeDrawer();if(page==='add')S.editingId=null;if(page==='explore'&&S.page!=='explore'&&S.page!=='home'){}S.page=page;render()}
async function refresh(){if(C.enabled){try{
 const [pub,own,adminCategories,homeContent]=await Promise.all([
  C.approved(),C.user?C.owned():Promise.resolve([]),C.publicCategories().catch(()=>[]),C.publicHomepageCity().catch(e=>{console.warn('Homepage content could not load',e);return []})
 ]);
 S.businesses=pub.map(x=>({...x,cover:x.cover||x.photoUrls?.[0]||''}));
 try{const publicSettings=await C.m.F.getDoc(C.m.F.doc(C.db,'appSettings','public'));const url=publicSettings.exists()?String(publicSettings.data().defaultBusinessCoverUrl||''):'';S.defaultBusinessCover=/^https:\/\//i.test(url)?url:'img/baran-pride-default-business.jpg';const settings=publicSettings.exists()?publicSettings.data():{};S.notificationSettings={enabled:settings.notificationSliderEnabled!==false,theme:settings.notificationSliderTheme||'purple',backgroundColor:settings.notificationSliderBackgroundColor||'',textColor:settings.notificationSliderTextColor||'',iconColor:settings.notificationSliderIconColor||''};S.heroImageUrl=safeHttps(settings.homeHeroImageUrl||'');S.socialLinks=settings.socialLinks||{}}catch(e){S.defaultBusinessCover='img/baran-pride-default-business.jpg';S.socialLinks={}}
 S.owned=own;S.customCategories=adminCategories;S.homeCityItems=homeContent;
 try{S.properties=await C.publicProperties()}catch(e){console.warn('Homepage properties unavailable',e);S.properties=[]}
 try{S.promotions=await C.publicPromotions();if(!S.promotionSelected||!S.promotions.some(x=>x.id===S.promotionSelected.id)){const last=localStorage.getItem('baran_promo_previous')||'';const choices=S.promotions.filter(x=>x.id!==last);const pool=choices.length?choices:S.promotions;S.promotionSelected=pool.length?pool[Math.floor(Math.random()*pool.length)]:null;if(S.promotionSelected)localStorage.setItem('baran_promo_previous',S.promotionSelected.id)}}catch(e){console.warn('Promotions unavailable',e);S.promotions=[];S.promotionSelected=null}try{S.notices=await C.publicNotices()}catch(e){console.warn('Notices not available',e);S.notices=[]}try{S.sliderMessages=await C.publicSliderMessages()}catch(e){console.warn('Slider messages unavailable',e);S.sliderMessages=[]}
 }catch(e){console.warn(e);toast('Could not load listings. Check internet.')}}else{
 S.businesses=[];S.properties=[];
 S.notificationSettings={enabled:true,theme:'purple'};S.heroImageUrl='';S.owned=cacheGet('baran_demo_owned',[]);S.customCategories=[];S.homeCityItems=[];S.promotions=[];S.promotionSelected=null;S.sliderMessages=[];
 }render();showNotice()}
async function onAuthSubmit(f){if(!C.enabled)return toast('Firebase settings not configured');let fd=new FormData(f),btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.innerHTML='<span class="loader"></span> Please wait';try{if(S.authTab==='signup')await C.signUp(fd.get('email').trim(),fd.get('password'),fd.get('name').trim(),String(fd.get('mobile')||'').trim());else await C.signIn(fd.get('email').trim(),fd.get('password'));toast('Signed in successfully');await refresh();go(S.afterAuth||'owner')}catch(e){toast(e.message.replace('Firebase: ','').slice(0,105));btn.disabled=false;render()}}
async function onBusinessSubmit(f){const fd=new FormData(f),data={};for(const k of ['name','category','area','address','phone','whatsapp','description','hours','mapUrl'])data[k]=String(fd.get(k)||'').trim();if(!/^[0-9+ -]{10,15}$/.test(data.phone))return toast('Please enter a valid phone number');const files=[...f.querySelector('[name=photos]')?.files||[]];if(files.length>2)return toast('Free listing allows maximum 2 photos');if(files.some(x=>x.size>5*1024*1024))return toast('Each photo must be 5 MB or less');const weekly={};for(const day of ['mon','tue','wed','thu','fri','sat','sun']){weekly[day]={closed:fd.get('closed_'+day)==='on',open:String(fd.get('open_'+day)||''),close:String(fd.get('close_'+day)||'')}}data.weeklyHours=weekly;if(data.mapUrl&&!/^https:\/\/(maps\.app\.goo\.gl|www\.google\.[^/]+\/maps|google\.[^/]+\/maps|maps\.google\.[^/]+\/)/i.test(data.mapUrl))return toast('Enter a valid Google Maps HTTPS link');const btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.innerHTML='<span class="loader"></span> Saving...';try{
 if(S.editingId){const old=S.owned.find(x=>x.id===S.editingId);const selected=[...new Set([data.category,...fd.getAll('extraCategory').map(x=>String(x))])];if(selected.length>(isPremium(old)?3:1))throw Error('Select maximum '+(isPremium(old)?3:1)+' categories');data.categories=selected;if(C.enabled)await C.requestEdit(S.editingId,data);else {let own=cacheGet('baran_demo_owned',[]);const idx=own.findIndex(b=>b.id===S.editingId);if(idx>=0){own[idx].pendingChange=data;localStorage.setItem('baran_demo_owned',JSON.stringify(own))}}toast('Change request sent for approval');}
 else if(C.enabled){await C.register(data,files,message=>{btn.innerHTML='<span class="loader"></span> '+escapeHtml(message)});toast('Submitted! Awaiting admin approval');}
 else{let own=cacheGet('baran_demo_owned',[]);own.unshift({...data,id:'local-'+Date.now(),status:'pending',plan:'free',planStatus:'inactive',paymentStatus:'unpaid',cover:'',demo:true});localStorage.setItem('baran_demo_owned',JSON.stringify(own));toast('Demo saved on this device (not sent to admin)');}
 S.editingId=null;await refresh();go('owner');
 }catch(e){const msg='Business registration failed: '+(e?.message||'Unknown error');console.error(msg,e);toast(msg.slice(0,180));alert(msg);btn.disabled=false;btn.textContent='Try Again'}}
// Branded password-reset dialog (avoids the WebView JavaScript prompt URL heading).
function openPasswordResetDialog(){
  document.getElementById('bp-reset-overlay')?.remove();
  if(!document.getElementById('bp-reset-style')){
    const style=document.createElement('style');style.id='bp-reset-style';
    style.textContent=`.bp-reset-overlay{position:fixed;inset:0;z-index:99999;background:#071b39a8;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box}.bp-reset-panel{width:100%;max-width:420px;background:#fff;border-radius:20px;padding:24px;box-shadow:0 20px 60px #061c4050;box-sizing:border-box;color:#102b50;font-family:inherit}.bp-reset-heading{display:flex;align-items:center;justify-content:space-between;gap:12px}.bp-reset-heading h2{margin:0;font-size:21px;color:#133e7b}.bp-reset-x{background:#edf3fc;border:0;border-radius:50%;width:34px;height:34px;font-size:23px;color:#315b92;cursor:pointer}.bp-reset-desc{font-size:13px;line-height:1.7;color:#53657c;margin:13px 0 19px}.bp-reset-label{font-size:13px;font-weight:700;display:block;margin-bottom:8px}.bp-reset-input{display:block;width:100%;box-sizing:border-box;border:1px solid #b8cce5;border-radius:11px;padding:13px 12px;font-size:15px;color:#183b66;background:#fff;outline:none}.bp-reset-input:focus{border-color:#1456b8;box-shadow:0 0 0 3px #1456b81c}.bp-reset-help{font-size:12px;line-height:1.5;color:#4c6582;background:#eff5ff;border-radius:10px;padding:11px;margin:14px 0}.bp-reset-error{font-size:12px;color:#b3261e;min-height:18px;margin:8px 0}.bp-reset-send{width:100%;background:#1456b8;color:#fff;border:0;border-radius:11px;padding:13px;font-size:15px;font-weight:700;cursor:pointer}.bp-reset-send:disabled{opacity:.65;cursor:wait}.bp-reset-cancel{display:block;margin:13px auto 0;background:transparent;border:0;color:#53657c;font-size:14px;cursor:pointer}`;
    document.head.appendChild(style);
  }
  const overlay=document.createElement('div');overlay.id='bp-reset-overlay';overlay.className='bp-reset-overlay';
  overlay.innerHTML=`<section class="bp-reset-panel" role="dialog" aria-modal="true" aria-labelledby="bp-reset-title"><div class="bp-reset-heading"><h2 id="bp-reset-title">🔒 Reset Your Password</h2><button type="button" class="bp-reset-x" data-reset-close aria-label="Close">×</button></div><p class="bp-reset-desc">अपना Registered Email Address दर्ज करें। हम आपको Password Reset Link भेजेंगे।</p><form id="bp-reset-form"><label class="bp-reset-label" for="bp-reset-email">Registered Email Address</label><input class="bp-reset-input" id="bp-reset-email" name="email" type="email" placeholder="you@example.com" autocomplete="email" required><p class="bp-reset-help">ℹ Reset Link आपके Email पर आएगा। Inbox और Spam Folder दोनों चेक करें।</p><div class="bp-reset-error" id="bp-reset-error" role="alert"></div><button class="bp-reset-send" type="submit">✉ Send Reset Link</button><button class="bp-reset-cancel" type="button" data-reset-close>Cancel</button></form></section>`;
  document.body.appendChild(overlay);
  const close=()=>overlay.remove();
  overlay.addEventListener('click',e=>{if(e.target===overlay||e.target.closest('[data-reset-close]'))close()});
  overlay.querySelector('#bp-reset-form').addEventListener('submit',async e=>{
    e.preventDefault();const email=overlay.querySelector('#bp-reset-email').value.trim();
    const error=overlay.querySelector('#bp-reset-error');const btn=overlay.querySelector('.bp-reset-send');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){error.textContent='Please enter a valid email address.';return}
    error.textContent='';btn.disabled=true;btn.textContent='Sending Reset Link...';
    try{await C.resetPassword(email);close();toast('If the email is registered, a reset link will arrive. Check Spam too.')}
    catch(err){error.textContent='Unable to send reset email. Please try again.';btn.disabled=false;btn.textContent='✉ Send Reset Link'}
  });
  overlay.querySelector('#bp-reset-email').focus();
}
$('#app').addEventListener('click',async e=>{
 const button=e.target.closest('button');if(!button)return;
 if(button.hasAttribute('data-promo-detail'))return go('promotionDetail');
 if(button.hasAttribute('data-promo-call')){const b=S.promotionSelected;if(b&&b.id===button.dataset.promoCall&&/^\+?[0-9 -]{10,16}$/.test(b.phone||''))return dialDirect(b.phone);return}
 if(button.hasAttribute('data-menu-open'))return openDrawer();
 if(button.hasAttribute('data-menu-close'))return closeDrawer();
 if(button.hasAttribute('data-city-type'))return openCity(button.dataset.cityType);
 if(button.hasAttribute('data-notice-call')){const n=S.noticeVisible;if(n&&button.dataset.noticeCall===n.phone)return dialDirect(n.phone);return}
 if(button.hasAttribute('data-notice-close'))return dismissNotice();
 if(button.dataset.special==='donors')return openDonors();
 if(button.dataset.special==='properties')return openProperties();
 if(button.hasAttribute('data-property-viewall'))return openProperties();
 if(button.hasAttribute('data-property-open'))return openProperties();
 if(button.hasAttribute('data-blood-filter')){S.donorFilter=button.dataset.bloodFilter;S.donors=shuffleDonors(S.donors);return render()}
 if(button.hasAttribute('data-blood-call')){const d=S.donors.find(x=>x.id===button.dataset.bloodCall&&x.publicConsent===true&&x.status==='published');if(d)return dialDirect(d.phone);return}
 if(button.dataset.propertyCall){const item=S.properties.find(p=>p.id===button.dataset.propertyCall);if(!item)return toast('Property is not available');const number=item.contactMode==='owner'&&validPhone(item.publicContactPhone)?item.publicContactPhone:S.helpline;return dialDirect(number)}
 if(button.hasAttribute('data-customer-care'))return S.helpline?dialDirect(S.helpline):toast('Customer Care number not configured');
 if(button.hasAttribute('data-city-retry'))return openCity(S.cityType);
 if(button.hasAttribute('data-home-viewall'))return openHomeCityList(button.dataset.homeViewall);
 if(button.hasAttribute('data-home-detail'))return homeCityDetail(button.dataset.homeDetail);
 if(button.hasAttribute('data-home-slide')){const slider=button.closest('[data-home-carousel]');if(slider)return displayHomeSlide(slider,(S.homeSlidePositions[slider.dataset.homeCarousel]||0)+Number(button.dataset.homeSlide));return}
 if(button.hasAttribute('data-home-dot')){const slider=button.closest('.home-city-block')?.querySelector('[data-home-carousel]');if(slider)return displayHomeSlide(slider,Number(button.dataset.homeDot));return}
 if(button.hasAttribute('data-contact-filter')){document.querySelectorAll('.bp-cat').forEach(b=>b.classList.toggle('active',b===button));document.querySelectorAll('.bp-contact-card').forEach(el=>{const q=(document.querySelector('#city-search')?.value||'').trim().toLowerCase();el.classList.toggle('hidden',!(button.dataset.contactFilter==='All'||el.dataset.contactCategory===button.dataset.contactFilter)||!(el.dataset.citySearch||'').includes(q))});return}
 if(button.hasAttribute('data-city-detail')){const x=S.cityItems.find(o=>o.id===button.dataset.cityDetail);if(x)S.cityType=x.type;S.cityId=button.dataset.cityDetail;S.cityBackTarget=S.page==='cityNews'?'cityNews':'cityList';return go('cityDetail')}
 if(button.hasAttribute('data-city-share'))return cityShare(button.dataset.cityShare);
 if(button.hasAttribute('data-city-map')){const x=S.cityItems.find(i=>i.id===button.dataset.cityMap);return x&&openUrl(safeHttps(x.mapUrl))}
 if(button.hasAttribute('data-city-call')){const x=S.cityItems.find(i=>i.id===button.dataset.cityCall);if(x&&x.phone){const ph=String(x.phone).replace(/[^0-9+]/g,'');if(!native('dial',ph))openUrl('tel:'+ph)}return}
 if(button.hasAttribute('data-go'))return button.dataset.go==='properties'?openProperties():button.dataset.go==='eventsTab'?openCity('events'):go(button.dataset.go);
 if(button.hasAttribute('data-back'))return cityGoBack()||(S.page==='explore'&&S.returnToCategories?(S.returnToCategories=false,go('allCategories')):go(S.page==='propertySubmit'?'properties':'home'));
 if(button.hasAttribute('data-category-view')){S.categoryView=button.dataset.categoryView==='grid'?'grid':'list';return render()}
 if(button.hasAttribute('data-all-category')){S.category=button.dataset.allCategory;S.query='';S.returnToCategories=true;return go('explore')}
 if(button.hasAttribute('data-category')){
  const category=button.dataset.category;
  if(category==='More'){S.categorySearch='';S.returnToCategories=false;return go('allCategories')}
  S.category=category;S.query='';S.returnToCategories=false;return go('explore');
 }
 if(button.hasAttribute('data-detail')){S.detail=button.dataset.detail;return go('detail')}
 if(button.hasAttribute('data-save'))return saveToggle(button.dataset.save);
 if(button.hasAttribute('data-call'))return callBusiness(button.dataset.call);
 if(button.hasAttribute('data-wa'))return whatsapp(button.dataset.wa);
 if(button.hasAttribute('data-map'))return directions(button.dataset.map);
 if(button.hasAttribute('data-share'))return share(button.dataset.share);
 if(button.hasAttribute('data-owner-photos')){S.photoBusinessId=button.dataset.ownerPhotos;return go('ownerPhotos')}
 if(button.hasAttribute('data-edit')){S.editingId=button.dataset.edit;S.page='add';return render()}
 if(button.hasAttribute('data-social')){const url=S.socialLinks?.[button.dataset.social]?.url;if(/^https:\/\//i.test(url||''))openUrl(url);return}
 if(button.hasAttribute('data-forgot-password'))return openPasswordResetDialog();
 if(button.hasAttribute('data-forgot-email')){if(!native('dial','7737325205'))openUrl('tel:7737325205');return}
 if(button.hasAttribute('data-auth-tab')){S.authTab=button.dataset.authTab;return render()}
 if(button.dataset.action==='notifications'){const n=S.notices.filter(noticeAllowed)[0];if(n){S.noticeVisible=n;return render()}return toast('No new announcements')}
 if(button.dataset.action==='logout'){await C.signOut();S.owned=[];toast('Signed out');go('profile')}
});
// Photo picker feedback: selection is visible before registration is submitted.
$('#app').addEventListener('change',e=>{
 if(!e.target.matches('input[name="photos"]'))return;
 const input=e.target, preview=$('#business-photo-preview'), hint=$('#business-photo-hint');
 if(!preview)return;
 const files=Array.from(input.files||[]);
 preview.replaceChildren();
 if(!files.length){if(hint)hint.textContent='No photo selected';return}
 if(files.length>2 || files.some(f=>!/^image\/(jpeg|png|webp)$/i.test(f.type)||f.size>=5*1024*1024)){
  input.value='';if(hint)hint.textContent='Please choose up to 2 JPG, PNG or WebP photos, each under 5 MB';toast('Invalid photo selection');return;
 }
 if(hint)hint.textContent=files.length+' photo(s) selected';
 files.forEach((file,i)=>{
  const box=document.createElement('div');
  box.style.cssText='min-width:0;border:1px solid #d7e4f4;border-radius:12px;padding:8px;background:#f7faff';
  const img=document.createElement('img');img.alt='Selected photo '+(i+1);img.style.cssText='width:100%;height:100px;object-fit:cover;border-radius:8px;display:block';
  const label=document.createElement('div');label.textContent=file.name;label.title=file.name;label.style.cssText='font-size:11px;overflow-wrap:anywhere;margin-top:5px;color:#27466c';
  const tag=document.createElement('strong');tag.textContent=i===0?'Cover Photo':'Gallery Photo';tag.style.cssText='display:block;font-size:11px;margin-top:4px;color:#185aa0';
  box.append(img,label,tag);preview.append(box);
  const reader=new FileReader();reader.onload=()=>{if(box.isConnected)img.src=reader.result};reader.onerror=()=>{label.textContent=file.name+' (preview unavailable)'};reader.readAsDataURL(file);
 });
});
$('#app').addEventListener('submit',e=>{
 if(e.target.id==='hero-form'){e.preventDefault();S.category='All';S.query=($('#hero-q')?.value||'').trim();go('explore')}
 else if(e.target.id==='business-form'){e.preventDefault();onBusinessSubmit(e.target)}
 else if(e.target.id==='owner-photo-form'){e.preventDefault();onOwnerPhotos(e.target)}
 else if(e.target.id==='auth-form'){e.preventDefault();onAuthSubmit(e.target)}
 else if(e.target.id==='property-request-form'){e.preventDefault();submitProperty(e.target)}
});
let debounce;$('#app').addEventListener('input',e=>{
 if(e.target.id==='all-categories-search'){
  S.categorySearch=e.target.value;
  let visible=0;
  document.querySelectorAll('.all-category-tile').forEach(tile=>{
   const show=(tile.dataset.categorySearch||'').includes(S.categorySearch.trim().toLocaleLowerCase());
   tile.classList.toggle('hidden',!show);if(show)visible++;
  });
  const count=$('#categories-result-count');if(count)count.textContent=visible+' categories';
  const empty=$('#category-search-empty');if(empty)empty.classList.toggle('hidden',visible!==0);
  return;
 }
 if(e.target.id==='city-search'){S.cityQuery=e.target.value;let n=0;document.querySelectorAll('.city-list-card, .bp-contact-card').forEach(el=>{let active=document.querySelector('.bp-cat.active')?.dataset.contactFilter||'All';let show=(active==='All'||el.dataset.contactCategory===active)&&(el.dataset.citySearch||'').includes(S.cityQuery.trim().toLowerCase());el.classList.toggle('hidden',!show);if(show)n++});const msg=$('#city-no-match');if(msg)msg.classList.toggle('hidden',n!==0);return}if(e.target.id==='explore-q'){const {selectionStart}=e.target;S.query=e.target.value;clearTimeout(debounce);debounce=setTimeout(()=>{let inp=$('#explore-q');const v=inp?.value;render();inp=$('#explore-q');if(inp){inp.focus();inp.value=v;inp.setSelectionRange(selectionStart,selectionStart)}},200)}});
window.BaranApp={go,render,refresh,goBack(){if(S.drawer){closeDrawer();return true}if(cityGoBack())return true;if(S.page==='propertySubmit'){go('properties');return true}if(S.page==='explore'&&S.returnToCategories){S.returnToCategories=false;go('allCategories');return true}if(S.page==='home')return false;go(S.page==='detail'?'explore':'home');return true}};
C.onUserChange=async user=>{if(C.enabled){C.user=user;await refresh()}};
render();C.init().then(()=>{preloadContacts();return refresh()});
})();
