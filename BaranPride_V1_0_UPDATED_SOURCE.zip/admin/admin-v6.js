(function(){
'use strict';
const cfg=window.BARAN_FIREBASE_CONFIG||{};
const base='https://www.gstatic.com/firebasejs/10.14.1/';
const $=(s)=>document.querySelector(s);
const h=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state={user:null,tab:'pending',biz:[],changes:[],auth:null,db:null,F:null,U:null,loading:false,modal:null,view:'business',localJobs:[],marketplaceListings:[],marketplaceFilter:'pending',jobFilter:'pending',jobEditId:null,cityContent:[],cityType:'historical',cityEdit:null,contentFilter:'',S:null,storage:null,propertyRequests:[],propertyListings:[],bloodDonors:[],customerCarePhone:'7737325205',defaultBusinessCoverUrl:'',extraTab:'requests',donorEdit:null,propertyContactEdit:null,businessCategories:[],notices:[],sliderMessages:[],sliderEditId:null,promotions:[],notificationSliderEnabled:true,notificationSliderTheme:'purple',notificationSliderBackgroundColor:'',notificationSliderTextColor:'',notificationSliderIconColor:'',homeHeroImageUrl:'',promotionEditId:null,offers:[],offerCategories:[],offerEditId:null,voiceWelcomeEnabled:true,voiceWelcomeFrequency:'daily',voiceWelcomeLanguage:'mix',voiceWelcomeMessage:'Welcome to Baran Pride! आपका अपना शहर, आपकी अपनी डायरेक्टरी।',voiceWelcomeAudioUrl:'',urgentAnnouncement:null,shutterBanner:{enabled:false,imageUrl:'',linkUrl:''},appUpdate:{enabled:false,mode:'normal',latestVersionCode:1,latestVersionName:'1.0',message:'A new version of Baran Pride is available.',playStoreUrl:''}};
function toast(msg){let x=$('#toast');x.textContent=msg;x.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>x.classList.remove('show'),3400)}

window.addEventListener('click',e=>{if(e.target.closest('[data-default-cover]')){e.preventDefault();defaultCoverPanel()}},true);
function defaultCoverPanel(){const current=state.defaultBusinessCoverUrl||'default-business.jpg';openModal('Default Business Cover Image',`<p class="label">Only businesses without a valid uploaded photo use this image. Existing owner photos take priority.</p><img src="${h(current)}" onerror="this.src='default-business.jpg'" style="width:100%;max-height:220px;object-fit:contain;border-radius:12px"><form id="default-cover-form" style="margin-top:15px"><label class="field"><span>Upload new default cover (JPG / PNG / WebP, max 5 MB)</span><input type="file" name="cover" accept="image/jpeg,image/png,image/webp" required></label><button type="submit" class="btn green">Upload & Set Default</button></form><button class="btn plain" id="reset-cover" type="button">Use Original BARAN PRIDE Cover</button>`);document.getElementById('default-cover-form').onsubmit=async e=>{e.preventDefault();const f=e.target.cover.files[0];if(!f||f.size>5*1024*1024||!['image/jpeg','image/png','image/webp'].includes(f.type))return toast('Select JPG/PNG/WebP under 5 MB');const btn=e.target.querySelector('button');btn.disabled=true;btn.textContent='Uploading...';try{const optimized=await bpOptimizeBusinessPhoto(f);const S=state.S,ref=S.ref(state.storage,'appSettings/defaultBusinessCover/'+Date.now()+'-'+optimized.name.replace(/[^a-z0-9._-]/gi,'_'));await S.uploadBytes(ref,optimized,{contentType:optimized.type});const url=await S.getDownloadURL(ref);await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{defaultBusinessCoverUrl:url,updatedAt:state.F.serverTimestamp()},{merge:true});toast('Default business image updated');await load()}catch(err){toast(err.message);btn.disabled=false;btn.textContent='Retry Upload'}};document.getElementById('reset-cover').onclick=async()=>{try{await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{defaultBusinessCoverUrl:'',updatedAt:state.F.serverTimestamp()},{merge:true});toast('Original cover restored');await load()}catch(err){toast(err.message)}}}
function login(message='Only authorized Baran Pride administrators can access this panel.'){
 $('#app').innerHTML=`<section class="center"><div class="box"><h1>BARAN PRIDE</h1><p>Private Business Approval & Manual Payments</p><p class="footnote">${h(message)}</p><form id="login"><label class="field"><span>Admin Email</span><input name="email" type="email" required autocomplete="username"></label><label class="field"><span>Password</span><input name="password" type="password" required autocomplete="current-password"></label><button class="btn" style="width:100%">Secure Sign In</button></form></div></section>`;
 $('#login').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target);let btn=$('#login button');btn.disabled=true;try{await state.U.signInWithEmailAndPassword(state.auth,f.get('email'),f.get('password'))}catch(err){toast(err.message);btn.disabled=false}}
}
const status=(s)=>`<span class="status ${h(s)}">${h((s||'pending').toUpperCase())}</span>`;
function adminBusinessCover(b){const urls=[b.cover,...(Array.isArray(b.photoUrls)?b.photoUrls:[])];return urls.find(u=>/^https:\/\//i.test(String(u||'')))||(state.defaultBusinessCoverUrl||'default-business.jpg')}
function card(b){let paid=b.paymentStatus==='paid';return `<article class="listing"><img src="${h(adminBusinessCover(b))}" onerror="this.onerror=null;this.src='default-business.jpg'" alt=""><div><h3>${h(b.name)} ${status(b.status)}</h3><p><b>${h(b.category)}</b> · ${h(b.area)} · ${h(b.phone)}</p><p>${h(b.address)}</p><p><b>Plan:</b> ${h(b.plan||'free')} · <b>Payment:</b> ${paid?'Paid ₹'+h(b.paidAmount||0):'Unpaid'} · <b>Owner UID:</b> ${h((b.ownerUid||'').slice(0,12))}…</p></div><div class="actions"><button class="btn plain small" data-view="${h(b.id)}">Details</button><button class="btn plain small" data-business-photos="${h(b.id)}">Manage Photos</button><button class="btn plain small" data-business-categories="${h(b.id)}">Categories</button>${b.plan!=='free'?`<button class="btn plain small" data-business-free="${h(b.id)}">Set Free</button>`:''}<button class="btn warn small" data-payment="${h(b.id)}">Manual Payment</button>${b.status!=='approved'?`<button class="btn green small" data-approve="${h(b.id)}">Approve</button>`:''}${b.status!=='rejected'?`<button class="btn red small" data-reject="${h(b.id)}">Reject</button>`:''}</div></article>`}
function changeCard(r){let patch=r.patch||{};let b=state.biz.find(x=>x.id===r.businessId);return `<article class="listing"><div style="font-size:33px;text-align:center">✎</div><div><h3>${h(b?.name||r.businessId)} ${status(r.status)}</h3><p>Requested Changes: ${Object.entries(patch).map(([k,v])=>'<b>'+h(k)+'</b>: '+h(v)).join(' · ')}</p></div><div class="actions">${r.status==='pending'?`<button class="btn green small" data-changeapprove="${h(r.id)}">Approve Changes</button><button class="btn red small" data-changereject="${h(r.id)}">Reject</button>`:''}</div></article>`}

 const SLIDER_THEMES=[
 ['blue','Royal Blue','#1554b4','#ffffff','#1554b4'],
 ['green','Fresh Green','#0b7656','#ffffff','#0b7656'],
 ['orange','Modern Orange','#ba4514','#ffffff','#ba4514'],
 ['purple','Premium Purple','#6539ba','#ffffff','#6539ba'],
 ['pink','Soft Pink','#f6d8ea','#7b2354','#f6d8ea'],
 ['elegant-gold','Elegant Gold','#6b4b10','#ffffff','#6b4b10'],
 ['night-blue','Night Blue','#071b39','#ffffff','#071b39'],
 ['sky','Sky Blue','#42b6db','#073b57','#42b6db'],
 ['dark-elegant','Dark Elegant','#151821','#ffffff','#151821'],
 ['red','Alert Red','#981a29','#ffffff','#981a29'],
 ['modern-teal','Modern Teal','#075e64','#ffffff','#075e64'],
 ['gradient-pro','Gradient Pro','#1644a5','#ffffff','#1644a5'],
 ['diwali','Diwali','#5b167d','#ffe599','#5b167d'],
 ['eid','Eid','#00634d','#fff3c1','#00634d'],
 ['holi','Holi','#ffb6dc','#7a1559','#ffb6dc'],
 ['independence','Independence / Republic Day','#ff9933','#122c64','#ff9933'],
 ['tiranga','Tiranga – Indian Flag','linear-gradient(180deg,#ff9933 0%,#ff9933 33.3%,#ffffff 33.3%,#ffffff 66.6%,#138808 66.6%,#138808 100%)','#122a65','#ffffff'],
 ['christmas','Christmas','#9b1735','#ffffff','#9b1735'],
 ['makar-sankranti','Makar Sankranti','#fff0d4','#8b3d0d','#fff0d4'],
 ['ganesh-chaturthi','Ganesh Chaturthi','#ad3e11','#ffffff','#ad3e11'],
 ['navratri','Navratri / Dussehra','#771b35','#ffffff','#771b35'],
 ['raksha-bandhan','Raksha Bandhan','#ba387e','#ffffff','#ba387e'],
 ['janmashtami','Janmashtami','#074c80','#fff2bd','#074c80'],
 ['guru-nanak','Guru Nanak Jayanti','#164b91','#ffffff','#164b91'],
 ['rainbow-celebration','Rainbow Celebration','#e24678','#ffffff','#e24678']
 ];

(function(){const el=document.createElement('style');el.id='bp-stylish-theme-styles';el.textContent='\n/* V4.0 illustrated notification themes: same rules in app and admin preview */\n.bp-theme-preview.bp-stylish{position:relative;isolation:isolate;overflow:hidden;background:var(--bp-notice-bg);color:var(--bp-notice-ink);box-shadow:0 3px 12px #112e5820}\n.bp-stylish:before{content:"";position:absolute;inset:0;background:var(--bp-decor);pointer-events:none;z-index:-1}\n.bp-stylish:after{content:var(--bp-art);position:absolute;right:11px;top:50%;transform:translateY(-50%);font-size:23px;opacity:.44;pointer-events:none;z-index:-1}\n.bp-stylish .bp-notification-icon,.bp-stylish .bp-preview-icon{display:grid;place-items:center;flex:0 0 31px;width:31px;height:31px;border:1.5px solid #ffffffa8;border-radius:50%;background:var(--bp-icon-bg,#1554b4);color:var(--bp-notice-accent,#fff);font-size:17px;box-shadow:0 2px 7px #0002;position:relative;z-index:1}\n.bp-stylish .bp-notification-viewport,.bp-stylish .bp-preview-message{position:relative;z-index:1;padding-right:20px}\n.bp-stylish .bp-theme-arrow{position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:23px;line-height:1;font-weight:800;color:var(--bp-notice-ink);opacity:.92;pointer-events:none;z-index:1}\n.bp-theme-preview{display:flex;align-items:center;gap:10px;min-height:57px;padding:9px 12px;border-radius:14px;box-sizing:border-box}\n.bp-theme-preview .bp-preview-message{font-weight:700;font-size:14px;line-height:1.4;overflow-wrap:anywhere;flex:1}\n.bp-stylish.bp-notification-blue{--bp-notice-bg:linear-gradient(110deg,#0a3a96,#1558d0);--bp-notice-ink:#fff;--bp-icon-bg:#0a3a96;--bp-decor:radial-gradient(circle at 86% 115%,#50a7ff66 0 17%,transparent 18%),linear-gradient(120deg,transparent 60%,#4a9bff33 100%);--bp-art:"🏰"}\n.bp-stylish.bp-notification-green{--bp-notice-bg:linear-gradient(110deg,#d6fbe8,#91edbb);--bp-notice-ink:#053d35;--bp-icon-bg:#d6fbe8;--bp-decor:radial-gradient(ellipse at 94% 100%,#19a56655 0 23%,transparent 24%),radial-gradient(ellipse at 4% 0%,#ffffff99 0 18%,transparent 19%);--bp-art:"🌿"}\n.bp-stylish.bp-notification-orange{--bp-notice-bg:linear-gradient(110deg,#ffe7bd,#ff9e29);--bp-notice-ink:#9a2600;--bp-icon-bg:#ffe7bd;--bp-decor:radial-gradient(circle at 105% -40%,#fff8 0 43%,transparent 44%),repeating-radial-gradient(circle at 98% 115%,#ffffff55 0 2px,transparent 3px 11px);--bp-art:"📣"}\n.bp-stylish.bp-notification-purple{--bp-notice-bg:linear-gradient(110deg,#5422c7,#a129ef);--bp-notice-ink:#fff;--bp-icon-bg:#5422c7;--bp-decor:repeating-radial-gradient(ellipse at 104% 140%,#ffffff24 0 2px,transparent 3px 15px);--bp-art:"🔔"}\n.bp-stylish.bp-notification-pink{--bp-notice-bg:linear-gradient(110deg,#ffd4ea,#ff8cc5);--bp-notice-ink:#991451;--bp-icon-bg:#ffd4ea;--bp-decor:radial-gradient(circle at 93% 55%,#ffeffa 0 8%,transparent 9%),radial-gradient(circle at 86% 80%,#d9488b55 0 16%,transparent 17%);--bp-art:"🌸"}\n.bp-stylish.bp-notification-elegant-gold{--bp-notice-bg:linear-gradient(110deg,#fff0bf,#f4bb4b);--bp-notice-ink:#76400c;--bp-icon-bg:#fff0bf;--bp-decor:repeating-radial-gradient(ellipse at 100% 155%,#bc8a2d55 0 2px,transparent 3px 12px);--bp-art:"★"}\n.bp-stylish.bp-notification-night-blue{--bp-notice-bg:linear-gradient(110deg,#041532,#0a438a);--bp-notice-ink:#fff;--bp-icon-bg:#041532;--bp-decor:radial-gradient(circle at 92% 10%,#fff8 0 2px,transparent 3px),radial-gradient(ellipse at 100% 110%,#e6a74255 0 17%,transparent 18%);--bp-art:"🌙"}\n.bp-stylish.bp-notification-sky{--bp-notice-bg:linear-gradient(110deg,#d5f4ff,#35aafa);--bp-notice-ink:#0c3479;--bp-icon-bg:#d5f4ff;--bp-decor:radial-gradient(ellipse at 90% 130%,#1377d3a8 0 27%,transparent 28%),radial-gradient(ellipse at 66% 150%,#ffffffa0 0 30%,transparent 31%);--bp-art:"ℹ"}\n.bp-stylish.bp-notification-dark-elegant{--bp-notice-bg:linear-gradient(110deg,#121319,#252831);--bp-notice-ink:#fff1bd;--bp-icon-bg:#121319;--bp-decor:linear-gradient(130deg,transparent 73%,#f4c55a 74%,transparent 76%),linear-gradient(130deg,transparent 79%,#d49b30 80%,transparent 81%);--bp-art:"✦"}\n.bp-stylish.bp-notification-red{--bp-notice-bg:linear-gradient(110deg,#ef122c,#ae0022);--bp-notice-ink:#fff;--bp-icon-bg:#ef122c;--bp-decor:repeating-radial-gradient(circle at 99% 80%,#ffffff24 0 1px,transparent 2px 9px);--bp-art:"❗"}\n.bp-stylish.bp-notification-modern-teal{--bp-notice-bg:linear-gradient(110deg,#d4fbff,#3dd6df);--bp-notice-ink:#073a76;--bp-icon-bg:#d4fbff;--bp-decor:repeating-radial-gradient(circle at 101% 65%,#ffffff66 0 2px,transparent 3px 15px);--bp-art:"⬡"}\n.bp-stylish.bp-notification-gradient-pro{--bp-notice-bg:linear-gradient(110deg,#008cf5,#bd25e6);--bp-notice-ink:#fff;--bp-icon-bg:#008cf5;--bp-decor:radial-gradient(ellipse at 98% 100%,#ff94aa 0 22%,transparent 23%),radial-gradient(ellipse at 0% 120%,#5239ff 0 24%,transparent 25%);--bp-art:"✨"}\n.bp-stylish.bp-notification-diwali{--bp-notice-bg:linear-gradient(110deg,#ffdc73,#9d30a8);--bp-notice-ink:#fff8d4;--bp-icon-bg:#ffdc73;--bp-decor:radial-gradient(circle at 95% 15%,#ffe57d 0 3%,transparent 4%),radial-gradient(circle at 85% 80%,#ffe57d88 0 10%,transparent 11%);--bp-art:"🪔"}\n.bp-stylish.bp-notification-eid{--bp-notice-bg:linear-gradient(110deg,#064c65,#07866c);--bp-notice-ink:#fff0bd;--bp-icon-bg:#064c65;--bp-decor:radial-gradient(circle at 90% 40%,#ffe9a4 0 10%,transparent 11%),radial-gradient(circle at 93% 34%,#07866c 0 9%,transparent 10%);--bp-art:"🌙"}\n.bp-stylish.bp-notification-holi{--bp-notice-bg:linear-gradient(110deg,#ff8bc7,#ffdb64);--bp-notice-ink:#81216b;--bp-icon-bg:#ff8bc7;--bp-decor:radial-gradient(circle at 90% 80%,#45c5f1 0 17%,transparent 18%),radial-gradient(circle at 76% 5%,#ac56e2aa 0 13%,transparent 14%);--bp-art:"🎨"}\n.bp-stylish.bp-notification-independence{--bp-notice-bg:linear-gradient(110deg,#ff9933,#138808);--bp-notice-ink:#102c6a;--bp-icon-bg:#ff9933;--bp-decor:linear-gradient(180deg,#ff9933 0 33%,#fff 33% 67%,#138808 67%);--bp-art:"🇮🇳"}\n.bp-stylish.bp-notification-christmas{--bp-notice-bg:linear-gradient(110deg,#ad1735,#135c3b);--bp-notice-ink:#fff;--bp-icon-bg:#ad1735;--bp-decor:radial-gradient(circle at 90% 25%,#ffffff 0 2%,transparent 3%),radial-gradient(circle at 80% 85%,#ffd36688 0 10%,transparent 11%);--bp-art:"🎄"}\n.bp-stylish.bp-notification-makar-sankranti{--bp-notice-bg:linear-gradient(110deg,#ffe2a2,#ffad35);--bp-notice-ink:#79350d;--bp-icon-bg:#ffe2a2;--bp-decor:linear-gradient(35deg,transparent 78%,#d65b18 79%,transparent 80%),radial-gradient(circle at 94% 35%,#fff5ca 0 14%,transparent 15%);--bp-art:"🪁"}\n.bp-stylish.bp-notification-ganesh-chaturthi{--bp-notice-bg:linear-gradient(110deg,#ffca67,#ed7421);--bp-notice-ink:#7a2e0b;--bp-icon-bg:#ffca67;--bp-decor:radial-gradient(circle at 92% 70%,#f5d763 0 18%,transparent 19%);--bp-art:"🌺"}\n.bp-stylish.bp-notification-navratri{--bp-notice-bg:linear-gradient(110deg,#8b214b,#e9982f);--bp-notice-ink:#fff;--bp-icon-bg:#8b214b;--bp-decor:repeating-conic-gradient(from 30deg at 95% 50%,#ffd46c44 0 14deg,transparent 15deg 30deg);--bp-art:"✨"}\n.bp-stylish.bp-notification-raksha-bandhan{--bp-notice-bg:linear-gradient(110deg,#ffb4db,#b86adb);--bp-notice-ink:#6b1d67;--bp-icon-bg:#ffb4db;--bp-decor:radial-gradient(circle at 90% 50%,#fff0bf 0 12%,transparent 13%);--bp-art:"🎀"}\n.bp-stylish.bp-notification-janmashtami{--bp-notice-bg:linear-gradient(110deg,#073b78,#199e9b);--bp-notice-ink:#fff4b8;--bp-icon-bg:#073b78;--bp-decor:radial-gradient(ellipse at 94% 65%,#33b3d7 0 18%,transparent 19%);--bp-art:"🦚"}\n.bp-stylish.bp-notification-guru-nanak{--bp-notice-bg:linear-gradient(110deg,#13509b,#f7a344);--bp-notice-ink:#fff;--bp-icon-bg:#13509b;--bp-decor:radial-gradient(circle at 90% 50%,#ffdf77 0 14%,transparent 15%);--bp-art:"☀"}\n.bp-stylish.bp-notification-rainbow-celebration{--bp-notice-bg:linear-gradient(110deg,#ff548f,#4a67e4);--bp-notice-ink:#fff;--bp-icon-bg:#ff548f;--bp-decor:linear-gradient(110deg,transparent 64%,#ffd85499 72%,#3bcda388 82%,#7b4be5aa 95%);--bp-art:"🎉"}\n';document.head.appendChild(el)})();
 function sliderThemePreview(theme,text){
  const t=SLIDER_THEMES.find(x=>x[0]===theme)||SLIDER_THEMES[0];
  const icons={diwali:'🪔',eid:'🌙',holi:'🎨',independence:'🇮🇳',tiranga:'🇮🇳',christmas:'🎄','makar-sankranti':'🪁','ganesh-chaturthi':'🌺',navratri:'✨','raksha-bandhan':'🎀',janmashtami:'🦚','guru-nanak':'☀','rainbow-celebration':'🎉',green:'🌿',orange:'📣',pink:'🌸','elegant-gold':'★','night-blue':'🌙',sky:'ℹ','dark-elegant':'✦',red:'❗','modern-teal':'⬡','gradient-pro':'✨'};
  const bg=state.notificationSliderBackgroundColor,textColor=state.notificationSliderTextColor,iconColor=state.notificationSliderIconColor;
  const inline=[bg?'--bp-notice-bg:'+bg:'',textColor?'--bp-notice-ink:'+textColor:'',iconColor?'--bp-notice-accent:'+iconColor:''].filter(Boolean).join(';');
  return `<div class="bp-theme-preview bp-stylish bp-notification-${t[0]}" style="${inline}"><span class="bp-preview-icon">${icons[t[0]]||'🔔'}</span><span class="bp-preview-message">${h(text||'बारां शहर की नई जानकारी यहाँ देखें')}</span><span class="bp-theme-arrow" aria-hidden="true">›</span></div>`;
 }
 function refreshSliderPreview(){const select=document.querySelector('#notification-settings-form [name=theme]'),out=document.querySelector('#slider-theme-live-preview');if(!select||!out)return;const active=state.sliderMessages.find(n=>n.active)?.text||'बारां शहर की नई जानकारी यहाँ देखें';out.innerHTML=sliderThemePreview(select.value,active);}
function noticePanel(){
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · CITY UPDATE</strong><p>In-App notices only. No push / status bar notification.</p></div><div class="admin-header-actions"><button class="btn plain" data-view-mode="business">← Business Dashboard</button><button class="btn plain" id="logout">Sign Out</button></div></header><main><h1>Notification Slider Settings</h1><section class="box"><form id="notification-settings-form"><label class="content-check"><input type="checkbox" name="enabled" ${state.notificationSliderEnabled?'checked':''}> Show Notification Slider on Homepage</label><label class="field"><span>Slider Color Theme</span><select name="theme">${SLIDER_THEMES.map(t=>[t[0],t[1]]).map(([v,n])=>`<option value="${v}" ${state.notificationSliderTheme===v?'selected':''}>${n}</option>`).join('')}</select></label><div class="formgrid"><label class="field"><span>Background Color (optional)</span><input type="color" name="backgroundColor" value="${state.notificationSliderBackgroundColor||'#164a96'}"><input type="checkbox" name="useBackgroundColor" ${state.notificationSliderBackgroundColor?'checked':''}> Override theme</label><label class="field"><span>Text Color (optional)</span><input type="color" name="textColor" value="${state.notificationSliderTextColor||'#ffffff'}"><input type="checkbox" name="useTextColor" ${state.notificationSliderTextColor?'checked':''}> Override theme</label><label class="field"><span>Icon Color (optional)</span><input type="color" name="iconColor" value="${state.notificationSliderIconColor||'#ffffff'}"><input type="checkbox" name="useIconColor" ${state.notificationSliderIconColor?'checked':''}> Override theme</label></div><div style="margin:12px 0 16px"><strong style="display:block;margin-bottom:8px">Live Design Preview</strong><div id="slider-theme-live-preview">${sliderThemePreview(state.notificationSliderTheme,state.sliderMessages.find(n=>n.active)?.text)}</div><small style="display:block;margin-top:8px;color:#65758a">Theme preview only. App animation: bottom-to-top, each message at least 5 seconds, no dots.</small></div><p class="label">Only bold message text appears. Messages slide upward; no headings or dots. Slider messages are managed separately from City Update Popups.</p><button class="btn green" type="submit">Save Slider Settings</button></form></section><h1>Notification Slider Messages</h1><section class="box"><form id="slider-message-form"><input type="hidden" name="editId" value="${h(state.sliderEditId||'')}"><label class="field"><span>Notification Text *</span><input name="text" required maxlength="220" placeholder="Write notification text here"></label><label class="content-check"><input type="checkbox" name="active" checked> Active (show in slider)</label><button class="btn green" type="submit">${state.sliderEditId?'Save Message Changes':'Add Notification'}</button>${state.sliderEditId?'<button class="btn plain" type="button" data-slider-cancel>Cancel Edit</button>':''}</form></section><h2>Saved Slider Messages</h2>${state.sliderMessages.length?`<div class="saved-table-wrap"><table class="saved-table"><thead><tr><th>#</th><th>Notification Message</th><th>Status</th><th>Actions</th></tr></thead><tbody>${state.sliderMessages.map((n,i)=>`<tr><td>${i+1}</td><td class="saved-message">${h(n.text)}</td><td>${status(n.active?'active':'inactive')}</td><td><div class="saved-table-actions"><button class="btn plain small" data-slider-edit="${h(n.id)}">Edit</button><button class="btn warn small" data-slider-toggle="${h(n.id)}">${n.active?'Turn OFF':'Turn ON'}</button><button class="btn red small" data-slider-delete="${h(n.id)}">Delete</button></div></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">No slider messages yet.</div>'}<h1>City Update Popup Manager</h1><section class="box"><form id="notice-form"><div class="formgrid"><label class="field"><span>Title *</span><input name="title" maxlength="120" required></label><label class="field"><span>Priority</span><input name="priority" type="number" value="1" min="0" max="99"></label></div><label class="field"><span>Message *</span><textarea name="message" maxlength="1500" required></textarea></label><label class="field"><span>Optional Image URL (HTTPS)</span><input name="imageUrl" type="url" placeholder="https://..."></label><label class="field"><span>Or Upload Popup Image (JPG / PNG / WebP, max 5 MB)</span><input name="imageFile" type="file" accept="image/jpeg,image/png,image/webp"></label><label class="field"><span>Optional Call Number</span><input name="phone" type="tel" maxlength="16" placeholder="e.g. 7737325205"></label><div class="formgrid"><label class="field"><span>Start Date</span><input name="startDate" type="date"></label><label class="field"><span>End Date</span><input name="endDate" type="date"></label><label class="field"><span>Show Frequency</span><select name="frequency"><option value="once">Only Once</option><option value="daily">Once Daily</option><option value="always">Every App Open</option><option value="custom">Custom Max Times</option></select></label><label class="field"><span>Custom Max Times</span><input name="maxShows" type="number" min="1" max="100" value="3"></label></div><label class="content-check"><input type="checkbox" name="active" checked> Active (publish to app)</label><button class="btn green" type="submit">Save New Popup</button></form></section><h2>Saved Popups</h2>${state.notices.length?`<div class="saved-table-wrap"><table class="saved-table"><thead><tr><th>#</th><th>Image</th><th>City Update</th><th>Schedule</th><th>Status</th><th>Actions</th></tr></thead><tbody>${state.notices.map((n,i)=>`<tr><td>${i+1}</td><td>${/^https:\/\//i.test(String(n.imageUrl||''))?`<img class="saved-popup-thumb" src="${h(n.imageUrl)}" alt="Popup image" loading="lazy">`:'—'}</td><td class="saved-message"><strong>${h(n.title)}</strong><div class="saved-popup-excerpt">${h(n.message)}</div><button class="saved-link" data-notice-view="${h(n.id)}">View Details</button></td><td><small>${h(n.startDate||'Any date')} – ${h(n.endDate||'Any date')}</small><div><small>${h(n.frequency||'once')}</small></div></td><td>${status(n.active?'active':'inactive')}</td><td><div class="saved-table-actions"><button class="btn warn small" data-notice-toggle="${h(n.id)}">${n.active?'Turn OFF':'Turn ON'}</button><button class="btn red small" data-notice-delete="${h(n.id)}">Delete</button></div></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">No popups yet.</div>'}</main>`;
 $('#logout').onclick=()=>state.U.signOut(state.auth);
}

// Client-side optimization. Never uploads the uncompressed original on successful conversion.
async function bpOptimizeBusinessPhoto(file){
 if(!file || !/^image\/(jpeg|png|webp)$/i.test(file.type))throw Error('Please choose JPG, PNG or WebP');
 if(file.size>5*1024*1024)throw Error('Business photo must be under 5 MB');
 if(typeof createImageBitmap!=='function')throw Error('This browser does not support WebP optimisation');
 let bitmap;try{bitmap=await createImageBitmap(file)}catch(e){throw Error('Could not decode image for WebP compression')}
 try{
  const ratio=Math.min(1,1200/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*ratio));canvas.height=Math.max(1,Math.round(bitmap.height*ratio));
  canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);
  let blob=null;
  for(const quality of [.82,.78,.73,.67,.60]){
   const next=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',quality));
   if(!next||next.type!=='image/webp')throw Error('WebP conversion unavailable');
   if(!blob||next.size<blob.size)blob=next;
   if(next.size<=250*1024)break;
  }
  if(!blob)throw Error('WebP conversion failed');
  if(file.type==='image/webp' && file.size<=blob.size)return file;
  return new File([blob],String(file.name||'photo').replace(/\.[^.]+$/,'')+'.webp',{type:'image/webp',lastModified:Date.now()});
 }finally{bitmap.close?.()}
}

async function saveSliderMessage(form){const fd=new FormData(form),text=String(fd.get('text')||'').trim(),id=String(fd.get('editId')||'');if(!text)return toast('Enter notification text');try{const F=state.F,data={text,active:fd.get('active')==='on',updatedAt:F.serverTimestamp()};if(id)await F.updateDoc(F.doc(state.db,'notificationSliderMessages',id),data);else await F.addDoc(F.collection(state.db,'notificationSliderMessages'),{...data,createdAt:F.serverTimestamp()});state.sliderEditId=null;toast('Slider message saved');await load()}catch(e){toast(e.message)}}
async function saveNotice(form){
 const fd=new FormData(form),F=state.F;
 const startDate=String(fd.get('startDate')||''),endDate=String(fd.get('endDate')||'');
 if(startDate&&endDate&&endDate<startDate)return toast('End date cannot be before start date');
 let imageUrl=String(fd.get('imageUrl')||'').trim();
 if(imageUrl&&!/^https:\/\//i.test(imageUrl))return toast('Image URL must be HTTPS');
 const phone=String(fd.get('phone')||'').trim();
 if(phone&&!/^\+?[0-9 -]{10,16}$/.test(phone))return toast('Enter a valid call number');
 const btn=form.querySelector('[type=submit]');btn.disabled=true;
 try{
  const file=form.elements.imageFile?.files?.[0];
  if(file)imageUrl=await uploadHomepageImage(file,'city-updates');
  await F.addDoc(F.collection(state.db,'appNotices'),{
   title:String(fd.get('title')||'').trim(),message:String(fd.get('message')||'').trim(),imageUrl,phone,
   startDate,endDate,frequency:String(fd.get('frequency')||'once'),
   maxShows:Math.max(1,Math.min(100,Number(fd.get('maxShows'))||1)),
   priority:Math.max(0,Math.min(99,Number(fd.get('priority'))||0)),
   active:fd.get('active')==='on',createdAt:F.serverTimestamp()
  });
  toast('City Update Popup saved');await load();
 }catch(e){toast('Popup save failed: '+e.message);btn.disabled=false}
}

let bpBannerTab='promo';
function bpArrangeBannerTabs(){
 const main=document.querySelector('#app main');if(!main)return;
 const nodes=Array.from(main.children);const titles=nodes.filter(n=>n.tagName==='H1');if(titles.length!==3)return;
 const tabs=document.createElement('nav');tabs.className='bp-banner-tabs';tabs.setAttribute('aria-label','Banner management tabs');
 const labels=[['promo','Promotional Banners'],['hero','Hero Image'],['shutter','Shutter Reveal']];
 tabs.innerHTML=labels.map(([key,label])=>`<button type="button" class="bp-banner-tab ${bpBannerTab===key?'active':''}" data-banner-tab="${key}" aria-pressed="${bpBannerTab===key}">${label}</button>`).join('');
 const groups={shutter:document.createElement('section'),hero:document.createElement('section'),promo:document.createElement('section')};
 for(const [key,el] of Object.entries(groups)){el.className='bp-banner-pane';el.dataset.bannerPane=key;el.hidden=bpBannerTab!==key}
 let current=null;
 for(const node of nodes){if(node===titles[0])current='shutter';else if(node===titles[1])current='hero';else if(node===titles[2])current='promo';if(current)groups[current].appendChild(node)}
 main.prepend(tabs);for(const key of ['promo','hero','shutter'])main.appendChild(groups[key]);
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-banner-tab]');if(!b)return;bpBannerTab=b.dataset.bannerTab;document.querySelectorAll('[data-banner-pane]').forEach(p=>p.hidden=p.dataset.bannerPane!==bpBannerTab);document.querySelectorAll('[data-banner-tab]').forEach(t=>{const on=t.dataset.bannerTab===bpBannerTab;t.classList.toggle('active',on);t.setAttribute('aria-pressed',String(on))})});
function promotionsPanel(){
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Homepage Promotional Banners</p></div><button class="btn plain" data-view-mode="business">← Dashboard</button></header><main><h1>Separate Shutter Reveal Banner</h1><section class="box"><p class="label">Independent from Promotional Banners. Upload an image, enable it, and optionally set an HTTPS click link. Currently shown on each Homepage render; frequency controls will be decided later.</p><form id="shutter-banner-form" style="max-width:680px"><label class="content-check"><input type="checkbox" name="enabled" ${state.shutterBanner.enabled?'checked':''}> Enable Shutter Banner</label>${validHttps(state.shutterBanner.imageUrl)?`<img src="${h(state.shutterBanner.imageUrl)}" alt="Current shutter banner" style="display:block;width:100%;max-height:230px;object-fit:contain;border-radius:12px;margin:12px 0">`:''}<label class="field"><span>Upload / Replace Image (JPG, PNG, WebP, under 5 MB)</span><input name="imageFile" type="file" accept="image/jpeg,image/png,image/webp"></label><label class="field"><span>Optional Banner Link (HTTPS)</span><input name="linkUrl" type="url" placeholder="https://example.com" value="${h(state.shutterBanner.linkUrl||'')}"></label><div id="shutter-local-preview"></div><button type="button" class="btn plain" data-shutter-preview>Preview Selected Image</button> <button class="btn green" type="submit">Save Shutter Banner</button></form></section><h1>Homepage Hero Image</h1><section class="box"><p class="label">Replace the existing homepage hero background image. Leave unchanged to keep the current image.</p>${state.homeHeroImageUrl?`<img src="${h(state.homeHeroImageUrl)}" style="width:100%;max-height:160px;object-fit:cover;border-radius:10px" alt="Current hero">`:''}<form id="hero-image-form"><label class="field"><span>Upload New Hero Image (JPG / PNG / WebP, max 5 MB)</span><input type="file" name="imageFile" accept="image/jpeg,image/png,image/webp" required></label><button class="btn green" type="submit">Upload / Replace Hero Image</button><button class="btn plain" type="button" data-hero-reset>Use Original Hero Image</button></form></section><h1>Homepage Promotional Banners</h1><p class="label">Only one active banner appears in the app per launch. Add multiple active banners for rotation.</p><form id="promotion-form" class="box" style="max-width:680px"><input type="hidden" name="editId" value="${h(state.promotionEditId||'')}"><label class="field"><span>Banner Title *</span><input name="title" required maxlength="120"></label><label class="field"><span>Banner Image URL (HTTPS) — optional if uploading</span><input name="imageUrl" type="url" placeholder="https://..."></label><label class="field"><span>Upload / Replace Banner Image (JPG, PNG, WebP up to 5 MB)</span><input name="imageFile" type="file" accept="image/jpeg,image/png,image/webp"></label><label class="field"><span>Banner Click Action</span><select name="linkType"><option value="none">No Link (Open Banner Details)</option>${[['section','Open App Section'],['detail','Open Specific Detail'],['external','Open External Website']].map(([v,n])=>`<option value="${v}">${n}</option>`).join('')}</select></label><label class="field"><span>Section / Detail Type</span><select name="linkSection">${[['offersAll','Deals & Offers'],['jobs','Local Jobs'],['properties','Buy/Sell Property'],['events','Events & Festivals'],['tourist','Tourist Places'],['historical','Historical Places'],['contacts','Important Contacts'],['updates','City Updates'],['blogs','Blogs & Articles'],['about','About Baran'],['donors','Blood Donors'],['donate','Donate Us'],['aboutUs','About Us'],['featured','Featured Businesses'],['categories','Business Categories'],['business','Business Directory']].map(([v,n])=>`<option value="${v}">${n}</option>`).join('')}</select></label><label class="field"><span>Choose Published Listing / Page (Specific Detail)</span><input type="search" id="bp-banner-search" autocomplete="off" placeholder="Search listing by name or title..." style="margin-bottom:8px" aria-label="Search published listings"><select name="linkId" id="bp-banner-record"><option value="">Choose a section first</option></select><small id="bp-banner-search-count"></small><small>Search and choose from published records. For a standalone page, use Open App Section.</small></label><label class="field"><span>External HTTPS URL (only for External Website)</span><input name="linkUrl" type="url" placeholder="https://example.com"></label><label class="field"><span>Detail Description</span><textarea name="description" maxlength="2000"></textarea></label><label class="field"><span>Call Number (optional)</span><input name="phone" type="tel" maxlength="16" placeholder="10 digit number"></label><label class="content-check"><input name="active" type="checkbox" checked> Show on Homepage</label><button class="btn green" type="submit">${state.promotionEditId?'Save Banner Changes':'Add Banner'}</button>${state.promotionEditId?'<button class="btn plain" type="button" data-promotion-cancel>Cancel Edit</button>':''}</form><h2>Saved Banners</h2>${state.promotions.map(b=>`<article class="listing"><div>${validHttps(b.imageUrl)?`<img src="${h(validHttps(b.imageUrl))}" alt="" style="width:150px;max-height:90px;object-fit:cover;border-radius:8px">`:''}<h3>${h(b.title)}</h3><p>${h(b.description||'')}</p><p>${h(b.phone||'No call number')} · ${b.active?'ON':'OFF'}</p></div><div class="actions"><button class="btn plain small" data-promotion-edit="${h(b.id)}">Edit / Replace</button><button class="btn plain small" data-promotion-toggle="${h(b.id)}">${b.active?'Turn OFF':'Turn ON'}</button><button class="btn red small" data-promotion-delete="${h(b.id)}">Delete</button></div></article>`).join('')||'<div class="empty">No banners yet.</div>'}</main>`;
 bpArrangeBannerTabs();
 const form=document.getElementById('promotion-form');
 if(form)bpBannerRecordOptions(form);
}
async function saveShutterBanner(form){const btn=form.querySelector('[type=submit]'),file=form.elements.imageFile.files[0];let imageUrl=state.shutterBanner.imageUrl||'';const linkUrl=String(form.elements.linkUrl.value||'').trim();if(linkUrl&&!validHttps(linkUrl))return toast('Link must be HTTPS');if(form.elements.enabled.checked&&!file&&!validHttps(imageUrl))return toast('Upload an image before enabling the Shutter Banner');btn.disabled=true;try{if(file)imageUrl=await uploadHomepageImage(file,'shutter');const shutterBanner={enabled:form.elements.enabled.checked,imageUrl,linkUrl};await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{shutterBanner,updatedAt:state.F.serverTimestamp()},{merge:true});toast('Shutter Banner saved');await load()}catch(err){toast('Shutter Banner save failed: '+err.message);btn.disabled=false}}
async function uploadHomepageImage(file,folder){
 if(!file||file.size>5*1024*1024||!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('Select JPG/PNG/WebP image under 5 MB');
 const name=Date.now()+'-'+Math.random().toString(36).slice(2)+'.'+(file.type==='image/png'?'png':file.type==='image/webp'?'webp':'jpg');
 const ref=state.S.ref(state.storage,'homepage/'+folder+'/'+name);
 await state.S.uploadBytes(ref,file,{contentType:file.type});return state.S.getDownloadURL(ref);
}
function bpBannerRecordOptions(form, selected=''){
 const section=String(form.elements.linkSection.value||''), select=form.elements.linkId;
 if(!select)return;
 const cityTypes=['events','tourist','historical','contacts','updates','blogs','about'];
 let items=[];
 if(cityTypes.includes(section))items=state.cityContent.filter(x=>x.type===section&&x.status==='published');
 else if(section==='business'||section==='featured')items=state.biz.filter(x=>x.status==='approved'&&(section!=='featured'||x.featured===true||x.isFeatured===true));
 else if(section==='offersAll')items=state.offers.filter(x=>x.status==='published');
 else if(section==='properties')items=state.propertyListings.filter(x=>x.status==='approved');
 else if(section==='jobs')items=(state.localJobs||[]).filter(x=>x.status==='approved'&&x.active===true);
 else if(section==='categories')items=(state.businessCategories||[]).map(x=>({...x,title:x.name||x.title||x.category}));
 // Standalone sections and donor/contact pages remain available as section links.
 select._bpAllOptions=null;
 select.innerHTML='<option value="">'+(items.length?'Select published listing':'No individual records — use Open App Section')+'</option>'+items.map(x=>'<option value="'+h(x.id)+'">'+h(x.title||x.name||x.company||x.businessName||x.propertyName||x.category||x.id)+'</option>').join('');
 if(selected)select.value=selected;
 const search=form.querySelector('#bp-banner-search');
 if(search){search.value='';search.disabled=!items.length;search.placeholder=items.length?'Search '+items.length+' listings by name...':'No searchable listings in this section';}
 const count=form.querySelector('#bp-banner-search-count');
 if(count)count.textContent=items.length+' published listings available';
 select.size=1;
}
function bpFilterBannerRecords(form){
 const select=form.elements.linkId, search=form.querySelector('#bp-banner-search');
 if(!select||!search)return;
 const query=search.value.trim().toLocaleLowerCase();
 // Filter existing loaded options without changing their document IDs.
 const all=Array.from(select.options).slice(1);
 let visible=0;
 for(const opt of all){const match=!query||opt.textContent.toLocaleLowerCase().includes(query);opt.hidden=!match;if(match)visible++;}
 // Browser native selects may ignore option.hidden; rebuild from a retained full list.
 if(!select._bpAllOptions)select._bpAllOptions=all.map(o=>({value:o.value,text:o.textContent}));
 const matches=select._bpAllOptions.filter(o=>!query||o.text.toLocaleLowerCase().includes(query));
 const current=select.value;
 select.innerHTML='<option value="">'+(matches.length?'Select matching listing':'No matching listing')+'</option>'+matches.map(o=>'<option value="'+h(o.value)+'">'+h(o.text)+'</option>').join('');
 if(matches.some(o=>o.value===current))select.value=current;
 select.size=query?Math.min(6,Math.max(2,matches.length+1)):1;
 const count=form.querySelector('#bp-banner-search-count');if(count)count.textContent=matches.length+' matching of '+select._bpAllOptions.length+' published listings';
}

async function savePromotion(form){const fd=new FormData(form),F=state.F,id=String(fd.get('editId')||''),old=state.promotions.find(x=>x.id===id);let imageUrl=validHttps(String(fd.get('imageUrl')||''))||old?.imageUrl||'',phone=String(fd.get('phone')||'').trim();if(phone&&!/^\+?[0-9 -]{10,16}$/.test(phone))return toast('Invalid call number');const btn=form.querySelector('[type=submit]');btn.disabled=true;try{const file=form.elements.imageFile?.files?.[0];if(file)imageUrl=await uploadHomepageImage(file,'promotions');if(!imageUrl)throw Error('Upload a banner image or provide an HTTPS image URL');const linkType=String(fd.get('linkType')||'none'),linkSection=String(fd.get('linkSection')||'offersAll'),linkId=String(fd.get('linkId')||'').trim(),linkUrl=String(fd.get('linkUrl')||'').trim();if(linkType==='external'&&!validHttps(linkUrl))throw Error('External banner link must be HTTPS');if(linkType==='detail'&&!linkId)throw Error('Select a published listing, or choose Open App Section');const data={linkType,linkSection,linkId,linkUrl:linkType==='external'?validHttps(linkUrl):'',title:String(fd.get('title')||'').trim(),imageUrl,description:String(fd.get('description')||'').trim(),phone,active:fd.get('active')==='on',updatedAt:F.serverTimestamp()};if(id&&old)await F.updateDoc(F.doc(state.db,'homePromotions',id),data);else await F.addDoc(F.collection(state.db,'homePromotions'),{...data,createdAt:F.serverTimestamp()});state.promotionEditId=null;toast('Banner saved');await load()}catch(e){toast('Banner save failed: '+e.message);btn.disabled=false}}
async function saveNotificationSettings(form){const fd=new FormData(form),theme=String(fd.get('theme')||'purple');if(!SLIDER_THEMES.some(t=>t[0]===theme))return;try{await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{notificationSliderEnabled:fd.get('enabled')==='on',notificationSliderTheme:theme,notificationSliderBackgroundColor:fd.get('useBackgroundColor')==='on'?String(fd.get('backgroundColor')):'',notificationSliderTextColor:fd.get('useTextColor')==='on'?String(fd.get('textColor')):'',notificationSliderIconColor:fd.get('useIconColor')==='on'?String(fd.get('iconColor')):''},{merge:true});toast('Slider settings saved');await load()}catch(e){toast(e.message)}}
async function saveHeroImage(form){const file=form.elements.imageFile?.files?.[0],btn=form.querySelector('[type=submit]');btn.disabled=true;try{const url=await uploadHomepageImage(file,'hero');await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{homeHeroImageUrl:url},{merge:true});toast('Homepage hero image updated');await load()}catch(e){toast(e.message);btn.disabled=false}}

function socialPanel(){const social=state.socialLinks||{};$('#app').innerHTML=`<header><strong>BARAN PRIDE · SOCIAL MEDIA</strong><button class="btn plain" data-view-mode="business">← Dashboard</button></header><main><h1>Side Menu Social Links</h1><p class="label">Only enabled, valid HTTPS links appear in the Android drawer. WhatsApp link example: https://wa.me/917737325205</p><form id="social-settings-form" class="box">${['instagram','facebook','youtube','whatsapp'].map(key=>`<label class="field"><span>${key.toUpperCase()} URL</span><input name="${key}" type="url" placeholder="https://..." value="${h(social[key]?.url||'')}"></label><label class="content-check"><input type="checkbox" name="${key}Enabled" ${social[key]?.enabled?'checked':''}> Show ${key}</label>`).join('')}<button class="btn green" type="submit">Save Social Settings</button></form></main>`}
function urgentAnnouncementPanel(){const a=state.urgentAnnouncement||{};$('#app').innerHTML=`<header><div><strong>BARAN PRIDE · URGENT ANNOUNCEMENT</strong><p>Admin-only setup; Android playback is a separate update</p></div><button class="btn plain" data-view-mode="business">← Dashboard</button></header><main><h1>Urgent Voice Announcement</h1><p class="label">One active announcement at a time. Each new announcement gets a new ID for once-per-user playback in a future Android update.</p><section class="box"><form id="urgent-announcement-form"><label class="content-check"><input type="checkbox" name="enabled" ${a.enabled?'checked':''}> Announcement Active</label><label class="field"><span>Announcement text *</span><textarea name="message" required maxlength="500" minlength="3">${h(a.message||'')}</textarea></label><div class="formgrid"><label class="field"><span>Voice method</span><select name="method"><option value="tts" ${a.method!=='audio'?'selected':''}>Text to Speech</option><option value="audio" ${a.method==='audio'?'selected':''}>Uploaded Audio</option></select></label><label class="field"><span>Expiry date (local, end of day)</span><input type="date" name="expiresOn" value="${h(a.expiresOn||'')}"></label></div><label class="field"><span>Upload audio (MP3/M4A/WAV, max 10 MB)</span><input type="file" name="voiceFile" accept=".mp3,.m4a,.wav,audio/mpeg,audio/mp4,audio/wav"></label>${a.audioUrl?`<audio controls preload="none" src="${h(a.audioUrl)}" style="width:100%"></audio>`:''}<p class="label">Playback frequency: once per user per announcement. Android playback is not included in this step.</p><button type="submit" class="btn green">Save Announcement</button><button type="button" id="urgent-deactivate" class="btn plain">Deactivate</button></form></section></main>`;$('#urgent-deactivate').onclick=async()=>{if(!confirm('Deactivate announcement?'))return;try{await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{urgentAnnouncement:{...a,enabled:false,updatedAt:new Date().toISOString()}},{merge:true});toast('Announcement deactivated');await load();state.view='urgent';panel()}catch(e){toast(e.message)}}}
async function saveUrgentAnnouncement(form){const f=new FormData(form),message=String(f.get('message')||'').trim(),method=String(f.get('method')||'tts'),expiresOn=String(f.get('expiresOn')||'');if(message.length<3||message.length>500)return toast('Text must be 3–500 characters');if(!['tts','audio'].includes(method))return toast('Invalid voice method');if(expiresOn&&!/^\d{4}-\d{2}-\d{2}$/.test(expiresOn))return toast('Invalid expiry date');if(expiresOn&&expiresOn<new Date().toLocaleDateString('en-CA'))return toast('Expiry cannot be in the past');const btn=form.querySelector('[type=submit]');btn.disabled=true;try{const old=state.urgentAnnouncement||{};let audioUrl=old.audioUrl||'';const file=form.elements.voiceFile.files[0];if(file){const ext=file.name.split('.').pop().toLowerCase();if(!['mp3','m4a','wav'].includes(ext)||!file.size||file.size>10*1024*1024)throw Error('Use MP3, M4A or WAV, max 10 MB');const ref=state.S.ref(state.storage,'appSettings/urgentAnnouncements/'+Date.now()+'-'+Math.random().toString(36).slice(2)+'.'+ext);await state.S.uploadBytes(ref,file,{contentType:{mp3:'audio/mpeg',m4a:'audio/mp4',wav:'audio/wav'}[ext]});audioUrl=await state.S.getDownloadURL(ref)}if(method==='audio'&&!audioUrl)throw Error('Upload an audio file first');const a={id:'urgent-'+Date.now()+'-'+Math.random().toString(36).slice(2,8),enabled:f.get('enabled')==='on',message,method,audioUrl,expiresOn,frequency:'once',updatedAt:new Date().toISOString()};await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{urgentAnnouncement:a},{merge:true});toast('Announcement saved (Admin only)');await load();state.view='urgent';panel()}catch(e){toast('Could not save announcement: '+e.message);btn.disabled=false}}
function voiceWelcomePanel(){$('#app').innerHTML=`<header><div><strong>BARAN PRIDE · VOICE WELCOME</strong><p>Welcome voice settings for the Android app</p></div><button class="btn plain" data-view-mode="business">← Dashboard</button></header><main><h1>Voice Welcome Settings</h1><p class="label">This step saves the Admin Panel settings only. Android playback will be implemented and tested as a separate step after you approve this panel.</p><section class="box"><form id="voice-welcome-form"><label class="content-check"><input type="checkbox" name="enabled" ${state.voiceWelcomeEnabled?'checked':''}> Enable Welcome Voice</label><label class="field"><span>Welcome Message *</span><textarea name="message" required minlength="3" maxlength="300">${h(state.voiceWelcomeMessage)}</textarea></label><div class="formgrid"><label class="field"><span>Language</span><select name="language"><option value="hi" ${state.voiceWelcomeLanguage==='hi'?'selected':''}>Hindi</option><option value="en" ${state.voiceWelcomeLanguage==='en'?'selected':''}>English</option><option value="mix" ${state.voiceWelcomeLanguage==='mix'?'selected':''}>Hindi + English</option></select></label><label class="field"><span>Playback Frequency</span><select name="frequency"><option value="every" ${state.voiceWelcomeFrequency==='every'?'selected':''}>Every app open</option><option value="daily" ${state.voiceWelcomeFrequency==='daily'?'selected':''}>Once per day</option><option value="3days" ${state.voiceWelcomeFrequency==='3days'?'selected':''}>Once every 3 days</option><option value="7days" ${state.voiceWelcomeFrequency==='7days'?'selected':''}>Once every 7 days</option></select></label></div><div class="box" style="background:#f2f7ff;box-shadow:none;margin:14px 0"><strong>Current Preview</strong><p id="voice-welcome-preview" style="margin-bottom:0;white-space:pre-wrap">${h(state.voiceWelcomeMessage)}</p></div><label class="field"><span>Upload Welcome Voice (MP3 / M4A / WAV, max 10 MB)</span><input type="file" name="voiceFile" accept=".mp3,.m4a,.wav,audio/mpeg,audio/mp4,audio/x-m4a,audio/wav,audio/x-wav"></label>${state.voiceWelcomeAudioUrl?`<audio controls preload="none" src="${h(state.voiceWelcomeAudioUrl)}" style="width:100%;margin:10px 0"></audio><p class="label">Uploaded audio is active. Upload another file to replace it.</p><button class="btn plain" type="button" id="voice-remove-audio">Remove Uploaded Voice (Use Text-to-Speech)</button>`:`<p class="label">No uploaded audio. Android will use Text-to-Speech.</p>`}<button class="btn green" type="submit">Save Voice Welcome Settings</button></form></section><p class="footnote">Frequency and message are saved in the existing appSettings/public document using merge, so other app settings remain unchanged. The app will not speak until the separate Android playback step is implemented.</p></main>`;const form=$('#voice-welcome-form');form.elements.message.addEventListener('input',()=>{$('#voice-welcome-preview').textContent=form.elements.message.value});const remove=$('#voice-remove-audio');if(remove)remove.onclick=async()=>{if(!confirm('Remove uploaded welcome voice and use Text-to-Speech?'))return;remove.disabled=true;try{await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{voiceWelcomeAudioUrl:'',voiceWelcomeUpdatedAt:state.F.serverTimestamp()},{merge:true});toast('Uploaded voice removed');await load();state.view='voice';panel()}catch(e){toast(e.message);remove.disabled=false}}}
async function saveVoiceWelcomeSettings(form){const fd=new FormData(form),message=String(fd.get('message')||'').trim(),frequency=String(fd.get('frequency')||'daily'),language=String(fd.get('language')||'mix');if(message.length<3||message.length>300)return toast('Welcome message must be 3–300 characters');if(!['every','daily','3days','7days'].includes(frequency)||!['hi','en','mix'].includes(language))return toast('Please choose valid voice settings');const btn=form.querySelector('[type=submit]');btn.disabled=true;try{let audioUrl=state.voiceWelcomeAudioUrl;const file=form.elements.voiceFile?.files?.[0];if(file){const ext=file.name.split('.').pop().toLowerCase();if(!['mp3','m4a','wav'].includes(ext)||file.size>10*1024*1024||!file.size)throw Error('Choose MP3, M4A or WAV under 10 MB');const types={mp3:'audio/mpeg',m4a:'audio/mp4',wav:'audio/wav'};const ref=state.S.ref(state.storage,'appSettings/voiceWelcome/'+Date.now()+'-'+Math.random().toString(36).slice(2)+'.'+ext);await state.S.uploadBytes(ref,file,{contentType:types[ext]});audioUrl=await state.S.getDownloadURL(ref)}await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{voiceWelcomeAudioUrl:audioUrl,voiceWelcomeEnabled:fd.get('enabled')==='on',voiceWelcomeFrequency:frequency,voiceWelcomeLanguage:language,voiceWelcomeMessage:message,voiceWelcomeUpdatedAt:state.F.serverTimestamp()},{merge:true});toast('Voice Welcome settings saved');await load();state.view='voice';panel()}catch(err){toast('Could not save voice settings: '+err.message);btn.disabled=false}}
function usersPanel(){const users=state.userProfiles||[];$('#app').innerHTML=`<header><strong>BARAN PRIDE · USER RECOVERY</strong><button class="btn plain" data-view-mode="business">← Dashboard</button></header><main><h1>User Management & Account Recovery</h1><p class="label">Only verified admins can initiate recovery. Never ask users for passwords or OTPs. Verify identity independently before assisting. Old passwords are not visible.</p><input id="user-filter" placeholder="Search name, email or mobile" style="padding:12px;width:100%;max-width:460px"><section id="user-results">${users.map(u=>`<div class="listing bp-user-row" data-user-search="${h([u.name,u.email,u.mobile].join(' ').toLowerCase())}"><div><strong>${h(u.name)}</strong><p>${h(u.email)}</p><p>Mobile: ${h(u.mobile)}</p></div><div class="actions"><button class="btn plain small" data-recovery-reset="${h(u.id)}">Send Reset Email</button><button class="btn small" data-recovery-password="${h(u.id)}">Set New Password</button><button class="btn warn small" data-recovery-email="${h(u.id)}">Lost Email Access</button></div></div>`).join('')||'<p>No new user profiles yet. Older Firebase Auth accounts may not have profiles.</p>'}</section><h2>Recovery Activity Log</h2><p class="label">Admin-only audit records, newest first.</p><section>${(state.recoveryLogs||[]).map(x=>`<div class="listing"><div><strong>${h(x.action||'Recovery')}</strong><p>Account: ${h(x.targetEmail||x.uid||'')}</p><p>Admin UID: ${h(x.adminUid||'')}</p><p>${h(x.createdAt?.toDate?.()?.toLocaleString?.()||'')}</p></div></div>`).join('')||'<p>No recovery actions recorded.</p>'}</section></main>${state.modal||''}`}
async function recoveryAudit(action,user){await state.F.addDoc(state.F.collection(state.db,'accountRecoveryLogs'),{action,uid:user.id,targetEmail:String(user.email||''),adminUid:state.user.uid,createdAt:state.F.serverTimestamp()})}
async function sendRecoveryReset(uid){const user=(state.userProfiles||[]).find(x=>x.id===uid);if(!user?.email)return toast('User email missing');if(!confirm('Verify user identity first. Send password reset email to '+user.email+'?'))return;try{await state.U.sendPasswordResetEmail(state.auth,user.email);await recoveryAudit('password_reset_email_requested',user);toast('Password reset email requested. Ask user to check inbox/spam.');await load()}catch(err){toast('Reset failed: '+err.message)}}
async function changeRecoveryEmail(uid){const user=(state.userProfiles||[]).find(x=>x.id===uid);if(!user)return;openModal('Secure Email Recovery',`<p class="label">Only use after independent identity verification. The server must be deployed separately (Firebase Functions / Blaze). This updates the Firebase Auth email, keeps the same UID/business ownership, and revokes old sessions.</p><form id="recovery-email-form"><input type="hidden" name="uid" value="${h(uid)}"><label class="field"><span>Current email</span><input value="${h(user.email||'')}" disabled></label><label class="field"><span>New email (user-controlled)</span><input name="newEmail" type="email" required autocomplete="off"></label><label class="field"><span>Identity verification reference / notes (min 12 characters)</span><textarea name="verificationNote" required minlength="12" maxlength="500" placeholder="Document verification or recorded support ticket reference. Never enter passwords or OTPs."></textarea></label><label class="content-check"><input type="checkbox" name="verified" required> I independently verified the account owner and obtained authorization</label><button class="btn warn" type="submit">Change Account Email</button></form>`)}
function changeRecoveryPassword(uid){
 const user=(state.userProfiles||[]).find(x=>x.id===uid);if(!user)return toast('User not found');
 openModal('Set New Password — '+(user.name||user.email||'User'),`<p class="label">Only after independently verifying the account owner and receiving authorization. This updates Firebase Authentication and revokes previous sessions. Passwords are never saved to Firestore.</p><form id="recovery-password-form" autocomplete="off"><input type="hidden" name="uid" value="${h(uid)}"><label class="field"><span>User email</span><input value="${h(user.email||'')}" disabled></label><label class="field"><span>New Password (minimum 8 characters)</span><input name="newPassword" type="password" minlength="8" maxlength="128" autocomplete="new-password" required></label><label class="field"><span>Confirm New Password</span><input name="confirmPassword" type="password" minlength="8" maxlength="128" autocomplete="new-password" required></label><label class="field"><span>Identity verification / authorization reference (min 12 characters)</span><textarea name="verificationNote" minlength="12" maxlength="500" required placeholder="Support ticket or verified authorization reference; never enter an OTP or password here"></textarea></label><label class="content-check"><input name="verified" type="checkbox" required> I independently verified the user and obtained authorization</label><button class="btn warn" type="submit">Update User Password</button></form>`);
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-recovery-password]');if(b){e.preventDefault();changeRecoveryPassword(b.dataset.recoveryPassword)}});
document.addEventListener('submit',async e=>{if(e.target.id==='bp-deal-category-form'){e.preventDefault();const name=String(new FormData(e.target).get('name')||'').trim();if(!name||name.length>55)return;if(state.offerCategories.some(c=>c.name.toLowerCase()===name.toLowerCase()))return toast('Category already exists');await bpSaveDealCategories([...state.offerCategories,{name,active:true}]);return}
 if(e.target.id!=='recovery-password-form')return;
 e.preventDefault();const f=e.target,uid=f.elements.uid.value,newPassword=f.elements.newPassword.value,confirmPassword=f.elements.confirmPassword.value,verificationNote=f.elements.verificationNote.value.trim();
 if(newPassword.length<8||newPassword.length>128)return toast('Password must be 8–128 characters');
 if(newPassword!==confirmPassword)return toast('Passwords do not match');
 if(!f.elements.verified.checked||verificationNote.length<12)return toast('Verification and authorization are required');
 if(!confirm('FINAL CONFIRMATION: Change this user password and revoke their previous sessions?'))return;
 const btn=f.querySelector('button[type=submit]');btn.disabled=true;
 try{const mod=await import(base+'firebase-functions.js');const fn=mod.httpsCallable(mod.getFunctions(state.auth.app,'asia-south1'),'adminSetUserPassword');await fn({uid,newPassword,verificationNote});f.reset();toast('User password updated securely. Previous sessions revoked.');await load()}
 catch(err){toast('Password update failed: '+err.message);btn.disabled=false}
});
document.addEventListener('click',e=>{const reset=e.target.closest('[data-recovery-reset]'),email=e.target.closest('[data-recovery-email]');if(reset){e.preventDefault();sendRecoveryReset(reset.dataset.recoveryReset)}if(email){e.preventDefault();changeRecoveryEmail(email.dataset.recoveryEmail)}});
document.addEventListener('submit',async e=>{if(e.target.id!=='recovery-email-form')return;e.preventDefault();const f=e.target,uid=f.elements.uid.value,newEmail=f.elements.newEmail.value.trim(),verificationNote=f.elements.verificationNote.value.trim();if(!f.elements.verified.checked||verificationNote.length<12)return toast('Identity verification is required');if(!confirm('FINAL CONFIRMATION: Change this user account email? This is a security-sensitive action.'))return;const btn=f.querySelector('button[type=submit]');btn.disabled=true;try{const mod=await import(base+'firebase-functions.js');const fn=mod.httpsCallable(mod.getFunctions(state.auth.app,'asia-south1'),'adminRecoverUserEmail');await fn({uid,newEmail,verificationNote});toast('Email updated securely. User can now request a reset email.');await load()}catch(err){toast('Recovery unavailable: '+err.message);btn.disabled=false}});

function bpOfferEditorRow(x={},i=0){return `<tr class="bp-suboffer-row"><td class="bp-suboffer-heading">${i+1}</td><td><strong>${h(x.title||'')}</strong><input type="hidden" data-subfield="title" value="${h(x.title||'')}"></td><td>${h(x.discount||'—')}<input type="hidden" data-subfield="discount" value="${h(x.discount||'')}"></td><td>${h(x.originalPrice||'—')}<input type="hidden" data-subfield="originalPrice" value="${h(x.originalPrice||'')}"></td><td>${h(x.offerPrice||'—')}<input type="hidden" data-subfield="offerPrice" value="${h(x.offerPrice||'')}"></td><td>${h(x.description||'—')}<input type="hidden" data-subfield="description" value="${h(x.description||'')}"></td><td><span class="bp-suboffer-image-label">${x.imageUrl?'Image saved':'No image'}</span><input type="hidden" data-subfield="imageUrl" value="${h(x.imageUrl||'')}"><span class="bp-suboffer-file-holder" style="display:none"><input data-subfile type="file" accept="image/jpeg,image/png,image/webp"></span></td><td style="white-space:nowrap"><button type="button" class="btn plain small" data-bp-edit-suboffer>Edit</button> <button type="button" class="btn red small" data-bp-remove-suboffer>Delete</button></td></tr>`}
function bpRenumberSuboffers(){document.querySelectorAll('#bp-suboffers-list .bp-suboffer-heading').forEach((el,i)=>el.textContent=String(i+1));const count=document.getElementById('bp-suboffer-count');if(count)count.textContent=document.querySelectorAll('#bp-suboffers-list .bp-suboffer-row').length+'/10 Offers'}
function bpResetOfferInputs(){const editor=document.getElementById('bp-suboffer-editor');if(!editor)return;editor.querySelectorAll('[data-bp-entry]').forEach(el=>el.value='');editor.querySelector('[data-bp-entry-file]').value='';editor.dataset.editIndex='';const btn=document.querySelector('[data-bp-add-suboffer]');if(btn)btn.textContent='+ Add Offer'}
function bpAddOfferToTable(){const editor=document.getElementById('bp-suboffer-editor'),list=document.getElementById('bp-suboffers-list');if(!editor||!list)return;const get=k=>editor.querySelector('[data-bp-entry="'+k+'"]')?.value.trim()||'';const title=get('title');if(!title)return toast('Enter Offer Title');const edit=editor.dataset.editIndex;const old=edit!==''?list.children[Number(edit)]:null;if(!old&&list.children.length>=10)return toast('Maximum 10 offers per deal');const x={title,discount:get('discount'),originalPrice:get('originalPrice'),offerPrice:get('offerPrice'),description:get('description'),imageUrl:get('imageUrl')};const holder=document.createElement('tbody');holder.innerHTML=bpOfferEditorRow(x,0);const row=holder.firstElementChild;const input=editor.querySelector('[data-bp-entry-file]');const target=row.querySelector('.bp-suboffer-file-holder');if(input.files.length){input.removeAttribute('data-bp-entry-file');input.setAttribute('data-subfile','');target.replaceChildren(input);const replacement=document.createElement('input');replacement.type='file';replacement.accept='image/jpeg,image/png,image/webp';replacement.setAttribute('data-bp-entry-file','');editor.querySelector('[data-bp-file-slot]').appendChild(replacement);row.querySelector('.bp-suboffer-image-label').textContent='Image selected'}else if(old){const existing=old.querySelector('[data-subfile]');if(existing){existing.remove();target.replaceChildren(existing)}}if(old)old.replaceWith(row);else list.appendChild(row);bpResetOfferInputs();bpRenumberSuboffers()}
function bpEditOfferRow(row){const editor=document.getElementById('bp-suboffer-editor'),list=document.getElementById('bp-suboffers-list');if(!editor||!row)return;editor.dataset.editIndex=String([...list.children].indexOf(row));for(const el of editor.querySelectorAll('[data-bp-entry]'))el.value=row.querySelector('[data-subfield="'+el.dataset.bpEntry+'"]')?.value||'';const btn=document.querySelector('[data-bp-add-suboffer]');if(btn)btn.textContent='Update Offer';editor.scrollIntoView({behavior:'smooth',block:'nearest'})}
function bpDealRequestsHtml(){const list=state.dealRequests||[];return `<section class="box" style="margin-bottom:20px"><h2>User Deal Submissions — Pending Approval (${list.filter(x=>x.status==='pending').length})</h2><p class="label">Review submissions before publishing. Only approved requests are copied to public offers. Featured is always OFF by default.</p><div style="overflow-x:auto"><table class="saved-table" style="min-width:720px;width:100%"><thead><tr><th>Deal / Business</th><th>Validity</th><th>Offers</th><th>Status</th><th>Actions</th></tr></thead><tbody>${list.map(x=>`<tr><td><strong>${h(x.title||'')}</strong><br>${h(x.businessName||'')}<br>${h(x.phone||'')}<br><small>${h(x.description||'')}</small></td><td>${h(bpOfferDisplayDate(x.startDate))} – ${h(bpOfferDisplayDate(x.endDate))}</td><td>${(x.subOffers||[]).map(y=>`<div>${h(y.title||'')} · ${h(y.discount||'')} ${y.offerPrice?'· ₹'+h(y.offerPrice):''}</div>`).join('')}</td><td>${h(x.status||'pending')}</td><td>${x.status==='pending'?`<button class="btn green small" data-deal-request-approve="${h(x.id)}">Approve</button> <button class="btn red small" data-deal-request-reject="${h(x.id)}">Reject</button>`:'—'}</td></tr>`).join('')||'<tr><td colspan="5">No user submissions yet.</td></tr>'}</tbody></table></div></section>`}
async function bpReviewDealRequest(id,approve){const x=(state.dealRequests||[]).find(r=>r.id===id);if(!x||x.status!=='pending')return;if(!confirm((approve?'Approve and publish':'Reject')+' this submitted deal?'))return;const F=state.F;try{if(approve){const {id:requestId,ownerUid,status,createdAt,reviewedAt,reviewedBy,...data}=x;const offerRef=F.doc(F.collection(state.db,'offers'));const batch=F.writeBatch(state.db);batch.set(offerRef,{...data,sourceRequestId:requestId,ownerUid,status:'published',featured:false,displayOrder:100,createdAt:F.serverTimestamp(),updatedAt:F.serverTimestamp()});batch.update(F.doc(state.db,'dealRequests',id),{status:'approved',publishedOfferId:offerRef.id,reviewedBy:state.user.uid,reviewedAt:F.serverTimestamp()});await batch.commit()}else await F.updateDoc(F.doc(state.db,'dealRequests',id),{status:'rejected',reviewedBy:state.user.uid,reviewedAt:F.serverTimestamp()});toast(approve?'Deal approved and published':'Deal rejected');await load()}catch(e){toast('Deal review failed: '+e.message)}}
function bpDealCategoryAdminHtml(){return `<section class="box" style="max-width:760px"><h2>Deals & Offers Categories</h2><p class="label">Active categories appear in the Android app even with zero deals.</p><form id="bp-deal-category-form" class="row"><input name="name" maxlength="55" required placeholder="New category name" style="min-width:170px;flex:1;padding:10px;border:1px solid #d8e6f9;border-radius:9px"><button class="btn" type="submit">Add Category</button></form><div class="row" style="flex-wrap:wrap;margin-top:12px">${state.offerCategories.map((c,i)=>`<span style="display:inline-flex;align-items:center;gap:6px;padding:7px 9px;border:1px solid #ddd;border-radius:10px"><b>${h(c.name)}</b><button class="btn plain" type="button" data-deal-category-toggle="${i}">${c.active===false?'Enable':'Disable'}</button></span>`).join('')||'<small>No custom categories yet.</small>'}</div></section>`}
async function bpSaveDealCategories(next){try{await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{offerCategories:next},{merge:true});state.offerCategories=next;toast('Deal categories saved');panel()}catch(e){toast('Category save failed: '+e.message)}}
function offersPanel(){
 const old=state.offers.find(x=>x.id===state.offerEditId)||{};
 const approved=state.biz.filter(b=>b.status==='approved');
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Offers & Deals Manager</p></div><button class="btn plain" data-view-mode="business">← Dashboard</button></header><main><h1>Offers & Deals</h1><p class="label">Only Published offers within their start/end dates appear in the app. Business profile button is available only for an exact linked approved business.</p>${bpDealRequestsHtml()}${bpDealCategoryAdminHtml()}<form id="offer-form" class="box" style="max-width:760px"><input type="hidden" name="editId" value="${h(old.id||'')}"><div class="formgrid"><label class="field"><span>Offer Title *</span><input name="title" required maxlength="120" value="${h(old.title||'')}" placeholder="e.g. Diwali Special Sale"></label><label class="field"><span>Discount / Deal *</span><input name="discount" required maxlength="100" value="${h(old.discount||'')}" placeholder="e.g. Up to 30% OFF"></label></div><label class="field"><span>Offer Image URL (HTTPS) — optional if uploading</span><input name="imageUrl" type="url" value="${h(old.imageUrl||'')}" placeholder="https://..."></label><label class="field"><span>Upload / Replace Image (JPG/PNG/WebP, max 5 MB)</span><input name="imageFile" type="file" accept="image/jpeg,image/png,image/webp"></label><label class="field"><span>Deal Category</span><select name="category">${[...new Set([...state.offerCategories.filter(c=>c.active!==false).map(c=>c.name),...state.offers.map(o=>o.category).filter(Boolean),'General'])].map(c=>`<option value="${c}" ${String(old.category||'General')===c?'selected':''}>${c}</option>`).join('')}</select></label><div class="field"><span><b>Offers in this Deal (maximum 10)</b></span><small>Enter one offer in the single row, click Add Offer, then it appears in the table below. Images optional.</small><div id="bp-suboffer-editor" style="overflow-x:auto;padding:10px 0" data-edit-index=""><div style="display:grid;grid-template-columns:170px 120px 110px 110px 190px 150px 115px;gap:8px;align-items:end;min-width:1000px"><label class="field"><span>Offer Title *</span><input data-bp-entry="title" maxlength="120" placeholder="Shirts"></label><label class="field"><span>Discount</span><input data-bp-entry="discount" maxlength="100" placeholder="20% OFF"></label><label class="field"><span>Original ₹</span><input data-bp-entry="originalPrice" maxlength="50" placeholder="999"></label><label class="field"><span>Offer ₹</span><input data-bp-entry="offerPrice" maxlength="50" placeholder="799"></label><label class="field"><span>Description</span><input data-bp-entry="description" maxlength="500" placeholder="Offer details"></label><label class="field"><span>Image (optional)</span><span data-bp-file-slot><input data-bp-entry-file type="file" accept="image/jpeg,image/png,image/webp" style="width:145px"></span><input data-bp-entry="imageUrl" type="hidden"></label><button type="button" class="btn green small" data-bp-add-suboffer>+ Add Offer</button></div></div><div style="overflow-x:auto"><table class="saved-table" style="width:100%;min-width:850px"><thead><tr><th>#</th><th>Offer Title</th><th>Discount</th><th>Original ₹</th><th>Offer ₹</th><th>Description</th><th>Image</th><th>Actions</th></tr></thead><tbody id="bp-suboffers-list">${(old.subOffers||[]).map((x,i)=>bpOfferEditorRow(x,i)).join('')}</tbody></table></div><small id="bp-suboffer-count">${(old.subOffers||[]).length}/10 Offers</small></div><label class="field"><span>Business / Shop Name *</span><input name="businessName" required maxlength="140" value="${h(old.businessName||'')}"></label><label class="field"><span>Link Existing Approved Business (optional)</span><select name="businessId"><option value="">No registered profile link</option>${approved.map(b=>`<option value="${h(b.id)}" ${old.businessId===b.id?'selected':''}>${h(b.name)} · ${h(b.area||'Baran')}</option>`).join('')}</select><small>Only exact approved business ID can show View Business Profile.</small></label><label class="field"><span>Description *</span><textarea name="description" required maxlength="2500">${h(old.description||'')}</textarea></label><div class="formgrid"><label class="field"><span>Start Date *</span><input type="text" name="startDate" required inputmode="numeric" maxlength="10" pattern="[0-9]{2}-[0-9]{2}-[0-9]{4}" placeholder="DD-MM-YYYY" title="DD-MM-YYYY" value="${h(bpOfferDisplayDate(old.startDate||new Date().toISOString().slice(0,10)))}"></label><label class="field"><span>End Date *</span><input type="text" name="endDate" required inputmode="numeric" maxlength="10" pattern="[0-9]{2}-[0-9]{2}-[0-9]{4}" placeholder="DD-MM-YYYY" title="DD-MM-YYYY" value="${h(bpOfferDisplayDate(old.endDate||''))}"></label><label class="field"><span>Contact Number (optional)</span><input name="phone" maxlength="16" value="${h(old.phone||'')}" placeholder="10 digit number"></label><label class="field"><span>Google Maps Link (HTTPS, optional)</span><input name="mapUrl" type="url" value="${h(old.mapUrl||'')}" placeholder="https://maps.google.com/..."></label><label class="field"><span>Business Address</span><input name="address" maxlength="300" value="${h(old.address||'')}"></label><label class="field"><span>Display Order (smaller first)</span><input name="displayOrder" type="number" min="0" max="999" value="${h(old.displayOrder??100)}"></label></div><label class="field"><span>Terms & Conditions</span><textarea name="terms" maxlength="1800">${h(old.terms||'')}</textarea></label><label class="content-check"><input type="checkbox" name="featured" ${old.featured?'checked':''}> Featured Deal (show on Homepage banner slider)</label><label class="content-check"><input type="checkbox" name="published" ${old.status==='published'?'checked':''}> Published / visible to public</label><div class="row"><button class="btn green" type="submit">${old.id?'Save Offer Changes':'Add Offer'}</button>${old.id?'<button class="btn plain" type="button" data-offer-cancel>Cancel Edit</button>':''}</div></form><h2>Saved Offers (${state.offers.length})</h2>${state.offers.map(o=>`<article class="listing">${validHttps(o.imageUrl)?`<img src="${h(o.imageUrl)}" alt="" style="width:110px;height:85px;object-fit:cover;border-radius:8px">`:''}<div><h3>${h(o.title)} ${status(o.status||'draft')}</h3><p><b>${h(o.discount||'')}</b> · ${h(o.businessName||'')}</p><p>${h(bpOfferDisplayDate(o.startDate))} – ${h(bpOfferDisplayDate(o.endDate))} · ${o.featured?'Featured · ':''}Order ${h(o.displayOrder??100)}</p><p>${h(o.businessId?'Linked business: '+(state.biz.find(b=>b.id===o.businessId)?.name||o.businessId):'No profile link')}</p></div><div class="actions"><button class="btn plain small" data-offer-edit="${h(o.id)}">Edit</button><button class="btn ${o.status==='published'?'warn':'green'} small" data-offer-toggle="${h(o.id)}">${o.status==='published'?'Hide':'Publish'}</button><button class="btn red small" data-offer-delete="${h(o.id)}">Delete</button></div></article>`).join('')||'<div class="empty">No offers yet. Add the first offer above.</div>'}</main>${state.modal||''}`;
}
function bpOfferDisplayDate(v){const s=String(v||'');return /^\d{4}-\d{2}-\d{2}$/.test(s)?s.slice(8,10)+'-'+s.slice(5,7)+'-'+s.slice(0,4):s;}
function bpOfferStoreDate(v){const s=String(v||'').trim(),m=/^(\d{2})-(\d{2})-(\d{4})$/.exec(s);if(!m)return '';const iso=m[3]+'-'+m[2]+'-'+m[1];const d=new Date(iso+'T12:00:00Z');return !Number.isNaN(d.getTime())&&d.toISOString().slice(0,10)===iso?iso:'';}
async function saveOffer(form){const fd=new FormData(form),F=state.F,id=String(fd.get('editId')||''),old=state.offers.find(x=>x.id===id);let imageUrl=validHttps(String(fd.get('imageUrl')||''))||old?.imageUrl||'';const startDate=bpOfferStoreDate(fd.get('startDate')),endDate=bpOfferStoreDate(fd.get('endDate')),phone=String(fd.get('phone')||'').trim(),mapInput=String(fd.get('mapUrl')||'').trim();if(!startDate||!endDate||endDate<startDate)return toast('Please check offer start and end dates');if(phone&&!/^\+?[0-9 -]{10,16}$/.test(phone))return toast('Invalid contact number');if(mapInput&&!validHttps(mapInput))return toast('Google Maps link must start with https://');const btn=form.querySelector('[type=submit]');btn.disabled=true;try{const file=form.elements.imageFile?.files?.[0];if(file)imageUrl=await uploadHomepageImage(file,'offers');const businessId=String(fd.get('businessId')||'');const linked=state.biz.find(b=>b.id===businessId&&b.status==='approved');const rows=[...form.querySelectorAll('.bp-suboffer-row')];if(!rows.length&&form.querySelector('[data-bp-entry=title]')?.value.trim())throw Error('Click Add Offer before saving the Main Deal');if(rows.length>10)throw Error('Maximum 10 sub-offers per deal');const subOffers=[];for(const row of rows){const get=k=>String(row.querySelector('[data-subfield="'+k+'"]')?.value||'').trim();const title=get('title');if(!title)throw Error('Every sub-offer needs a title');let subImage=validHttps(get('imageUrl'));const subFile=row.querySelector('[data-subfile]')?.files?.[0];if(subFile)subImage=await uploadHomepageImage(subFile,'offers');subOffers.push({title:title.slice(0,120),discount:get('discount').slice(0,100),originalPrice:get('originalPrice').slice(0,50),offerPrice:get('offerPrice').slice(0,50),description:get('description').slice(0,500),imageUrl:subImage})}const data={category:String(fd.get('category')||'General'),subOffers,title:String(fd.get('title')||'').trim(),discount:String(fd.get('discount')||'').trim(),imageUrl,businessName:String(fd.get('businessName')||'').trim(),businessId:linked?linked.id:'',description:String(fd.get('description')||'').trim(),startDate,endDate,phone,address:String(fd.get('address')||'').trim(),mapUrl:validHttps(mapInput),terms:String(fd.get('terms')||'').trim(),featured:fd.get('featured')==='on',displayOrder:Math.max(0,Number(fd.get('displayOrder')||100)),status:fd.get('published')==='on'?'published':'draft',updatedAt:F.serverTimestamp()};if(id&&old)await F.updateDoc(F.doc(state.db,'offers',id),data);else await F.addDoc(F.collection(state.db,'offers'),{...data,createdAt:F.serverTimestamp()});state.offerEditId=null;toast('Offer saved');await load();state.view='offers';panel()}catch(e){toast('Offer save failed: '+e.message);btn.disabled=false}}
async function offerAction(id,action){const o=state.offers.find(x=>x.id===id);if(!o)return;try{if(action==='delete'){if(!confirm('Permanently delete this offer?'))return;await state.F.deleteDoc(state.F.doc(state.db,'offers',id))}else await state.F.updateDoc(state.F.doc(state.db,'offers',id),{status:o.status==='published'?'draft':'published',updatedAt:state.F.serverTimestamp()});toast(action==='delete'?'Offer deleted':'Offer status updated');await load();state.view='offers';panel()}catch(e){toast(e.message)}}

// Version updates can point to a direct HTTPS APK download or Google Play.
function appUpdatePanel(){
 const u=state.appUpdate||{};
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · APP UPDATE</strong><p>Google Play or Direct APK update settings</p></div><button class="btn plain" data-view-mode="business">← Dashboard</button></header><main><h1>Android App Update Settings</h1><p class="label">Publish a newer signed APK to a trusted HTTPS download address, or publish to Google Play. Set Latest versionCode higher than the installed app. Force Update blocks app access until an updated version is installed.</p><section class="box" style="max-width:720px"><form id="app-update-form"><label class="content-check"><input type="checkbox" name="enabled" ${u.enabled?'checked':''}> Enable update message</label><div class="formgrid"><label class="field"><span>Latest versionCode (integer)</span><input name="latestVersionCode" type="number" min="1" max="999999" step="1" required value="${h(u.latestVersionCode||1)}"></label><label class="field"><span>Latest version name</span><input name="latestVersionName" maxlength="32" required value="${h(u.latestVersionName||'1.0')}" placeholder="e.g. 1.1"></label></div><label class="field"><span>Update Type</span><select name="mode"><option value="normal" ${u.mode!=='force'?'selected':''}>Normal Update — Update Now / Later</option><option value="force" ${u.mode==='force'?'selected':''}>Force Update — Update Now only</option></select></label><label class="field"><span>Update Message</span><textarea name="message" minlength="3" maxlength="500" required>${h(u.message||'A new version of Baran Pride is available.')}</textarea></label><label class="field"><span>Update Source</span><select name="source"><option value="apk" ${u.source==='apk'?'selected':''}>Direct APK Download</option><option value="play" ${u.source!=='apk'?'selected':''}>Google Play Store</option></select></label><label class="field"><span>Direct APK Download URL (HTTPS)</span><input name="apkUrl" type="url" maxlength="1000" placeholder="https://your-domain.com/downloads/baranpride-v2.apk" value="${h(u.apkUrl||'')}"></label><label class="field"><span>Google Play Store URL</span><input name="playStoreUrl" type="url" maxlength="500" placeholder="https://play.google.com/store/apps/details?id=in.baranpride.app" value="${h(u.playStoreUrl||'')}"></label><p class="label">Only the selected source link is required when enabled. APK URL must be HTTPS and point to an .apk file. The update popup appears only when installed versionCode is lower. Normal Update has Later; Force Update has no Later. APK download requires the user to install the newer signed APK manually.</p><button type="submit" class="btn green">Save Update Settings</button></form></section></main>`;
}
async function saveAppUpdate(form){
 const fd=new FormData(form),enabled=fd.get('enabled')==='on',mode=String(fd.get('mode')),latestVersionCode=Number(fd.get('latestVersionCode')),latestVersionName=String(fd.get('latestVersionName')||'').trim(),message=String(fd.get('message')||'').trim(),playStoreUrl=String(fd.get('playStoreUrl')||'').trim(),apkUrl=String(fd.get('apkUrl')||'').trim(),source=String(fd.get('source')||'play');
 if(!Number.isSafeInteger(latestVersionCode)||latestVersionCode<1||latestVersionCode>999999)return toast('Enter a valid integer versionCode');
 if(!['normal','force'].includes(mode)||!latestVersionName||latestVersionName.length>32||message.length<3||message.length>500)return toast('Check version name, mode and message');
 if(!['apk','play'].includes(source))return toast('Select a valid update source');
 if(playStoreUrl&&!isGooglePlayAppLink(playStoreUrl))return toast('Enter a valid Google Play Store app URL');
 if(apkUrl&&!isDirectApkLink(apkUrl))return toast('Direct APK URL must be HTTPS and end in .apk');
 if(enabled&&source==='play'&&!isGooglePlayAppLink(playStoreUrl))return toast('Enter your Google Play app URL');
 if(enabled&&source==='apk'&&!isDirectApkLink(apkUrl))return toast('Enter a valid HTTPS APK download URL');
 const btn=form.querySelector('[type=submit]');btn.disabled=true;
 try{await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{appUpdate:{enabled,mode,latestVersionCode,latestVersionName,message,source,apkUrl,playStoreUrl},updatedAt:state.F.serverTimestamp()},{merge:true});toast('App update settings saved');await load();state.view='appUpdate';panel()}
 catch(e){toast('Could not save update settings: '+e.message);btn.disabled=false}
}
function isDirectApkLink(url){try{const u=new URL(url);return u.protocol==='https:'&&/\.apk$/i.test(u.pathname)&&!u.username&&!u.password}catch(e){return false}}
function isGooglePlayAppLink(url){try{const u=new URL(url);return u.protocol==='https:'&&u.hostname==='play.google.com'&&u.pathname==='/store/apps/details'&&/^[a-zA-Z][a-zA-Z0-9_]*(?:\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(u.searchParams.get('id')||'')}catch(e){return false}}


function marketplaceAdminPanel(){
 const items=state.marketplaceListings||[];
 const filter=state.marketplaceFilter||'pending';
 const shown=items.filter(x=>filter==='all'||(filter==='sold'?x.isSold:x.status===filter));
 const buttons=['pending','approved','rejected','sold','all'].map(k=>`<button type="button" class="btn ${filter===k?'primary':'plain'}" data-market-filter="${k}">${k[0].toUpperCase()+k.slice(1)} (${k==='all'?items.length:k==='sold'?items.filter(x=>x.isSold).length:items.filter(x=>x.status===k).length})</button>`).join('');
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Buy & Sell Marketplace</p></div><div class="admin-header-actions"><button class="btn plain" data-view-mode="business">← Dashboard</button><button class="btn plain" id="refresh">Refresh</button><button class="btn plain" id="logout">Sign Out</button></div></header><main><h1>Marketplace Management</h1><p>Review sellers, publish approved items and manage Premium promotions.</p><div class="bp-market-admin-tabs">${buttons}</div><div class="bp-market-admin-grid">${shown.map(x=>{const premium=x.isPremium&&x.premiumExpiresAt?.seconds*1000>Date.now();const photo=(x.images||[])[0];return `<article class="box bp-market-admin-item"><div class="bp-market-admin-info">${photo?`<img src="${h(photo)}" alt="" loading="lazy">`:''}<div><h3>${h(x.title||'Untitled')}</h3><p>₹${Number(x.price||0).toLocaleString('en-IN')} · ${h(x.category||'')} · ${h(x.condition||'')}</p><p>${h(x.sellerName||'')} · ${h(x.sellerPhone||'')} · ${h(x.location||'')}</p><p>Status: <b>${h(x.status||'pending')}</b> · ${x.isSold?'SOLD':x.active?'Active':'Inactive'} ${premium?'· PREMIUM':''}</p><p>${h(x.description||'')}</p></div></div><div class="actions">${x.status!=='approved'?`<button class="btn primary" data-market-approve="${h(x.id)}">Approve</button>`:''}${x.status!=='rejected'?`<button class="btn warn" data-market-reject="${h(x.id)}">Reject</button>`:''}${x.status==='approved'&&!x.isSold?`<button class="btn plain" data-market-toggle="${h(x.id)}">${x.active?'Deactivate':'Activate'}</button>`:''}${x.status==='approved'&&!x.isSold?[3,7,15,30].map(d=>`<button class="btn plain" data-market-premium="${h(x.id)}" data-market-days="${d}">Premium ${d}d</button>`).join(''):''}${x.isPremium?`<button class="btn warn" data-market-premium-off="${h(x.id)}">Remove Premium</button>`:''}<button class="btn warn" data-market-delete="${h(x.id)}">Delete</button></div></article>`}).join('')||'<div class="empty">No Marketplace listings in this filter.</div>'}</div></main>`;
 $('#logout').onclick=()=>state.U.signOut(state.auth);
 $('#refresh').onclick=load;
}
async function marketplaceAdminAction(id,action){
 const x=state.marketplaceListings.find(v=>v.id===id);if(!x)return;
 if(!confirm(`${action==='delete'?'Permanently DELETE':action==='approve'?'Approve':action==='reject'?'Reject':'Change visibility of'} "${x.title}"?`))return;
 try{
  const F=state.F,ref=F.doc(state.db,'marketplaceListings',id);
  if(action==='delete')await F.deleteDoc(ref);
  else {
   const patch=action==='approve'?{status:'approved',active:!x.isSold,approvedAt:F.serverTimestamp(),approvedBy:state.user.uid}:action==='reject'?{status:'rejected',active:false,isPremium:false}:action==='toggle'?{active:!x.active}:{};
   await F.updateDoc(ref,{...patch,updatedAt:F.serverTimestamp()});
  }
  toast('Marketplace listing updated');await load();
 }catch(e){toast('Marketplace action failed: '+e.message)}
}
async function marketplaceAdminPremium(id,days){
 const x=state.marketplaceListings.find(v=>v.id===id);if(!x)return;
 if(days&&!(x.status==='approved'&&x.active&&!x.isSold))return toast('Only approved active unsold items can be Premium');
 if(!confirm(days?`Activate Premium for ${days} days on "${x.title}"?`:`Remove Premium from "${x.title}"?`))return;
 try{
  const F=state.F,expires=days?F.Timestamp.fromMillis(Date.now()+days*86400000):null;
  await F.updateDoc(F.doc(state.db,'marketplaceListings',id),{isPremium:days>0,premiumExpiresAt:expires,updatedAt:F.serverTimestamp()});
  toast('Premium updated');await load();
 }catch(e){toast('Premium update failed: '+e.message)}
}
function localJobsAdminPanel(){
 const jobs=state.localJobs||[],counts={pending:0,approved:0,rejected:0,inactive:0};
 jobs.forEach(j=>{if(j.status in counts)counts[j.status]++;if(j.status==='approved'&&j.active===false)counts.inactive++});
 const filtered=jobs.filter(j=>state.jobFilter==='all'||(state.jobFilter==='inactive'?j.status==='approved'&&!j.active:j.status===state.jobFilter));
 const formatDate=x=>x?.seconds?new Date(x.seconds*1000).toLocaleDateString('en-IN'):String(x||'—');
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Local Jobs Management</p></div><div class="admin-header-actions"><button class="btn plain" data-view-mode="business">← Dashboard</button><button class="btn plain" id="logout">Sign Out</button></div></header><main class="bp-jobs-admin"><h1>Local Jobs</h1><button class="btn green" type="button" data-job-admin-new>+ Publish New Job</button><p class="label">Review submissions before publishing. Contact information becomes public after approval.</p><section class="cards">${[['Pending',counts.pending],['Approved',counts.approved],['Rejected',counts.rejected],['Inactive',counts.inactive]].map(([label,count])=>`<div class="metric"><small>${label}</small><strong>${count}</strong></div>`).join('')}</section><div class="tabs">${[['pending','Pending'],['approved','Approved'],['rejected','Rejected'],['inactive','Inactive'],['all','All Jobs']].map(([id,label])=>`<button class="tab ${state.jobFilter===id?'active':''}" data-job-filter="${id}">${label}</button>`).join('')}</div><section class="bp-job-admin-list">${filtered.map(j=>`<article class="box bp-job-admin-card"><div class="row" style="justify-content:space-between"><div><h3>${h(j.title)}</h3><p>${h(j.company)} · ${h(j.location)}</p></div><strong>${h(j.status)}${j.active?' · Live':''}</strong></div><p><b>Salary:</b> ${h(j.salary)} · <b>Type:</b> ${h(j.jobType)} · <b>Submitted:</b> ${h(formatDate(j.createdAt))}</p><div class="row"><button class="btn plain" data-job-details="${h(j.id)}">Details</button><button class="btn plain" data-job-edit="${h(j.id)}">Edit</button>${j.status!=='approved'?`<button class="btn green" data-job-approve="${h(j.id)}">Approve</button>`:''}${j.status!=='rejected'?`<button class="btn warn" data-job-reject="${h(j.id)}">Reject</button>`:''}${j.status==='approved'?`<button class="btn plain" data-job-toggle="${h(j.id)}">${j.active?'Deactivate':'Activate'}</button>`:''}<button class="btn warn" data-job-delete="${h(j.id)}" title="Permanently delete this job">Delete</button></div></article>`).join('')||'<div class="empty">No jobs in this section.</div>'}</section></main>${state.modal||''}`;
 $('#logout').onclick=()=>state.U.signOut(state.auth);
}
function bpAdminNewJob(){
 const categories=['Education & Teaching','IT & Computer','Sales & Marketing','Office & Administration','Bank & Finance','Healthcare & Medical','Retail & Shop Staff','Hotel & Restaurant','Driver & Delivery','Technical & Skilled Work','Construction & Labour','Factory & Manufacturing','Security & Housekeeping','Other Jobs'];
 openModal('Publish Local Job',`<form id="bp-admin-job-new"><div class="bp-job-fields"><label class="field">Organisation *<input name="company" required maxlength="120"></label><label class="field">Job Title(s) * (comma separated)<textarea name="titles" required maxlength="1000"></textarea></label><label class="field">Category *<select name="category">${categories.map(c=>`<option>${h(c)}</option>`).join('')}</select></label><label class="field">Job Type<select name="jobType"><option>Full Time</option><option>Part Time</option><option>Contract</option><option>Internship</option></select></label><label class="field">Vacancies<input name="vacancies" type="number" min="1" max="1000" value="1"></label><label class="field">Salary<input name="salary" maxlength="100"></label><label class="field">Qualification<input name="qualification" maxlength="120"></label><label class="field">Experience<input name="experience" maxlength="100"></label><label class="field">Skills<input name="skills" maxlength="200"></label><label class="field">Description<textarea name="description" maxlength="2000"></textarea></label><label class="field">Mobile *<input name="mobile" required pattern="[6-9][0-9]{9}" maxlength="10"></label><label class="field">WhatsApp<input name="whatsapp" maxlength="10"></label><label class="field">Apply Link<input name="applyLink" type="url" maxlength="500"></label><label class="field">Last Apply Date<input name="lastApplyDate" type="date"></label></div><button class="btn green" type="submit">Publish Jobs</button></form>`);
}
async function bpAdminPublishJobs(form){
 const fd=new FormData(form),v=k=>String(fd.get(k)||'').trim(),titles=[...new Set(v('titles').split(',').map(x=>x.trim()).filter(Boolean))];
 if(!titles.length||titles.length>10||titles.some(t=>t.length>100))return toast('Enter 1–10 valid job titles');
 if(!/^[6-9][0-9]{9}$/.test(v('mobile'))||(v('whatsapp')&&!/^[6-9][0-9]{9}$/.test(v('whatsapp'))))return toast('Invalid mobile number');
 const btn=form.querySelector('[type=submit]');btn.disabled=true;
 try{const F=state.F,batch=F.writeBatch(state.db);for(const title of titles){const ref=F.doc(F.collection(state.db,'localJobs'));batch.set(ref,{title,company:v('company'),category:v('category'),location:'Baran, Rajasthan',jobType:v('jobType'),vacancies:Number(v('vacancies'))||1,salary:v('salary'),qualification:v('qualification'),experience:v('experience'),skills:v('skills'),description:v('description'),contactPerson:'',mobile:v('mobile'),whatsapp:v('whatsapp'),applyLink:v('applyLink'),workingHours:'',weeklyOff:'',lastApplyDate:v('lastApplyDate'),contactConsent:true,ownerUid:state.user.uid,status:'approved',active:true,featured:false,createdAt:F.serverTimestamp(),approvedAt:F.serverTimestamp(),approvedBy:state.user.uid})}await batch.commit();state.modal=null;toast('Jobs published');await load()}
 catch(e){toast('Publish failed: '+e.message);btn.disabled=false}
}
function jobAdminDetails(id,edit=false){
 const j=state.localJobs.find(x=>x.id===id);if(!j)return;
 if(edit){
  const fields=[['title','Job Title'],['company','Company / Shop'],['category','Category'],['location','Location'],['qualification','Qualification'],['experience','Experience'],['salary','Salary'],['jobType','Job Type'],['description','Description'],['contactPerson','Contact Person'],['mobile','Mobile'],['whatsapp','WhatsApp'],['lastApplyDate','Last Apply Date']];
  openModal('Edit Job',`<form id="job-admin-edit-form" data-job-id="${h(id)}"><div class="bp-job-fields">${fields.map(([key,label])=>`<label class="field"><span>${label}</span>${key==='description'?`<textarea name="${key}" maxlength="2000">${h(j[key]||'')}</textarea>`:`<input name="${key}" maxlength="${['mobile','whatsapp'].includes(key)?10:180}" value="${h(j[key]||'')}">`}</label>`).join('')}<label class="field"><span>Vacancies</span><input type="number" min="1" max="1000" name="vacancies" value="${h(j.vacancies||'')}"></label></div><button class="btn green" type="submit">Save Changes</button></form>`);
 }else{
  openModal('Job Details',`<div class="bp-job-detail">${['title','company','category','location','qualification','experience','salary','jobType','vacancies','description','contactPerson','mobile','whatsapp','lastApplyDate','status','active'].map(key=>`<p><b>${h(key)}:</b> ${h(j[key]??'—')}</p>`).join('')}</div>`);
 }
}
async function jobAdminAction(id,action){
 const j=state.localJobs.find(x=>x.id===id);if(!j)return;
 const update=action==='approve'?{status:'approved',active:true,approvedAt:state.F.serverTimestamp(),approvedBy:state.user.uid}:action==='reject'?{status:'rejected',active:false}:action==='toggle'?{active:!j.active}:{};
 if(!Object.keys(update).length)return;
 if(!confirm(`${action==='approve'?'Publish':action==='reject'?'Reject':'Change visibility of'} job: ${j.title}?`))return;
 try{await state.F.updateDoc(state.F.doc(state.db,'localJobs',id),{...update,updatedAt:state.F.serverTimestamp()});toast('Job updated');await load()}catch(e){toast('Job update failed: '+e.message)}
}
async function jobAdminDelete(id){
 const j=state.localJobs.find(x=>x.id===id);if(!j)return;
 if(!confirm(`Permanently delete job "${j.title}"? This cannot be undone.`))return;
 try{
  await state.F.deleteDoc(state.F.doc(state.db,'localJobs',id));
  toast('Job deleted');
  await load();
 }catch(e){toast('Job deletion failed: '+e.message)}
}
async function jobAdminSave(form){
 const id=form.dataset.jobId,j=state.localJobs.find(x=>x.id===id);if(!j)return;
 const f=new FormData(form),patch={};
 for(const k of ['title','company','category','location','qualification','experience','salary','jobType','description','contactPerson','mobile','whatsapp','lastApplyDate'])patch[k]=String(f.get(k)||'').trim();
 if(!patch.title||!patch.company||!patch.location||!patch.description||!patch.mobile)return toast('Fill required fields');
 if(!/^[6-9][0-9]{9}$/.test(patch.mobile)||patch.whatsapp&&!/^[6-9][0-9]{9}$/.test(patch.whatsapp))return toast('Invalid phone number');
 if(patch.description.length<20)return toast('Description must be at least 20 characters');
 const n=String(f.get('vacancies')||'');patch.vacancies=n?Number(n):null;
 if(n&&(!Number.isInteger(patch.vacancies)||patch.vacancies<1||patch.vacancies>1000))return toast('Invalid vacancy count');
 try{await state.F.updateDoc(state.F.doc(state.db,'localJobs',id),{...patch,updatedAt:state.F.serverTimestamp()});state.modal=null;toast('Job changes saved');await load()}catch(e){toast('Save failed: '+e.message)}
}
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-job-admin-new],[data-job-filter],[data-job-details],[data-job-edit],[data-job-approve],[data-job-reject],[data-job-toggle],[data-job-delete]');if(!b)return;
 e.preventDefault();
 if(b.hasAttribute('data-job-admin-new'))return bpAdminNewJob();
 if(b.hasAttribute('data-job-filter')){state.jobFilter=b.dataset.jobFilter;localJobsAdminPanel();return}
 if(b.hasAttribute('data-job-details'))return jobAdminDetails(b.dataset.jobDetails);
 if(b.hasAttribute('data-job-edit'))return jobAdminDetails(b.dataset.jobEdit,true);
 if(b.hasAttribute('data-job-approve'))return jobAdminAction(b.dataset.jobApprove,'approve');
 if(b.hasAttribute('data-job-reject'))return jobAdminAction(b.dataset.jobReject,'reject');
 if(b.hasAttribute('data-job-toggle'))return jobAdminAction(b.dataset.jobToggle,'toggle');
 if(b.hasAttribute('data-job-delete'))return jobAdminDelete(b.dataset.jobDelete);
});
document.addEventListener('submit',e=>{if(e.target.id==='bp-admin-job-new'){e.preventDefault();bpAdminPublishJobs(e.target);return}if(e.target.id==='job-admin-edit-form'){e.preventDefault();jobAdminSave(e.target)}});

// Phase 4B: consolidated review inbox. All actions open existing management screens.
let bpApprovalFilter='all';
function bpApprovalCenter(){
 const groups=[
  {key:'business',label:'Businesses',icon:'🏪',items:(state.biz||[]).filter(x=>x.status==='pending'),view:'business'},
  {key:'changes',label:'Business Changes',icon:'✎',items:(state.changes||[]).filter(x=>x.status==='pending'),view:'business'},
  {key:'deals',label:'Deal Requests',icon:'◇',items:(state.dealRequests||[]).filter(x=>x.status==='pending'),view:'offers'},
  {key:'properties',label:'Properties',icon:'⌂',items:(state.propertyRequests||[]).filter(x=>x.status==='pending'),view:'community'},
  {key:'jobs',label:'Local Jobs',icon:'▣',items:(state.localJobs||[]).filter(x=>x.status==='pending'),view:'jobs'}
 ];
 const total=groups.reduce((n,g)=>n+g.items.length,0);
 const active=groups.some(g=>g.key===bpApprovalFilter)?bpApprovalFilter:'all';
 const entries=groups.filter(g=>active==='all'||g.key===active).flatMap(g=>g.items.map(item=>({g,item})))
   .sort((a,b)=>(b.item.createdAt?.seconds||0)-(a.item.createdAt?.seconds||0));
 const date=x=>x?.createdAt?.seconds?new Date(x.createdAt.seconds*1000).toLocaleDateString('en-IN'):'—';
 const title=(g,x)=>g.key==='business'?x.name:g.key==='changes'?(state.biz||[]).find(b=>b.id===x.businessId)?.name||'Business change':g.key==='deals'?x.title:g.key==='properties'?(x.propertyType||'Property')+' · '+(x.area||''):x.title;
 const detail=(g,x)=>g.key==='business'?x.category||x.area:g.key==='changes'?Object.keys(x.patch||{}).join(', '):g.key==='deals'?x.businessName:g.key==='properties'?x.area:x.company;
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Central Approval Center</p></div><div class="admin-header-actions"><button class="btn plain" data-view-mode="business">← Dashboard</button><button class="btn plain" id="logout">Sign Out</button></div></header><main class="bp-approval-center"><div class="bp-approval-head"><div><h1>Approval Center</h1><p class="label">One inbox for pending submissions. Review and approve in the existing management screens.</p></div><div class="bp-approval-total"><strong>${total}</strong><small>Total pending</small></div></div><section class="bp-approval-summary">${groups.map(g=>`<button type="button" class="bp-approval-tile ${active===g.key?'active':''}" data-approval-filter="${g.key}"><span>${g.icon} ${h(g.label)}</span><strong>${g.items.length}</strong></button>`).join('')}</section><div class="bp-approval-tabs"><button type="button" class="btn ${active==='all'?'':'plain'}" data-approval-filter="all">All (${total})</button>${groups.map(g=>`<button type="button" class="btn ${active===g.key?'':'plain'}" data-approval-filter="${g.key}">${h(g.label)} (${g.items.length})</button>`).join('')}</div><section class="box"><div class="row" style="justify-content:space-between"><h2>Pending Requests (${entries.length})</h2><button class="btn plain" id="refresh">↻ Refresh</button></div><div class="bp-approval-table-wrap"><table class="saved-table bp-approval-table"><thead><tr><th>Type</th><th>Request</th><th>Details</th><th>Submitted</th><th>Review</th></tr></thead><tbody>${entries.map(({g,item})=>`<tr><td>${h(g.label)}</td><td><strong>${h(title(g,item)||'Untitled')}</strong></td><td>${h(detail(g,item)||'—')}</td><td>${h(date(item))}</td><td><button class="btn small" type="button" data-approval-review="${g.key}">Review →</button></td></tr>`).join('')||'<tr><td colspan="5">No pending requests in this category.</td></tr>'}</tbody></table></div></section><p class="footnote">Approval and rejection continue to use existing permissions and review workflows. No automatic publication occurs here.</p></main>`;
 const logout=document.querySelector('#logout');if(logout)logout.onclick=()=>state.U.signOut(state.auth);
 const refresh=document.querySelector('#refresh');if(refresh)refresh.onclick=load;
}
document.addEventListener('click',e=>{
 const filter=e.target.closest('[data-approval-filter]');
 if(filter){bpApprovalFilter=filter.dataset.approvalFilter;state.view='approvals';bpApprovalCenter();return}
 const review=e.target.closest('[data-approval-review]');
 if(!review)return;
 const kind=review.dataset.approvalReview;
 if(kind==='business'){state.tab='pending';state.view='business'}
 else if(kind==='changes'){state.tab='changes';state.view='business'}
 else if(kind==='deals')state.view='offers';
 else if(kind==='properties'){state.extraTab='requests';state.view='community'}
 else if(kind==='jobs'){state.jobFilter='pending';state.view='jobs'}
 state.modal=null;panel();
});


// Phase 4C: read-only reports from records already loaded by the admin panel.
let bpAnalyticsRange='all';
function bpAnalyticsPanel(){
 const now=new Date(),today=now.toISOString().slice(0,10);
 const days=bpAnalyticsRange==='7'?7:bpAnalyticsRange==='30'?30:null;
 const start=days?new Date(now.getTime()-days*86400000):null;
 const stamp=x=>{if(!x)return null;if(typeof x.toDate==='function')return x.toDate();if(typeof x.seconds==='number')return new Date(x.seconds*1000);if(typeof x==='string'){const d=new Date(x);return Number.isNaN(d.getTime())?null:d}return null};
 const inRange=x=>!start||(stamp(x?.createdAt)&&stamp(x.createdAt)>=start);
 const list=(arr)=>Array.isArray(arr)?arr:[];
 const b=list(state.biz),o=list(state.offers),j=list(state.localJobs),p=list(state.propertyRequests),d=list(state.dealRequests);
 const activity=[['Businesses',b],['Jobs',j],['Property requests',p],['Deal requests',d]];
 const count=(arr,fn)=>arr.filter(fn).length;
 const n=x=>Number.isFinite(Number(x))?Math.max(0,Number(x)):0;
 const sum=(arr,key)=>arr.reduce((v,x)=>v+n(x[key]),0);
 const views=sum(b,'views'),calls=sum(b,'callClicks');
 const premium=b.filter(x=>x.plan==='premium'&&x.planStatus==='active'&&x.paymentStatus==='paid');
 const featured=o.filter(x=>x.status==='published'&&x.featured===true);
 const expired=o.filter(x=>x.status==='published'&&x.endDate&&x.endDate<today);
 const top=[...b].sort((a,z)=>n(z.views)-n(a.views)).slice(0,10);
 const activityRows=activity.map(([name,arr])=>({name,total:arr.length,dated:arr.filter(x=>stamp(x.createdAt)).length,period:arr.filter(inRange).length}));
 const monthly={};activity.forEach(([name,arr])=>arr.forEach(x=>{const dt=stamp(x.createdAt);if(!dt)return;const k=dt.toISOString().slice(0,7);(monthly[k]??={month:k})[name]=((monthly[k]||{})[name]||0)+1}));
 const months=Object.values(monthly).sort((a,z)=>z.month.localeCompare(a.month)).slice(0,12);
 const csv=(rows)=>rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
 window.bpDownloadAnalytics=()=>{const rows=[['Report','Metric','Value'],['Business','Total',b.length],['Business','Views (lifetime)',views],['Business','Call clicks (lifetime)',calls],['Business','Active paid premium',premium.length],['Deals','Published',count(o,x=>x.status==='published')],['Deals','Featured published',featured.length],['Deals','Expired published',expired.length],...activityRows.map(x=>['Activity '+(days?'last '+days+' days':'all time'),x.name,x.period]),[],['Top businesses','Name','Views','Call clicks'],...top.map(x=>['Business',x.name,n(x.views),n(x.callClicks)])];const blob=new Blob(['\uFEFF'+csv(rows)],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='baran-pride-analytics-'+today+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Read-only Analytics & Reports</p></div><div class="admin-header-actions"><button class="btn plain" data-view-mode="business">← Dashboard</button><button class="btn plain" id="logout">Sign Out</button></div></header><main class="bp-analytics"><div class="bp-analytics-heading"><div><h1>Analytics & Reports</h1><p class="label">Based on existing Firestore records; no new tracking or permissions.</p></div><div class="bp-analytics-controls"><select id="bp-analytics-range" aria-label="Activity date range"><option value="7" ${bpAnalyticsRange==='7'?'selected':''}>Last 7 days</option><option value="30" ${bpAnalyticsRange==='30'?'selected':''}>Last 30 days</option><option value="all" ${bpAnalyticsRange==='all'?'selected':''}>All time</option></select><button class="btn" id="bp-analytics-export">Export CSV</button><button class="btn plain" id="refresh">↻ Refresh</button></div></div><p class="bp-analytics-note">Views and call clicks are lifetime totals. Date filter applies to new-record activity only, not lifetime counters. Records without creation dates cannot be assigned to a date range.</p><div class="bp-analytics-cards">${[['Businesses',b.length],['Lifetime Views',views],['Lifetime Call Clicks',calls],['Active Paid Premium',premium.length],['Published Deals',count(o,x=>x.status==='published')],['Featured Deals',featured.length],['Expired Published Deals',expired.length],['Approved Active Jobs',count(j,x=>x.status==='approved'&&x.active===true)]].map(([k,v])=>`<div class="bp-analytics-card"><small>${h(k)}</small><strong>${v.toLocaleString('en-IN')}</strong></div>`).join('')}</div><section class="box"><h2>New Record Activity · ${days?'Last '+days+' days':'All Time'}</h2><div class="bp-analytics-scroll"><table class="saved-table"><thead><tr><th>Type</th><th>Selected period</th><th>All records</th><th>Missing creation date</th></tr></thead><tbody>${activityRows.map(x=>`<tr><td>${h(x.name)}</td><td>${x.period}</td><td>${x.total}</td><td>${x.total-x.dated}</td></tr>`).join('')}</tbody></table></div></section><section class="box"><h2>Top Businesses by Lifetime Views</h2><div class="bp-analytics-scroll"><table class="saved-table"><thead><tr><th>Business</th><th>Views</th><th>Call Clicks</th><th>Plan</th></tr></thead><tbody>${top.map(x=>`<tr><td>${h(x.name||'Unnamed')}</td><td>${n(x.views)}</td><td>${n(x.callClicks)}</td><td>${h(x.plan||'free')}</td></tr>`).join('')||'<tr><td colspan="4">No businesses yet.</td></tr>'}</tbody></table></div></section><section class="box"><h2>Monthly Submission Activity</h2><p class="label">Last 12 months with dated records, grouped by UTC month.</p><div class="bp-analytics-scroll"><table class="saved-table"><thead><tr><th>Month</th>${activity.map(x=>`<th>${h(x[0])}</th>`).join('')}</tr></thead><tbody>${months.map(x=>`<tr><td>${h(x.month)}</td>${activity.map(([k])=>`<td>${x[k]||0}</td>`).join('')}</tr>`).join('')||'<tr><td colspan="5">No dated activity available.</td></tr>'}</tbody></table></div></section><p class="footnote">Reports show only data currently accessible to the signed-in administrator. Historical daily views/clicks cannot be reconstructed from lifetime counters.</p></main>`;
 $('#bp-analytics-range').onchange=e=>{bpAnalyticsRange=e.target.value;bpAnalyticsPanel()};$('#bp-analytics-export').onclick=window.bpDownloadAnalytics;$('#refresh').onclick=load;$('#logout').onclick=()=>state.U.signOut(state.auth);
}

// Phase 4A: dashboard summaries reuse already-loaded collections; no extra Firebase reads.
function bpDashboardOverview(){
 const count=(items,pred)=>(items||[]).filter(pred).length;
 const pendingJobs=count(state.localJobs,x=>x.status==='pending');
 const pendingProperties=count(state.propertyRequests,x=>x.status==='pending');
 const pendingDeals=count(state.dealRequests,x=>x.status==='pending');
 const pendingChanges=count(state.changes,x=>x.status==='pending');
 const pendingBusinesses=count(state.biz,x=>x.status==='pending');
 const total=pendingJobs+pendingProperties+pendingDeals+pendingChanges+pendingBusinesses;
 const metrics=[
  ['Businesses',(state.biz||[]).length,'business'],
  ['Approved Businesses',count(state.biz,x=>x.status==='approved'),'business'],
  ['Published Deals',count(state.offers,x=>x.status==='published'),'offers'],
  ['Active Jobs',count(state.localJobs,x=>x.status==='approved'&&x.active===true),'jobs'],
  ['Listed Properties',count(state.propertyListings,x=>x.status==='approved'),'community'],
  ['Registered Profiles',(state.userProfiles||[]).length,'users']
 ];
 const queues=[
  ['All Pending Requests',total,'approvals'],
  ['Business Approvals',pendingBusinesses,'business'],
  ['Business Changes',pendingChanges,'business'],
  ['Deal Requests',pendingDeals,'offers'],
  ['Property Requests',pendingProperties,'community'],
  ['Job Requests',pendingJobs,'jobs']
 ];
 return `<section class="bp-dash-intro"><div><span class="bp-dash-eyebrow">ADMIN OVERVIEW</span><h2>City Management Dashboard</h2><p>Review activity and manage Baran Pride from one place.</p></div><div class="bp-dash-total"><small>Pending Actions</small><strong>${total}</strong></div></section>
 <section class="bp-dash-metrics" aria-label="Platform statistics">${metrics.map(([label,value,view])=>`<button type="button" class="bp-dash-stat" data-view-mode="${view}"><small>${label}</small><strong>${value}</strong><span>Open section →</span></button>`).join('')}</section>
 <div class="bp-dash-columns"><section class="bp-dash-panel"><h2>Approval Overview</h2><p>Pending items needing administrator review</p>${queues.map(([label,value,view])=>`<button class="bp-dash-queue" type="button" data-view-mode="${view}"><span>${label}</span><strong class="${value?'has-pending':''}">${value}</strong><span aria-hidden="true">›</span></button>`).join('')}</section><section class="bp-dash-panel"><h2>Quick Actions</h2><p>Open commonly used management screens</p><div class="bp-dash-actions">${[['Review Deals','offers'],['Manage Jobs','jobs'],['Homepage Banners','promotions'],['City Updates','notices'],['App Updates','appUpdate'],['Manage Users','users']].map(([label,view])=>`<button class="btn plain" type="button" data-view-mode="${view}">${label} →</button>`).join('')}</div></section></div>`;
}
function panel(){if(state.view==='analytics')return bpAnalyticsPanel();if(state.view==='approvals')return bpApprovalCenter();if(state.view==='jobs')return localJobsAdminPanel();if(state.view==='marketplace')return marketplaceAdminPanel();if(state.view==='appUpdate')return appUpdatePanel();if(state.view==='content')return contentPanel();if(state.view==='community')return communityPanel();if(state.view==='categories')return categoryPanel();if(state.view==='notices')return noticePanel();if(state.view==='promotions')return promotionsPanel();if(state.view==='offers')return offersPanel();if(state.view==='offers')return offersPanel();if(state.view==='social')return socialPanel();if(state.view==='voice')return voiceWelcomePanel();if(state.view==='urgent')return urgentAnnouncementPanel();if(state.view==='users')return usersPanel();let pending=state.biz.filter(x=>x.status==='pending').length, approved=state.biz.filter(x=>x.status==='approved').length, rejected=state.biz.filter(x=>x.status==='rejected').length, changePending=state.changes.filter(x=>x.status==='pending').length;
 let visible=state.tab==='all'?state.biz:state.tab==='changes'?state.changes.filter(x=>x.status==='pending'):state.biz.filter(x=>x.status===state.tab);
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Private approval and manual payment management</p></div><div class="admin-header-actions"><button class="btn" data-view-mode="jobs">💼 Local Jobs</button><button class="btn" data-view-mode="content">☰ City Content Manager</button><button class="btn plain" data-view-mode="categories">Business Categories</button><button class="btn plain" data-default-cover>Default Business Image</button><button class="btn plain" data-view-mode="notices">City Update</button><button class="btn plain" data-view-mode="promotions">Homepage Banners</button><button class="btn plain" data-view-mode="offers">Offers & Deals</button><button class="btn plain" data-view-mode="community">Property & Blood Donors</button><button class="btn plain" data-view-mode="social">Social Media</button><button class="btn plain" data-view-mode="voice">Voice Welcome</button><button class="btn plain" data-view-mode="urgent">Urgent Voice</button><button class="btn plain" data-view-mode="appUpdate">App Updates</button><button class="btn plain" data-view-mode="users">Users</button><button class="btn plain" id="logout">Sign Out</button></div></header><main><h1 style="margin:0;color:#122b51">Dashboard</h1><p class="label">Business listings and membership records</p>${bpDashboardOverview()}<div class="row"><h2>Approval Queue</h2><button class="btn plain" id="refresh">↻ Refresh</button></div><div class="tabs">${[['pending','Pending'],['approved','Approved'],['rejected','Rejected'],['all','All Businesses'],['changes','Change Requests']].map(([id,label])=>`<button class="tab ${state.tab===id?'active':''}" data-tab="${id}">${label}</button>`).join('')}</div><section>${visible.length?(state.tab==='changes'?visible.map(changeCard):visible.map(card)).join(''):'<div class="empty">No records in this section.</div>'}</section><p class="footnote">Security: only Firebase accounts with the admin custom claim can read/approve listings or record payments. No payment gateway is integrated.</p></main>${state.modal||''}`;
 $('#logout').onclick=()=>state.U.signOut(state.auth);
 $('#refresh').onclick=load;
}
async function load(){if(!state.user)return;try{const F=state.F;const [biz,chg,cont,requests,listings,donors,settings,notices,sliderMessages,offers]=await Promise.all([F.getDocs(F.collection(state.db,'businesses')),F.getDocs(F.collection(state.db,'changeRequests')),F.getDocs(F.collection(state.db,'cityContent')),F.getDocs(F.collection(state.db,'propertyRequests')),F.getDocs(F.collection(state.db,'propertyListings')),F.getDocs(F.collection(state.db,'bloodDonors')),F.getDoc(F.doc(state.db,'appSettings','public')),F.getDocs(F.collection(state.db,'appNotices')).catch(()=>({docs:[]})),F.getDocs(F.collection(state.db,'notificationSliderMessages')).catch(()=>({docs:[]})),F.getDocs(F.collection(state.db,'offers')).catch(()=>({docs:[]}))]);try{const req=await F.getDocs(F.collection(state.db,'dealRequests'));state.dealRequests=req.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0))}catch(e){state.dealRequests=[];console.warn('Deal requests unavailable: check Firestore rules',e)}try{const mp=await F.getDocs(F.collection(state.db,'marketplaceListings'));state.marketplaceListings=mp.docs.map(d=>({id:d.id,...d.data()})).sort((x,y)=>(y.createdAt?.seconds||0)-(x.createdAt?.seconds||0))}catch(e){state.marketplaceListings=[];console.warn('Marketplace admin list unavailable',e)}state.biz=biz.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));state.changes=chg.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));state.cityContent=cont.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>(b.updatedAt?.seconds||0)-(a.updatedAt?.seconds||0));state.propertyRequests=requests.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));state.propertyListings=listings.docs.map(x=>({id:x.id,...x.data()}));state.bloodDonors=donors.docs.map(x=>({id:x.id,...x.data()}));state.notices=notices.docs.map(x=>({id:x.id,...x.data()}));state.sliderMessages=sliderMessages.docs.map(x=>({id:x.id,...x.data()}));state.offerCategories=Array.isArray(settings.exists()?settings.data().offerCategories:null)?settings.data().offerCategories:[];state.offers=offers.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>(Number(b.featured)||0)-(Number(a.featured)||0)||(Number(a.displayOrder)||0)-(Number(b.displayOrder)||0));try{const promos=await F.getDocs(F.collection(state.db,'homePromotions'));state.promotions=promos.docs.map(x=>({id:x.id,...x.data()}))}catch(e){console.warn('Promotions unavailable',e);state.promotions=[]}state.customerCarePhone=settings.exists()?String(settings.data().customerCarePhone||'7737325205'):'7737325205';state.defaultBusinessCoverUrl=settings.exists()?String(settings.data().defaultBusinessCoverUrl||''):'';state.notificationSliderEnabled=settings.exists()?settings.data().notificationSliderEnabled!==false:true;state.notificationSliderTheme=settings.exists()?String(settings.data().notificationSliderTheme||'purple'):'purple';state.notificationSliderBackgroundColor=settings.exists()?String(settings.data().notificationSliderBackgroundColor||''):'';state.notificationSliderTextColor=settings.exists()?String(settings.data().notificationSliderTextColor||''):'';state.notificationSliderIconColor=settings.exists()?String(settings.data().notificationSliderIconColor||''):'';state.homeHeroImageUrl=settings.exists()?String(settings.data().homeHeroImageUrl||''):'';try{const catSnap=await F.getDocs(F.collection(state.db,'businessCategories'));state.businessCategories=catSnap.docs.map(d=>({id:d.id,...d.data()}))}catch(e){console.warn('Category collection requires updated rules',e);state.businessCategories=[]}try{const up=await F.getDocs(F.collection(state.db,'userProfiles'));state.userProfiles=up.docs.map(x=>({id:x.id,...x.data()}))}catch(e){state.userProfiles=[];console.warn('User profiles unavailable',e)}state.socialLinks=settings.exists()?settings.data().socialLinks||{}:{};state.voiceWelcomeEnabled=settings.exists()?settings.data().voiceWelcomeEnabled!==false:true;state.voiceWelcomeFrequency=settings.exists()?String(settings.data().voiceWelcomeFrequency||'daily'):'daily';state.voiceWelcomeLanguage=settings.exists()?String(settings.data().voiceWelcomeLanguage||'mix'):'mix';state.voiceWelcomeMessage=settings.exists()?String(settings.data().voiceWelcomeMessage||'Welcome to Baran Pride! आपका अपना शहर, आपकी अपनी डायरेक्टरी।'):'Welcome to Baran Pride! आपका अपना शहर, आपकी अपनी डायरेक्टरी।';state.voiceWelcomeAudioUrl=settings.exists()?String(settings.data().voiceWelcomeAudioUrl||''):'';state.urgentAnnouncement=settings.exists()?settings.data().urgentAnnouncement||null:null;state.shutterBanner=settings.exists()?settings.data().shutterBanner||{enabled:false,imageUrl:'',linkUrl:''}:{enabled:false,imageUrl:'',linkUrl:''};state.appUpdate=settings.exists()?settings.data().appUpdate||{enabled:false,mode:'normal',latestVersionCode:1,latestVersionName:'1.0',message:'A new version of Baran Pride is available.',playStoreUrl:''}:{enabled:false,mode:'normal',latestVersionCode:1,latestVersionName:'1.0',message:'A new version of Baran Pride is available.',playStoreUrl:''};try{const logSnap=await F.getDocs(F.query(F.collection(state.db,'accountRecoveryLogs'),F.orderBy('createdAt','desc'),F.limit(40)));state.recoveryLogs=logSnap.docs.map(x=>({id:x.id,...x.data()}))}catch(err){console.warn('Recovery logs unavailable',err);state.recoveryLogs=[]}try{const jobSnap=await F.getDocs(F.collection(state.db,'localJobs'));state.localJobs=jobSnap.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0))}catch(e){state.localJobs=[];console.warn('Local Jobs unavailable; deploy admin rules',e);if(state.view==='jobs')toast('Local Jobs access unavailable: check Firestore rules')}state.modal=null;panel()}catch(err){toast('Cannot load admin records: '+err.message)}}
function openModal(title,body,actions=''){state.modal=`<div class="modalwrap" id="modal"><div class="modal"><h2>${h(title)}</h2>${body}<div class="row"><button class="btn plain" id="close-modal">Cancel</button>${actions}</div></div></div>`;panel();$('#close-modal').onclick=()=>{state.modal=null;panel()}}
function detail(b){openModal('Business Details',`<p><b>Name:</b> ${h(b.name)}</p><p><b>Category:</b> ${h(b.category)}</p><p><b>Area:</b> ${h(b.area)}</p><p><b>Address:</b> ${h(b.address)}</p><p><b>Phone:</b> ${h(b.phone)}</p><p><b>WhatsApp:</b> ${h(b.whatsapp)}</p><p><b>Hours:</b> ${h(b.hours)}</p><p><b>Description:</b> ${h(b.description)}</p><p><b>Status:</b> ${h(b.status)} · <b>Plan:</b> ${h(b.plan)} · <b>Payment:</b> ${h(b.paymentStatus)}</p>${(b.photoUrls?.length?b.photoUrls:(b.cover?[b.cover]:[])).map(url=>`<img alt="Business uploaded photo" src="${h(url)}" style="width:100px;height:70px;object-fit:cover;border-radius:8px;margin:4px">`).join('')}`)}
async function approve(id){const b=state.biz.find(x=>x.id===id);if(!b)return;
 if(b.plan!=='free'&&b.paymentStatus!=='paid')return toast('Paid plan needs manually confirmed payment first');
 if(!confirm('Approve '+b.name+'?'))return;
 try{await state.F.updateDoc(state.F.doc(state.db,'businesses',id),{status:'approved',planStatus:'active',updatedAt:state.F.serverTimestamp()});toast('Business approved');await load()}catch(e){toast(e.message)}
}
async function reject(id){const b=state.biz.find(x=>x.id===id);if(!b)return;if(!confirm('Reject '+b.name+'?'))return;
 try{await state.F.updateDoc(state.F.doc(state.db,'businesses',id),{status:'rejected',planStatus:'inactive',updatedAt:state.F.serverTimestamp()});toast('Listing rejected');await load()}catch(e){toast(e.message)}
}
function payment(b){openModal('Record Verified Manual Payment — '+b.name,`<p class="label">Record payment only after you independently verify Cash, UPI or Bank Transfer. This is NOT a payment collection form.</p><form id="payment-form"><div class="formgrid"><label class="field"><span>Plan *</span><select name="plan" required><option value="premium" ${b.plan==='premium'?'selected':''}>Premium</option></select></label><label class="field"><span>Amount received (₹) *</span><input name="amount" type="number" min="1" step="0.01" value="${h(b.paidAmount||499)}" required></label><label class="field"><span>Payment Method *</span><select name="method" required><option>UPI</option><option>Cash</option><option>Bank Transfer</option></select></label><label class="field"><span>Payment Reference / Receipt *</span><input name="reference" required maxlength="120" placeholder="UTR or cash receipt number"></label><label class="field"><span>Validity (months) *</span><select name="months"><option value="12">12 months</option><option value="6">6 months</option><option value="3">3 months</option></select></label><label class="field"><span>Internal Note (optional)</span><input name="note" maxlength="300" placeholder="Verified by / remarks"></label></div><button type="submit" class="btn green" style="width:100%;margin-top:15px">Confirm & Record Payment</button></form>`);
 $('#payment-form').onsubmit=async e=>{e.preventDefault();let vals=Object.fromEntries(new FormData(e.target)),amount=Number(vals.amount),months=Number(vals.months);if(!(amount>0&&months>=1))return toast('Check payment amount and validity');if(!confirm('Have you verified payment of ₹'+amount+' from '+b.name+'?'))return;let btn=$('#payment-form button[type=submit]');btn.disabled=true;
  try{const F=state.F,expires=new Date();expires.setMonth(expires.getMonth()+months);const batch=F.writeBatch(state.db);const record=F.doc(F.collection(state.db,'paymentHistory'));
   batch.set(record,{businessId:b.id,businessName:b.name,ownerUid:b.ownerUid,amount,method:vals.method,reference:vals.reference,plan:vals.plan,months,note:vals.note||'',verifiedBy:state.user.uid,paidAt:F.serverTimestamp(),expiresAt:F.Timestamp.fromDate(expires)});
   batch.update(F.doc(state.db,'businesses',b.id),{plan:vals.plan,featured:vals.plan==='premium',paymentStatus:'paid',planStatus:b.status==='approved'?'active':'inactive',paidAmount:amount,paymentMethod:vals.method,paymentReference:vals.reference,paidAt:F.serverTimestamp(),expiresAt:F.Timestamp.fromDate(expires),updatedAt:F.serverTimestamp()});
   await batch.commit();toast('Payment verified and recorded');await load();
  }catch(err){toast('Payment not recorded: '+err.message);btn.disabled=false}
 }
}
function activePremium(b){return b.plan==='premium'&&b.planStatus==='active'&&b.paymentStatus==='paid'&&(typeof b.expiresAt?.toMillis==='function'&&b.expiresAt.toMillis()>Date.now())}
function businessPhotos(b){
 const limit=activePremium(b)?5:2,urls=Array.isArray(b.photoUrls)?b.photoUrls:[];
 openModal('Manage Photos — '+b.name,`<p>Plan: ${activePremium(b)?'Premium':'Free'} · ${urls.length} / ${limit} photos</p><form id="admin-business-photos"><div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px">${urls.map((u,i)=>`<label style="min-width:0"><img src="${h(u)}" style="width:100%;height:80px;object-fit:cover"><span style="font-size:11px"><input type="checkbox" name="remove" value="${h(u)}"> Remove</span><br><input type="radio" name="cover" value="${h(u)}" ${u===(b.cover||urls[0])?'checked':''}> Cover</label>`).join('')}</div><p class="label">Add JPG/PNG/WebP images (under 5 MB each; optimized to WebP)</p><input type="file" name="photos" accept="image/jpeg,image/png,image/webp" multiple><p class="label">You can select a new cover after uploading by opening Manage Photos again.</p><button class="btn green" type="submit">Save Photos</button></form>`);
 $('#admin-business-photos').onsubmit=async e=>{
  e.preventDefault();const f=e.target,files=[...f.elements.photos.files],remove=[...f.querySelectorAll('input[name=remove]:checked')].map(x=>x.value),kept=urls.filter(u=>!remove.includes(u));
  if(kept.length+files.length>limit)return toast('Maximum '+limit+' photos allowed');
  if(files.some(x=>!/^image\/(jpeg|png|webp)$/i.test(x.type)||x.size>=5*1024*1024))return toast('Use JPG, PNG or WebP under 5 MB');
  const btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.textContent='Saving...';const S=state.S,F=state.F,added=[];
  try{
   for(const originalFile of files){const file=await bpOptimizeBusinessPhoto(originalFile);const path='businesses/'+b.ownerUid+'/'+b.id+'/'+Date.now()+'-'+Math.random().toString(36).slice(2)+'-'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');const ref=S.ref(state.storage,path);await S.uploadBytes(ref,file,{contentType:file.type});added.push(await S.getDownloadURL(ref))}
   const all=[...kept,...added],wanted=f.querySelector('input[name=cover]:checked')?.value,cover=all.includes(wanted)?wanted:all[0]||'';
   await F.updateDoc(F.doc(state.db,'businesses',b.id),{photoUrls:all,cover,updatedAt:F.serverTimestamp()});
   for(const url of remove){if(!urls.includes(url))continue;try{await S.deleteObject(S.ref(state.storage,url))}catch(err){console.warn('Storage cleanup',err)}}
   state.modal=null;toast('Business photos updated');await load();
  }catch(err){for(const url of added){try{await S.deleteObject(S.ref(state.storage,url))}catch(_){}}toast('Photo update failed: '+err.message);btn.disabled=false;btn.textContent='Save Photos'}
 };
}
async function downgradeFree(b){if(!confirm('Change '+b.name+' to Free? Extra photos and categories will be preserved but hidden from public listings.'))return;try{await state.F.updateDoc(state.F.doc(state.db,'businesses',b.id),{plan:'free',featured:false,planStatus:'inactive',paymentStatus:'unpaid',updatedAt:state.F.serverTimestamp()});toast('Business changed to Free');await load()}catch(e){toast(e.message)}}
function businessCategoryEdit(b){
 const limit=activePremium(b)?3:1,selected=Array.isArray(b.categories)&&b.categories.length?b.categories:[b.category];
 const seed=['Shopping','Doctors','Restaurants','Education','Property','Services','Automobile','Jobs','Hotels','Temples','Medical','Beauty Parlour','Electronics','Clothing','Hardware','Gym','Photography','Printing & Stationery','Grocery','Real Estate','Others'];const names=[...new Set([...seed,...state.businessCategories.filter(x=>x.active).map(x=>x.name),...selected,b.category].filter(Boolean))];
 openModal('Business Categories — '+b.name,`<p>${activePremium(b)?'Premium: up to 3':'Free: 1'} category</p><form id="admin-business-categories">${names.map(c=>`<label class="field"><span><input type="checkbox" name="categories" value="${h(c)}" ${selected.includes(c)?'checked':''}> ${h(c)}</span></label>`).join('')}<button class="btn green" type="submit">Save Categories</button></form>`);
 $('#admin-business-categories').onsubmit=async e=>{e.preventDefault();const arr=[...e.target.querySelectorAll('input[name=categories]:checked')].map(x=>x.value);if(!arr.length||arr.length>limit)return toast('Select 1 to '+limit+' categories');try{await state.F.updateDoc(state.F.doc(state.db,'businesses',b.id),{category:arr[0],categories:arr,updatedAt:state.F.serverTimestamp()});state.modal=null;toast('Categories updated');await load()}catch(err){toast(err.message)}};
}
async function changeStatus(id,approved){let r=state.changes.find(x=>x.id===id);if(!r)return;if(!confirm((approved?'Approve':'Reject')+' requested changes?'))return;try{let F=state.F,batch=F.writeBatch(state.db);if(approved){batch.update(F.doc(state.db,'businesses',r.businessId),{...r.patch,updatedAt:F.serverTimestamp()})}batch.update(F.doc(state.db,'changeRequests',id),{status:approved?'approved':'rejected',reviewedAt:F.serverTimestamp(),reviewedBy:state.user.uid});await batch.commit();toast(approved?'Changes approved':'Changes rejected');await load()}catch(e){toast(e.message)}}

// V2 private content manager: only admin-authenticated web sessions can reach these screens.
const CONTENT_TYPES=[['historical','Historical Places'],['blogs','Blogs & Articles'],['tourist','Tourist Places'],['events','Events & Festivals'],['updates','City Updates'],['contacts','Important Contacts'],['about','About Baran']];
const contentName=(v)=>CONTENT_TYPES.find(x=>x[0]===v)?.[1]||'City Information';
const validHttps=(v)=>{if(!v)return'';try{let x=new URL(v);return x.protocol==='https:'?x.href:''}catch{return ''}};
function previewText(v){return h(v).replace(/\r?\n/g,'<br>')}
function contentPanel(){
 const items=state.cityContent.filter(x=>x.type===state.cityType && (x.title+' '+x.summary+' '+x.area).toLowerCase().includes(state.contentFilter.toLowerCase())).sort((a,b)=>state.cityType==='about'?(Number(a.displayOrder??9999)-Number(b.displayOrder??9999)||String(a.title).localeCompare(String(b.title))):state.cityType==='updates'?((b.publishedAt?.seconds||b.createdAt?.seconds||0)-(a.publishedAt?.seconds||a.createdAt?.seconds||0)):0);
 const counts={published:state.cityContent.filter(x=>x.status==='published').length,draft:state.cityContent.filter(x=>x.status==='draft').length};
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Private City Content Manager</p></div><div class="admin-header-actions"><button class="btn plain" data-view-mode="business">← Business Approval</button><button class="btn" data-view-mode="community">Property & Blood Donors</button><button class="btn plain" id="logout">Sign Out</button></div></header><main class="content-manager"><div class="row content-title"><div><h1 style="margin:0;color:#122b51">City Information</h1><p class="label">Only Admin can create, edit and publish content to the Android app.</p></div><button class="btn green" data-content-add>+ Add Content</button></div><section class="cards"><div class="metric"><small>Total Articles</small><strong>${state.cityContent.length}</strong></div><div class="metric"><small>Published</small><strong>${counts.published}</strong></div><div class="metric"><small>Drafts</small><strong>${counts.draft}</strong></div><div class="metric"><small>Sections</small><strong>${CONTENT_TYPES.length}</strong></div></section><div class="tabs">${CONTENT_TYPES.map(([id,name])=>`<button class="tab ${state.cityType===id?'active':''}" data-content-type="${id}">${name}</button>`).join('')}</div><div class="row content-find"><h2>${h(contentName(state.cityType))}</h2><input id="content-search" aria-label="Search content" placeholder="Search title or area" value="${h(state.contentFilter)}"></div><section>${items.length?items.map(x=>`<article class="listing content-listing">${validHttps(x.cover)?`<img src="${h(validHttps(x.cover))}" alt="">`:'<div class="content-thumbnail">▤</div>'}<div><h3>${h(x.title)} ${status(x.status)}</h3><p>${h(x.area||contentName(x.type))} · ${h(x.summary||'No summary')}</p>${x.type==='about'?`<p><strong>Display Order: ${h(x.displayOrder??'Not set')}</strong></p>`:''}<p>${(x.photos||[]).length} photo(s) · ${x.featured?'Featured':'Regular'}${x.showOnHomepage&&x.status==='published'?' · ★ On Homepage (Order '+h(x.homeOrder??100)+')':''}</p></div><div class="actions">${x.type==='about'?`<button class="btn plain small" data-about-move="${h(x.id)}" data-direction="up" title="Move up">↑</button><button class="btn plain small" data-about-move="${h(x.id)}" data-direction="down" title="Move down">↓</button>`:''}<button class="btn plain small" data-content-preview="${h(x.id)}">Preview</button><button class="btn small" data-content-edit="${h(x.id)}">Edit</button>${['events','historical','blogs','updates'].includes(x.type)&&x.status==='published'?`<button class="btn plain small" data-home-publish="${h(x.id)}">${x.showOnHomepage?'Remove from Home':'Show on Home'}</button>`:''}<button class="btn ${x.status==='published'?'warn':'green'} small" data-content-toggle="${h(x.id)}">${x.status==='published'?'Unpublish':'Publish'}</button><button class="btn red small" data-content-delete="${h(x.id)}">Delete</button></div></article>`).join(''):'<div class="empty">इस सेक्शन में अभी कोई जानकारी नहीं है। <br>“Add Content” से नया लेख जोड़ें।</div>'}</section><p class="footnote">Drafts are private. Only Published items are visible in the Android app. This does not change existing business listings or manual payments.</p></main>${state.cityEdit!==null?contentEditor():''}${state.modal||''}`;
 $('#logout').onclick=()=>state.U.signOut(state.auth);
}
function contentEditor(){const old=state.cityEdit==='new'?{}:state.cityContent.find(x=>x.id===state.cityEdit)||{};const type=old.type||state.cityType;
 if(type==='contacts')return `<div class="content-editor-wrap"><div class="content-editor"><div class="row"><h2>${old.id?'Edit':'Add'} Important Contact</h2><button class="btn plain" data-content-cancel>✕ Close</button></div><form id="city-content-form"><input type="hidden" name="type" value="contacts"><label class="field"><span>Contact / Department Name *</span><input name="title" required maxlength="140" value="${h(old.title||'')}"></label><label class="field"><span>Short Description *</span><input name="summary" required maxlength="350" value="${h(old.summary||'')}" placeholder="e.g. Medical Emergency"></label><label class="field"><span>Phone Number *</span><input name="phone" required maxlength="16" value="${h(old.phone||'')}" inputmode="tel" placeholder="Verified public number"></label><div class="formgrid"><label class="field"><span>Category</span><input name="contactCategory" list="bp-contact-category-suggestions" required maxlength="70" value="${h(old.contactCategory||old.area||'Public')}" placeholder="Type or choose category"><datalist id="bp-contact-category-suggestions">${[...new Set(['Medical','Government','Public','Utilities','Other',...state.cityContent.filter(x=>x.type==='contacts'&&x.contactCategory&&x.contactCategory.toLowerCase()!=='emergency').map(x=>x.contactCategory)])].map(c=>`<option value="${h(c)}">`).join('')}</datalist><small>नई Category बनाने के लिए नया नाम लिखें। Contact Publish करने पर Category App में अपने आप दिखेगी।</small></label><label class="field"><span>Display Order</span><input name="homeOrder" type="number" min="0" max="999" value="${h(old.homeOrder??100)}"></label></div><label class="content-check"><input name="featured" type="checkbox" ${old.featured?'checked':''}> Show directly in Emergency Helplines (no category card)</label><p class="label">Publish = visible in app. Save Draft = hidden. No location is displayed.</p><div class="content-editor-actions"><button class="btn plain" type="submit" name="saveMode" value="draft">Save Draft / Hide</button><button class="btn green" type="submit" name="saveMode" value="published">Publish / Show</button></div></form></div></div>`;

 return `<div class="content-editor-wrap"><div class="content-editor"><div class="row"><h2>${old.id?'Edit':'Add'} City Information</h2><button class="btn plain" data-content-cancel>✕ Close</button></div><p class="label">Text and photos are visible to visitors only after Publish. Choose Draft to save privately.</p><form id="city-content-form"><div class="formgrid"><label class="field"><span>Section *</span><select name="type" required>${CONTENT_TYPES.map(([id,name])=>`<option value="${id}" ${type===id?'selected':''}>${name}</option>`).join('')}</select></label><label class="field"><span>Title *</span><input name="title" required maxlength="140" value="${h(old.title||'')}" placeholder="हिंदी या English नाम"></label></div><label class="field"><span>Short Description *</span><textarea name="summary" required maxlength="350" placeholder="List card में दिखाई देने वाला छोटा विवरण">${h(old.summary||'')}</textarea></label>${type==='about'?`<label class="field"><span>Display Order (smaller number appears first)</span><input name="displayOrder" type="number" min="1" max="99999" step="1" value="${h(old.displayOrder??state.cityContent.filter(x=>x.type==='about').length+1)}"></label>`:''}<label class="field"><span>Full Article / Historical Details *</span><textarea class="full-content" name="body" required minlength="20" maxlength="20000" placeholder="इतिहास, विस्तृत जानकारी, यात्रा निर्देश...">${h(old.body||'')}</textarea></label><div class="formgrid"><label class="field"><span>Area / Tehsil</span><input name="area" maxlength="100" value="${h(old.area||'')}" placeholder="Shahabad, Baran"></label><label class="field"><span>Full Address / Landmark</span><input name="placeAddress" maxlength="300" value="${h(old.placeAddress||'')}"></label><label class="field"><span>Google Maps Link (https only)</span><input name="mapUrl" type="url" value="${h(old.mapUrl||'')}" placeholder="https://maps.google.com/..."></label><label class="field"><span>Event Date / Visiting Hours</span><input name="eventDate" maxlength="100" value="${h(old.eventDate||'')}" placeholder="Only if verified"></label><label class="field"><span>Event Start Date</span><input type="date" name="startDate" value="${h(old.startDate||'')}"></label><label class="field"><span>Event End Date</span><input type="date" name="endDate" value="${h(old.endDate||'')}"></label><label class="field"><span>Contact Number (optional)</span><input name="phone" maxlength="16" value="${h(old.phone||'')}" placeholder="Public information only"></label><label class="field"><span>Photos (up to 5, each ≤ 5 MB)</span><input name="photos" accept="image/*" type="file" multiple><small>Choosing new photos replaces the existing gallery. Leave empty to keep existing photos.</small></label></div>${old.photos?.length?`<div class="content-image-preview">${old.photos.filter(validHttps).map(p=>`<img src="${h(validHttps(p))}" alt="Existing photo">`).join('')}</div>`:''}<label class="content-check"><input name="featured" type="checkbox" ${old.featured?'checked':''}> Feature this content within its category</label><div class="home-display-options" id="home-display-options" ${['events','historical','blogs','updates'].includes(type)?'':'hidden'}><label class="content-check"><input name="showOnHomepage" type="checkbox" ${old.showOnHomepage?'checked':''}> <strong>Show on Homepage</strong> (Admin selected)</label><label class="field"><span>Homepage display order (smaller first)</span><input name="homeOrder" type="number" min="0" max="999" step="1" value="${h(old.homeOrder??100)}"></label><p class="label">Visible on Home only when Published. Other published items remain in View All.</p></div><div class="content-editor-actions"><button class="btn plain" type="submit" name="saveMode" value="draft">Save Draft</button><button class="btn green" type="submit" name="saveMode" value="published">Publish</button></div></form></div></div>`
}
function previewContent(id){const x=state.cityContent.find(z=>z.id===id);if(!x)return;openModal('Content Preview',`${validHttps(x.cover)?`<img src="${h(validHttps(x.cover))}" style="width:100%;height:200px;object-fit:cover;border-radius:10px" alt="">`:''}<h3>${h(x.title)}</h3><p>${h(x.summary||'')}</p><div style="white-space:pre-wrap;line-height:1.7;overflow-wrap:anywhere">${previewText(x.body||'')}</div><p class="label">${h(contentName(x.type))} · ${h(x.area)} · ${h(x.status)}</p>`)}
async function saveCityContent(e){e.preventDefault();if(!state.user)return;const f=e.target,fd=new FormData(f),mode=e.submitter?.value||'draft';const type=String(fd.get('type')||'');if(!CONTENT_TYPES.some(x=>x[0]===type))return toast('Select a valid section');const mapInput=String(fd.get('mapUrl')||'').trim(),mapUrl=validHttps(mapInput);if(mapInput&&!mapUrl)return toast('Google Maps URL must start with https://');
 const files=[...(f.querySelector('[name=photos]')?.files||[])];if(files.length>5||files.some(x=>!x.type.startsWith('image/')||x.size>5*1024*1024))return toast('Maximum 5 photos, 5 MB each (image files only)');
 const old=state.cityContent.find(x=>x.id===state.cityEdit)||{},F=state.F;const id=old.id||F.doc(F.collection(state.db,'cityContent')).id;
 const payload={type,displayOrder:type==='about'?Math.max(1,Math.min(99999,Math.round(Number(fd.get('displayOrder'))||Number(old.displayOrder)||state.cityContent.filter(x=>x.type==='about').length+1))):old.displayOrder??null,contactCategory:type==='contacts'?String(fd.get('contactCategory')||'Public'):'',title:String(fd.get('title')||'').trim(),summary:String(fd.get('summary')||'').trim(),body:String(fd.get('body')||'').trim(),area:type==='contacts'?String(fd.get('contactCategory')||'Public'):String(fd.get('area')||'').trim(),placeAddress:String(fd.get('placeAddress')||'').trim(),mapUrl,eventDate:String(fd.get('eventDate')||'').trim(),startDate:type==='events'?String(fd.get('startDate')||''):'',endDate:type==='events'?String(fd.get('endDate')||''):'',phone:String(fd.get('phone')||'').trim(),featured:fd.get('featured')==='on',showOnHomepage:['events','historical','blogs','updates'].includes(type)&&fd.get('showOnHomepage')==='on',homeOrder:Math.max(0,Math.min(999,Math.round(Number(fd.get('homeOrder'))||100))),status:mode,updatedAt:F.serverTimestamp(),authorUid:state.user.uid};
 if(type==='events'&&payload.startDate&&payload.endDate&&payload.endDate<payload.startDate)return toast('End date cannot be before start date');
 if(type==='contacts'){payload.contactCategory=payload.contactCategory.trim();if(!payload.contactCategory||payload.contactCategory.length>70)return toast('Enter a valid category');if(payload.contactCategory.toLowerCase()==='emergency')payload.featured=true;if(payload.title.length<3||payload.summary.length<3||!/^\+?[0-9\s-]{3,16}$/.test(payload.phone))return toast('Enter contact name, description and valid phone number');payload.body=payload.summary;}else if(payload.title.length<3||payload.summary.length<5||payload.body.length<20)return toast('Please complete the title, summary and full article');
 if(!old.id)payload.createdAt=F.serverTimestamp();if(mode==='published'&&old.status!=='published')payload.publishedAt=F.serverTimestamp();
 if(files.length){const urls=[],paths=[];for(let i=0;i<files.length;i++){
  const file=files[i],fileName=file.name.replace(/[^a-zA-Z0-9._-]/g,'_').slice(-90),path=`cityContent/${id}/${Date.now()}-${i}-${fileName}`;
  paths.push(path);const ref=state.S.ref(state.storage,path);
  try{await state.S.uploadBytes(ref,file,{contentType:file.type});urls.push(await state.S.getDownloadURL(ref))}
  catch(err){toast('Photo upload failed: '+err.message);return}
 }payload.photos=urls;payload.photoPaths=paths;payload.cover=urls[0]||'';
 }else if(!old.id){payload.photos=[];payload.photoPaths=[];payload.cover=''}
 f.querySelectorAll('button[type=submit]').forEach(b=>b.disabled=true);
 try{await F.setDoc(F.doc(state.db,'cityContent',id),payload,{merge:true});state.cityType=type;state.cityEdit=null;state.contentFilter='';toast(mode==='published'?'Published to Android app':'Saved as private draft');await load()}
 catch(err){toast('Cannot save content: '+err.message);f.querySelectorAll('button[type=submit]').forEach(b=>b.disabled=false)}
}
async function moveAboutContent(id,direction){
 const items=state.cityContent.filter(x=>x.type==='about').sort((a,b)=>Number(a.displayOrder??9999)-Number(b.displayOrder??9999)||String(a.title).localeCompare(String(b.title)));
 const index=items.findIndex(x=>x.id===id),next=index+(direction==='up'?-1:1);
 if(index<0||next<0||next>=items.length)return;
 // Normalize the sequence in one atomic Firestore batch, including older posts without displayOrder.
 const reordered=[...items];[reordered[index],reordered[next]]=[reordered[next],reordered[index]];
 try{const F=state.F,batch=F.writeBatch(state.db);reordered.forEach((item,i)=>batch.update(F.doc(state.db,'cityContent',item.id),{displayOrder:i+1}));await batch.commit();toast('About Baran order saved');await load()}
 catch(e){toast('Unable to save order: '+e.message)}
}
async function toggleCityContent(id){const x=state.cityContent.find(x=>x.id===id);if(!x)return;const newStatus=x.status==='published'?'draft':'published';if(!confirm((newStatus==='published'?'Publish ':'Unpublish ')+x.title+'?'))return;
 try{await state.F.updateDoc(state.F.doc(state.db,'cityContent',id),{status:newStatus,updatedAt:state.F.serverTimestamp(),...(newStatus==='published'&&x.status!=='published'?{publishedAt:state.F.serverTimestamp()}:{})});toast(newStatus==='published'?'Published':'Unpublished');await load()}catch(e){toast(e.message)}
}
async function toggleHomepageCity(id){
 const x=state.cityContent.find(v=>v.id===id);if(!x||!['events','historical','blogs','updates'].includes(x.type))return;
 if(x.status!=='published')return toast('Publish this item before adding it to the Homepage');
 try{await state.F.updateDoc(state.F.doc(state.db,'cityContent',id),{showOnHomepage:!x.showOnHomepage,updatedAt:state.F.serverTimestamp()});toast(x.showOnHomepage?'Removed from Homepage':'Added to Homepage');await load()}
 catch(e){toast('Could not update Homepage: '+e.message)}
}
async function deleteCityContent(id){const x=state.cityContent.find(x=>x.id===id);if(!x)return;if(!confirm('Permanently delete '+x.title+'?'))return;
 try{await state.F.deleteDoc(state.F.doc(state.db,'cityContent',id));for(const p of (x.photoPaths||[])){try{await state.S.deleteObject(state.S.ref(state.storage,p))}catch(err){console.warn('Cleanup photo failed',err)}}toast('Content deleted');await load()}catch(err){toast('Cannot delete: '+err.message)}
}


// V3: PRIVATE property approvals, PUBLIC opt-in blood donor records, ADMIN helpline config.
const BLOOD_GROUPS=['A+','A-','B+','B-','AB+','AB-','O+','O-'];
const tenDigit=v=>/^[6-9][0-9]{9}$/.test(String(v||'').trim());
function communityPanel(){const pending=state.propertyRequests.filter(x=>x.status==='pending').length,published=state.bloodDonors.filter(x=>x.status==='published'&&x.publicConsent).length;
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Private Property, Blood Donors & Helpline</p></div><div class="admin-header-actions"><button class="btn plain" data-view-mode="business">← Business Approval</button><button class="btn plain" data-view-mode="content">City Content</button><button class="btn plain" id="logout">Sign Out</button></div></header><main><h1 style="margin:0;color:#122b51">Property & Blood Donors</h1><p class="label">Seller name is always private. Seller phone is shown only if Admin selects it and verified seller consent is recorded.</p><section class="cards"><div class="metric"><small>Pending Properties</small><strong>${pending}</strong></div><div class="metric"><small>Live Properties</small><strong>${state.propertyListings.filter(x=>x.status==='approved'&&(!propertyExpiryMillis(x)||propertyExpiryMillis(x)>Date.now())).length}</strong></div><div class="metric"><small>Published Donors</small><strong>${published}</strong></div><div class="metric"><small>Customer Care</small><strong style="font-size:15px">${h(state.customerCarePhone||'Not Set')}</strong></div></section><div class="tabs">${[['requests','Property Requests'],['listings','Live Properties'],['donors','Blood Donors'],['helpline','Customer Care']].map(([id,label])=>`<button class="tab ${state.extraTab===id?'active':''}" data-extra-tab="${id}">${label}</button>`).join('')}</div>${communityBody()}</main>${state.donorEdit!==null?donorEditor():''}${state.propertyContactEdit!==null?propertyContactEditor():''}${state.modal||''}`;
 $('#logout').onclick=()=>state.U.signOut(state.auth)
}
function propertyAdminPhotos(item){
 const urls=[...(Array.isArray(item?.photoUrls)?item.photoUrls:[]),item?.coverImage,item?.coverUrl,item?.imageUrl].filter(u=>typeof u==='string'&&/^https:\/\//i.test(u));
 return [...new Set(urls)];
}
function propertyAdminThumb(item){const u=propertyAdminPhotos(item)[0];return u?`<div class="content-thumbnail"><img src="${h(u)}" alt="Property photo" loading="lazy" style="width:100%;height:100%;object-fit:cover;border-radius:8px" onerror="this.parentNode.textContent='🏠'"></div>`:'<div class="content-thumbnail">🏠</div>'}
function propertyAdminGallery(item){const urls=propertyAdminPhotos(item);return `<div style="grid-column:1/-1;margin:8px 0"><strong>Property Photos (${urls.length})</strong>${urls.length?`<div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px">${urls.map((u,i)=>`<a href="${h(u)}" target="_blank" rel="noopener noreferrer" title="Open photo ${i+1}"><img src="${h(u)}" alt="Property photo ${i+1}" loading="lazy" style="width:100px;height:80px;object-fit:cover;border-radius:8px;border:1px solid #ddd" onerror="this.style.display='none'"></a>`).join('')}</div>`:'<p class="label">No uploaded photo URL found. Check original request upload.</p>'}</div>`}
function communityBody(){if(state.extraTab==='requests')return `<h2>Property Sale Requests</h2><p class="label">Only Admin can see owner contact details. Call to verify ownership before approval.</p>${state.propertyRequests.length?state.propertyRequests.map(r=>`<article class="listing">${propertyAdminThumb(r)}<div><h3>${h(r.propertyType)} · ${h(r.area)} ${status(r.status)}</h3><p>Size: ${h(r.size||'—')} · ₹${Number(r.askingPrice||0).toLocaleString('en-IN')}</p><p>${h(r.description||'')}</p><p class="private-row"><b>PRIVATE Owner:</b> ${h(r.ownerName)} · <b>${h(r.ownerPhone)}</b></p>${propertyAdminGallery(r)}<p><b>Visibility:</b> ${h(propertyExpiryLabel(state.propertyListings.find(x=>x.id===r.id)))}</p><p><b>Owner public-phone consent:</b> ${r.publicPhoneConsent?'YES — recorded':'NO — do not publish phone'}</p></div><div class="actions"><button class="btn green small" data-property-contact="${h(r.id)}">${r.status==='approved'?'Edit Contact':'Approve / Contact'}</button>${r.status==='pending'?`<button class="btn red small" data-property-reject="${h(r.id)}">Reject</button>`:''}${r.status==='approved'?`<button class="btn warn small" data-property-hide="${h(r.id)}">Unpublish</button>`:''}<button class="btn red small" data-property-delete="${h(r.id)}">Delete</button></div></article>`).join(''):'<div class="empty">No property requests yet.</div>'}`;
 if(state.extraTab==='listings')return `<h2>Public Property Listings</h2><p class="label">Only non-private property fields are displayed in the Android app.</p>${state.propertyListings.length?state.propertyListings.map(x=>`<article class="listing">${propertyAdminThumb(x)}<div><h3>${h(x.propertyType)} · ${h(x.area)} ${status(x.status)}</h3><p>${h(x.size||'')} · ₹${Number(x.askingPrice||0).toLocaleString('en-IN')}</p><p>${h(x.description||'')}</p><p><b>Public contact:</b> ${x.contactMode==='owner'?'Owner mobile '+h(x.publicContactPhone||''):'Customer Care '+h(state.customerCarePhone)}</p>${propertyAdminGallery(x)}<p><b>Visibility:</b> ${h(propertyExpiryLabel(x))}</p><p><b>Owner name is never published.</b></p></div><div class="actions"><button class="btn plain small" data-property-contact="${h(x.id)}">Edit Contact</button><button class="btn warn small" data-property-hide="${h(x.id)}">Unpublish</button><button class="btn red small" data-property-delete="${h(x.id)}">Delete</button></div></article>`).join(''):'<div class="empty">No public property listings yet.</div>'}`;
 if(state.extraTab==='donors')return `<div class="row"><div><h2>Blood Donor Manager</h2><p class="label">Only adults who gave explicit consent may have name and mobile displayed publicly. Verify this before Publish.</p></div><button class="btn green" data-donor-add>+ Add Donor</button></div>${state.bloodDonors.length?state.bloodDonors.map(d=>`<article class="listing"><div class="content-thumbnail">🩸</div><div><h3>${h(d.name)} · ${h(d.bloodGroup)} ${status(d.status)}</h3><p>${h(d.area)} · ${h(d.phone)}</p><p><b>Consent:</b> ${d.publicConsent?'Recorded':'Not recorded'} · <b>Public:</b> ${d.status==='published'&&d.publicConsent?'Yes':'No'}</p></div><div class="actions"><button class="btn plain small" data-donor-edit="${h(d.id)}">Edit</button>${d.status==='published'?`<button class="btn warn small" data-donor-hide="${h(d.id)}">Unpublish</button>`:`<button class="btn green small" data-donor-publish="${h(d.id)}" ${!d.publicConsent?'disabled title="Donor consent required"':''}>Publish</button>`}<button class="btn red small" data-donor-delete="${h(d.id)}">Delete</button></div></article>`).join(''):'<div class="empty">No donors added. Add only willing, consenting adults.</div>'}`;
 return `<section class="box" style="max-width:560px"><h2>Public Customer Care Number</h2><p class="label">Default number for all properties. Admin may override it per listing only with verified owner consent.</p><form id="helpline-form"><label class="field"><span>Customer Care Mobile *</span><input name="phone" type="tel" required maxlength="10" pattern="[6-9][0-9]{9}" value="${h(state.customerCarePhone)}" placeholder="10 digit official number"></label><button class="btn green" type="submit">Save Customer Care</button></form><p class="footnote">Use an official number you control. This number is visible publicly inside the Android app.</p></section>`;
}
function donorEditor(){let old=state.donorEdit==='new'?{}:state.bloodDonors.find(x=>x.id===state.donorEdit)||{};return `<div class="content-editor-wrap"><div class="content-editor" style="max-width:620px"><div class="row"><h2>${old.id?'Edit':'Add'} Voluntary Blood Donor</h2><button class="btn plain" data-donor-close>✕ Close</button></div><p class="label">Do not add anyone's personal medical information without their explicit informed permission. Adults only.</p><form id="donor-form"><div class="formgrid"><label class="field"><span>Donor Name *</span><input name="name" required minlength="3" maxlength="100" value="${h(old.name||'')}"></label><label class="field"><span>Blood Group *</span><select name="bloodGroup" required><option value="">Choose</option>${BLOOD_GROUPS.map(g=>`<option value="${g}" ${old.bloodGroup===g?'selected':''}>${g}</option>`).join('')}</select></label><label class="field"><span>Mobile Number *</span><input name="phone" type="tel" required maxlength="10" pattern="[6-9][0-9]{9}" value="${h(old.phone||'')}"></label><label class="field"><span>Area (no exact address)</span><input name="area" maxlength="80" value="${h(old.area||'')}"></label></div><label class="content-check"><input type="checkbox" name="publicConsent" ${old.publicConsent?'checked':''}> I have verified the adult donor explicitly consents to publishing their NAME, BLOOD GROUP and PHONE NUMBER in the public app, and understands they can withdraw consent.</label><div class="content-editor-actions"><button class="btn plain" type="submit" name="status" value="draft">Save Private Draft</button><button class="btn green" type="submit" name="status" value="published">Publish with Consent</button></div></form></div></div>`}
// Contact visibility is selected exclusively by the private Admin panel.
// Owners can CONSENT in their submission, but cannot change this setting.
function propertyExpiryMillis(x){const v=x?.expiresAt;if(!v)return 0;if(typeof v.toMillis==='function')return v.toMillis();if(typeof v.seconds==='number')return v.seconds*1000;if(typeof v==='string')return Date.parse(v)||0;return 0}
function propertyExpiryLabel(x){const ms=propertyExpiryMillis(x);return ms?(ms<=Date.now()?'Expired · ':'Expires · ')+new Date(ms).toLocaleString('en-IN'):'No expiry (legacy)'}
function propertyContactEditor(){
 const id=state.propertyContactEdit,r=state.propertyRequests.find(x=>x.id===id),listing=state.propertyListings.find(x=>x.id===id);
 if(!r)return '';
 const expiryDays=Number(listing?.durationDays||3);
 const premium=listing?.isPremium===true;
 const hasConsent=r.publicPhoneConsent===true,selected=listing?.contactMode==='owner'&&hasConsent?'owner':'care';
 return `<div class="content-editor-wrap"><div class="content-editor" style="max-width:620px"><div class="row"><h2>${r.status==='approved'?'Edit Contact Number':'Approve Property & Contact'}</h2><button class="btn plain" data-property-contact-close>✕ Close</button></div>
 <p class="label">Only Admin decides what number appears in the Android app. Property owner name ALWAYS remains hidden.</p>
 <p><b>${h(r.propertyType)} · ${h(r.area)}</b></p><p class="private-row"><b>PRIVATE owner:</b> ${h(r.ownerName)} · ${h(r.ownerPhone)}</p>
 <p class="label">Seller's permission to publicly show mobile: <b>${hasConsent?'YES — recorded':'NO — missing'}</b>. ${!hasConsent?'Ask owner to re-submit with optional consent before choosing owner number.':''}</p>
 <form id="property-contact-form"><label class="content-check"><input type="checkbox" name="isPremium" ${premium?'checked':''}> ★ Premium — Show in Homepage 12-hour rotation</label><label class="field"><span>Show Property For (days) *</span><input type="number" name="durationDays" min="1" max="3650" required value="${expiryDays}" style="max-width:180px"></label><p class="label">On saving, visibility runs for this many days from now. You can extend it later.</p><input type="hidden" name="requestId" value="${h(r.id)}"><label class="content-check"><input type="radio" name="contactMode" value="care" ${selected==='care'?'checked':''}> Customer Care — ${h(state.customerCarePhone)} (Default)</label>
 <label class="content-check"><input type="radio" name="contactMode" value="owner" ${selected==='owner'?'checked':''} ${!hasConsent?'disabled':''}> Show Owner Mobile — ${hasConsent?h(r.ownerPhone):'Consent required'}</label>
 <p class="footnote">The owner cannot pick the public number. If consent is withdrawn, set Customer Care immediately and unpublish the owner number.</p>
 <div class="content-editor-actions"><button type="button" class="btn plain" data-property-contact-close>Cancel</button><button class="btn green" type="submit">${r.status==='approved'?'Save Public Contact':'Approve & Publish'}</button></div></form></div></div>`
}
function redactProperty(r,value){
 let text=String(value||'').replace(/(?:\+?91[ -]?)?[6-9][0-9\s-]{9,13}/g,'[contact hidden]');
 const name=String(r.ownerName||'').trim();
 if(name){const escaped=name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');text=text.replace(new RegExp(escaped,'ig'),'[owner hidden]')}
 return text;
}
async function savePropertyContact(form){
 const fd=new FormData(form),id=String(fd.get('requestId')||''),r=state.propertyRequests.find(x=>x.id===id);
 if(!r)return toast('Property request not found');
 const mode=String(fd.get('contactMode')||'care');
 if(mode!=='care'&&mode!=='owner')return toast('Invalid contact option');
 if(!tenDigit(state.customerCarePhone))return toast('Configure customer-care number first');
 if(mode==='owner'&&(!r.publicPhoneConsent||!tenDigit(r.ownerPhone)))return toast('Explicit owner consent is required before publishing seller number');
 const existing=state.propertyListings.find(x=>x.id===id);
 const durationDays=Number(fd.get('durationDays'));
 if(!Number.isInteger(durationDays)||durationDays<1||durationDays>3650)return toast('Enter 1 to 3650 days');
 const expiresAt=new Date(Date.now()+durationDays*86400000);
 const isPremium=fd.get('isPremium')==='on';
 const msg=existing?'Update public contact for this property?':'Confirm property ownership checked and publish this listing?';
 if(!confirm(msg))return;
 const F=state.F;
 const publicDoc={requestId:id,propertyType:redactProperty(r,r.propertyType),area:redactProperty(r,r.area),size:redactProperty(r,r.size),askingPrice:Number(r.askingPrice||0),description:redactProperty(r,r.description),listingType:r.listingType==='Rent'?'Rent':'Sale',features:Array.isArray(r.features)?r.features.slice(0,15).map(v=>redactProperty(r,v)):[],photoUrls:[...new Set([...propertyAdminPhotos(r),...propertyAdminPhotos(existing||{})])].slice(0,5),isPremium,status:'approved',contactMode:mode,durationDays,expiresAt:F.Timestamp.fromDate(expiresAt),publishedAt:existing?.publishedAt||F.serverTimestamp()};
 // Seller's number exists in PUBLIC document ONLY when Admin selects owner AND seller consent is recorded.
 if(mode==='owner')publicDoc.publicContactPhone=r.ownerPhone;
 try{
  const batch=F.writeBatch(state.db);
  batch.set(F.doc(state.db,'propertyListings',id),publicDoc);
  batch.update(F.doc(state.db,'propertyRequests',id),{status:'approved',reviewedAt:F.serverTimestamp(),reviewedBy:state.user.uid,lastPublicContactMode:mode});
  await batch.commit();
  state.propertyContactEdit=null;
  toast(mode==='owner'?'Approved: owner number is public with consent':'Approved: Customer Care is public; seller phone stays private');
  await load();
 }catch(err){toast('Unable to save: '+err.message)}
}
async function hideProperty(id){if(!confirm('Remove this property from the public app?'))return;const F=state.F;try{const batch=F.writeBatch(state.db);batch.delete(F.doc(state.db,'propertyListings',id));const r=state.propertyRequests.find(x=>x.id===id);if(r)batch.update(F.doc(state.db,'propertyRequests',id),{status:'unpublished'});await batch.commit();toast('Property unpublished');await load()}catch(e){toast(e.message)}}
async function deleteProperty(id){
 const req=state.propertyRequests.find(x=>x.id===id),listing=state.propertyListings.find(x=>x.id===id);
 if(!req&&!listing)return toast('Property record not found');
 if(!confirm('Permanently delete this property request AND its public listing (if any)? This cannot be undone.'))return;
 try{
  const F=state.F,batch=F.writeBatch(state.db);
  if(req)batch.delete(F.doc(state.db,'propertyRequests',id));
  if(listing)batch.delete(F.doc(state.db,'propertyListings',id));
  await batch.commit();
  state.propertyContactEdit=null;
  toast('Property permanently deleted');
  await load();
 }catch(e){toast('Property delete failed: '+e.message)}
}
async function rejectProperty(id){if(!confirm('Reject this property request?'))return;try{await state.F.updateDoc(state.F.doc(state.db,'propertyRequests',id),{status:'rejected',reviewedBy:state.user.uid,reviewedAt:state.F.serverTimestamp()});toast('Property rejected');await load()}catch(e){toast(e.message)}}
async function saveDonor(f,e){e.preventDefault();const fd=new FormData(f),status=e.submitter?.value||'draft',consent=fd.get('publicConsent')==='on';if(status==='published'&&!consent)return toast('Cannot publish without donor consent');if(!tenDigit(fd.get('phone'))||!BLOOD_GROUPS.includes(fd.get('bloodGroup')))return toast('Check mobile and blood group');const old=state.bloodDonors.find(x=>x.id===state.donorEdit),F=state.F,id=old?.id||F.doc(F.collection(state.db,'bloodDonors')).id;
 const doc={name:String(fd.get('name')||'').trim(),bloodGroup:String(fd.get('bloodGroup')),phone:String(fd.get('phone')).trim(),area:String(fd.get('area')||'').trim(),publicConsent:consent,status,updatedAt:F.serverTimestamp(),verifiedBy:state.user.uid};if(doc.name.length<3)return toast('Donor name required');if(!old)doc.createdAt=F.serverTimestamp();if(status==='published')doc.publishedAt=F.serverTimestamp();
 try{await F.setDoc(F.doc(state.db,'bloodDonors',id),doc,{merge:true});state.donorEdit=null;toast('Donor saved ('+status+')');await load()}catch(err){toast(err.message)}}
async function donorAction(id,action){const old=state.bloodDonors.find(x=>x.id===id);if(!old)return;if(action==='publish'&&!old.publicConsent)return toast('Explicit public consent required');if(!confirm(action+' donor '+old.name+'?'))return;try{const ref=state.F.doc(state.db,'bloodDonors',id);if(action==='delete')await state.F.deleteDoc(ref);else await state.F.updateDoc(ref,{status:action==='publish'?'published':'draft',updatedAt:state.F.serverTimestamp()});toast('Donor updated');await load()}catch(err){toast(err.message)}}
async function saveHelpline(f){const number=String(new FormData(f).get('phone')||'').trim();if(!tenDigit(number))return toast('Enter valid official 10-digit customer-care number');try{await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{customerCarePhone:number,updatedAt:state.F.serverTimestamp()},{merge:true});toast('Customer Care number saved');await load()}catch(err){toast(err.message)}}

// Additional category manager, separate from existing business approval and payments.
// Existing seeded homepage categories continue to work even if no custom category exists.
const CATEGORY_ICON_OPTIONS=["store","grid","cart","book","heart","camera","tools","property","hotel","temple","food","medical","education","car","phone","briefcase","home","star"];
function categoryPanel(){
 const sorted=[...state.businessCategories].sort((a,b)=>String(a.name||'').localeCompare(String(b.name||'')));
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Business Category Manager</p></div><div class="admin-header-actions"><button class="btn plain" data-view-mode="business">← Business Approval</button><button class="btn plain" data-view-mode="content">City Content Manager</button><button class="btn plain" id="logout">Sign Out</button></div></header><main><h1>All Business Categories</h1><p class="label">Add categories for the Android More screen and business registration form. Default categories (including Hotels and Temples) are included automatically. Only Admin can create categories.</p><form id="new-business-category" class="formgrid" style="max-width:540px;align-items:end"><label class="field"><span>New Category Name *</span><input name="name" required maxlength="65" minlength="2" placeholder="e.g. Furniture, Coaching Institutes"></label><button class="btn green" type="submit">+ Add Category</button></form><section>${sorted.length?sorted.map(c=>`<div class="listing" style="display:flex;align-items:center;justify-content:space-between;gap:12px"><strong>${h(c.name)} <small style="font-weight:normal;color:#64748b">(${h(c.icon||"store")})</small></strong><div><button class="btn plain small" data-edit-business-category="${h(c.id)}">Edit Name / Icon</button> <span class="status ${c.active?'approved':'rejected'}">${c.active?'Active':'Hidden'}</span> <button class="btn plain small" data-toggle-business-category="${h(c.id)}">${c.active?'Hide':'Activate'}</button></div></div>`).join(''):'<div class="empty">No custom categories yet. Default categories still appear in the app.</div>'}</section><p class="footnote">Hiding a category does not delete already approved businesses. Categories used by approved businesses can still appear in All Categories.</p></main>${state.modal||''}`;
 $('#logout').onclick=()=>state.U.signOut(state.auth);
}
function editBusinessCategory(id){
 const c=state.businessCategories.find(x=>x.id===id);if(!c)return;
 openModal('Edit Business Category',`<form id="edit-business-category"><input type="hidden" name="categoryId" value="${h(c.id)}"><label class="field"><span>Category Name</span><input name="name" required minlength="2" maxlength="65" value="${h(c.name)}"></label><label class="field"><span>Choose Icon</span><select name="icon">${CATEGORY_ICON_OPTIONS.map(i=>`<option value="${h(i)}" ${i===(c.icon||'store')?'selected':''}>${h(i)}</option>`).join('')}</select></label><p class="label">Category ID remains unchanged. Android icon display will be enabled in a separate app update.</p><button class="btn green" type="submit">Save Category</button></form>`);
}
async function saveEditedBusinessCategory(form){
 const fd=new FormData(form),id=String(fd.get('categoryId')||'');
 const c=state.businessCategories.find(x=>x.id===id);if(!c)return toast('Category not found');
 const name=String(fd.get('name')||'').trim().replace(/\s+/g,' '),icon=String(fd.get('icon')||'store');
 if(name.length<2||name.length>65)return toast('Name must be 2–65 characters');
 if(!CATEGORY_ICON_OPTIONS.includes(icon))return toast('Invalid icon');
 if(state.businessCategories.some(x=>x.id!==id&&String(x.name||'').toLocaleLowerCase()===name.toLocaleLowerCase()))return toast('Category name already exists');
 const btn=form.querySelector('[type="submit"]');btn.disabled=true;
 try{await state.F.updateDoc(state.F.doc(state.db,'businessCategories',id),{name,icon,updatedAt:state.F.serverTimestamp()});toast('Category saved; ID unchanged');await load()}
 catch(e){toast('Save failed: '+e.message);btn.disabled=false}
}
async function addBusinessCategory(form){
 const value=String(new FormData(form).get('name')||'').trim().replace(/\s+/g,' ');
 if(value.length<2||value.length>65)return toast('Category name must be 2–65 characters');
 if(state.businessCategories.some(c=>c.name.toLocaleLowerCase()===value.toLocaleLowerCase()))return toast('Category already added');
 try{const F=state.F;await F.addDoc(F.collection(state.db,'businessCategories'),{name:value,active:true,createdBy:state.user.uid,createdAt:F.serverTimestamp()});toast('Category added. It will appear in the Android More screen after reload');await load()}catch(e){toast('Could not save category: '+e.message)}
}
async function toggleBusinessCategory(id){
 const c=state.businessCategories.find(x=>x.id===id);if(!c)return;
 try{await state.F.updateDoc(state.F.doc(state.db,'businessCategories',id),{active:!c.active,updatedAt:state.F.serverTimestamp()});toast('Category updated');await load()}catch(e){toast(e.message)}
}

document.addEventListener('submit',async e=>{if(e.target.id==='app-update-form'){e.preventDefault();saveAppUpdate(e.target);return}if(e.target.id==='urgent-announcement-form'){e.preventDefault();saveUrgentAnnouncement(e.target);return}if(e.target.id==='voice-welcome-form'){e.preventDefault();saveVoiceWelcomeSettings(e.target);return}if(e.target.id!=='social-settings-form')return;e.preventDefault();const f=e.target,links={};for(const key of ['instagram','facebook','youtube','whatsapp']){const url=String(f.elements[key].value||'').trim(),enabled=f.elements[key+'Enabled'].checked;if(enabled&&!/^https:\/\/[^\s]+$/i.test(url))return toast('Enter a valid HTTPS URL for '+key);links[key]={url,enabled}}const btn=f.querySelector('[type=submit]');btn.disabled=true;try{await state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{socialLinks:links,updatedAt:state.F.serverTimestamp()},{merge:true});toast('Social settings saved');await load()}catch(err){toast(err.message);btn.disabled=false}});
document.addEventListener('input',e=>{if(e.target.id==='user-filter'){const q=e.target.value.toLowerCase().trim();document.querySelectorAll('.bp-user-row').forEach(el=>{el.hidden=!el.dataset.userSearch.includes(q)})}});
document.addEventListener('click',e=>{let b=e.target.closest('button');if(!b||!state.user)return;if(b.hasAttribute('data-deal-category-toggle')){const i=Number(b.dataset.dealCategoryToggle);if(!Number.isInteger(i)||!state.offerCategories[i])return;const next=state.offerCategories.map((c,j)=>j===i?{...c,active:c.active===false}:c);bpSaveDealCategories(next);return}if(b.hasAttribute('data-promotion-cancel')){state.promotionEditId=null;return panel()}
 if(b.hasAttribute('data-slider-cancel')){state.sliderEditId=null;return panel()}
 if(b.dataset.sliderEdit){const n=state.sliderMessages.find(x=>x.id===b.dataset.sliderEdit);if(!n)return;state.sliderEditId=n.id;panel();const f=$('#slider-message-form');f.elements.text.value=n.text||'';f.elements.active.checked=n.active===true;f.scrollIntoView({behavior:'smooth',block:'start'});return}
 if(b.dataset.sliderToggle){const n=state.sliderMessages.find(x=>x.id===b.dataset.sliderToggle);if(n)state.F.updateDoc(state.F.doc(state.db,'notificationSliderMessages',n.id),{active:!n.active}).then(load).catch(e=>toast(e.message));return}
 if(b.dataset.sliderDelete){if(confirm('Delete slider message?'))state.F.deleteDoc(state.F.doc(state.db,'notificationSliderMessages',b.dataset.sliderDelete)).then(load).catch(e=>toast(e.message));return}
 if(b.dataset.promotionEdit){const x=state.promotions.find(p=>p.id===b.dataset.promotionEdit);if(!x)return;state.promotionEditId=x.id;panel();const form=$('#promotion-form');for(const k of ['title','imageUrl','description','phone','linkType','linkSection','linkId','linkUrl'])if(form.elements[k])form.elements[k].value=x[k]||'';bpBannerRecordOptions(form,x.linkId||'');form.elements.active.checked=x.active===true;form.scrollIntoView({behavior:'smooth',block:'start'});return}
 if(b.hasAttribute('data-shutter-preview')){const form=document.getElementById('shutter-banner-form'),file=form?.elements.imageFile.files[0],target=document.getElementById('shutter-local-preview');if(!target)return;if(file){if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>=5*1024*1024)return toast('Select JPG/PNG/WebP under 5 MB');const url=URL.createObjectURL(file);target.innerHTML='<img alt="Selected shutter image preview" style="width:100%;max-height:220px;object-fit:contain;margin:12px 0">';target.querySelector('img').src=url;target.querySelector('img').onload=()=>URL.revokeObjectURL(url)}else toast('Choose an image first');return} if(b.hasAttribute('data-hero-reset')){if(confirm('Restore original homepage hero image?'))state.F.setDoc(state.F.doc(state.db,'appSettings','public'),{homeHeroImageUrl:''},{merge:true}).then(load).catch(e=>toast(e.message));return}
 if(b.dataset.promotionToggle){const x=state.promotions.find(p=>p.id===b.dataset.promotionToggle);if(x)state.F.updateDoc(state.F.doc(state.db,'homePromotions',x.id),{active:!x.active}).then(load).catch(e=>toast(e.message));return}if(b.dataset.promotionDelete){if(confirm('Delete this banner?'))state.F.deleteDoc(state.F.doc(state.db,'homePromotions',b.dataset.promotionDelete)).then(load).catch(e=>toast(e.message));return}if(b.dataset.noticeView){const n=state.notices.find(x=>x.id===b.dataset.noticeView);if(!n)return;openModal('City Update Details',`${/^https:\/\//i.test(String(n.imageUrl||''))?`<img src="${h(n.imageUrl)}" alt="City Update" style="width:100%;max-height:240px;object-fit:contain;border-radius:12px">`:''}<h3>${h(n.title)}</h3><p style="white-space:pre-wrap;overflow-wrap:anywhere">${h(n.message)}</p><p><b>Status:</b> ${n.active?'Active':'Inactive'}</p><p><b>Frequency:</b> ${h(n.frequency||'once')}</p><p><b>Dates:</b> ${h(n.startDate||'Any date')} – ${h(n.endDate||'Any date')}</p>${n.phone?`<p><b>Call:</b> ${h(n.phone)}</p>`:''}`);return}if(b.dataset.noticeToggle){const n=state.notices.find(x=>x.id===b.dataset.noticeToggle);if(n)state.F.updateDoc(state.F.doc(state.db,'appNotices',n.id),{active:!n.active}).then(load).catch(e=>toast(e.message));return}if(b.dataset.noticeDelete){if(confirm('Delete this popup?'))state.F.deleteDoc(state.F.doc(state.db,'appNotices',b.dataset.noticeDelete)).then(load).catch(e=>toast(e.message));return}
 if(b.dataset.editBusinessCategory){editBusinessCategory(b.dataset.editBusinessCategory);return}
 if(b.dataset.toggleBusinessCategory){toggleBusinessCategory(b.dataset.toggleBusinessCategory);return}
 if(b.dataset.dealRequestApprove){bpReviewDealRequest(b.dataset.dealRequestApprove,true);return}if(b.dataset.dealRequestReject){bpReviewDealRequest(b.dataset.dealRequestReject,false);return}
 if(b.hasAttribute('data-bp-add-suboffer')){bpAddOfferToTable();return}
 if(b.hasAttribute('data-bp-edit-suboffer')){bpEditOfferRow(b.closest('.bp-suboffer-row'));return}
 if(b.hasAttribute('data-bp-remove-suboffer')){const row=b.closest('.bp-suboffer-row');if(row){const editor=document.getElementById('bp-suboffer-editor');if(editor?.dataset.editIndex===String([...row.parentElement.children].indexOf(row)))bpResetOfferInputs();row.remove();bpRenumberSuboffers()}return}
 if(b.hasAttribute('data-offer-cancel')){state.offerEditId=null;panel();return}
 if(b.dataset.offerEdit){state.offerEditId=b.dataset.offerEdit;state.view='offers';panel();return}
 if(b.dataset.offerToggle){offerAction(b.dataset.offerToggle,'toggle');return}
 if(b.dataset.offerDelete){offerAction(b.dataset.offerDelete,'delete');return}
 if(b.dataset.marketFilter){state.marketplaceFilter=b.dataset.marketFilter;panel();return}
 if(b.dataset.marketApprove){marketplaceAdminAction(b.dataset.marketApprove,'approve');return}
 if(b.dataset.marketReject){marketplaceAdminAction(b.dataset.marketReject,'reject');return}
 if(b.dataset.marketToggle){marketplaceAdminAction(b.dataset.marketToggle,'toggle');return}
 if(b.dataset.marketDelete){marketplaceAdminAction(b.dataset.marketDelete,'delete');return}
 if(b.dataset.marketPremium){marketplaceAdminPremium(b.dataset.marketPremium,Number(b.dataset.marketDays));return}
 if(b.dataset.marketPremiumOff){marketplaceAdminPremium(b.dataset.marketPremiumOff,0);return}
 if(b.dataset.viewMode){state.view=b.dataset.viewMode;state.cityEdit=null;state.donorEdit=null;state.modal=null;panel();return}
 if(b.dataset.extraTab){state.extraTab=b.dataset.extraTab;panel();return}
 if(b.hasAttribute('data-donor-add')){state.donorEdit='new';panel();return}
 if(b.dataset.donorEdit){state.donorEdit=b.dataset.donorEdit;panel();return}
 if(b.hasAttribute('data-donor-close')){state.donorEdit=null;panel();return}
 if(b.dataset.donorHide){donorAction(b.dataset.donorHide,'hide');return}
 if(b.dataset.donorPublish){donorAction(b.dataset.donorPublish,'publish');return}
 if(b.dataset.donorDelete){donorAction(b.dataset.donorDelete,'delete');return}
 if(b.dataset.propertyContact){state.propertyContactEdit=b.dataset.propertyContact;panel();return}
 if(b.hasAttribute('data-property-contact-close')){state.propertyContactEdit=null;panel();return}
 if(b.dataset.propertyApprove){state.propertyContactEdit=b.dataset.propertyApprove;panel();return}
 if(b.dataset.propertyReject){rejectProperty(b.dataset.propertyReject);return}
 if(b.dataset.propertyHide){hideProperty(b.dataset.propertyHide);return}
 if(b.dataset.propertyDelete){deleteProperty(b.dataset.propertyDelete);return}
 if(b.dataset.contentType){state.cityType=b.dataset.contentType;state.contentFilter='';panel();return}
 if(b.hasAttribute('data-content-add')){state.cityEdit='new';panel();return}
 if(b.dataset.contentEdit){state.cityEdit=b.dataset.contentEdit;panel();return}
 if(b.hasAttribute('data-content-cancel')){state.cityEdit=null;panel();return}
 if(b.dataset.aboutMove){moveAboutContent(b.dataset.aboutMove,b.dataset.direction);return}
 if(b.dataset.contentPreview){previewContent(b.dataset.contentPreview);return}
 if(b.dataset.homePublish){toggleHomepageCity(b.dataset.homePublish);return}
 if(b.dataset.contentToggle){toggleCityContent(b.dataset.contentToggle);return}
 if(b.dataset.contentDelete){deleteCityContent(b.dataset.contentDelete);return}
 if(b.dataset.tab){state.tab=b.dataset.tab;panel()}
 if(b.dataset.view){let x=state.biz.find(o=>o.id===b.dataset.view);if(x)detail(x)}
 if(b.dataset.approve)approve(b.dataset.approve);
 if(b.dataset.reject)reject(b.dataset.reject);
 if(b.dataset.businessPhotos){let x=state.biz.find(o=>o.id===b.dataset.businessPhotos);if(x)businessPhotos(x)}
 if(b.dataset.businessCategories){let x=state.biz.find(o=>o.id===b.dataset.businessCategories);if(x)businessCategoryEdit(x)}
 if(b.dataset.businessFree){let x=state.biz.find(o=>o.id===b.dataset.businessFree);if(x)downgradeFree(x)}
 if(b.dataset.payment){let x=state.biz.find(o=>o.id===b.dataset.payment);if(x)payment(x)}
 if(b.dataset.changeapprove)changeStatus(b.dataset.changeapprove,true);
 if(b.dataset.changereject)changeStatus(b.dataset.changereject,false);
});
document.addEventListener('submit',e=>{if(e.target.id==='edit-business-category'){e.preventDefault();saveEditedBusinessCategory(e.target);return}if(e.target.id==='offer-form'){e.preventDefault();saveOffer(e.target);return}if(e.target.id==='shutter-banner-form'){e.preventDefault();saveShutterBanner(e.target);return}if(e.target.id==='hero-image-form'){e.preventDefault();saveHeroImage(e.target);return}if(e.target.id==='notification-settings-form'){e.preventDefault();saveNotificationSettings(e.target);return}if(e.target.id==='promotion-form'){e.preventDefault();savePromotion(e.target);return}if(e.target.id==='slider-message-form'){e.preventDefault();saveSliderMessage(e.target);return}if(e.target.id==='notice-form'){e.preventDefault();saveNotice(e.target);return}if(e.target.id==='new-business-category'){e.preventDefault();addBusinessCategory(e.target)}if(e.target.id==='city-content-form')saveCityContent(e);if(e.target.id==='donor-form')saveDonor(e.target,e);if(e.target.id==='property-contact-form'){e.preventDefault();savePropertyContact(e.target)}if(e.target.id==='helpline-form'){e.preventDefault();saveHelpline(e.target)}});
document.addEventListener('change',e=>{if(e.target.matches('#notification-settings-form [name=theme]'))refreshSliderPreview();if(e.target.matches('#city-content-form [name=type]')){const allowed=['events','historical','blogs','updates'].includes(e.target.value),wrap=$('#home-display-options');if(wrap){wrap.hidden=!allowed;if(!allowed)wrap.querySelector('[name=showOnHomepage]').checked=false}}});
document.addEventListener('input',e=>{if(e.target.id==='content-search'){state.contentFilter=e.target.value;const focus=e.target.selectionStart;contentPanel();const input=$('#content-search');input?.focus();input?.setSelectionRange(focus,focus)}});
async function init(){if(!cfg.apiKey||!cfg.projectId){login('Firebase is not configured. Enter the same Firebase Web App config in admin/firebase-config.js and in the Android app config.');$('#login button').disabled=true;return}
 try{let [A,U,F,S]=await Promise.all([import(base+'firebase-app.js'),import(base+'firebase-auth.js'),import(base+'firebase-firestore.js'),import(base+'firebase-storage.js')]);let app=A.initializeApp(cfg);state.U=U;state.F=F;state.S=S;state.auth=U.getAuth(app);state.db=F.getFirestore(app);state.storage=S.getStorage(app);
  U.onAuthStateChanged(state.auth,async user=>{if(!user){state.user=null;login();return}
   try{let result=await user.getIdTokenResult(true);if(result.claims.admin!==true){state.user=null;await U.signOut(state.auth);login('This account is not authorized as a Baran Pride administrator.');toast('Access denied: admin role required');return}
    state.user=user;await load()
   }catch(err){state.user=null;login(err.message)}
  });
 }catch(err){login('Firebase initialization failed: '+err.message);$('#login button').disabled=true}
}

// Admin workspace navigation: keeps existing data-view-mode handlers and every legacy screen.
const bpAdminMenus=[
 ['business','Dashboard / Businesses','▦'],['approvals','Approval Center','✓'],['analytics','Analytics & Reports','▥'],['jobs','Local Jobs','▣'],['marketplace','Buy & Sell Marketplace','◇'],
 ['content','City Content','▤'],['categories','Business Categories','▦'],
 ['notices','City Updates','◫'],['promotions','Homepage Banners','▧'],
 ['offers','Offers & Deals','◇'],['community','Property & Blood Donors','⌂'],
 ['social','Social Media','◎'],['voice','Voice Welcome','♫'],
 ['urgent','Urgent Voice','◉'],['appUpdate','App Updates','↻'],
 ['users','Users','♙']
];

// Phase B: upgrade repeated record cards into accessible compact data tables.
// Existing buttons/forms are moved (not recreated), preserving delegated handlers.

// Phase C: Jobs use custom cards rather than .listing. Convert those to
// compact table rows while keeping their existing data-job-* controls intact.
function bpBuildJobTable(){
 const list=document.querySelector('#app .bp-job-admin-list');
 if(!list||list.dataset.bpConverted)return;
 const cards=[...list.querySelectorAll(':scope > .bp-job-admin-card')];
 if(!cards.length)return;
 list.dataset.bpConverted='1';
 const tools=document.createElement('div');tools.className='bp-table-toolbar';
 const title=document.createElement('strong');title.textContent='Local Jobs · '+cards.length+' records';
 const search=document.createElement('input');search.type='search';search.className='bp-table-search';search.placeholder='Search job, company, location…';search.setAttribute('aria-label','Search local jobs');
 const select=document.createElement('select');select.className='bp-table-pagesize';select.setAttribute('aria-label','Rows per page');
 select.innerHTML='<option value="10">10 rows</option><option value="20" selected>20 rows</option><option value="50">50 rows</option><option value="100">100 rows</option>';
 tools.append(title,search,select);
 const scroll=document.createElement('div');scroll.className='bp-table-scroll';
 const table=document.createElement('table');table.className='bp-data-table bp-jobs-table';
 table.innerHTML='<thead><tr><th scope="col">Job / Company</th><th scope="col">Salary / Type / Date</th><th scope="col">Status</th><th scope="col">Actions</th></tr></thead><tbody></tbody>';
 const tbody=table.tBodies[0];
 for(const card of cards){
   const tr=document.createElement('tr');
   const first=card.querySelector(':scope > .row:first-child');
   const p=card.querySelector(':scope > p');
   const buttons=card.querySelector(':scope > .row:last-child');
   const statusNode=first?.querySelector('strong');
   const details=first?.querySelector('div');
   const c1=document.createElement('td'),c2=document.createElement('td'),c3=document.createElement('td'),c4=document.createElement('td');
   if(details)c1.appendChild(details);
   if(p)c2.appendChild(p);
   if(statusNode)c3.appendChild(statusNode);
   if(buttons){buttons.classList.add('bp-job-row-actions');c4.appendChild(buttons)}
   tr.append(c1,c2,c3,c4);tbody.appendChild(tr);
   card.remove();
 }
 scroll.appendChild(table);
 const footer=document.createElement('div');footer.className='bp-table-footer';
 const info=document.createElement('span');
 const prev=document.createElement('button');prev.type='button';prev.textContent='Previous';prev.className='btn plain small';
 const next=document.createElement('button');next.type='button';next.textContent='Next';next.className='btn plain small';
 footer.append(info,prev,next);
 list.classList.add('bp-table-wrap');list.append(tools,scroll,footer);
 let page=0;
 function update(){
   const term=search.value.trim().toLocaleLowerCase();
   const rows=[...tbody.rows],matched=rows.filter(r=>r.textContent.toLocaleLowerCase().includes(term));
   const size=Number(select.value)||20,total=Math.max(1,Math.ceil(matched.length/size));
   page=Math.max(0,Math.min(page,total-1));
   const visible=new Set(matched.slice(page*size,(page+1)*size));
   rows.forEach(r=>r.hidden=!visible.has(r));
   info.textContent=matched.length+' matching · Page '+(page+1)+' of '+total;
   prev.disabled=page===0;next.disabled=page>=total-1;
 }
 search.oninput=()=>{page=0;update()};
 select.onchange=()=>{page=0;update()};
 prev.onclick=()=>{page--;update()};
 next.onclick=()=>{page++;update()};
 update();
}

function bpBuildCompactTables(){
 const root=document.querySelector('#app main');
 if(!root)return;
 const listings=[...root.querySelectorAll('.listing:not([data-bp-table-ready])')];
 const groups=new Map();
 for(const item of listings){
   if(item.closest('.bp-data-table'))continue;
   const parent=item.parentElement;
   if(!groups.has(parent))groups.set(parent,[]);
   groups.get(parent).push(item);
 }
 for(const [parent,items] of groups){
   if(!items.length||items.length>2000)continue;
   // Avoid converting unrelated layout groups; at least two rows, or one row with action buttons.
   if(items.length===1&&!items[0].querySelector('.actions,button'))continue;
   const wrapper=document.createElement('section');
   wrapper.className='bp-table-wrap';
   const bar=document.createElement('div');bar.className='bp-table-toolbar';
   const heading=document.createElement('strong');heading.textContent='Records ('+items.length+')';
   const search=document.createElement('input');search.type='search';search.className='bp-table-search';search.placeholder='Search these records…';search.setAttribute('aria-label','Search records');
   const pageSize=document.createElement('select');pageSize.className='bp-table-pagesize';pageSize.setAttribute('aria-label','Rows per page');
   pageSize.innerHTML='<option value="10">10 rows</option><option value="20" selected>20 rows</option><option value="50">50 rows</option><option value="100">100 rows</option>';
   bar.append(heading,search,pageSize);
   const scroll=document.createElement('div');scroll.className='bp-table-scroll';
   const table=document.createElement('table');table.className='bp-data-table';
   table.innerHTML='<thead><tr><th scope="col">Image</th><th scope="col">Record / Details</th><th scope="col">Actions</th></tr></thead><tbody></tbody>';
   const tbody=table.tBodies[0];
   const rows=[];
   for(const item of items){
     const tr=document.createElement('tr');
     const thumb=document.createElement('td');thumb.className='bp-table-image';
     const details=document.createElement('td');details.className='bp-table-details';
     const actions=document.createElement('td');actions.className='bp-table-actions';
     for(const child of [...item.children]){
       if(child.classList.contains('actions'))actions.appendChild(child);
       else if(child.matches('img,.content-thumbnail')||child.getAttribute('style')?.includes('font-size:33px'))thumb.appendChild(child);
       else details.appendChild(child);
     }
     if(!actions.children.length){
       // Keep any inline action controls visible without modifying their listeners.
       const btns=[...details.querySelectorAll(':scope > button')];
       for(const btn of btns)actions.appendChild(btn);
     }
     tr.append(thumb,details,actions);tbody.appendChild(tr);rows.push(tr);
     item.dataset.bpTableReady='1';
   }
   scroll.appendChild(table);
   const footer=document.createElement('div');footer.className='bp-table-footer';
   const count=document.createElement('span');
   const prev=document.createElement('button');prev.type='button';prev.className='btn plain small';prev.textContent='Previous';
   const next=document.createElement('button');next.type='button';next.className='btn plain small';next.textContent='Next';
   footer.append(count,prev,next);
   wrapper.append(bar,scroll,footer);
   parent.insertBefore(wrapper,items[0]);
   items.forEach(item=>item.remove());
   let page=0;
   const update=()=>{
     const term=search.value.trim().toLocaleLowerCase();
     const filtered=rows.filter(tr=>tr.textContent.toLocaleLowerCase().includes(term));
     const size=Number(pageSize.value)||20;
     const totalPages=Math.max(1,Math.ceil(filtered.length/size));
     page=Math.min(page,totalPages-1);
     const selected=new Set(filtered.slice(page*size,(page+1)*size));
     for(const tr of rows)tr.hidden=!selected.has(tr);
     count.textContent=filtered.length+' matching · Page '+(page+1)+' of '+totalPages;
     prev.disabled=page===0;next.disabled=page>=totalPages-1;
   };
   search.addEventListener('input',()=>{page=0;update()});
   pageSize.addEventListener('change',()=>{page=0;update()});
   prev.addEventListener('click',()=>{page--;update()});
   next.addEventListener('click',()=>{page++;update()});
   update();
 }
}

let bpSidebarScheduled=false;
function bpInstallSidebar(){
 bpSidebarScheduled=false;
 const app=document.getElementById('app');
 if(!app)return;
 const loggedIn=!!state.user&&!!app.querySelector('header');
 if(!loggedIn){document.body.classList.remove('bp-admin-workspace');return}
 document.body.classList.add('bp-admin-workspace');
 if(app.querySelector('#bp-admin-sidebar'))return;
 const nav=document.createElement('aside');
 nav.id='bp-admin-sidebar';
 nav.innerHTML='<div class="bp-side-brand"><b>BARAN PRIDE</b><small>ADMIN WORKSPACE</small><button type="button" class="bp-side-close" aria-label="Close menu">×</button></div><nav aria-label="Admin sections">'+bpAdminMenus.map(([key,label,icon])=>'<button type="button" class="bp-side-link '+(state.view===key?'is-active':'')+'" data-view-mode="'+key+'"><span aria-hidden="true">'+icon+'</span>'+h(label)+'</button>').join('')+'</nav><div class="bp-side-foot">Secure Administration</div>';
 app.prepend(nav);
 const search=document.createElement('input');search.type='search';search.className='bp-side-search';search.placeholder='Find a section…';search.setAttribute('aria-label','Search admin sections');
 nav.querySelector('.bp-side-brand').after(search);
 search.addEventListener('input',()=>{const q=search.value.trim().toLowerCase();nav.querySelectorAll('.bp-side-link').forEach(b=>{b.hidden=!b.textContent.toLowerCase().includes(q)})});
 const toggle=document.createElement('button');
 toggle.type='button';toggle.id='bp-admin-menu-toggle';toggle.textContent='☰ Menu';
 toggle.setAttribute('aria-label','Toggle admin sidebar');
 app.querySelector('header').prepend(toggle);
 toggle.onclick=()=>document.body.classList.toggle('bp-side-open');
 nav.querySelector('.bp-side-close').onclick=()=>document.body.classList.remove('bp-side-open');
 nav.addEventListener('click',e=>{if(e.target.closest('[data-view-mode]'))document.body.classList.remove('bp-side-open')});
 // Preserve existing page controls and event handlers; compact row styling only.
 bpBuildCompactTables();
 bpBuildJobTable();
}
new MutationObserver(()=>{if(!bpSidebarScheduled){bpSidebarScheduled=true;requestAnimationFrame(bpInstallSidebar)}}).observe(document.getElementById('app'),{childList:true});


// Keep the picker listeners inside this closure so they can access state and bpBannerRecordOptions.
document.addEventListener('change',e=>{
 const form=e.target?.closest?.('#promotion-form');
 if(!form)return;
 if(e.target.name==='linkSection'||e.target.name==='linkType'){
   bpBannerRecordOptions(form);
 }
});
document.addEventListener('input',e=>{if(e.target?.id==='bp-banner-search'){const form=e.target.closest('#promotion-form');if(form)bpFilterBannerRecords(form);}});
document.addEventListener('change',e=>{if(e.target?.id==='bp-banner-record'){e.target.size=1;const form=e.target.closest('#promotion-form');const search=form?.querySelector('#bp-banner-search');if(search&&e.target.selectedOptions[0]?.value)search.value=e.target.selectedOptions[0].textContent;}});
document.addEventListener('focusin',e=>{
 if(e.target?.id==='bp-banner-record'){
   const form=e.target.closest('#promotion-form');
   if(form&&e.target.options.length<=1)bpBannerRecordOptions(form);
 }
});

init();
})();


/* Phase 4E-A: read-only client-side search/filter/sort of rendered management records. */
(()=>{
 const allowed=new Set(['business','offers','jobs','content','community']);
 const saved={};let busy=false;
 function apply(){
  const bar=document.getElementById('bp-smart-filter');if(!bar)return;
  const q=bar.querySelector('[data-bp-q]').value.trim().toLocaleLowerCase();
  const status=bar.querySelector('[data-bp-status]').value;
  const order=bar.querySelector('[data-bp-order]').value;
  const main=document.querySelector('#app main');if(!main)return;
  // Restrict filtering to list records, not editor forms, controls or summary cards.
  const candidates=[...main.querySelectorAll('article.listing, div.listing, table.saved-table tbody tr')].filter(el=>!el.closest('#bp-smart-filter,form,.modalwrap') && !el.querySelector('form'));
  const groups=new Map();let count=0;
  for(const el of candidates){
   if(!el.dataset.bpOriginalOrder)el.dataset.bpOriginalOrder=String(candidates.indexOf(el)+1);
   const txt=el.textContent.toLocaleLowerCase();
   const foundStatus=(txt.match(/\b(pending|approved|published|rejected|draft|inactive|active)\b/)||[])[1]||'';
   const show=(!q||txt.includes(q))&&(!status||foundStatus===status||new RegExp('\\b'+status+'\\b').test(txt));
   el.hidden=!show;el.classList.toggle('bp-filter-hidden',!show);if(show)count++;
   const parent=el.parentElement;if(!groups.has(parent))groups.set(parent,[]);groups.get(parent).push(el);
  }
  for(const [parent,els] of groups){
   if(els.length<2)continue;
   const ordered=[...els].sort((a,b)=>{
    if(order==='az')return a.textContent.trim().localeCompare(b.textContent.trim());
    const ai=Number(a.dataset.bpOriginalOrder),bi=Number(b.dataset.bpOriginalOrder);
    return order==='old'?bi-ai:ai-bi;
   });
   for(const el of ordered)parent.appendChild(el);
  }
  const n=bar.querySelector('[data-bp-count]');if(n)n.textContent=`${count} visible records`;
 }
 function mount(){
  if(busy)return;busy=true;
  try{
   const view=window.state?.view || (typeof state!=='undefined'?state.view:'');
   const main=document.querySelector('#app main');
   if(!main||!allowed.has(view))return;
   let bar=document.getElementById('bp-smart-filter');
   if(bar)return;
   const v=saved[view]||{q:'',status:'',order:'new'};
   bar=document.createElement('section');bar.id='bp-smart-filter';bar.className='bp-smart-filter';
   bar.innerHTML='<div class="bp-smart-heading"><strong>Search, Filter & Sort</strong><span data-bp-count></span></div><div class="bp-smart-fields"><input type="search" data-bp-q placeholder="Search visible records" aria-label="Search records"><select data-bp-status aria-label="Filter by status"><option value="">All statuses</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="published">Published</option><option value="rejected">Rejected</option><option value="draft">Draft</option><option value="active">Active</option><option value="inactive">Inactive</option></select><select data-bp-order aria-label="Sort records"><option value="new">Original order</option><option value="old">Reverse order</option><option value="az">A–Z</option></select><button type="button" data-bp-reset class="btn plain">Reset</button></div><p class="label">Filters apply to records currently displayed on this page. Use existing section tabs to switch datasets.</p>';
   const heading=main.querySelector('h1');if(heading)heading.insertAdjacentElement('afterend',bar);else main.prepend(bar);
   bar.querySelector('[data-bp-q]').value=v.q;bar.querySelector('[data-bp-status]').value=v.status;bar.querySelector('[data-bp-order]').value=v.order;
   const change=()=>{saved[view]={q:bar.querySelector('[data-bp-q]').value,status:bar.querySelector('[data-bp-status]').value,order:bar.querySelector('[data-bp-order]').value};apply()};
   bar.addEventListener('input',change);bar.addEventListener('change',change);
   bar.querySelector('[data-bp-reset]').addEventListener('click',()=>{bar.querySelector('[data-bp-q]').value='';bar.querySelector('[data-bp-status]').value='';bar.querySelector('[data-bp-order]').value='new';change()});
   apply();
  }finally{busy=false}
 }
 const observer=new MutationObserver(()=>{if(!document.getElementById('bp-smart-filter'))queueMicrotask(mount)});
 function start(){const app=document.getElementById('app');if(app){observer.observe(app,{childList:true,subtree:false});mount()}}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
