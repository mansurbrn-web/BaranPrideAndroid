# BARAN PRIDE V3 — Blood Donors + Sell Property

यह V2 Royal Blue Premium के ऊपर बनाया गया अपडेट है। **Original Home, Business Directory, Search, Featured Businesses, Owner Dashboard, Manual Payment, City Content** सुरक्षित हैं। केवल Side Menu में दो अतिरिक्त सेक्शन जोड़े हैं।

## Side Menu में क्रम
Home → Local Businesses → **Sell Property** → **Blood Donors** → Historical Places → Blogs → Tourist Places → Events → City Updates → Important Contacts → About Baran.

## Sell Property (Privacy-by-design)
- Android ऐप में लॉग-इन व्यापारी/प्रॉपर्टी मालिक Property Sale Request भेज सकता है।
- `propertyRequests` Firestore Collection में `ownerName`, `ownerPhone`, `ownerUid`, property facts और `status: pending` सुरक्षित रहते हैं। यह दस्तावेज़ **केवल Admin और स्वयं Request Owner** पढ़ सकते हैं।
- Admin सिर्फ Ownership की मैन्युअल जाँच करके Approve करेगा। Public App को अलग `propertyListings` Collection से जानकारी मिलती है। इसमें **seller name, phone, UID, exact address शामिल नहीं** होते। Admin Approval logic प्रकाशित text से name/number हटाने का भी प्रयास करता है। प्रकाशन से पहले Admin को सभी फ़ील्ड खुद जाँचना है।
- Public Listing में Type, Area, Size, Asking Price और Description दिखते हैं। Customer Care बटन ऐप Settings से प्रकाशित अधिकृत हेल्पलाइन को ही कॉल करता है।
- **Customer Care Mobile पहले Admin Panel → Property & Blood Donors → Customer Care में सेट करें।** बिना नम्बर सेव किए Admin किसी Property को Approve नहीं कर सकता।
- Property Approvals का भुगतान या सदस्यता से कोई स्वतः संबंध नहीं जोड़ा गया है। मौजूदा Manual Payment फीचर अपरिवर्तित है।

## Blood Donors
- App Side Menu → Blood Donors, Historical Places से ऊपर है। Visitors ब्लड ग्रुप से फिल्टर कर सकते हैं और प्रकाशित दाताओं का Name, Blood Group, Area, Mobile देखकर सीधे कॉल कर सकते हैं।
- **सिर्फ Admin** Private Admin Web Panel → Property & Blood Donors → Blood Donors से लिस्ट जोड़ता/बदलता/Publish करता है।
- दाता वयस्क होना चाहिए, और उसका नाम, ब्लड ग्रुप, मोबाइल सार्वजनिक रूप से छापने की **स्पष्ट जानकारीयुक्त सहमति** Admin ने प्राप्त और सत्यापित की हो। बिना `publicConsent=true` के Publish नहीं होगा।
- Donor चाहें तो Admin से नाम हटाने को कह सकते हैं; Admin तुरंत Unpublish/Delete कर सकता है।
- यह केवल स्वैच्छिक संपर्क सूची है, रक्त की उपलब्धता, स्वास्थ्य योग्यता या आपातकालीन चिकित्सा सहायता की गारंटी नहीं है। अस्पताल/रजिस्टर्ड ब्लड बैंक से पुष्टि करें।

## Firebase सेटअप
1. Android Firebase Web Config: `app/src/main/assets/js/config.js`.
2. Admin Firebase Web Config: `admin/firebase-config.js`.
3. Firebase Firestore + Email/Password Authentication सेट करें। Admin खाते को `admin: true` **Custom Claim** सुरक्षित Firebase Admin SDK द्वारा दें (देखें `tools/set-admin.mjs`)।
4. `firestore.rules` और `storage.rules` deploy करें। नए नियम **बिना deploy किए Android की live नई सुविधाएँ काम नहीं करेंगी**। Existing rules को merge करते समय पुराने Business/Payment rules सुरक्षित रखें।
5. `admin/` को PRIVATE admin access के रूप में Host करें। Firebase Rules वास्तविक authorization की सुरक्षा देते हैं; login UI अकेला पर्याप्त नहीं है।
6. Admin Panel में Customer Care नम्बर जोड़ें, जरूरत के अनुसार Property Requests Approve करें, Donor Consent verify करके Publish करें।

## GitHub से APK
- GitHub Repository के ROOT में `BaranPride_V3_Android_Admin_Source.zip` Upload करें। **इसे GitHub पर ZIP के रूप में ही अपलोड करना है**, क्योंकि supplied workflow ZIP खुद Extract करता है।
- `.github/workflows/build-apk.yml` में शामिल `BaranPride_V3_GitHub_Build.yml` का पूरा कोड Copy करें। इससे Android SDK और Gradle सेट कर ZIP Extract करके Debug APK Artifact बनता है।
- GitHub Actions → Build BARAN PRIDE V3 APK → Run workflow → Successful Run → Artifacts → BaranPride-V3-Debug-APK.
- यदि काम न करे तो GitHub Actions Job Log देखें; source ZIP का नाम `BaranPride_V3_Android_Admin_Source.zip` ही होना चाहिए।

## क्या तैयार है / क्या बाकी है?
- तैयार: Android HTML/CSS/JS V3, Side Menu, Screens, App-side Firestore integration, Admin-side management code, Firestore rules, GitHub build workflow, mobile UI prototype.
- बाकी: आपका वास्तविक Firebase Config, Admin Claims और Security Rules का Deploy, Firebase पर Customer Care नंबर Save करना, वास्तविक consented donors, property records, APK compilation और physical-device testing.
- Demo Mode में कोई असली Seller/Donor डेटा नहीं है; Property Customer Care नंबर 7737325205 का उदाहरण संपर्क दिखता है। असली property/donor रिकॉर्ड Firebase से प्रकाशित होने पर ही दिखेंगे।

## Property Customer Care — Confirmed on 14 October 2026
- Official public BARAN PRIDE property customer-care number: **7737325205**. The Android app and admin panel use this as the default until a centrally saved number is available.
- After connecting Firebase, open **Admin → Property & Blood Donors → Customer Care** and click **Save Customer Care**. This persists the number to `appSettings/public`, ensuring existing installed clients receive it as well.
- Do not add private property seller name or mobile to public `propertyListings`.
