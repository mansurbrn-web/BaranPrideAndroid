// Secure one-time administrator role assignment. Run only from trusted machine.
// export GOOGLE_APPLICATION_CREDENTIALS=/private/path/service-account.json
// ADMIN_UID=... npm run grant-admin
import admin from 'firebase-admin';
const uid=process.env.ADMIN_UID;
if(!uid || !process.env.GOOGLE_APPLICATION_CREDENTIALS){
 console.error('Required: ADMIN_UID and GOOGLE_APPLICATION_CREDENTIALS');process.exit(1);
}
admin.initializeApp({credential:admin.credential.applicationDefault()});
await admin.auth().setCustomUserClaims(uid,{admin:true});
console.log(`Admin claim applied to ${uid}. Sign out and sign back in to refresh token.`);
