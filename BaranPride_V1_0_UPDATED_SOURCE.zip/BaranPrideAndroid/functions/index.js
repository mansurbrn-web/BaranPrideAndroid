"use strict";
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {initializeApp}=require('firebase-admin/app');
const {getAuth}=require('firebase-admin/auth');
const {getFirestore,FieldValue}=require('firebase-admin/firestore');
initializeApp();
exports.adminRecoverUserEmail=onCall({region:'asia-south1',enforceAppCheck:false,maxInstances:2},async(request)=>{
  if(!request.auth || request.auth.token.admin!==true)throw new HttpsError('permission-denied','Admin access required');
  const {uid,newEmail,verificationNote}=request.data||{};
  if(typeof uid!=='string'||uid.length<10||uid.length>128)throw new HttpsError('invalid-argument','Invalid UID');
  if(typeof newEmail!=='string'||newEmail.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail))throw new HttpsError('invalid-argument','Invalid email');
  if(typeof verificationNote!=='string'||verificationNote.trim().length<12||verificationNote.length>500)throw new HttpsError('invalid-argument','Verification reference required');
  const auth=getAuth(),db=getFirestore(),adminUid=request.auth.uid;
  const target=await auth.getUser(uid).catch(()=>{throw new HttpsError('not-found','Account not found')});
  if(target.customClaims?.admin===true||uid===adminUid)throw new HttpsError('permission-denied','Admin accounts cannot be changed here');
  if((target.email||'').toLowerCase()===newEmail.toLowerCase())throw new HttpsError('already-exists','Email is unchanged');
  try{const taken=await auth.getUserByEmail(newEmail);if(taken)throw new HttpsError('already-exists','Email already in use')}catch(err){if(err instanceof HttpsError)throw err;if(err.code!=='auth/user-not-found')throw err}
  // Log intent before changing credentials, so security-sensitive actions are traceable.
  const log=db.collection('accountRecoveryLogs').doc();
  await log.set({action:'email_change_requested',uid,oldEmail:target.email||'',targetEmail:newEmail,adminUid,verificationNote:verificationNote.trim(),createdAt:FieldValue.serverTimestamp(),status:'pending'});
  try{
    await auth.updateUser(uid,{email:newEmail,emailVerified:false});
    await auth.revokeRefreshTokens(uid);
    await db.collection('userProfiles').doc(uid).set({email:newEmail},{merge:true});
    await log.update({status:'completed',completedAt:FieldValue.serverTimestamp()});
    return {ok:true};
  }catch(err){await log.update({status:'failed',errorCode:String(err.code||'unknown').slice(0,80),failedAt:FieldValue.serverTimestamp()});throw new HttpsError('internal','Recovery failed; check audit log and account state')}
});
