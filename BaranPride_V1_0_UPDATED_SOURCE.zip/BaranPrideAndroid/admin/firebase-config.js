// SAME Firebase Web App config as app/src/main/assets/js/config.js
window.BARAN_FIREBASE_CONFIG = {
  apiKey: "AIzaSyAEoG9snP_RWMa6B0fkBzlp1cO6cL0e2WE",
  authDomain: "baran-pride.firebaseapp.com",
  projectId: "baran-pride",
  storageBucket: "baran-pride.firebasestorage.app",
  appId: "1:164645114530:web:4f75aa24ebf072e013fdfb"
};
