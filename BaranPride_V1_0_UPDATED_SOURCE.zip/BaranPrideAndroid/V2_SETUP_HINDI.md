# BARAN PRIDE V2 — Update Guide (Android + Private Admin)

## पहले से फाइनल Royal Blue Premium V1 को सुरक्षित रखते हुए

- पुरानी Home Screen, Business Categories, Featured Businesses, Explore, Saved, Add Business, My Business, Profile और Bottom Navigation को यथावत रखा गया है।
- Home header के ऊपर दाईं तरफ सिर्फ नया **☰ City Menu** जोड़ा गया है।
- अलग मेन्यू: Historical Places, Blogs & Articles, Tourist Places, Events & Festivals, City Updates, Important Contacts, About Baran.
- हर सेक्शन में Search, Listing, Detail, Photo Gallery (maximum 5), Share, जहाँ लागू हो Maps/Phone सुविधा।
- कोई नया Public Website नहीं: पढ़ने का अनुभव Android ऐप में और लिखने/Publish करने का काम Private Admin Web Panel में।
- Admin Manager: Add, Edit, Preview, Save Draft, Publish, Unpublish, Delete. Business/Manual Payment modules unchanged.
- नया Firestore collection `cityContent`; केवल `published` status का कंटेंट Visitors पढ़ सकेंगे; केवल Admin custom claim के साथ Publish/Write.

## V2 को GitHub पर मोबाइल से APK में बदलना (वही पुरानी repository)

अगर आपकी repository में अभी केवल V1 ZIP और `.github/workflows/build-apk.yml` हैं, तो:
1. `BaranPride_V2_Android_Admin_Source.zip` को repository **root** में Upload files से अपलोड करके Commit करें। पुराने V1 ZIP को हटाने की ज़रूरत नहीं।
2. अलग से दी गई `BaranPride_V2_GitHub_Build.yml` की **पूरी सामग्री** को repository की `.github/workflows/build-apk.yml` फाइल में replace करें और Commit करें।
3. GitHub → Actions → `Build BARAN PRIDE V2 APK` → Run workflow → `main` → Run.
4. सफल build के बाद Artifacts से `BaranPride-V2-Debug-APK` ZIP डाउनलोड करें, extract करें, `app-debug.apk` इंस्टॉल करें। यह testing APK है, Google Play के लिए Signed AAB नहीं।

यदि repository में **पूरा Extract किया हुआ Android project** रखा है (ZIP नहीं), तो `BaranPrideAndroid/.github/workflows/android.yml` का workflow root `.github/workflows/android.yml` में रखें; project root folder nesting के अनुसार `working-directory` बदलें।

## Firebase (जरूरी Live Data Setup)

**ZIP में Firebase Config खाली है।** ऐप की V2 screens बिना Firebase भी खुलेंगी, पर city articles खाली दिखेंगे; कोई वास्तविक article नहीं दिखाई देगा।

1. Firebase Console में Baran Pride प्रोजेक्ट में Email/Password Auth, Firestore, Storage सक्षम करें।
2. Firebase Web Config को दो files में डालें: `app/src/main/assets/js/config.js` और `admin/firebase-config.js`.
3. `firestore.rules` तथा `storage.rules` deploy करें। ध्यान दें: **rules पुराने के ऊपर replace होते हैं**, इसलिए यही समेकित V2 rules deploy करें (business/payments rules भी शामिल हैं)।
4. Private Admin `admin/` Firebase Hosting पर deploy करें। सिर्फ `admin` custom-claim वाला user प्रवेश कर पाएगा।
5. Admin login → **City Content Manager** → Category → Add Content → Title, Short Description, Full Content, photos, location → Save Draft/Publish.
6. Content Publish करने के बाद Android App की ☰ Menu स्क्रीन में नया item इंटरनेट से दिखेगा, नए APK की आवश्यकता नहीं।
7. पुराने `README_HINDI.md` में पहली बार Admin custom claim सेट करने के निर्देश हैं। Service-account JSON को GitHub पर कभी अपलोड न करें।

**Admin Hosting public website नहीं है:** `admin/index.html` केवल login-सुरक्षित control panel है। Listing और content के लिए visitor-facing website नहीं है।

## Launch/testing notes

- Demo business entries Sample हैं। Firebase live होने पर वास्तविक approved business entries से replace होंगे।
- बिना Admin द्वारा Publish किए Historical Places/Blogs empty रहेंगे। Placeholder इतिहास/गलत समय/fees auto-publish नहीं की गई हैं।
- Android Studio/Cloud Build में Compile और physical-device smoke test ज़रूरी हैं। इस package में कोई prebuilt APK नहीं है।
- Facebook/WhatsApp Share सिस्टम Android के Native chooser से होगा; historical articles के लिए शेयर में Title/Summary रहेगी, deep link नहीं (public website नहीं है)।
- Firebase Firestore indexes से `status == published` के single-field query में सामान्यतः composite index नहीं चाहिए।
- Admin photo URL public-readable है; draft article text Firestore rules से सुरक्षित है। फोटो की अधिक गोपनीयता चाहिए तो published-only Storage access architecture अलग से implement करें।
