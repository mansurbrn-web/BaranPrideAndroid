package `in`.baranpride.app

import android.app.Activity
import android.content.Intent
import android.content.ClipData
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.widget.FrameLayout
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader

/** Native Android shell: all end-user UI is bundled inside the APK, never hosted as a public website. */
class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingFileChooser: ValueCallback<Array<Uri>>? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = pendingFileChooser ?: return@registerForActivityResult
        val uris: Array<Uri>? = if (result.resultCode == Activity.RESULT_OK) {
            val intent = result.data
            val chosen = mutableListOf<Uri>()
            intent?.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i).uri?.let { chosen.add(it) }
                }
            }
            intent?.data?.let { if (!chosen.contains(it)) chosen.add(it) }
            if (chosen.isEmpty()) {
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, intent)
            } else chosen.distinct().toTypedArray()
        } else null
        callback.onReceiveValue(uris)
        pendingFileChooser = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 15+ lays edge-to-edge by default. Reserve real space for
        // status/navigation bars so the HTML header and fixed bottom tabs never overlap.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.rgb(244, 248, 254)
        window.navigationBarColor = android.graphics.Color.WHITE
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(244, 248, 254))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true // Required for content:// photo URIs returned by Android picker
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.mediaPlaybackRequiresUserGesture = true
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (request.url.host == "appassets.androidplatform.net") return false
                    openAllowedUrl(request.url.toString())
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView,
                    filePathCallback: ValueCallback<Array<Uri>>,
                    fileChooserParams: FileChooserParams
                ): Boolean {
                    pendingFileChooser?.onReceiveValue(null)
                    pendingFileChooser = filePathCallback
                    try {
                        // ACTION_OPEN_DOCUMENT reliably returns readable content:// URIs,
                        // including multi-select from modern Android document providers.
                        val pickIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "image/*"
                            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        filePicker.launch(pickIntent)
                    } catch (_: Exception) {
                        pendingFileChooser?.onReceiveValue(null)
                        pendingFileChooser = null
                        Toast.makeText(this@MainActivity, "Cannot open photo picker", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
            }
            loadUrl("https://appassets.androidplatform.net/assets/index.html")
        }
        // Do not pad the WebView itself: WebView's CSS/fixed-position content may
        // still render under the system bars. Constrain its *viewport* with a parent.
        val root = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(244, 248, 254))
            addView(webView, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            // Keep bottom controls above Android's keyboard when form inputs are active.
            val keyboardBottom = if (insets.isVisible(WindowInsetsCompat.Type.ime())) {
                insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            } else 0
            view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, keyboardBottom))
            // We have handled these insets natively; don't apply them again in HTML.
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)
        ViewCompat.requestApplyInsets(root)
    }

    private fun openAllowedUrl(url: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" && uri.scheme != "tel" && uri.scheme != "geo") return
        try { startActivity(Intent(if (uri.scheme == "tel") Intent.ACTION_DIAL else Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { Toast.makeText(this, "No app available to open link", Toast.LENGTH_SHORT).show() }
    }

    private inner class AndroidBridge {
        @JavascriptInterface fun getVersionCode(): Long {
            return if (android.os.Build.VERSION.SDK_INT >= 28) packageManager.getPackageInfo(packageName, 0).longVersionCode
            else @Suppress("DEPRECATION") packageManager.getPackageInfo(packageName, 0).versionCode.toLong()
        }
        @JavascriptInterface fun dial(phone: String) = runOnUiThread {
            val clean = phone.filter { it.isDigit() || it == '+' }
            if (clean.isNotBlank()) openAllowedUrl("tel:$clean")
        }
        @JavascriptInterface fun openUrl(url: String) = runOnUiThread { openAllowedUrl(url) }
        @JavascriptInterface fun shareText(text: String) = runOnUiThread {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text.take(2000))
            }
            startActivity(Intent.createChooser(intent, "Share business"))
        }
    }

    @Deprecated("Used for backwards compatibility on different Android versions")
    override fun onBackPressed() {
        webView.evaluateJavascript("window.BaranApp && window.BaranApp.goBack()") { result ->
            if (result == "false" || result == "null") {
                webView.evaluateJavascript("window.BaranApp && window.BaranApp.go(\"home\")", null)
            }
        }
    }

    override fun onDestroy() {
        pendingFileChooser?.onReceiveValue(null)
        webView.removeJavascriptInterface("AndroidBridge")
        webView.destroy()
        super.onDestroy()
    }
}
