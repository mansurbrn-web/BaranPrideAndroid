/* Optional Firebase data layer. App works as an explicitly labelled demo until configured. */
(function(){
 const cfg=window.BARAN_FIREBASE_CONFIG||{};
 const C={enabled:false,ready:false,user:null,auth:null,db:null,storage:null,m:null,onUserChange:null};
 const base='https://www.gstatic.com/firebasejs/10.14.1/';
 C.init=async function(){
  if(!cfg.apiKey||!cfg.projectId||!cfg.appId){C.ready=true;return false}
  try{
   const [A,U,F,S]=await Promise.all([import(base+'firebase-app.js'),import(base+'firebase-auth.js'),import(base+'firebase-firestore.js'),import(base+'firebase-storage.js')]);
   const app=A.initializeApp(cfg); C.auth=U.getAuth(app);C.db=F.getFirestore(app);C.storage=S.getStorage(app);C.m={U,F,S};C.enabled=true;
   U.onAuthStateChanged(C.auth,user=>{C.user=user;if(typeof C.onUserChange==='function') C.onUserChange(user)});
   C.ready=true;return true;
  }catch(e){console.error('Firebase unavailable',e);C.ready=true;C.error=e.message;return false}
 };
 C.signUp=async function(email,password,name){
  const x=await C.m.U.createUserWithEmailAndPassword(C.auth,email,password);
  if(name) await C.m.U.updateProfile(x.user,{displayName:name});C.user=x.user;return x.user;
 };
 C.signIn=async function(email,password){let x=await C.m.U.signInWithEmailAndPassword(C.auth,email,password);C.user=x.user;return x.user};
 C.signOut=async function(){await C.m.U.signOut(C.auth);C.user=null};
 C.approved=async function(){const F=C.m.F;
  const snap=await F.getDocs(F.query(F.collection(C.db,'businesses'),F.where('status','==','approved')));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
 };
 // Optional admin-managed categories; approved listings are also discovered dynamically.
 C.publicCategories=async function(){if(!C.enabled)return[];const F=C.m.F;
  const q=F.query(F.collection(C.db,'businessCategories'),F.where('active','==',true));
  const snap=await F.getDocs(q);return snap.docs.map(d=>String(d.data().name||'').trim()).filter(Boolean);
 };
 C.owned=async function(){if(!C.user)return[];const F=C.m.F;
  const snap=await F.getDocs(F.query(F.collection(C.db,'businesses'),F.where('ownerUid','==',C.user.uid)));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
 };
 C.register=async function(data,files){
  if(!C.user)throw Error('Please sign in first');
  const F=C.m.F;
  const doc=F.doc(F.collection(C.db,'businesses'));
  const selected=Array.from(files||[]);
  if(selected.length>2)throw Error('Free listing allows maximum 2 photos');
  const urls=[];
  // Upload photos BEFORE creating the business, so a failed upload cannot
  // silently create a business with missing photos.
  for(let i=0;i<selected.length;i++){
    const file=selected[i];
    if(!file.type || !file.type.startsWith('image/'))throw Error('Photo '+(i+1)+': choose a JPG, PNG or WebP image');
    if(file.size>=5*1024*1024)throw Error('Photo '+(i+1)+': image must be under 5 MB');
    const path='businesses/'+C.user.uid+'/'+doc.id+'/'+Date.now()+'-'+i+'-'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
    try{
      const ref=C.m.S.ref(C.storage,path);
      await C.m.S.uploadBytes(ref,file,{contentType:file.type});
      urls.push(await C.m.S.getDownloadURL(ref));
    }catch(e){
      const reason=e?.code||e?.message||'unknown error';
      console.error('BARAN PRIDE business image upload failed', {path,reason},e);
      throw Error('Photo '+(i+1)+' upload failed: '+reason+'. Business not submitted.');
    }
  }
  try{
    await F.setDoc(doc,{
      name:data.name,category:data.category,area:data.area,address:data.address,phone:data.phone,whatsapp:data.whatsapp||data.phone,
      description:data.description||'',hours:data.hours||'Contact business',weeklyHours:data.weeklyHours||{},mapUrl:data.mapUrl||'',ownerUid:C.user.uid,
      status:'pending',plan:'free',planStatus:'inactive',paymentStatus:'unpaid',featured:false,
      cover:urls[0]||'',photoUrls:urls,views:0,callClicks:0,createdAt:F.serverTimestamp(),updatedAt:F.serverTimestamp()
    });
  }catch(e){
    console.error('BARAN PRIDE business registration save failed',e);
    throw Error('Business save failed: '+(e?.code||e?.message||'unknown error'));
  }
  return doc.id;
 };
 C.requestEdit=async function(id,patch){if(!C.user)throw Error('Please sign in');
  const F=C.m.F;
  await F.addDoc(F.collection(C.db,'changeRequests'),{businessId:id,ownerUid:C.user.uid,patch,createdAt:F.serverTimestamp(),status:'pending'});
 };
 // Public query only loads published content; Firestore denies access to drafts.
 C.publicCity=async function(){if(!C.enabled)return[];const F=C.m.F;
  const q=F.query(F.collection(C.db,'cityContent'),F.where('status','==','published'));
  const docs=await F.getDocs(q);
  return docs.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>{
   const v=x=>x.publishedAt?.seconds||x.updatedAt?.seconds||0;
   return Number(!!b.featured)-Number(!!a.featured)||v(b)-v(a);
  });
 };

 // Read only the Admin-selected published homepage entries (limited for speed).
 // Firestore index for the two equality filters is bundled with the patch.
 C.publicHomepageCity=async function(){if(!C.enabled)return[];const F=C.m.F;
  const q=F.query(F.collection(C.db,'cityContent'),F.where('status','==','published'),F.where('showOnHomepage','==',true),F.limit(60));
  const snap=await F.getDocs(q);return snap.docs.map(d=>({id:d.id,...d.data()}));
 };

 // Public blood donor directory. Only adults who explicitly consented and were published by Admin are visible.
 C.publicDonors=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'bloodDonors'),F.where('status','==','published'),F.where('publicConsent','==',true)));return snap.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>String(a.bloodGroup).localeCompare(String(b.bloodGroup)))};
 C.publicNotices=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'appNotices'),F.where('active','==',true)));return snap.docs.map(d=>({id:d.id,...d.data()}))};
 C.publicProperties=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'propertyListings'),F.where('status','==','approved')));return snap.docs.map(x=>({id:x.id,...x.data()}))};
 C.customerCare=async function(){const fallback='7737325205';if(!C.enabled)return fallback;const F=C.m.F;const snap=await F.getDoc(F.doc(C.db,'appSettings','public'));return snap.exists()?String(snap.data().customerCarePhone||fallback):fallback};
 C.submitProperty=async function(data){if(!C.user)throw Error('Sign in before submitting a property');const F=C.m.F;const snap=await F.addDoc(F.collection(C.db,'propertyRequests'),{...data,ownerUid:C.user.uid,status:'pending',createdAt:F.serverTimestamp()});return snap.id};
 window.BaranCloud=C;
})();
