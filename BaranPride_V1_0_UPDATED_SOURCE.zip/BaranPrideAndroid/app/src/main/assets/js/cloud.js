/* Optional Firebase data layer. App works as an explicitly labelled demo until configured. */
(function(){
 const cfg=window.BARAN_FIREBASE_CONFIG||{};
 const C={enabled:false,ready:false,user:null,auth:null,db:null,storage:null,m:null,onUserChange:null};
 const base='https://www.gstatic.com/firebasejs/10.14.1/';
 C.init=async function(){
  if(C.enabled)return true;
  if(C.initPromise)return C.initPromise;
  C.initPromise=(async()=>{
  if(!cfg.apiKey||!cfg.projectId||!cfg.appId){C.ready=true;return false}
  try{
   const [A,U,F,S]=await Promise.all([import(base+'firebase-app.js'),import(base+'firebase-auth.js'),import(base+'firebase-firestore.js'),import(base+'firebase-storage.js')]);
   const app=A.getApps().length?A.getApp():A.initializeApp(cfg); C.auth=U.getAuth(app);C.db=F.getFirestore(app);C.storage=S.getStorage(app);C.m={U,F,S};C.enabled=true;
   U.onAuthStateChanged(C.auth,user=>{C.user=user;if(typeof C.onUserChange==='function') C.onUserChange(user)});
   C.ready=true;C.error='';return true;
  }catch(e){console.error('Firebase unavailable',e);C.ready=true;C.error=e.message;return false}
  })();
  try{return await C.initPromise}finally{C.initPromise=null}
 };
 C.ensureConnected=async function(){
  if(C.enabled)return true;
  for(let attempt=0;attempt<4;attempt++){
   if(await C.init())return true;
   if(attempt<3)await new Promise(resolve=>setTimeout(resolve,1200*(attempt+1)));
  }
  return false;
 };
 C.signUp=async function(email,password,name,mobile){
  if(!/^[6-9][0-9]{9}$/.test(String(mobile||'')))throw Error('Enter a valid 10-digit mobile number');
  const x=await C.m.U.createUserWithEmailAndPassword(C.auth,email,password);
  if(name)await C.m.U.updateProfile(x.user,{displayName:name});C.user=x.user;
  // Profile writes are owner-only; do not store passwords in Firestore.
  try{await C.m.F.setDoc(C.m.F.doc(C.db,'userProfiles',x.user.uid),{uid:x.user.uid,name,email,mobile,createdAt:C.m.F.serverTimestamp()})}
  catch(e){console.error('Profile save failed',e);throw Error('Account created, but mobile profile could not be saved. Contact support before registering again.')}
  return x.user;
 };
 C.resetPassword=async function(email){return C.m.U.sendPasswordResetEmail(C.auth,email)};
 C.signIn=async function(email,password){let x=await C.m.U.signInWithEmailAndPassword(C.auth,email,password);C.user=x.user;return x.user};
 C.signOut=async function(){await C.m.U.signOut(C.auth);C.user=null};
 C.approved=async function(){const F=C.m.F;
  const snap=await F.getDocs(F.query(F.collection(C.db,'businesses'),F.where('status','==','approved')));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
 };
 // Optional admin-managed categories; approved listings are also discovered dynamically.
 C.publicCategories=async function(){if(!C.enabled)return[];const F=C.m.F;
  const q=F.query(F.collection(C.db,'businessCategories'),F.where('active','==',true));
  const snap=await F.getDocs(q);return snap.docs.map(d=>String(d.data().name||'').trim()).filter(Boolean);
 };
 C.owned=async function(){if(!C.user)return[];const F=C.m.F;
  const snap=await F.getDocs(F.query(F.collection(C.db,'businesses'),F.where('ownerUid','==',C.user.uid)));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
 };

// Client-side optimization. Never uploads the uncompressed original on successful conversion.
async function bpOptimizeBusinessPhoto(file){
 if(!file || !/^image\/(jpeg|png|webp)$/i.test(file.type))throw Error('Please choose JPG, PNG or WebP');
 if(file.size>5*1024*1024)throw Error('Business photo must be under 5 MB');
 if(typeof createImageBitmap!=='function')return file; // Older WebView: preserve working upload
 let bitmap;try{bitmap=await createImageBitmap(file)}catch(e){return file}
 try{
  const ratio=Math.min(1,1200/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*ratio));canvas.height=Math.max(1,Math.round(bitmap.height*ratio));
  canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);
  let blob=null;
  for(const quality of [.82,.78,.73,.67,.60]){
   const next=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',quality));
   if(!next||next.type!=='image/webp')break;
   if(!blob||next.size<blob.size)blob=next;
   if(next.size<=250*1024)break;
  }
  if(!blob||blob.size>=file.size)return file;
  return new File([blob],String(file.name||'photo').replace(/\.[^.]+$/,'')+'.webp',{type:'image/webp',lastModified:Date.now()});
 }finally{bitmap.close?.()}
}

 C.register=async function(data,files,onProgress){
  if(!C.user)throw Error('Please sign in first');
  const F=C.m.F;
  const doc=F.doc(F.collection(C.db,'businesses'));
  const selected=Array.from(files||[]);
  if(selected.length>2)throw Error('Free listing allows maximum 2 photos');
  for(let i=0;i<selected.length;i++){
   const file=selected[i];
   if(!/^image\/(jpeg|png|webp)$/i.test(file.type))throw Error('Photo '+(i+1)+': choose JPG, PNG or WebP');
   if(file.size>=5*1024*1024)throw Error('Photo '+(i+1)+': must be under 5 MB');
  }
  // Firestore create rules require empty cover and photoUrls. Create the pending
  // record first, then upload images and update only permitted photo fields.
  onProgress?.('Saving business details...');
  try{
   await F.setDoc(doc,{
    name:data.name,category:data.category,categories:[data.category],area:data.area,address:data.address,phone:data.phone,whatsapp:data.whatsapp||data.phone,
    description:data.description||'',hours:data.hours||'Contact business',weeklyHours:data.weeklyHours||{},mapUrl:data.mapUrl||'',ownerUid:C.user.uid,
    status:'pending',plan:'free',planStatus:'inactive',paymentStatus:'unpaid',featured:false,
    cover:'',photoUrls:[],views:0,callClicks:0,createdAt:F.serverTimestamp(),updatedAt:F.serverTimestamp()
   });
  }catch(e){console.error('Business create failed',e);throw Error('Business save failed: '+(e?.code||e?.message||'unknown error'))}
  const urls=[];
  for(let i=0;i<selected.length;i++){
   const file=await bpOptimizeBusinessPhoto(selected[i]);
   const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
   const path='businesses/'+C.user.uid+'/'+doc.id+'/'+Date.now()+'-'+i+'-'+safeName;
   onProgress?.('Uploading photo '+(i+1)+' of '+selected.length+'...');
   try{
    const ref=C.m.S.ref(C.storage,path);
    await C.m.S.uploadBytes(ref,file,{contentType:file.type});
    urls.push(await C.m.S.getDownloadURL(ref));
    // Save after EACH successful upload to avoid losing completed photos.
    await F.updateDoc(doc,{cover:urls[0]||'',photoUrls:[...urls],updatedAt:F.serverTimestamp()});
   }catch(e){
    console.error('Business photo upload/update failed', {path,code:e?.code},e);
    throw Error('Business saved as Pending, but photo '+(i+1)+' failed: '+(e?.code||e?.message||'unknown error')+'. Contact Admin before retrying to avoid duplicate listings.');
   }
  }
  return doc.id;
 };
  C.managePhotos=async function(b,files=[],removeUrls=[],coverUrl=''){
   if(!C.user || b.ownerUid!==C.user.uid)throw Error('Not your business');
   const F=C.m.F,S=C.m.S,doc=F.doc(C.db,'businesses',b.id);
   const latest=(await F.getDoc(doc)).data();if(!latest||latest.ownerUid!==C.user.uid)throw Error('Business unavailable');
   const premium=latest.plan==='premium'&&latest.planStatus==='active'&&latest.paymentStatus==='paid'&&latest.expiresAt?.toMillis?.()>Date.now();
   const limit=premium?5:2;
   const old=Array.isArray(latest.photoUrls)?latest.photoUrls:[];
   const kept=old.filter(u=>!removeUrls.includes(u));
   if(kept.length+files.length>limit)throw Error('Maximum '+limit+' photos allowed');
   const added=[];
   try{
    for(const originalFile of files){
     const file=await bpOptimizeBusinessPhoto(originalFile);
     if(!/^image\/(jpeg|png|webp)$/i.test(file.type)||file.size>=5*1024*1024)throw Error('Use JPG, PNG or WebP under 5 MB');
     const path='businesses/'+C.user.uid+'/'+b.id+'/'+Date.now()+'-'+Math.random().toString(36).slice(2)+'-'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
     const ref=S.ref(C.storage,path);await S.uploadBytes(ref,file,{contentType:file.type});added.push(await S.getDownloadURL(ref));
    }
    const urls=[...kept,...added];const cover=urls.includes(coverUrl)?coverUrl:urls[0]||'';
    await F.updateDoc(doc,{photoUrls:urls,cover,updatedAt:F.serverTimestamp()});
    for(const url of removeUrls.filter(u=>old.includes(u))){try{await S.deleteObject(S.ref(C.storage,url))}catch(e){console.warn('Old image cleanup failed',e)}}
   }catch(e){for(const url of added){try{await S.deleteObject(S.ref(C.storage,url))}catch(_){}}throw e}
  };
 C.requestEdit=async function(id,patch){if(!C.user)throw Error('Please sign in');
  const F=C.m.F;
  await F.addDoc(F.collection(C.db,'changeRequests'),{businessId:id,ownerUid:C.user.uid,patch,createdAt:F.serverTimestamp(),status:'pending'});
 };
 // Public query only loads published content; Firestore denies access to drafts.
 C.publicCity=async function(){if(!C.enabled)return[];const F=C.m.F;
  const q=F.query(F.collection(C.db,'cityContent'),F.where('status','==','published'));
  const docs=await F.getDocs(q);
  return docs.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>{
   const v=x=>x.publishedAt?.seconds||x.updatedAt?.seconds||0;
   return Number(!!b.featured)-Number(!!a.featured)||v(b)-v(a);
  });
 };

 // Read only the Admin-selected published homepage entries (limited for speed).
 // Firestore index for the two equality filters is bundled with the patch.
 C.publicHomepageCity=async function(){if(!C.enabled)return[];const F=C.m.F;
  const q=F.query(F.collection(C.db,'cityContent'),F.where('status','==','published'),F.where('showOnHomepage','==',true),F.limit(60));
  const snap=await F.getDocs(q);return snap.docs.map(d=>({id:d.id,...d.data()}));
 };

 // Public blood donor directory. Only adults who explicitly consented and were published by Admin are visible.
 C.publicDonors=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'bloodDonors'),F.where('status','==','published'),F.where('publicConsent','==',true)));return snap.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>String(a.bloodGroup).localeCompare(String(b.bloodGroup)))};
 C.publicPromotions=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'homePromotions'),F.where('active','==',true)));return snap.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.active===true)};
 C.publicSliderMessages=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'notificationSliderMessages'),F.where('active','==',true)));return snap.docs.map(d=>({id:d.id,...d.data()}))};
 C.publicNotices=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'appNotices'),F.where('active','==',true)));return snap.docs.map(d=>({id:d.id,...d.data()}))};
 C.publicProperties=async function(){if(!C.enabled)return[];const F=C.m.F;const snap=await F.getDocs(F.query(F.collection(C.db,'propertyListings'),F.where('status','==','approved')));return snap.docs.map(x=>({id:x.id,...x.data()}))};
 C.customerCare=async function(){const fallback='7737325205';if(!C.enabled)return fallback;const F=C.m.F;const snap=await F.getDoc(F.doc(C.db,'appSettings','public'));return snap.exists()?String(snap.data().customerCarePhone||fallback):fallback};
 C.submitProperty=async function(data){if(!C.user)throw Error('Sign in before submitting a property');const F=C.m.F;const snap=await F.addDoc(F.collection(C.db,'propertyRequests'),{...data,ownerUid:C.user.uid,status:'pending',createdAt:F.serverTimestamp()});return snap.id};
 window.BaranCloud=C;
})();
