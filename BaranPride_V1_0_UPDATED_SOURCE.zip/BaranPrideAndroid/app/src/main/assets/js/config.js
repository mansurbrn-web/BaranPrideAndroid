// Copy Firebase Web App config from Firebase Console > Project settings > Your apps.
// Keep these fields blank to run a LOCAL DEMO. Never place an admin service-account key here.
window.BARAN_FIREBASE_CONFIG = {
  apiKey: "AIzaSyAEoG9snP_RWMa6B0fkBzlp1cO6cL0e2WE",
  authDomain: "baran-pride.firebaseapp.com",
  projectId: "baran-pride",
  storageBucket: "baran-pride.firebasestorage.app",
  appId: "1:164645114530:web:4f75aa24ebf072e013fdfb"
};
