# BARAN PRIDE — Royal Blue Premium (Android-first Directory)

**Tagline:** हमारा शहर, हमारी पहचान  
**Main experience:** Android App only (customer + business owner).  
**Website:** ONLY private Admin Approval + Manual Payment Entry panel. No public directory website.

## इसमें क्या तैयार है?

Android app (`app/src/main/assets` में responsive native-bundled screens):
- Home: approved Royal Blue Premium design, brand, scenic hero, search, 10 categories, featured and recently added businesses.
- Explore: business search + category filtering.
- Business Detail: Call, WhatsApp, Google Maps Directions, Share and Save.
- Saved: favorites stored locally on the Android device.
- Add Business: details, area, phone, optional WhatsApp, up to 5 photos, owner signup/login with Firebase.
- My Business: own listing, admin approval status, plan/payment status and change request.
- Profile: basic account screen.

Private Admin Web Panel (`admin/`):
- Email/password sign-in requiring Firebase **admin custom claim**.
- Pending/Approved/Rejected businesses, detailed review and accept/reject.
- Verified manual payments: UPI / Cash / Bank Transfer, amount, reference, validity; separate `paymentHistory` ledger.
- Approve/reject business change requests.
- Firestore and Storage rules for access control.

**Important:** Screenshot/sample business names and ratings are MOCK DATA. They are not verified real businesses. Demo registration is stored only on the current device and will not appear in admin until Firebase is connected.

## 1) बिना Firebase के Android Design Demo

Android Studio में इस पूरे folder को Project के रूप में खोलें → Gradle Sync → Build APK / Run. App के demo mode में सारे UI pages दिखेंगे. Offline demo data, Favorites और local registration चलेंगे. **APK इस package में शामिल नहीं है** क्योंकि इस environment में Android SDK/Gradle build tools उपलब्ध नहीं हैं. दिए गए स्रोत से APK compile करना होगा.

**कंप्यूटर के बिना APK build:** Entire `BaranPrideAndroid` folder को GitHub repository की root में upload/push करें → **Actions** tab → `Build Baran Pride Android APK` workflow → `Run workflow` → `BaranPride-Debug-APK` artifact से debug APK प्राप्त करें. (GitHub Actions account/build minutes और Google Play release-signing अलग विषय हैं.)

> Build requirements: JDK 17, Android SDK platform 35, Gradle 8.11.1, internet for dependencies. Android Studio Open Project can sync Gradle automatically. `gradle :app:assembleDebug` is the command.

## 2) Firebase live data सेटअप

1. Firebase Console में नया project बनाएँ: **Baran Pride** (Kota Directory से अलग project).
2. **Authentication → Sign-in method** में **Email/Password** enable करें.
3. **Firestore Database** create करें; **Storage** initialize करें.
4. **Project settings → Your apps → Add Web App** से Firebase Web Config लें (यह public client config है, service account secret नहीं).
5. **एक ही config** इन दो files में डालें:
   - `app/src/main/assets/js/config.js`
   - `admin/firebase-config.js`
6. Firebase CLI install करके project root में:
   ```sh
   npm install -g firebase-tools
   firebase login
   firebase use --add
   firebase deploy --only firestore:rules,storage,hosting
   ```
7. दोबारा Android APK build करें. Approved businesses cloud से दिखेंगे; owner signup/auth और registration cloud database में save होंगे. Admin Web Panel Firebase Hosting पर केवल Admin Login के लिए होगा.

## 3) पहला Admin सेट करना (बहुत जरूरी)

**Firebase Web Config से Admin बनाना संभव नहीं है.** Privileged service-account credential केवल अपने सुरक्षित कंप्यूटर पर रखें, Android APK/Hosting में कभी नहीं.

1. Firebase Authentication → Users में admin email/password user बनाएँ और उसका UID लें.
2. Firebase Console → Project Settings → Service Accounts से service account JSON सुरक्षित डाउनलोड करें.
3. `tools` directory में `npm install` चलाएँ.
4. सुरक्षित कंप्यूटर में environment set करके run करें:
   ```sh
   export GOOGLE_APPLICATION_CREDENTIALS='/secure/private/service-account.json'
   export ADMIN_UID='YOUR_ADMIN_FIREBASE_USER_UID'
   npm run grant-admin
   ```
5. Admin Web Page खोलें और उसी email/password से sign in करें. Already logged-in session हो तो logout/login करें.

`firestore.rules` only lets admin claim users approve/reject/payment record; other users cannot edit `status`, `paymentStatus`, `plan`, `featured`.

## 4) Manual Payment workflow

1. व्यापारी Android App में business register करता है → **Pending**.
2. Admin website पर business verify करता है.
3. Free listing: **Approve** press करें, कोई भुगतान आवश्यक नहीं.
4. Paid listing: पैसा अलग से (UPI/Cash/Bank) लेने और खुद सत्यापित करने के बाद **Manual Payment** खोलें → Plan, actual amount, reference, method, validity दर्ज करें.
5. Paid business का Payment History सुरक्षित ledger में बनेगा → फिर **Approve** करें.
6. Admin नए listing edits के लिए अलग approval दे सकता है.

No in-app external payment link or payment gateway is provided. This is intentional for the Android-only customer experience.

## 5) Launch से पहले जरूरी काम

- Demo business names, invented star ratings और placeholder photos हटाएँ; केवल verified real listings दर्ज करें. Firebase connected होने पर demo data automatically disappears.
- Sample photo images are crops of the approved AI design mockup, not verified pictures of actual businesses.
- Complete Android physical-device testing: Android 8–15+, form/photo picker, WhatsApp/Maps, Firebase email sign-up.
- App icon, trademark/brand verification and a compliant Privacy Policy/Data Safety declaration for Play Store.
- Real traffic, backend cost, spam/rate-limits, profile analytics, expiry automation/renewals, notifications and production monitoring need additional work. **View and Call click analytics are not enabled yet**; placeholder counters are not displayed as real analytics.
- Before Play Store release, generate an AAB signed with your own release signing key. Debug APK is for installation/testing only.

## Repository Layout

```
app/src/main/       Android Manifest, MainActivity and bundled design UI
admin/              Secure admin-only web interface
firestore.rules     Auth + ownership + admin security rules
storage.rules       Image upload permissions
firebase.json       Hosting/rules deployment config
.github/workflows/  Debug APK build through GitHub Actions
/tools/             Admin custom-claim assignment (trusted machine only)
```
