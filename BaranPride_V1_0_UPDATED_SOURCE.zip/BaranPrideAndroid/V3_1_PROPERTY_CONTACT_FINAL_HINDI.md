# BARAN PRIDE V3.1 — Admin-only Property Contact (FINAL)

## क्या बदला है
- पुरानी Royal Blue Premium Business Homepage, Category, Blood Donors, Historical Places, Blogs, तथा अन्य Side Menu **बिना बदलाव**।
- Sell Property में **डिफॉल्ट Customer Care 7737325205** हर प्रॉपर्टी की सार्वजनिक संपर्क जानकारी है।
- किसी प्रॉपर्टी के लिए सिर्फ Private Admin Panel → **Property & Blood Donors → Property Requests/Live Properties → Approve / Contact या Edit Contact** में नंबर चुना जा सकता है।
- विकल्प: `Customer Care` (default) या `Show Owner Mobile`। दूसरा विकल्प **केवल मालिक के साफ सार्वजनिक सहमति** (`publicPhoneConsent == true`) होने पर खुलता है।
- Seller के Property Submission Form में **वैकल्पिक सहमति का checkbox** है, लेकिन सार्वजनिक नंबर चुनने का विकल्प नहीं दिया गया है। कौन सा नंबर दिखेगा यह निर्णय हमेशा Admin करेगा।
- Owner Name, ownerUid और private ownerPhone मूल `propertyRequests` में ही सुरक्षित रखे जाते हैं। Public `propertyListings` में मालिक का नाम/UID कभी नहीं जाता।
- अगर Admin ने Owner Mobile चुना और सहमति है, तभी `propertyListings.publicContactPhone` को सार्वजनिक दस्तावेज में जोड़ा जाता है।
- अगर Admin `Customer Care` चुने, तो Public Listing पूरी तरह **replace** होती है और Seller Mobile फ़ील्ड हट जाती है। पुरानी सार्वजनिक कॉपी/स्क्रीनशॉट पहले से देखने वाले यूज़र के पास रह सकती है, इसलिए सहमति वापस होने पर Admin तुरंत बदलें।

## Firebase
1. `app/src/main/assets/js/config.js` और `admin/firebase-config.js` में एक ही Firebase web configuration रखें। Secret/Admin credentials source में न डालें।
2. Firebase Authentication + admin custom claim से सिर्फ विश्वसनीय Admin Private Panel खोल सके।
3. Firestore Rules का नया `firestore.rules` **Deploy करें**; सिर्फ APK अपडेट करने से नियम नहीं बदलते।
4. Firestore में `appSettings/public.customerCarePhone` का नंबर `7737325205` Admin Panel → Customer Care से Save करें।
5. **नए rule deploy और APK अपडेट एक ही release में करें**। पुराने `propertyRequests` जिनमें `publicPhoneConsent` नहीं है उन्हें बिना रिकॉर्डेड सहमति Owner Phone मोड में बदला नहीं जा सकता। ऐसे में Customer Care ही रहेगा; नया वैध सहमति वाला अनुरोध लें।
6. यदि किसी मालिक ने सहमति वापस ली है तो Admin तुरंत उस प्रॉपर्टी का Contact `Customer Care` कर दे; रिकॉर्ड को सार्वजनिक रूप से हटाना आवश्यक हो तो Unpublish दबाएँ।

## GitHub से APK
- GitHub Repository `BaranPrideAndroid` root में `BaranPride_V3_1_Admin_Contact_Source.zip` upload करें।
- GitHub root में `.github/workflows/build-apk.yml` को साथ दिए गए `BaranPride_V3_1_GitHub_Build.yml` के टेक्स्ट से अपडेट करें।
- GitHub Actions में `Build BARAN PRIDE V3.1 APK` चलाकर सफल Artifacts से APK लें। ZIP को Github Releases → Source Code नहीं मानें।

## Testing
- Real Firebase keys और Admin claim के बिना HTML preview **demo-only** है; वास्तविक owner consent/approval/published contact व्यवहार Firebase Setup के बाद verify करें।
- `node --check` के साथ Android app JS और Admin JS का syntax check करें।
- APK Compilation/GitHub Build और डिवाइस पर runtime परीक्षण अभी तक नहीं किए गए हैं।
