(function(){
'use strict';
const cfg=window.BARAN_FIREBASE_CONFIG||{};
const base='https://www.gstatic.com/firebasejs/10.14.1/';
const $=(s)=>document.querySelector(s);
const h=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state={user:null,tab:'pending',biz:[],changes:[],auth:null,db:null,F:null,U:null,loading:false,modal:null};
function toast(msg){let x=$('#toast');x.textContent=msg;x.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>x.classList.remove('show'),3400)}
function login(message='Only authorized Baran Pride administrators can access this panel.'){
 $('#app').innerHTML=`<section class="center"><div class="box"><h1>BARAN PRIDE</h1><p>Private Business Approval & Manual Payments</p><p class="footnote">${h(message)}</p><form id="login"><label class="field"><span>Admin Email</span><input name="email" type="email" required autocomplete="username"></label><label class="field"><span>Password</span><input name="password" type="password" required autocomplete="current-password"></label><button class="btn" style="width:100%">Secure Sign In</button></form></div></section>`;
 $('#login').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target);let btn=$('#login button');btn.disabled=true;try{await state.U.signInWithEmailAndPassword(state.auth,f.get('email'),f.get('password'))}catch(err){toast(err.message);btn.disabled=false}}
}
const status=(s)=>`<span class="status ${h(s)}">${h((s||'pending').toUpperCase())}</span>`;
function card(b){let paid=b.paymentStatus==='paid';return `<article class="listing"><img src="${h(b.cover||'')}" alt=""><div><h3>${h(b.name)} ${status(b.status)}</h3><p><b>${h(b.category)}</b> · ${h(b.area)} · ${h(b.phone)}</p><p>${h(b.address)}</p><p><b>Plan:</b> ${h(b.plan||'free')} · <b>Payment:</b> ${paid?'Paid ₹'+h(b.paidAmount||0):'Unpaid'} · <b>Owner UID:</b> ${h((b.ownerUid||'').slice(0,12))}…</p></div><div class="actions"><button class="btn plain small" data-view="${h(b.id)}">Details</button><button class="btn warn small" data-payment="${h(b.id)}">Manual Payment</button>${b.status!=='approved'?`<button class="btn green small" data-approve="${h(b.id)}">Approve</button>`:''}${b.status!=='rejected'?`<button class="btn red small" data-reject="${h(b.id)}">Reject</button>`:''}</div></article>`}
function changeCard(r){let patch=r.patch||{};let b=state.biz.find(x=>x.id===r.businessId);return `<article class="listing"><div style="font-size:33px;text-align:center">✎</div><div><h3>${h(b?.name||r.businessId)} ${status(r.status)}</h3><p>Requested Changes: ${Object.entries(patch).map(([k,v])=>'<b>'+h(k)+'</b>: '+h(v)).join(' · ')}</p></div><div class="actions">${r.status==='pending'?`<button class="btn green small" data-changeapprove="${h(r.id)}">Approve Changes</button><button class="btn red small" data-changereject="${h(r.id)}">Reject</button>`:''}</div></article>`}
function panel(){let pending=state.biz.filter(x=>x.status==='pending').length, approved=state.biz.filter(x=>x.status==='approved').length, rejected=state.biz.filter(x=>x.status==='rejected').length, changePending=state.changes.filter(x=>x.status==='pending').length;
 let visible=state.tab==='all'?state.biz:state.tab==='changes'?state.changes.filter(x=>x.status==='pending'):state.biz.filter(x=>x.status===state.tab);
 $('#app').innerHTML=`<header><div><strong>BARAN PRIDE · ADMIN</strong><p>Private approval and manual payment management</p></div><button class="btn plain" id="logout">Sign Out</button></header><main><h1 style="margin:0;color:#122b51">Dashboard</h1><p class="label">Business listings and membership records</p><section class="cards"><div class="metric"><small>Pending Businesses</small><strong>${pending}</strong></div><div class="metric"><small>Approved Businesses</small><strong>${approved}</strong></div><div class="metric"><small>Rejected Businesses</small><strong>${rejected}</strong></div><div class="metric"><small>Pending Changes</small><strong>${changePending}</strong></div></section><div class="row"><h2>Approval Queue</h2><button class="btn plain" id="refresh">↻ Refresh</button></div><div class="tabs">${[['pending','Pending'],['approved','Approved'],['rejected','Rejected'],['all','All Businesses'],['changes','Change Requests']].map(([id,label])=>`<button class="tab ${state.tab===id?'active':''}" data-tab="${id}">${label}</button>`).join('')}</div><section>${visible.length?(state.tab==='changes'?visible.map(changeCard):visible.map(card)).join(''):'<div class="empty">No records in this section.</div>'}</section><p class="footnote">Security: only Firebase accounts with the admin custom claim can read/approve listings or record payments. No payment gateway is integrated.</p></main>${state.modal||''}`;
 $('#logout').onclick=()=>state.U.signOut(state.auth);
 $('#refresh').onclick=load;
}
async function load(){if(!state.user)return;try{const F=state.F;const [biz,chg]=await Promise.all([F.getDocs(F.collection(state.db,'businesses')),F.getDocs(F.collection(state.db,'changeRequests'))]);state.biz=biz.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));state.changes=chg.docs.map(x=>({id:x.id,...x.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));state.modal=null;panel()}catch(err){toast('Cannot load admin records: '+err.message)}}
function openModal(title,body,actions=''){state.modal=`<div class="modalwrap" id="modal"><div class="modal"><h2>${h(title)}</h2>${body}<div class="row"><button class="btn plain" id="close-modal">Cancel</button>${actions}</div></div></div>`;panel();$('#close-modal').onclick=()=>{state.modal=null;panel()}}
function detail(b){openModal('Business Details',`<p><b>Name:</b> ${h(b.name)}</p><p><b>Category:</b> ${h(b.category)}</p><p><b>Area:</b> ${h(b.area)}</p><p><b>Address:</b> ${h(b.address)}</p><p><b>Phone:</b> ${h(b.phone)}</p><p><b>WhatsApp:</b> ${h(b.whatsapp)}</p><p><b>Hours:</b> ${h(b.hours)}</p><p><b>Description:</b> ${h(b.description)}</p><p><b>Status:</b> ${h(b.status)} · <b>Plan:</b> ${h(b.plan)} · <b>Payment:</b> ${h(b.paymentStatus)}</p>${(b.photoUrls||[]).map(url=>`<img alt="Business uploaded photo" src="${h(url)}" style="width:100px;height:70px;object-fit:cover;border-radius:8px;margin:4px">`).join('')}`)}
async function approve(id){const b=state.biz.find(x=>x.id===id);if(!b)return;
 if(b.plan!=='free'&&b.paymentStatus!=='paid')return toast('Paid plan needs manually confirmed payment first');
 if(!confirm('Approve '+b.name+'?'))return;
 try{await state.F.updateDoc(state.F.doc(state.db,'businesses',id),{status:'approved',planStatus:'active',updatedAt:state.F.serverTimestamp()});toast('Business approved');await load()}catch(e){toast(e.message)}
}
async function reject(id){const b=state.biz.find(x=>x.id===id);if(!b)return;if(!confirm('Reject '+b.name+'?'))return;
 try{await state.F.updateDoc(state.F.doc(state.db,'businesses',id),{status:'rejected',planStatus:'inactive',updatedAt:state.F.serverTimestamp()});toast('Listing rejected');await load()}catch(e){toast(e.message)}
}
function payment(b){openModal('Record Verified Manual Payment — '+b.name,`<p class="label">Record payment only after you independently verify Cash, UPI or Bank Transfer. This is NOT a payment collection form.</p><form id="payment-form"><div class="formgrid"><label class="field"><span>Plan *</span><select name="plan" required><option value="standard" ${b.plan==='standard'?'selected':''}>Standard</option><option value="premium" ${b.plan==='premium'?'selected':''}>Premium</option></select></label><label class="field"><span>Amount received (₹) *</span><input name="amount" type="number" min="1" step="0.01" value="${h(b.paidAmount||499)}" required></label><label class="field"><span>Payment Method *</span><select name="method" required><option>UPI</option><option>Cash</option><option>Bank Transfer</option></select></label><label class="field"><span>Payment Reference / Receipt *</span><input name="reference" required maxlength="120" placeholder="UTR or cash receipt number"></label><label class="field"><span>Validity (months) *</span><select name="months"><option value="12">12 months</option><option value="6">6 months</option><option value="3">3 months</option></select></label><label class="field"><span>Internal Note (optional)</span><input name="note" maxlength="300" placeholder="Verified by / remarks"></label></div><button type="submit" class="btn green" style="width:100%;margin-top:15px">Confirm & Record Payment</button></form>`);
 $('#payment-form').onsubmit=async e=>{e.preventDefault();let vals=Object.fromEntries(new FormData(e.target)),amount=Number(vals.amount),months=Number(vals.months);if(!(amount>0&&months>=1))return toast('Check payment amount and validity');if(!confirm('Have you verified payment of ₹'+amount+' from '+b.name+'?'))return;let btn=$('#payment-form button[type=submit]');btn.disabled=true;
  try{const F=state.F,expires=new Date();expires.setMonth(expires.getMonth()+months);const batch=F.writeBatch(state.db);const record=F.doc(F.collection(state.db,'paymentHistory'));
   batch.set(record,{businessId:b.id,businessName:b.name,ownerUid:b.ownerUid,amount,method:vals.method,reference:vals.reference,plan:vals.plan,months,note:vals.note||'',verifiedBy:state.user.uid,paidAt:F.serverTimestamp(),expiresAt:F.Timestamp.fromDate(expires)});
   batch.update(F.doc(state.db,'businesses',b.id),{plan:vals.plan,featured:vals.plan==='premium',paymentStatus:'paid',planStatus:b.status==='approved'?'active':'inactive',paidAmount:amount,paymentMethod:vals.method,paymentReference:vals.reference,paidAt:F.serverTimestamp(),expiresAt:F.Timestamp.fromDate(expires),updatedAt:F.serverTimestamp()});
   await batch.commit();toast('Payment verified and recorded');await load();
  }catch(err){toast('Payment not recorded: '+err.message);btn.disabled=false}
 }
}
async function changeStatus(id,approved){let r=state.changes.find(x=>x.id===id);if(!r)return;if(!confirm((approved?'Approve':'Reject')+' requested changes?'))return;try{let F=state.F,batch=F.writeBatch(state.db);if(approved){batch.update(F.doc(state.db,'businesses',r.businessId),{...r.patch,updatedAt:F.serverTimestamp()})}batch.update(F.doc(state.db,'changeRequests',id),{status:approved?'approved':'rejected',reviewedAt:F.serverTimestamp(),reviewedBy:state.user.uid});await batch.commit();toast(approved?'Changes approved':'Changes rejected');await load()}catch(e){toast(e.message)}}
document.addEventListener('click',e=>{let b=e.target.closest('button');if(!b||!state.user)return;
 if(b.dataset.tab){state.tab=b.dataset.tab;panel()}
 if(b.dataset.view){let x=state.biz.find(o=>o.id===b.dataset.view);if(x)detail(x)}
 if(b.dataset.approve)approve(b.dataset.approve);
 if(b.dataset.reject)reject(b.dataset.reject);
 if(b.dataset.payment){let x=state.biz.find(o=>o.id===b.dataset.payment);if(x)payment(x)}
 if(b.dataset.changeapprove)changeStatus(b.dataset.changeapprove,true);
 if(b.dataset.changereject)changeStatus(b.dataset.changereject,false);
});
async function init(){if(!cfg.apiKey||!cfg.projectId){login('Firebase is not configured. Enter the same Firebase Web App config in admin/firebase-config.js and in the Android app config.');$('#login button').disabled=true;return}
 try{let [A,U,F]=await Promise.all([import(base+'firebase-app.js'),import(base+'firebase-auth.js'),import(base+'firebase-firestore.js')]);let app=A.initializeApp(cfg);state.U=U;state.F=F;state.auth=U.getAuth(app);state.db=F.getFirestore(app);
  U.onAuthStateChanged(state.auth,async user=>{if(!user){state.user=null;login();return}
   try{let result=await user.getIdTokenResult(true);if(result.claims.admin!==true){state.user=null;await U.signOut(state.auth);login('This account is not authorized as a Baran Pride administrator.');toast('Access denied: admin role required');return}
    state.user=user;await load()
   }catch(err){state.user=null;login(err.message)}
  });
 }catch(err){login('Firebase initialization failed: '+err.message);$('#login button').disabled=true}
}
init();
})();
