// SAME Firebase Web App config as app/src/main/assets/js/config.js
window.BARAN_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  appId: ""
};
