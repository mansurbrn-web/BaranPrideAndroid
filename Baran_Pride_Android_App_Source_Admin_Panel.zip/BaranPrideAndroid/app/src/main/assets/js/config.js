// Copy Firebase Web App config from Firebase Console > Project settings > Your apps.
// Keep these fields blank to run a LOCAL DEMO. Never place an admin service-account key here.
window.BARAN_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  appId: ""
};
