/* Optional Firebase data layer. App works as an explicitly labelled demo until configured. */
(function(){
 const cfg=window.BARAN_FIREBASE_CONFIG||{};
 const C={enabled:false,ready:false,user:null,auth:null,db:null,storage:null,m:null,onUserChange:null};
 const base='https://www.gstatic.com/firebasejs/10.14.1/';
 C.init=async function(){
  if(!cfg.apiKey||!cfg.projectId||!cfg.appId){C.ready=true;return false}
  try{
   const [A,U,F,S]=await Promise.all([import(base+'firebase-app.js'),import(base+'firebase-auth.js'),import(base+'firebase-firestore.js'),import(base+'firebase-storage.js')]);
   const app=A.initializeApp(cfg); C.auth=U.getAuth(app);C.db=F.getFirestore(app);C.storage=S.getStorage(app);C.m={U,F,S};C.enabled=true;
   U.onAuthStateChanged(C.auth,user=>{C.user=user;if(typeof C.onUserChange==='function') C.onUserChange(user)});
   C.ready=true;return true;
  }catch(e){console.error('Firebase unavailable',e);C.ready=true;C.error=e.message;return false}
 };
 C.signUp=async function(email,password,name){
  const x=await C.m.U.createUserWithEmailAndPassword(C.auth,email,password);
  if(name) await C.m.U.updateProfile(x.user,{displayName:name});C.user=x.user;return x.user;
 };
 C.signIn=async function(email,password){let x=await C.m.U.signInWithEmailAndPassword(C.auth,email,password);C.user=x.user;return x.user};
 C.signOut=async function(){await C.m.U.signOut(C.auth);C.user=null};
 C.approved=async function(){const F=C.m.F;
  const snap=await F.getDocs(F.query(F.collection(C.db,'businesses'),F.where('status','==','approved')));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
 };
 C.owned=async function(){if(!C.user)return[];const F=C.m.F;
  const snap=await F.getDocs(F.query(F.collection(C.db,'businesses'),F.where('ownerUid','==',C.user.uid)));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
 };
 C.register=async function(data,files){
  if(!C.user)throw Error('Please sign in first');
  const F=C.m.F,doc=await F.addDoc(F.collection(C.db,'businesses'),{
   name:data.name,category:data.category,area:data.area,address:data.address,phone:data.phone,whatsapp:data.whatsapp||data.phone,
   description:data.description||'',hours:data.hours||'Contact business',ownerUid:C.user.uid,
   status:'pending',plan:'free',planStatus:'inactive',paymentStatus:'unpaid',featured:false,
   cover:'',photoUrls:[],views:0,callClicks:0,createdAt:F.serverTimestamp(),updatedAt:F.serverTimestamp()
  });
  if(files&&files.length){
   const urls=[];
   for(let i=0;i<Math.min(files.length,5);i++){
    const file=files[i]; if(!file.type.startsWith('image/')||file.size>5*1024*1024)continue;
    const path='businesses/'+C.user.uid+'/'+doc.id+'/'+Date.now()+'-'+i+'-'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
    const ref=C.m.S.ref(C.storage,path);await C.m.S.uploadBytes(ref,file,{contentType:file.type});
    urls.push(await C.m.S.getDownloadURL(ref));
   }
   await F.updateDoc(F.doc(C.db,'businesses',doc.id),{cover:urls[0]||'',photoUrls:urls,updatedAt:F.serverTimestamp()});
  }
  return doc.id;
 };
 C.requestEdit=async function(id,patch){if(!C.user)throw Error('Please sign in');
  const F=C.m.F;
  await F.addDoc(F.collection(C.db,'changeRequests'),{businessId:id,ownerUid:C.user.uid,patch,createdAt:F.serverTimestamp(),status:'pending'});
 };
 window.BaranCloud=C;
})();
