(function(){
'use strict';
const C=window.BaranCloud;
const svgPaths={
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>', bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
 user:'<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',pin:'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
 sliders:'<path d="M4 7h8m4 0h4M4 17h3m4 0h9"/><circle cx="14" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
 cart:'<circle cx="9" cy="20" r="1"/><circle cx="19" cy="20" r="1"/><path d="M2 3h3l3 13h11l3-10H6"/>',
 health:'<path d="M5 4a4 4 0 0 0-4 4v5a6 6 0 0 0 12 0V8a4 4 0 0 0-4-4M5 4v3m4-3v3m4 6v2a5 5 0 0 0 10 0v-3"/><circle cx="19" cy="10" r="2"/>',
 food:'<path d="M4 2v8m4-8v8M2 6h8M6 10v12M17 2v20M17 2c7 3 7 11 0 11"/>',
 education:'<path d="m2 9 10-5 10 5-10 5zM6 11v6c4 3 8 3 12 0v-6M22 9v7"/>',
 property:'<path d="m2 11 10-9 10 9M5 10v12h14V10M9 22v-8h6v8"/>',
 tools:'<path d="M14 6a6 6 0 0 1-8 8L2 18l4 4 4-4a6 6 0 0 0 8-8l-4 4-4-4z"/>',
 car:'<path d="M5 16h14l-1-8H6zM3 16h18v4H3zM7 20v2m10-2v2M7 8l2-4h6l2 4"/>',
 job:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18m-11-1h4v3h-4z"/>',
 hotel:'<path d="M4 22V4h16v18M2 22h20M8 8h2m4 0h2M8 12h2m4 0h2M8 16h2m4 0h2M10 22v-4h4v4"/>',
 temple:'<path d="M4 22h16M5 22V9h14v13M3 9h18M12 2l8 7H4zM10 22v-7h4v7"/>',
 grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
 store:'<path d="M3 10h18l-2-6H5zM5 10v11h14V10M9 21v-7h6v7"/>',
 arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',back:'<path d="M15 18 9 12l6-6"/>',phone:'<path d="M22 16.5v3a2 2 0 0 1-2.2 2 19 19 0 0 1-17-17A2 2 0 0 1 4.8 2h3a2 2 0 0 1 2 1.7l.7 3a2 2 0 0 1-.7 2l-1.7 1.4a15 15 0 0 0 5.8 5.8l1.4-1.7a2 2 0 0 1 2-.7l3 .7a2 2 0 0 1 1.7 2.3z"/>',
 message:'<path d="M21 11.5a8.4 8.4 0 0 1-12 7.5L3 21l2-6A8.5 8.5 0 1 1 21 11.5z"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',share:'<circle cx="18" cy="5" r="2"/><circle cx="6" cy="12" r="2"/><circle cx="18" cy="19" r="2"/><path d="m8 11 8-5M8 13l8 5"/>',edit:'<path d="M12 20h9M16 3l5 5L9 20H4v-5z"/>',check:'<path d="m4 12 5 5L20 6"/>',logout:'<path d="M10 3H4v18h6M14 7l5 5-5 5m5-5H8"/>',camera:'<path d="M4 7h4l2-3h4l2 3h4v14H4z"/><circle cx="12" cy="14" r="4"/>',plus:'<path d="M12 3v18M3 12h18"/>',drop:'<path d="M12 3c2.6 4 7 8.4 7 12a7 7 0 0 1-14 0c0-3.6 4.4-8 7-12z"/>', menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',close:'<path d="M5 5l14 14M19 5 5 19"/>',book:'<path d="M12 7c-4-3-8-3-10-2v14c3-1 7-1 10 2m0-14c4-3 8-3 10-2v14c-3-1-7-1-10 2m0-14v14"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>',news:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h6v5H7zM16 8h2M16 11h2M7 16h11"/>',info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7h.01"/>',map:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3zM9 3v15m6-12v15"/>'
};
const icon=(n,size=21)=>`<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${svgPaths[n]||svgPaths.grid}</svg>`;
const $=s=>document.querySelector(s), escapeHtml=(v)=>String(v??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
// V3.1: Mask every alternate visible character in EACH word of a donor name.
// Example: Mansur Ali -> M*n*u* A*i. This is a display-only mask.
function maskBloodDonorName(name){
  return String(name??'').trim().split(/(\s+)/u).map(word=>{
    if(/^\s+$/u.test(word))return word;
    const letters=typeof Intl.Segmenter==='function'
      ? Array.from(new Intl.Segmenter('hi',{granularity:'grapheme'}).segment(word),item=>item.segment)
      : Array.from(word);
    return letters.map((letter,index)=>index%2===0?letter:'*').join('');
  }).join('');
}
const categories=[['Shopping','cart'],['Doctors','health'],['Restaurants','food'],['Education','education'],['Property','property'],['Services','tools'],['Automobile','car'],['Jobs','job'],['Hotels','hotel'],['More','grid']];
// Full directory category screen: keep the ten existing homepage slots unchanged.
// New approved business categories and active admin-managed categories appear automatically.
const ALL_CATEGORY_SEED=[
 ['Shopping','cart'],['Doctors','health'],['Restaurants','food'],['Education','education'],
 ['Property','property'],['Services','tools'],['Automobile','car'],['Jobs','job'],
 ['Hotels','hotel'],['Temples','temple'],['Medical','health'],['Beauty Parlour','store'],
 ['Electronics','store'],['Clothing','cart'],['Hardware','tools'],['Gym','heart'],
 ['Photography','camera'],['Printing & Stationery','book'],['Grocery','cart'],
 ['Real Estate','property'],['Others','grid']
];
const categoryIcon=name=>{
 const n=String(name||'').toLowerCase().trim();
 return ALL_CATEGORY_SEED.find(item=>item[0].toLowerCase()===n)?.[1]||'store';
};
function allBusinessCategories(){
 const names=new Map();
 function add(value){const n=String(value||'').trim();if(!n||n.toLowerCase()==='more'||n.toLowerCase()==='all')return;
  const key=n.toLocaleLowerCase();if(!names.has(key))names.set(key,n)}
 ALL_CATEGORY_SEED.forEach(item=>add(item[0]));
 (S.customCategories||[]).forEach(add);
 S.businesses.filter(b=>b.status==='approved').forEach(b=>add(b.category));
 return [...names.values()];
}
function categoryCount(name){return S.businesses.filter(b=>b.status==='approved'&&String(b.category||'').toLocaleLowerCase()===name.toLocaleLowerCase()).length}
function allCategoriesPage(){
 const items=allBusinessCategories();
 return `<div class="screen categories-page">${head('All Business Categories')}<h1 class="page-title">Explore Categories</h1><p class="intro">श्रेणी चुनकर Baran के स्थानीय बिजनेस खोजें</p><div class="search-bar category-search">${icon('search')}<input id="all-categories-search" value="${escapeHtml(S.categorySearch)}" placeholder="Search categories..." autocomplete="off" aria-label="Search all categories"></div><p class="result-count" id="categories-result-count">${items.length} categories</p><div class="all-category-grid" id="all-category-grid">${items.map(name=>`<button class="all-category-tile" data-all-category="${escapeHtml(name)}" data-category-search="${escapeHtml(name.toLocaleLowerCase())}"><span class="all-category-symbol">${icon(categoryIcon(name),25)}</span><strong>${escapeHtml(name)}</strong><small>${categoryCount(name)} businesses</small></button>`).join('')}</div><div class="city-message hidden" id="category-search-empty">No matching categories found.</div></div>`;
}
const DEMO=[
 {id:'demo-1',name:'The Royal Restaurant',category:'Restaurants',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/restaurant.jpg',rating:4.5,reviews:128,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-2',name:'MediCare Hospital',category:'Doctors',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/hospital.jpg',rating:4.8,reviews:210,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-3',name:'Fashion Hub',category:'Shopping',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/fashion.jpg',rating:4.3,reviews:96,featured:true,status:'approved',demo:true,description:'Demonstration listing to show the design.'},
 {id:'demo-4',name:'Sharma Electronics',category:'Shopping',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/electronics.jpg',rating:0,featured:false,status:'approved',demo:true,description:'Example business name only.'},
 {id:'demo-5',name:'Guru Kirpa Motors',category:'Automobile',area:'Baran',address:'Sample listing, Baran, Rajasthan',cover:'img/automobile.jpg',rating:0,featured:false,status:'approved',demo:true,description:'Example business name only.'}
];
const CITY_TYPES=[['historical','Historical Places','ऐतिहासिक स्थल','temple'],['blogs','Blogs & Articles','ब्लॉग और लेख','book'],['tourist','Tourist Places','घूमने की जगहें','pin'],['events','Events & Festivals','कार्यक्रम और मेले','calendar'],['updates','City Updates','शहर की जानकारी','news'],['contacts','Important Contacts','जरूरी संपर्क','phone'],['about','About Baran','बारां के बारे में','info']];
const cityType=(id)=>CITY_TYPES.find(x=>x[0]===id)||CITY_TYPES[0];
const S={customCategories:[],categorySearch:'',returnToCategories:false,donors:[],donorError:'',donorFilter:'All',properties:[],propertyError:'',helpline:'7737325205',propertySubmitting:false,drawer:false,cityType:'historical',cityItems:[],cityId:null,cityQuery:'',cityLoading:false,cityError:'',cityBackTarget:'cityList',homeCityItems:[],homeCityError:'',homeSlidePositions:{events:0,historical:0},page:'home',category:'All',query:'',businesses:[...DEMO],owned:[],saved:new Set(JSON.parse(localStorage.getItem('baran_saved')||'[]')),detail:null,authTab:'signin',afterAuth:'add',editingId:null,loading:false};
const cacheGet=(k,def)=>{try{return JSON.parse(localStorage.getItem(k))??def}catch{return def}};
const toast=(msg)=>{let t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2600)};
function native(method,...args){try{if(window.AndroidBridge&&typeof window.AndroidBridge[method]==='function'){window.AndroidBridge[method](...args);return true}}catch(e){console.warn(e)}return false}
function openUrl(url){if(!url)return;if(!native('openUrl',url))window.open(url,'_blank','noopener')}
function demoWarning(){toast('यह सिर्फ Design Demo Listing है');}
function callBusiness(id){const b=findBiz(id);if(!b)return;if(!b.phone||b.demo)return demoWarning();if(!native('dial',b.phone))openUrl('tel:'+encodeURIComponent(b.phone));}
function whatsapp(id){const b=findBiz(id);if(!b)return;if(!b.whatsapp&&!b.phone||b.demo)return demoWarning();const num=(b.whatsapp||b.phone).replace(/[^\d]/g,'');openUrl('https://wa.me/'+(num.startsWith('91')?num:'91'+num));}
function directions(id){const b=findBiz(id);if(!b)return;if(b.demo)return demoWarning();openUrl('https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(b.address+', '+b.area+', Rajasthan'));}
function share(id){const b=findBiz(id);if(!b)return;const txt=b.name+' — '+b.area+', Baran Rajasthan';if(native('shareText',txt))return;if(navigator.share){navigator.share({title:b.name,text:txt}).catch(()=>{})}else if(navigator.clipboard){navigator.clipboard.writeText(txt).then(()=>toast('Business details copied'))}}
function findBiz(id){return [...S.businesses,...S.owned].find(b=>b.id===id)}
function saveToggle(id){if(S.saved.has(id))S.saved.delete(id);else S.saved.add(id);localStorage.setItem('baran_saved',JSON.stringify([...S.saved]));toast(S.saved.has(id)?'Saved to favorites':'Removed from favorites');render()}
const bottom=()=>`<nav class="bottom-nav" aria-label="Main navigation">${[['home','home','Home'],['explore','grid','Explore'],['saved','heart','Saved'],['owner','store','My Business'],['profile','user','Profile']].map(([key,ic,label])=>`<button class="nav-item ${S.page===key?'active':''}" data-go="${key}" aria-label="${label}">${icon(ic,24)}<span>${label}</span></button>`).join('')}</nav>`;
const brand=()=>`<div class="brand"><div class="logo"><img src="img/baran-pride-blue-logo.png" width="57" height="57" alt="BARAN PRIDE logo" loading="eager"></div><div><div class="brand-main">BARAN <span>PRIDE</span></div><div class="tagline">हमारा शहर, हमारी पहचान</div></div></div>`;
const head=(title)=>`<div class="back-header"><button data-back aria-label="Back">${icon('back')}</button><strong>${title}</strong></div>`;
const banner=()=>C.enabled?'':`<span class="demo-badge">DESIGN DEMO · दिखाई गई लिस्टिंग वास्तविक नहीं हैं</span>`;
function section(title,go){return `<div class="section-head"><h2>${title}</h2><button data-go="${go}">View All →</button></div>`}
function bizCard(b){return `<article class="business-card"><div class="imgwrap"><img src="${escapeHtml(b.cover||'img/restaurant.jpg')}" alt="${escapeHtml(b.name)}" loading="lazy">${b.featured?'<span class="mark-featured">★ Featured</span>':''}</div><div class="card-body"><div class="card-name">${escapeHtml(b.name)}</div><div class="card-sub">${escapeHtml(b.category)} · ${escapeHtml(b.area)}</div><div class="rating">${b.rating?`<span class="star">★</span> ${b.rating} <em>(${b.reviews||0})</em>`:'<em>New listing</em>'}</div><div class="card-actions"><button data-call="${b.id}">${icon('phone',17)}Call</button><button data-wa="${b.id}">${icon('message',17)}WhatsApp</button><button data-detail="${b.id}">${icon('pin',17)}Details</button></div></div></article>`}
function latestCard(b){return `<article class="latest-row"><img src="${escapeHtml(b.cover||'img/restaurant.jpg')}" alt=""><div><strong>${escapeHtml(b.name)}</strong><small>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</small></div><button class="smallaction" data-detail="${b.id}" aria-label="View business">${icon('arrow',18)}</button></article>`}
function filtered(){return S.businesses.filter(b=>(S.category==='All'||String(b.category||'').toLocaleLowerCase()===S.category.toLocaleLowerCase())&&[b.name,b.category,b.area,b.address].join(' ').toLowerCase().includes(S.query.toLowerCase())).sort((a,b)=>Number(!!b.featured)-Number(!!a.featured))}
// Homepage city panels are intentionally small additions to the existing V3.1 design.
// Only published AND explicitly chosen by Admin appear on the Homepage.
const HOME_SECTION_TYPES={events:['events'],historical:['historical'],news:['blogs','updates']};
function homeCitySorted(section){
 const types=HOME_SECTION_TYPES[section]||[];
 return S.homeCityItems.filter(x=>x.status==='published'&&x.showOnHomepage===true&&types.includes(x.type)).sort((a,b)=>{
  const order=x=>Number.isFinite(Number(x.homeOrder))?Number(x.homeOrder):100;
  const published=x=>x.publishedAt?.seconds||x.updatedAt?.seconds||0;
  return order(a)-order(b)||published(b)-published(a);
 });
}
function homeCityHeading(title,section,iconName){
 return `<div class="section-head home-city-section-head"><h2>${icon(iconName,20)} ${title}</h2><button data-home-viewall="${section}">View All →</button></div>`;
}
function homepageSlider(section,title,iconName){
 const items=homeCitySorted(section);if(!items.length)return '';
 const index=Math.min(Math.max(0,S.homeSlidePositions[section]||0),items.length-1);
 const slides=items.map((x,i)=>{
  const image=safeHttps(x.cover);
  const subtitle=section==='events'? [x.eventDate||cityDate(x.publishedAt),x.area].filter(Boolean).join(' · '): String(x.summary||'').trim();
  return `<article class="home-landscape-slide ${i===index?'is-current':''}" data-home-slide-index="${i}" role="group" aria-label="${i+1} of ${items.length}" aria-hidden="${i!==index}">
   ${image?`<img src="${escapeHtml(image)}" alt="${escapeHtml(x.title)}" loading="lazy">`:'<div class="home-landscape-no-image" aria-hidden="true"></div>'}
   <div class="home-landscape-shade"></div>
   <div class="home-landscape-caption"><div class="home-landscape-title">${escapeHtml(x.title)}</div>${subtitle?`<p>${escapeHtml(subtitle)}</p>`:''}</div>
   <button class="home-landscape-detail" data-home-detail="${escapeHtml(x.id)}" type="button">View Details →</button>
  </article>`;
 }).join('');
 return `<section class="home-city-block" aria-label="${title}">${homeCityHeading(title,section,iconName)}
  <div class="home-landscape-slider" data-home-carousel="${section}">${slides}
   ${items.length>1?`<button class="home-landscape-nav prev" data-home-slide="-1" aria-label="Previous ${title}">${icon('back',21)}</button><button class="home-landscape-nav next" data-home-slide="1" aria-label="Next ${title}">${icon('arrow',21)}</button>`:''}</div>
   ${items.length>1?`<div class="home-slider-dots" role="group" aria-label="${title} slides">${items.map((_,i)=>`<button data-home-dot="${i}" aria-label="Show item ${i+1}" class="${i===index?'active':''}"></button>`).join('')}</div>`:''}
 </section>`;
}
function homepageNews(){
 const items=homeCitySorted('news');if(!items.length)return '';
 return `<section class="home-city-block home-news-block" aria-label="News & Blog">${homeCityHeading('News & Blog','news','news')}
  <div class="featured-strip home-news-strip">${items.map(x=>{
   const image=safeHttps(x.cover);
   return `<article class="business-card home-news-card"><div class="imgwrap">${image?`<img src="${escapeHtml(image)}" loading="lazy" alt="${escapeHtml(x.title)}">`:`<div class="home-news-no-image">${icon('news',30)}</div>`}</div><div class="card-body"><div class="card-name">${escapeHtml(x.title)}</div><div class="card-sub">${escapeHtml(cityDate(x.publishedAt)||x.eventDate||'News & Blog')}</div><div class="card-actions"><button type="button" data-home-detail="${escapeHtml(x.id)}">Read More →</button></div></div></article>`;
  }).join('')}</div></section>`;
}
let homeSlidesTimer=null;
function displayHomeSlide(slider,index){
 const slides=[...slider.querySelectorAll('.home-landscape-slide')];if(!slides.length)return;
 const target=((index%slides.length)+slides.length)%slides.length;
 slides.forEach((el,i)=>{el.classList.toggle('is-current',i===target);el.setAttribute('aria-hidden',String(i!==target))});
 slider.parentElement.querySelectorAll('[data-home-dot]').forEach((el,i)=>el.classList.toggle('active',i===target));
 S.homeSlidePositions[slider.dataset.homeCarousel]=target;
}
function startHomeSlides(){
 if(homeSlidesTimer){clearInterval(homeSlidesTimer);homeSlidesTimer=null}
 if(S.page!=='home')return;
 const eligible=()=>[...document.querySelectorAll('[data-home-carousel]')].filter(el=>el.querySelectorAll('.home-landscape-slide').length>1);
 if(eligible().length && !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches))homeSlidesTimer=setInterval(()=>{
  if(S.page!=='home'||document.hidden)return;
  eligible().forEach(el=>displayHomeSlide(el,(S.homeSlidePositions[el.dataset.homeCarousel]||0)+1));
 },4800);
}
function cityNewsList(){
 const arr=S.cityItems.filter(x=>x.status==='published'&&['blogs','updates'].includes(x.type));
 return `<div class="screen city-page">${head('News & Blog')}<div class="city-heading"><span>${icon('news',27)}</span><div><h1>News & Blog</h1><p>Published Baran city updates and articles</p></div></div>${S.cityLoading?'<div class="city-message">Loading published news and blogs...</div>':S.cityError?`<div class="city-message">${escapeHtml(S.cityError)}</div>`:arr.length?arr.map(x=>`<article class="city-list-card">${safeHttps(x.cover)?`<img src="${escapeHtml(safeHttps(x.cover))}" loading="lazy" alt="">`:`<div class="city-list-placeholder">${icon('news',32)}</div>`}<div class="city-list-text"><small>${x.type==='updates'?'City News':'Blog'} · ${escapeHtml(cityDate(x.publishedAt))}</small><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.summary||'')}</p><button data-city-detail="${escapeHtml(x.id)}">Read More →</button></div></article>`).join(''):'<div class="city-message">No published news or blogs yet.</div>'}</div>`;
}
async function openHomeCityList(section){
 if(section==='news'){
  S.cityError='';S.cityLoading=true;S.cityBackTarget='cityNews';go('cityNews');
  try{S.cityItems=C.enabled?await C.publicCity():[]}catch(e){S.cityError='Unable to load news and blogs.';console.warn(e)}
  finally{S.cityLoading=false;if(S.page==='cityNews')render()}
 }else{S.cityBackTarget='cityList';await openCity(section)}
}
function homeCityDetail(id){
 const x=S.homeCityItems.find(item=>item.id===id&&item.status==='published'&&item.showOnHomepage===true);
 if(!x)return toast('This information is no longer available');
 S.cityItems=S.homeCityItems;S.cityType=x.type;S.cityId=x.id;S.cityBackTarget='home';go('cityDetail');
}

function home(){const featured=S.businesses.filter(b=>b.featured).slice(0,10);const latest=[...S.businesses].slice(-8).reverse();return `<div class="screen"><div class="topbar">${brand()}<div class="top-actions"><button class="round-btn" data-action="notifications" aria-label="Notifications">${icon('bell')}</button><button class="round-btn" data-go="profile" aria-label="Profile">${icon('user')}</button><button class="round-btn city-menu-toggle" data-menu-open aria-label="City information menu">${icon('menu')}</button></div></div>${banner()}<section class="hero"><p class="location">${icon('pin',14)} Baran, Rajasthan</p><h1>Discover the<br>Best of Baran</h1><p class="subline">Find local businesses,<br>shops & services</p><form class="hero-search" id="hero-form">${icon('search',23)}<input id="hero-q" name="q" placeholder="Search businesses, services, places..." autocomplete="off" aria-label="Search"><button class="filter" type="submit" aria-label="Search">${icon('sliders')}</button></form></section><section class="categories">${categories.map(([c,i])=>`<button class="cat" data-category="${c}"><span class="cat-icon">${icon(i,25)}</span><span>${c}</span></button>`).join('')}</section>${homepageSlider('events','Events & Festivals','calendar')}<section class="grow"><span class="grow-icon">${icon('store',39)}</span><div class="grow-copy"><strong>Grow Your Business</strong><p>Get listed in Baran Pride and reach more customers</p></div><button class="pill-cta" data-go="add">Add Business →</button></section>${section('<span class="star">★</span> Featured Businesses','explore')}<div class="featured-strip">${(featured.length?featured:S.businesses).map(bizCard).join('')}</div>${homepageSlider('historical','Historical Places','temple')}${homepageNews()}${section('◷ Recently Added','explore')}${latest.map(latestCard).join('')||empty('No listings yet','Approved businesses will appear here.')}</div>`}
function empty(title,desc,action,label){return `<div class="empty"><div style="color:#2f67ac">${icon('store',48)}</div><h3>${title}</h3><p>${desc}</p>${action?`<button class="primary-btn" data-go="${action}">${label||'Get Started'}</button>`:''}</div>`}
function explore(){const arr=filtered();return `<div class="screen"><h1 class="page-title">Explore Baran</h1><p class="intro">Find the right shops, services and professionals</p>${banner()}<div class="search-bar">${icon('search')}<input id="explore-q" value="${escapeHtml(S.query)}" placeholder="Search business, category or area..."></div><div class="chipbar">${['All',...allBusinessCategories()].map(c=>`<button class="chip ${S.category===c?'selected':''}" data-category="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('')}</div><p class="result-count">${arr.length} business${arr.length===1?'':'es'} found</p>${arr.length?arr.map(b=>`<article class="listing-card"><img src="${escapeHtml(b.cover||'img/restaurant.jpg')}" alt=""><main><h3>${escapeHtml(b.name)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p><p>${b.rating?'★ '+b.rating+' · ':''}${b.featured?'Featured':'Local Business'}</p><div class="row-actions"><button class="primary-small" data-detail="${b.id}">View Details</button><button class="outline-small" data-save="${b.id}">${S.saved.has(b.id)?'♥ Saved':'♡ Save'}</button></div></main></article>`).join(''):empty('No businesses found','Try another search or select a different category.')}</div>`}
function detail(){const b=findBiz(S.detail);if(!b)return explore();return `<div class="screen">${head('Business Details')}<img class="detail-photo" src="${escapeHtml(b.cover||'img/restaurant.jpg')}" alt="${escapeHtml(b.name)}"><div class="detail-head"><div><h1>${escapeHtml(b.name)}</h1><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}, Rajasthan</p></div><button class="round-btn" data-save="${b.id}" aria-label="Save business" style="color:${S.saved.has(b.id)?'#d64c69':''}">${icon('heart',23)}</button></div>${b.demo?banner():''}<div class="detail-actions"><button data-call="${b.id}">${icon('phone',23)}Call</button><button data-wa="${b.id}">${icon('message',23)}WhatsApp</button><button data-map="${b.id}">${icon('pin',23)}Directions</button></div><h3 class="block-title">About Business</h3><div class="info-panel"><p style="font-size:13px;line-height:1.65;color:#425a7b;margin:0">${escapeHtml(b.description||'Explore this business in Baran.')}</p></div><h3 class="block-title">Contact & Location</h3><div class="info-panel"><div class="info-row">${icon('pin')}<span>${escapeHtml(b.address||'Baran, Rajasthan')}</span></div><div class="info-row">${icon('clock')}<span>${escapeHtml(b.hours||'Contact business for opening hours')}</span></div><div class="info-row">${icon('phone')}<span>${escapeHtml(b.phone||'Not provided')}</span></div></div><div class="detail-actions"><button data-share="${b.id}">${icon('share')}Share</button><button data-save="${b.id}">${icon('heart')}Save</button><button data-go="explore">${icon('search')}Explore</button></div></div>`}
function saved(){const arr=S.businesses.filter(b=>S.saved.has(b.id));return `<div class="screen"><h1 class="page-title">Saved Businesses</h1><p class="intro">Quickly find your favorite places</p>${arr.length?arr.map(b=>`<article class="listing-card"><img src="${escapeHtml(b.cover||'img/restaurant.jpg')}" alt=""><main><h3>${escapeHtml(b.name)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p><div class="row-actions"><button data-detail="${b.id}" class="primary-small">View Details</button><button data-save="${b.id}" class="outline-small">Remove</button></div></main></article>`).join(''):empty('No saved businesses','Save your favourite places to find them quickly.','explore','Explore Businesses')}</div>`}
function owner(){if(C.enabled&&!C.user)return `<div class="screen"><h1 class="page-title">My Business</h1><p class="intro">Manage your business listings</p>${empty('Sign in to manage listings','Sign in or register to add and view your businesses.','auth','Sign in / Register')}</div>`;
 return `<div class="screen"><h1 class="page-title">My Business</h1><p class="intro">Manage your listings and approval status</p>${!C.enabled?banner():''}<button class="primary-btn" data-go="add">${icon('plus',19)} Add New Business</button>${S.owned.length?S.owned.map(b=>`<article class="owner-card"><div style="display:flex;justify-content:space-between;align-items:flex-start;gap:9px"><div><h3>${escapeHtml(b.name)}</h3><p>${escapeHtml(b.category)} · ${escapeHtml(b.area)}</p></div><span class="status ${b.status||'pending'}">${escapeHtml(b.status||'pending').toUpperCase()}</span></div><div class="owner-statrow"><div class="stat"><small>Listing Plan</small><strong style="font-size:17px">${escapeHtml(b.plan||'Free')}</strong></div><div class="stat"><small>Payment</small><strong style="font-size:17px">${escapeHtml(b.paymentStatus||'Unpaid')}</strong></div></div><p><b>Validity:</b> ${b.expiresAt&&b.expiresAt.toDate?b.expiresAt.toDate().toLocaleDateString('en-IN'):'Not activated'}</p><p><b>Status:</b> ${b.status==='pending'?'Admin verification is pending.':b.status==='approved'?'Your business is live.':b.status==='rejected'?'Your listing needs corrections.':'Awaiting approval.'}</p><button class="secondary-btn" data-edit="${b.id}">${icon('edit',15)} Request Profile Change</button></article>`).join(''):empty('No business added yet','Register your shop, institute or service to get listed on Baran Pride.','add','Add Your Business')}</div>`}
function addForm(){if(C.enabled&&!C.user){S.afterAuth='add';return auth()}let b=S.editingId?S.owned.find(x=>x.id===S.editingId):null;return `<div class="screen">${head(b?'Request Business Changes':'Add Your Business')}<h1 class="page-title">${b?'Edit Request':'Business Registration'}</h1><p class="intro">${b?'Admin must approve changes before they appear.':'Submit your listing for admin approval.'}</p>${!C.enabled?banner():''}<form id="business-form" class="form-card"><div class="field"><label for="b-name">Business Name *</label><input id="b-name" name="name" required minlength="3" maxlength="100" value="${escapeHtml(b?.name||'')}" placeholder="Enter business or shop name"></div><div class="fieldrow"><div class="field"><label>Category *</label><select name="category" required><option value="">Select</option>${allBusinessCategories().map((c)=>`<option ${b?.category===c?'selected':''}>${escapeHtml(c)}</option>`).join('')}</select></div><div class="field"><label>Area *</label><input name="area" required placeholder="e.g. Kota Road" value="${escapeHtml(b?.area||'')}"></div></div><div class="field"><label>Full Address *</label><textarea name="address" required placeholder="Street, landmark, Baran, Rajasthan">${escapeHtml(b?.address||'')}</textarea></div><div class="fieldrow"><div class="field"><label>Mobile Number *</label><input type="tel" name="phone" inputmode="numeric" pattern="[0-9+ -]{10,15}" required placeholder="10-digit mobile" value="${escapeHtml(b?.phone||'')}"></div><div class="field"><label>WhatsApp Number</label><input type="tel" name="whatsapp" inputmode="numeric" pattern="[0-9+ -]{10,15}" placeholder="Optional" value="${escapeHtml(b?.whatsapp||'')}"></div></div><div class="field"><label>About Business</label><textarea name="description" maxlength="700" placeholder="Tell customers about your business">${escapeHtml(b?.description||'')}</textarea></div><div class="field"><label>Opening Hours</label><input name="hours" placeholder="e.g. Mon-Sat 9 AM to 8 PM" value="${escapeHtml(b?.hours||'')}"></div>${!b?`<div class="field"><label>Business Photos (up to 5, 5 MB each)</label><input type="file" name="photos" accept="image/*" multiple><span class="tiny">Photo upload works after Firebase setup; demo mode stores the business without photos.</span></div>`:''}<div class="form-note">After submission, the business remains <b>Pending</b> until approved by Admin. Premium payments are verified manually outside the Android app. No online payment link is shown here.</div><button class="primary-btn" id="submit-business" type="submit">${icon('check',18)} ${b?'Send Change Request':'Submit for Approval'}</button></form></div>`}
function auth(){return `<div class="screen">${head('Business Account')}<h1 class="page-title">${S.authTab==='signup'?'Create Account':'Welcome Back'}</h1><p class="intro">Sign in to manage your Baran Pride business</p><div class="chipbar"><button class="chip ${S.authTab==='signin'?'selected':''}" data-auth-tab="signin">Sign In</button><button class="chip ${S.authTab==='signup'?'selected':''}" data-auth-tab="signup">Register</button></div><form id="auth-form" class="form-card">${S.authTab==='signup'?`<div class="field"><label>Your Name *</label><input name="name" autocomplete="name" required></div>`:''}<div class="field"><label>Email Address *</label><input name="email" type="email" autocomplete="email" required placeholder="you@example.com"></div><div class="field"><label>Password *</label><input name="password" type="password" minlength="6" autocomplete="${S.authTab==='signup'?'new-password':'current-password'}" required placeholder="Minimum 6 characters"></div><button class="primary-btn" type="submit">${S.authTab==='signup'?'Create Account':'Sign In'} ${icon('arrow',16)}</button></form><div class="form-note">Only business owners need an account. Customers can browse listings without signing in.</div></div>`}
function profile(){const user=C.user;return `<div class="screen"><h1 class="page-title">My Profile</h1><p class="intro">Account and app information</p><div class="account"><div class="avatar">${icon('user',36)}</div><h2>${escapeHtml(user?.displayName||'Welcome to Baran Pride')}</h2><p>${escapeHtml(user?.email||'Discover local businesses in Baran')}</p></div><div class="menu-group"><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="owner">${icon('store')} My Business ${icon('arrow',17)}</button><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="saved">${icon('heart')} Saved Businesses ${icon('arrow',17)}</button><button style="width:100%;text-align:left;border:0;background:transparent" class="menu-row" data-go="add">${icon('plus')} Add Your Business ${icon('arrow',17)}</button></div>${C.enabled?(user?`<button class="secondary-btn" data-action="logout">${icon('logout',17)} Sign Out</button>`:`<button class="primary-btn" data-go="auth">Sign In / Register</button>`):'<div class="notice">Demo mode: Firebase project is not connected. Listings are samples or stored only on this device.</div>'}<p class="fine-print">BARAN PRIDE · हमारा शहर, हमारी पहचान<br>Royal Blue Premium • Version 1.0</p></div>`}

// V2: Additional city information lives only behind this drawer; original business homepage stays intact.
function cityDrawer(){return `<div class="city-drawer-layer"><button class="city-drawer-shade" data-menu-close aria-label="Close menu"></button><aside class="city-drawer" role="dialog" aria-modal="true" aria-label="Baran city information"><div class="city-drawer-header"><button class="city-drawer-x" data-menu-close aria-label="Close">${icon('close')}</button><strong>BARAN PRIDE</strong><small>हमारा शहर, हमारी पहचान</small><p>Explore More About Baran</p></div><div class="city-drawer-items"><button data-go="home">${icon('home')} Home ${icon('arrow',17)}</button><button data-go="explore">${icon('store')} Local Businesses ${icon('arrow',17)}</button><hr><button data-special="properties">${icon('property')}<span>Sell Property<small>प्रॉपर्टी बिक्री और ग्राहक सेवा</small></span>${icon('arrow',17)}</button><button data-special="donors">${icon('drop')}<span>Blood Donors<small>रक्तदाताओं की सूची</small></span>${icon('arrow',17)}</button>${CITY_TYPES.map(t=>`<button data-city-type="${t[0]}">${icon(t[3])}<span>${t[1]}<small>${t[2]}</small></span>${icon('arrow',17)}</button>`).join('')}</div><p class="city-drawer-footer">City information is published only by the Admin.</p></aside></div>`}
function openDrawer(){if(document.querySelector('.city-drawer-layer'))return;S.drawer=true;$('#app').insertAdjacentHTML('beforeend',cityDrawer());document.body.classList.add('city-drawer-open')}
function closeDrawer(){S.drawer=false;document.querySelector('.city-drawer-layer')?.remove();document.body.classList.remove('city-drawer-open')}
async function openCity(type){closeDrawer();S.cityBackTarget='cityList';S.cityType=cityType(type)[0];S.cityId=null;S.cityQuery='';S.cityError='';S.cityLoading=true;go('cityList');
 try{S.cityItems=C.enabled?await C.publicCity():[]}
 catch(e){S.cityError='Unable to load city information. Please check the internet.';console.warn(e)}
 finally{S.cityLoading=false;if(S.page==='cityList')render()}
}
function safeHttps(u){try{const x=new URL(String(u||''));return x.protocol==='https:'?x.href:''}catch{return ''}}
function cityDate(v){const d=v&&typeof v.toDate==='function'?v.toDate():v?.seconds?new Date(v.seconds*1000):v?new Date(v):null;return d&&!Number.isNaN(d.getTime())?d.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}):''}
function cityList(){const t=cityType(S.cityType),arr=S.cityItems.filter(x=>x.type===S.cityType);return `<div class="screen city-page">${head(t[1])}<div class="city-heading"><span>${icon(t[3],27)}</span><div><h1>${t[1]}</h1><p>${t[2]} · BARAN PRIDE</p></div></div><div class="search-bar">${icon('search')}<input id="city-search" value="${escapeHtml(S.cityQuery)}" placeholder="Search ${escapeHtml(t[1].toLowerCase())}..." aria-label="Search city information"></div>${S.cityLoading?'<div class="city-message">Loading published information...</div>':S.cityError?`<div class="city-message">${escapeHtml(S.cityError)} <button data-city-retry>Retry</button></div>`:arr.length?`<div id="city-results">${arr.map(x=>`<article class="city-list-card" data-city-search="${escapeHtml([x.title,x.area,x.summary].join(' ').toLowerCase())}">${safeHttps(x.cover)?`<img src="${escapeHtml(safeHttps(x.cover))}" loading="lazy" alt="">`:`<div class="city-list-placeholder">${icon(t[3],32)}</div>`}<div class="city-list-text"><small>${escapeHtml(t[1])}${x.area?' · '+escapeHtml(x.area):''}</small><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.summary||'Tap to read more.')}</p><button data-city-detail="${escapeHtml(x.id)}">Read More →</button></div></article>`).join('')}</div><p class="city-no-match hidden" id="city-no-match">No matching information found.</p>`:'<div class="city-message">अभी इस सेक्शन में कोई जानकारी प्रकाशित नहीं हुई है।<br><small>Only Admin can publish new information.</small></div>'}</div>`}
function cityDetail(){const x=S.cityItems.find(o=>o.id===S.cityId&&o.status==='published'),t=cityType(S.cityType);if(!x)return cityList();let gallery=(Array.isArray(x.photos)?x.photos:[]).map(safeHttps).filter(Boolean);const cover=safeHttps(x.cover);if(!gallery.length&&cover)gallery=[cover];const mapUrl=safeHttps(x.mapUrl),phone=String(x.phone||'').replace(/[^0-9+]/g,'');return `<div class="screen city-page">${head(t[1])}<article class="city-article">${cover?`<img class="city-article-cover" src="${escapeHtml(cover)}" alt="${escapeHtml(x.title)}">`:`<div class="city-article-cover city-article-empty">${icon(t[3],55)}</div>`}<div class="city-article-meta">${escapeHtml(t[1])}${x.area?' · '+escapeHtml(x.area):''}</div><h1>${escapeHtml(x.title)}</h1>${x.summary?`<p class="city-summary">${escapeHtml(x.summary)}</p>`:''}<div class="city-article-actions"><button data-city-share="${escapeHtml(x.id)}">${icon('share',17)} Share</button>${mapUrl?`<button data-city-map="${escapeHtml(x.id)}">${icon('pin',17)} Directions</button>`:''}${x.type==='contacts'&&phone?`<button data-city-call="${escapeHtml(x.id)}">${icon('phone',17)} Call</button>`:''}</div>${x.area||x.placeAddress?`<div class="city-fact">${icon('pin',19)} ${escapeHtml([x.placeAddress,x.area].filter(Boolean).join(' · '))}</div>`:''}${x.eventDate?`<div class="city-fact">${icon('calendar',19)} ${escapeHtml(x.eventDate)}</div>`:''}<div class="city-prose">${escapeHtml(x.body||'').replace(/\r?\n/g,'<br>')}</div>${gallery.length>1?`<h3>Photo Gallery</h3><div class="city-gallery">${gallery.map(img=>`<img src="${escapeHtml(img)}" loading="lazy" alt="${escapeHtml(x.title)}">`).join('')}</div>`:''}<p class="city-published">Published by BARAN PRIDE Admin${cityDate(x.publishedAt)?' · '+cityDate(x.publishedAt):''}</p></article></div>`}
// V3: New sections in the side menu only; original business homepage is untouched.
const bloodGroups=['All','A+','A-','B+','B-','AB+','AB-','O+','O-'];
const validPhone=(v)=>/^[6-9]\d{9}$/.test(String(v||'').replace(/[^0-9]/g,''));
const dialDirect=(p)=>{const val=String(p||'').replace(/[^+\d]/g,'');if(!val)return toast('Contact number not available');if(!native('dial',val))openUrl('tel:'+val)};
async function openDonors(){closeDrawer();S.donorError='';S.donors=[];S.donorFilter='All';go('donors');if(!C.enabled)return;try{S.donors=await C.publicDonors()}catch(e){S.donorError='Unable to load donors. Check internet.'}if(S.page==='donors')render()}
async function openProperties(){closeDrawer();S.properties=[];S.propertyError='';S.helpline='7737325205';go('properties');if(!C.enabled)return;try{const [items,number]=await Promise.all([C.publicProperties(),C.customerCare()]);S.properties=items;S.helpline=number}catch(e){S.propertyError='Unable to load properties. Check internet.'}if(S.page==='properties')render()}
function donorPage(){const group=S.donorFilter;const entries=S.donors.filter(d=>group==='All'||d.bloodGroup===group);return `<div class="screen city-page">${head('Blood Donors')}<div class="city-heading">${icon('drop',32)}<div><h1>Blood Donors</h1><p>स्वैच्छिक रक्तदाताओं की सूची</p></div></div><div class="special-note">केवल सहमति देने वाले रक्तदाताओं के फोन नंबर दिखते हैं। रक्त की उपलब्धता की गारंटी नहीं है। आपात स्थिति में अस्पताल या ब्लड बैंक से संपर्क करें।</div><div class="special-filter">${bloodGroups.map(g=>`<button class="${group===g?'selected':''}" data-blood-filter="${escapeHtml(g)}">${escapeHtml(g)}</button>`).join('')}</div>${S.donorError?`<div class="city-message">${escapeHtml(S.donorError)}</div>`:entries.length?entries.map(d=>`<article class="blood-card"><span class="blood-pill">${escapeHtml(d.bloodGroup)}</span><div class="blood-card-text"><strong>${escapeHtml(maskBloodDonorName(d.name))}</strong><small>${escapeHtml(d.area||'Baran')} · Voluntary Donor</small><p>${escapeHtml(d.phone)}</p></div><button data-blood-call="${escapeHtml(d.id)}" aria-label="Call ${escapeHtml(maskBloodDonorName(d.name))}">${icon('phone',18)} Call</button></article>`).join(''):`<div class="city-message">इस ग्रुप में फिलहाल कोई सत्यापित रक्तदाता उपलब्ध नहीं है।<br><small>Admin से सूची अपडेट की जाएगी।</small></div>`}<p class="fine-print">प्रकाशित नंबर स्वैच्छिक सार्वजनिक सहमति पर आधारित हैं। गलत नंबर या सूची हटाने के लिए BARAN PRIDE Admin से संपर्क करें।</p></div>`}
function propertiesPage(){return `<div class="screen city-page">${head('Sell Property')}<div class="city-heading">${icon('property',31)}<div><h1>Property in Baran</h1><p>प्रॉपर्टी देखें या बेचने के लिए भेजें</p></div></div><div class="special-note">प्रॉपर्टी मालिक का <b>नाम हमेशा निजी</b> रहेगा। फोन नंबर दिखाने का फैसला सिर्फ BARAN PRIDE Admin करेगा। डिफॉल्ट संपर्क Customer Care <b>7737325205</b> है; मालिक की अनुमति मिलने पर Admin उसका नंबर दिखा सकता है।</div><button class="primary-btn" data-go="propertySubmit">${icon('plus',18)} List Your Property for Sale</button><h2 class="block-title">Available Properties</h2>${S.propertyError?`<div class="city-message">${escapeHtml(S.propertyError)}</div>`:S.properties.length?S.properties.map(x=>`<article class="property-card"><div class="property-banner">${icon('property',29)}<span>${escapeHtml(x.propertyType||'Property')}</span></div><div class="property-body"><h3>${escapeHtml(x.propertyType||'Property for Sale')} · ${escapeHtml(x.area||'Baran')}</h3><p>Area: ${escapeHtml(x.area||'Baran')}${x.size?' · Size: '+escapeHtml(x.size):''}</p>${x.askingPrice?`<strong class="property-price">₹${Number(x.askingPrice).toLocaleString('en-IN')}</strong>`:''}${x.description?`<p>${escapeHtml(x.description)}</p>`:''}<div class="property-contact-line"><b>${x.contactMode==='owner'&&validPhone(x.publicContactPhone)?'Owner Contact':'Customer Care'}:</b> ${escapeHtml(x.contactMode==='owner'&&validPhone(x.publicContactPhone)?x.publicContactPhone:S.helpline)}</div><button class="primary-btn" data-property-call="${escapeHtml(x.id)}">${icon('phone',18)} ${x.contactMode==='owner'&&validPhone(x.publicContactPhone)?'Call Property Owner':'Call Customer Care'}</button></div></article>`).join(''):'<div class="city-message">अभी कोई Approved Property नहीं है।<br><small>नए विज्ञापन Admin Approval के बाद दिखेंगे।</small></div>'}${S.helpline?`<button class="secondary-btn" data-customer-care>${icon('phone',18)} Customer Care: ${escapeHtml(S.helpline)}</button>`:'<div class="form-note">Customer Care नंबर अभी Admin द्वारा सेट नहीं किया गया है।</div>'}</div>`}
function propertySubmitPage(){if(C.enabled&&!C.user){S.afterAuth='propertySubmit';return auth()}return `<div class="screen city-page">${head('Sell Your Property')}<h1 class="page-title">Property Sale Request</h1><p class="intro">प्रॉपर्टी की जानकारी भरें। Owner Name और Mobile केवल Admin को दिखाई देंगे।</p>${!C.enabled?banner():''}<form id="property-request-form" class="form-card"><div class="field"><label>Owner Name * (PRIVATE)</label><input name="ownerName" required minlength="3" maxlength="100" placeholder="Property owner name"></div><div class="field"><label>Owner Mobile Number * (PRIVATE)</label><input name="ownerPhone" type="tel" inputmode="numeric" required maxlength="10" pattern="[6-9][0-9]{9}" placeholder="10-digit number"></div><div class="fieldrow"><div class="field"><label>Property Type *</label><select name="propertyType" required><option value="">Select Type</option>${['Plot','House','Flat','Shop','Land','Commercial Property','Other'].map(x=>`<option>${x}</option>`).join('')}</select></div><div class="field"><label>Area / Locality *</label><input name="area" required maxlength="100" placeholder="e.g. Kota Road"></div></div><div class="fieldrow"><div class="field"><label>Property Size</label><input name="size" maxlength="60" placeholder="e.g. 1200 sq ft"></div><div class="field"><label>Expected Price ₹</label><input type="number" min="1" max="1000000000" step="1" name="askingPrice" placeholder="Optional"></div></div><div class="field"><label>Property Details</label><textarea name="description" maxlength="900" placeholder="Rooms, facilities, property features (do not include names or phone numbers)"></textarea></div><label class="special-consent"><input type="checkbox" name="confirmed" required> मैं मालिक हूँ या अधिकृत प्रतिनिधि हूँ। मेरा नाम और मोबाइल Admin सत्यापन के लिए दिया गया है।</label><label class="special-consent"><input type="checkbox" name="publicPhoneConsent"> मैं स्पष्ट सहमति देता/देती हूँ कि BARAN PRIDE Admin चाहे तो मेरा मोबाइल नंबर ऐप पर सार्वजनिक कर सकता है। यह विकल्प वैकल्पिक है; नंबर दिखाने का अंतिम निर्णय सिर्फ Admin करेगा।</label><div class="form-note">आपका नाम हमेशा छिपा रहेगा। डिफॉल्ट नंबर Customer Care 7737325205 होगा। अगर आपने ऊपर सार्वजनिक नंबर की अनुमति दी है, तब भी केवल Admin ही नंबर दिखाने का फैसला करेगा। अनुमति वापस लेने के लिए Customer Care से संपर्क करें।</div><button type="submit" class="primary-btn">${icon('check',18)} Submit to Admin</button></form></div>`}
async function submitProperty(f){const fd=new FormData(f);const data={ownerName:String(fd.get('ownerName')||'').trim(),ownerPhone:String(fd.get('ownerPhone')||'').trim(),propertyType:String(fd.get('propertyType')||'').trim(),area:String(fd.get('area')||'').trim(),size:String(fd.get('size')||'').trim(),askingPrice:Number(fd.get('askingPrice')||0),description:String(fd.get('description')||'').trim(),publicPhoneConsent:fd.get('publicPhoneConsent')==='on'};if(!validPhone(data.ownerPhone)||data.ownerName.length<3||!data.area||!data.propertyType||fd.get('confirmed')!=='on')return toast('Please complete all required fields');const btn=f.querySelector('button[type=submit]');btn.disabled=true;try{if(C.enabled){if(!C.user)throw Error('Please sign in first');await C.submitProperty(data);toast('Property request sent for Admin approval')}else toast('Demo only: connect Firebase to submit a real request');openProperties()}catch(err){toast('Unable to submit: '+err.message);btn.disabled=false}}
function cityGoBack(){if(S.page==='cityDetail'){go(S.cityBackTarget||'cityList');return true}if(S.page==='cityNews'){go('home');return true}if(S.page==='cityList'){go('home');return true}return false}
function cityShare(id){const x=S.cityItems.find(o=>o.id===id&&o.status==='published');if(!x)return;const msg=x.title+' — BARAN PRIDE\n'+(x.summary||'');if(native('shareText',msg))return;if(navigator.share)navigator.share({title:x.title,text:msg}).catch(()=>{});else if(navigator.clipboard)navigator.clipboard.writeText(msg).then(()=>toast('Information copied'))}

function render(){const pages={home,explore,allCategories:allCategoriesPage,detail,saved,owner,add:addForm,auth,profile,cityList,cityNews:cityNewsList,cityDetail,donors:donorPage,properties:propertiesPage,propertySubmit:propertySubmitPage};const fn=pages[S.page]||home;$('#app').innerHTML=fn()+bottom();startHomeSlides();window.scrollTo(0,0)}
function go(page){closeDrawer();if(page==='add')S.editingId=null;if(page==='explore'&&S.page!=='explore'&&S.page!=='home'){}S.page=page;render()}
async function refresh(){if(C.enabled){try{
 const [pub,own,adminCategories,homeContent]=await Promise.all([
  C.approved(),C.user?C.owned():Promise.resolve([]),C.publicCategories().catch(()=>[]),C.publicHomepageCity().catch(e=>{console.warn('Homepage content could not load',e);return []})
 ]);
 S.businesses=pub.map(x=>({...x,cover:x.cover||'img/restaurant.jpg'}));
 S.owned=own;S.customCategories=adminCategories;S.homeCityItems=homeContent;
 }catch(e){console.warn(e);toast('Could not load listings. Check internet.')}}else{
 S.businesses=[...DEMO,...cacheGet('baran_demo_approved',[])];
 S.owned=cacheGet('baran_demo_owned',[]);S.customCategories=[];S.homeCityItems=[];
 }render()}
async function onAuthSubmit(f){if(!C.enabled)return toast('Firebase settings not configured');let fd=new FormData(f),btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.innerHTML='<span class="loader"></span> Please wait';try{if(S.authTab==='signup')await C.signUp(fd.get('email').trim(),fd.get('password'),fd.get('name').trim());else await C.signIn(fd.get('email').trim(),fd.get('password'));toast('Signed in successfully');await refresh();go(S.afterAuth||'owner')}catch(e){toast(e.message.replace('Firebase: ','').slice(0,105));btn.disabled=false;render()}}
async function onBusinessSubmit(f){const fd=new FormData(f),data={};for(const k of ['name','category','area','address','phone','whatsapp','description','hours'])data[k]=String(fd.get(k)||'').trim();if(!/^[0-9+ -]{10,15}$/.test(data.phone))return toast('Please enter a valid phone number');const files=[...f.querySelector('[name=photos]')?.files||[]];if(files.length>5)return toast('Maximum 5 photos are allowed');if(files.some(x=>x.size>5*1024*1024))return toast('Each photo must be 5 MB or less');const btn=f.querySelector('button[type=submit]');btn.disabled=true;btn.innerHTML='<span class="loader"></span> Saving...';try{
 if(S.editingId){if(C.enabled)await C.requestEdit(S.editingId,data);else {let own=cacheGet('baran_demo_owned',[]);const idx=own.findIndex(b=>b.id===S.editingId);if(idx>=0){own[idx].pendingChange=data;localStorage.setItem('baran_demo_owned',JSON.stringify(own))}}toast('Change request sent for approval');}
 else if(C.enabled){await C.register(data,files);toast('Submitted! Awaiting admin approval');}
 else{let own=cacheGet('baran_demo_owned',[]);own.unshift({...data,id:'local-'+Date.now(),status:'pending',plan:'free',planStatus:'inactive',paymentStatus:'unpaid',cover:'img/restaurant.jpg',demo:true});localStorage.setItem('baran_demo_owned',JSON.stringify(own));toast('Demo saved on this device (not sent to admin)');}
 S.editingId=null;await refresh();go('owner');
 }catch(e){toast('Could not submit: '+e.message.slice(0,75));btn.disabled=false;btn.textContent='Try Again'}}
$('#app').addEventListener('click',async e=>{
 const button=e.target.closest('button');if(!button)return;
 if(button.hasAttribute('data-menu-open'))return openDrawer();
 if(button.hasAttribute('data-menu-close'))return closeDrawer();
 if(button.hasAttribute('data-city-type'))return openCity(button.dataset.cityType);
 if(button.dataset.special==='donors')return openDonors();
 if(button.dataset.special==='properties')return openProperties();
 if(button.hasAttribute('data-blood-filter')){S.donorFilter=button.dataset.bloodFilter;return render()}
 if(button.hasAttribute('data-blood-call')){const d=S.donors.find(x=>x.id===button.dataset.bloodCall&&x.publicConsent===true&&x.status==='published');if(d)return dialDirect(d.phone);return}
 if(button.dataset.propertyCall){const item=S.properties.find(p=>p.id===button.dataset.propertyCall);if(!item)return toast('Property is not available');const number=item.contactMode==='owner'&&validPhone(item.publicContactPhone)?item.publicContactPhone:S.helpline;return dialDirect(number)}
 if(button.hasAttribute('data-customer-care'))return S.helpline?dialDirect(S.helpline):toast('Customer Care number not configured');
 if(button.hasAttribute('data-city-retry'))return openCity(S.cityType);
 if(button.hasAttribute('data-home-viewall'))return openHomeCityList(button.dataset.homeViewall);
 if(button.hasAttribute('data-home-detail'))return homeCityDetail(button.dataset.homeDetail);
 if(button.hasAttribute('data-home-slide')){const slider=button.closest('[data-home-carousel]');if(slider)return displayHomeSlide(slider,(S.homeSlidePositions[slider.dataset.homeCarousel]||0)+Number(button.dataset.homeSlide));return}
 if(button.hasAttribute('data-home-dot')){const slider=button.closest('.home-city-block')?.querySelector('[data-home-carousel]');if(slider)return displayHomeSlide(slider,Number(button.dataset.homeDot));return}
 if(button.hasAttribute('data-city-detail')){const x=S.cityItems.find(o=>o.id===button.dataset.cityDetail);if(x)S.cityType=x.type;S.cityId=button.dataset.cityDetail;S.cityBackTarget=S.page==='cityNews'?'cityNews':'cityList';return go('cityDetail')}
 if(button.hasAttribute('data-city-share'))return cityShare(button.dataset.cityShare);
 if(button.hasAttribute('data-city-map')){const x=S.cityItems.find(i=>i.id===button.dataset.cityMap);return x&&openUrl(safeHttps(x.mapUrl))}
 if(button.hasAttribute('data-city-call')){const x=S.cityItems.find(i=>i.id===button.dataset.cityCall);if(x&&x.phone){const ph=String(x.phone).replace(/[^0-9+]/g,'');if(!native('dial',ph))openUrl('tel:'+ph)}return}
 if(button.hasAttribute('data-go'))return button.dataset.go==='properties'?openProperties():go(button.dataset.go);
 if(button.hasAttribute('data-back'))return cityGoBack()||(S.page==='explore'&&S.returnToCategories?(S.returnToCategories=false,go('allCategories')):go(S.page==='propertySubmit'?'properties':'home'));
 if(button.hasAttribute('data-all-category')){S.category=button.dataset.allCategory;S.query='';S.returnToCategories=true;return go('explore')}
 if(button.hasAttribute('data-category')){
  const category=button.dataset.category;
  if(category==='More'){S.categorySearch='';S.returnToCategories=false;return go('allCategories')}
  S.category=category;S.query='';S.returnToCategories=false;return go('explore');
 }
 if(button.hasAttribute('data-detail')){S.detail=button.dataset.detail;return go('detail')}
 if(button.hasAttribute('data-save'))return saveToggle(button.dataset.save);
 if(button.hasAttribute('data-call'))return callBusiness(button.dataset.call);
 if(button.hasAttribute('data-wa'))return whatsapp(button.dataset.wa);
 if(button.hasAttribute('data-map'))return directions(button.dataset.map);
 if(button.hasAttribute('data-share'))return share(button.dataset.share);
 if(button.hasAttribute('data-edit')){S.editingId=button.dataset.edit;S.page='add';return render()}
 if(button.hasAttribute('data-auth-tab')){S.authTab=button.dataset.authTab;return render()}
 if(button.dataset.action==='notifications')return toast('You have no new notifications');
 if(button.dataset.action==='logout'){await C.signOut();S.owned=[];toast('Signed out');go('profile')}
});
$('#app').addEventListener('submit',e=>{
 if(e.target.id==='hero-form'){e.preventDefault();S.category='All';S.query=($('#hero-q')?.value||'').trim();go('explore')}
 else if(e.target.id==='business-form'){e.preventDefault();onBusinessSubmit(e.target)}
 else if(e.target.id==='auth-form'){e.preventDefault();onAuthSubmit(e.target)}
 else if(e.target.id==='property-request-form'){e.preventDefault();submitProperty(e.target)}
});
let debounce;$('#app').addEventListener('input',e=>{
 if(e.target.id==='all-categories-search'){
  S.categorySearch=e.target.value;
  let visible=0;
  document.querySelectorAll('.all-category-tile').forEach(tile=>{
   const show=(tile.dataset.categorySearch||'').includes(S.categorySearch.trim().toLocaleLowerCase());
   tile.classList.toggle('hidden',!show);if(show)visible++;
  });
  const count=$('#categories-result-count');if(count)count.textContent=visible+' categories';
  const empty=$('#category-search-empty');if(empty)empty.classList.toggle('hidden',visible!==0);
  return;
 }
 if(e.target.id==='city-search'){S.cityQuery=e.target.value;let n=0;document.querySelectorAll('.city-list-card').forEach(el=>{let show=(el.dataset.citySearch||'').includes(S.cityQuery.trim().toLowerCase());el.classList.toggle('hidden',!show);if(show)n++});const msg=$('#city-no-match');if(msg)msg.classList.toggle('hidden',n!==0);return}if(e.target.id==='explore-q'){const {selectionStart}=e.target;S.query=e.target.value;clearTimeout(debounce);debounce=setTimeout(()=>{let inp=$('#explore-q');const v=inp?.value;render();inp=$('#explore-q');if(inp){inp.focus();inp.value=v;inp.setSelectionRange(selectionStart,selectionStart)}},200)}});
window.BaranApp={go,render,refresh,goBack(){if(S.drawer){closeDrawer();return true}if(cityGoBack())return true;if(S.page==='propertySubmit'){go('properties');return true}if(S.page==='explore'&&S.returnToCategories){S.returnToCategories=false;go('allCategories');return true}if(S.page==='home')return false;go(S.page==='detail'?'explore':'home');return true}};
C.onUserChange=async user=>{if(C.enabled){C.user=user;await refresh()}};
render();C.init().then(()=>refresh());
})();
